<?php
session_start();
require_once 'config.php';
if (!isset($_SESSION['user_phone'])) {
    header('Location: index.php');
    exit;
}
$phone = $_SESSION['user_phone'];

// ==========================================
// EXTRA FIRST DEPOSIT BONUS - EXACT AMOUNT
// ==========================================

$deposits = firebase_read("deposits/" . $phone) ?? [];
$max_single_deposit = 0;
if (is_array($deposits)) {
    foreach ($deposits as $dep) {
        $st = $dep['status'] ?? '';
        if ($st === 'Complete' || $st === 'Completed') {
            $amt = floatval($dep['amount'] ?? 0);
            if ($amt > $max_single_deposit) {
                $max_single_deposit = $amt; // Highest single deposit count hoga
            }
        }
    }
}

$userData = firebase_read("users/" . $phone) ?? [];
$claimed_bonuses = $userData['claimed_first_dep_bonuses'] ?? [];
$has_claimed_any = !empty($claimed_bonuses); // True if claimed at least once

// Determine only highest eligible tier
$eligible_tier = 0;
if ($max_single_deposit >= 5000) $eligible_tier = 5000;
elseif ($max_single_deposit >= 1000) $eligible_tier = 1000;
elseif ($max_single_deposit >= 500) $eligible_tier = 500;
elseif ($max_single_deposit >= 300) $eligible_tier = 300;

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'claim_dep_bonus') {
    header('Content-Type: application/json');
    $tier = intval($_POST['tier']);
    $bonuses = [300 => 48, 500 => 108, 1000 => 188, 5000 => 488];

    if (!array_key_exists($tier, $bonuses)) {
        echo json_encode(['success' => false, 'message' => 'Invalid tier']);
        exit;
    }
    if ($has_claimed_any) {
        echo json_encode(['success' => false, 'message' => 'First deposit bonus already claimed!']);
        exit;
    }
    if ($eligible_tier !== $tier) {
        echo json_encode(['success' => false, 'message' => 'Deposit requirement not met for this tier']);
        exit;
    }

    $bonus_amount = $bonuses[$tier];
    $userData['balance'] = ($userData['balance'] ?? 0) + $bonus_amount;
    $claimed_bonuses[] = $tier;
    $userData['claimed_first_dep_bonuses'] = $claimed_bonuses;
    firebase_write("users/" . $phone, $userData);

    echo json_encode(['success' => true, 'message' => 'Bonus ₹'.$bonus_amount.' claimed successfully!']);
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
<title>3win - Dashboard</title>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800;900&display=swap" rel="stylesheet">
<link href="https://fonts.googleapis.com/icon?family=Material+Icons+Round" rel="stylesheet">
<style>
* { margin: 0; padding: 0; box-sizing: border-box; font-family: 'Inter', sans-serif; -webkit-tap-highlight-color: transparent; }
html { scroll-behavior: smooth; }
body { background-color: #f2f5fa; color: #333; overflow-x: hidden; padding-bottom: 90px; }
.app-container { max-width: 480px; margin: 0 auto; background: #f2f5fa; min-height: 100vh; position: relative; box-shadow: 0 0 20px rgba(0,0,0,0.05); }
.top-header { display: flex; justify-content: space-between; align-items: center; padding: 12px 16px; background: #4781ff; color: white; position: sticky; top: 0; z-index: 100; box-shadow: 0 2px 10px rgba(71,129,255,0.2); }
.brand { font-size: 22px; font-weight: 900; display: flex; align-items: center; gap: 6px; font-style: italic; letter-spacing: 0.5px; }
.header-actions { display: flex; gap: 16px; align-items: center; }
.header-actions a { color: white; text-decoration: none; display: flex; }
.banner-wrap { padding: 12px 16px; }
.promo-banner { width: 100%; height: 160px; border-radius: 12px; background: linear-gradient(135deg, #0a1f44 0%, #1a3c7a 100%); color: white; display: flex; flex-direction: column; justify-content: center; padding: 20px; position: relative; overflow: hidden; box-shadow: 0 4px 10px rgba(0,0,0,0.1); }
.promo-banner h2 { font-size: 26px; font-weight: 900; color: #ffda44; line-height: 1.1; margin-bottom: 5px; text-shadow: 2px 2px 4px rgba(0,0,0,0.5); }
.promo-banner p { font-size: 13px; font-weight: 600; text-transform: uppercase; letter-spacing: 1px; color: #fff; }
.notice-bar { background: white; margin: 0 16px 16px; padding: 10px 12px; border-radius: 30px; display: flex; align-items: center; gap: 10px; box-shadow: 0 2px 8px rgba(0,0,0,0.04); }
.notice-bar .material-icons-round { color: #4781ff; font-size: 20px; }
.notice-bar marquee { flex: 1; font-size: 13px; font-weight: 600; color: #555; }
.notice-bar .detail-btn { background: #f0f4ff; color: #4781ff; border: none; padding: 4px 12px; border-radius: 12px; font-size: 12px; font-weight: 700; display: flex; align-items: center; gap: 2px; }
.section-header { display: flex; align-items: center; gap: 8px; padding: 0 16px; margin: 20px 0 15px; font-size: 18px; font-weight: 800; color: #111; }
.section-header::before { content: ''; display: inline-block; width: 4px; height: 18px; background: #4781ff; border-radius: 4px; }
.games-grid { display: grid; grid-template-columns: repeat(3, 1fr); gap: 12px; padding: 0 16px 10px; }
.game-card { border-radius: 14px; overflow: hidden; position: relative; text-decoration: none; display: flex; flex-direction: column; box-shadow: 0 4px 10px rgba(0,0,0,0.08); transition: transform .15s; background: white; }
.game-card:active { transform: scale(.95); }
.game-card img { width: 100%; height: 110px; object-fit: cover; display: block; border-radius: 14px 14px 0 0; }
.game-card .gname { padding: 10px 4px; text-align: center; color: #fff; font-weight: 800; font-size: 12px; letter-spacing: .5px; }
.gc-1 { background: linear-gradient(180deg,#3b82f6,#1d4ed8); } .gc-1 .gname { background: #1e40af; }
.gc-2 { background: linear-gradient(180deg,#6366f1,#4338ca); } .gc-2 .gname { background: #3730a3; }
.gc-3 { background: linear-gradient(180deg,#ef4444,#b91c1c); } .gc-3 .gname { background: #991b1b; }
.gc-4 { background: linear-gradient(180deg,#8b5cf6,#6d28d9); } .gc-4 .gname { background: #5b21b6; }
.gc-5 { background: linear-gradient(180deg,#10b981,#047857); } .gc-5 .gname { background: #065f46; }
.gc-6 { background: linear-gradient(180deg,#f59e0b,#b45309); } .gc-6 .gname { background: #92400e; }
.gc-7 { background: linear-gradient(180deg,#ec4899,#be185d); } .gc-7 .gname { background: #9d174d; }
.gc-8 { background: linear-gradient(180deg,#14b8a6,#0f766e); } .gc-8 .gname { background: #047857; }
.list-games-container { display: flex; flex-direction: column; gap: 12px; padding: 0 16px 20px; }
.list-game-card { background: linear-gradient(90deg, #4781ff, #6b9aff); border-radius: 16px; padding: 16px 20px; display: flex; justify-content: space-between; align-items: center; text-decoration: none; color: white; position: relative; overflow: hidden; box-shadow: 0 4px 10px rgba(71,129,255,0.2); min-height: 105px; transition: transform 0.15s; }
.list-game-card:active { transform: scale(0.98); }
.lg-text { position: relative; z-index: 2; }
.lg-title { font-size: 22px; font-weight: 800; margin-bottom: 6px; text-shadow: 1px 1px 2px rgba(0,0,0,0.1); }
.lg-sub { font-size: 12px; font-weight: 600; opacity: 0.9; line-height: 1.4; }
.lg-img { position: absolute; right: 10px; top: 50%; transform: translateY(-50%); height: 85px; width: 85px; object-fit: contain; z-index: 1; filter: drop-shadow(0 4px 6px rgba(0,0,0,0.2)); }
.lg-img.aviator-img { border-radius: 50%; height: 75px; width: 75px; right: 15px; object-fit: cover; }
.winning-list { background: white; margin: 0 16px 20px; border-radius: 16px; padding: 10px; box-shadow: 0 4px 15px rgba(0,0,0,0.04); }
.winner-item { display: flex; align-items: center; justify-content: space-between; padding: 12px 10px; border-bottom: 1px solid #f2f5fa; }
.winner-item:last-child { border-bottom: none; }
.winner-left { display: flex; align-items: center; gap: 12px; }
.winner-left img { width: 44px; height: 44px; border-radius: 50%; box-shadow: 0 2px 6px rgba(0,0,0,0.1); border: 2px solid #fff; }
.winner-left span { font-size: 14px; font-weight: 700; color: #222; }
.winner-right { display: flex; align-items: center; gap: 10px; }
.winner-img { width: 60px; height: 35px; border-radius: 6px; object-fit: cover; }
.winner-amount { text-align: right; }
.winner-amount h4 { font-size: 14px; font-weight: 800; color: #111; }
.winner-amount p { font-size: 11px; color: #888; font-weight: 600; margin-top: 2px; }
.podium-section { padding: 0 16px 20px; }
.podium-container { display: flex; align-items: flex-end; justify-content: center; gap: 8px; margin-bottom: 16px; padding-top: 30px; }
.podium-col { display: flex; flex-direction: column; align-items: center; width: 31%; position: relative; }
.podium-avatar { width: 65px; height: 65px; border-radius: 50%; border: 3px solid white; box-shadow: 0 4px 10px rgba(0,0,0,0.15); z-index: 2; position: relative; }
.podium-crown { position: absolute; top: -35px; width: 45px; z-index: 3; left: 50%; transform: translateX(-50%); }
.podium-box { width: 100%; border-radius: 12px 12px 0 0; display: flex; flex-direction: column; align-items: center; justify-content: center; padding: 15px 5px; margin-top: -30px; box-shadow: 0 4px 10px rgba(0,0,0,0.1); position: relative; }
.rank-badge { background: rgba(255,255,255,0.3); color: white; font-size: 11px; font-weight: 800; padding: 2px 12px; border-radius: 10px; margin-bottom: 8px; margin-top: 15px; }
.podium-user { color: white; font-size: 12px; font-weight: 700; margin-bottom: 4px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; max-width: 90%; }
.podium-amt { background: rgba(255,255,255,0.25); color: white; font-size: 11px; font-weight: 800; padding: 4px 8px; border-radius: 15px; width: 90%; text-align: center; }
.rank-1 .podium-avatar { width: 80px; height: 80px; border: 4px solid #fff; }
.rank-1 .podium-box { height: 160px; background: linear-gradient(180deg, #ff6b6b, #ff4757); }
.rank-2 .podium-box { height: 130px; background: linear-gradient(180deg, #a4b0be, #747d8c); }
.rank-3 .podium-box { height: 110px; background: linear-gradient(180deg, #ffa502, #eccc68); }
.lb-list { background: white; border-radius: 16px; padding: 5px 10px; box-shadow: 0 4px 15px rgba(0,0,0,0.04); }
.lb-item { display: flex; align-items: center; padding: 12px 5px; border-bottom: 1px solid #f2f5fa; }
.lb-item:last-child { border-bottom: none; }
.lb-rank { font-size: 18px; font-weight: 800; color: #888; width: 30px; text-align: center; }
.lb-avatar { width: 40px; height: 40px; border-radius: 50%; margin: 0 12px; border: 1px solid #eee; }
.lb-name { flex: 1; font-size: 14px; font-weight: 700; color: #333; }
.lb-amt { background: #4781ff; color: white; padding: 6px 14px; border-radius: 20px; font-size: 13px; font-weight: 800; }
.floating-actions { position: fixed; right: 12px; bottom: 130px; display: flex; flex-direction: column; gap: 15px; z-index: 50; }
.float-icon { width: 50px; height: 50px; border-radius: 50%; display: flex; align-items: center; justify-content: center; box-shadow: 0 4px 15px rgba(0,0,0,0.2); transition: transform 0.2s; background: white; overflow: hidden; border: 2px solid #fff; }
.float-icon:active { transform: scale(0.9); }
.float-icon img { width: 100%; height: 100%; object-fit: cover; }
.add-desktop { position: fixed; bottom: 85px; left: 50%; transform: translateX(-50%); background: #4781ff; color: white; padding: 10px 24px; border-radius: 30px; font-size: 15px; font-weight: 700; display: flex; align-items: center; gap: 8px; box-shadow: 0 4px 15px rgba(71,129,255,0.4); z-index: 49; text-decoration: none; }

/* UNIVERSAL BOTTOM NAV (Fix across all pages) */
.bottom-nav { position: fixed; bottom: 0; width: 100%; max-width: 480px; left: 50%; transform: translateX(-50%); background: white; display: flex; justify-content: space-around; align-items: flex-end; padding: 10px 0 12px; box-shadow: 0 -4px 20px rgba(0,0,0,0.06); z-index: 100; border-radius: 20px 20px 0 0; }
.nav-item { display: flex; flex-direction: column; align-items: center; color: #999; text-decoration: none; font-size: 11px; font-weight: 700; gap: 4px; flex: 1; }
.nav-item .material-icons-round { font-size: 26px; }
.nav-item.active { color: #4781ff; }
.nav-center { flex: 1; display: flex; flex-direction: column; align-items: center; text-decoration: none; color: #4781ff; font-size: 12px; font-weight: 800; position: relative; margin-top: -30px; gap: 2px; }
.nav-center-bg { background: white; width: 68px; height: 68px; border-radius: 50%; display: flex; align-items: center; justify-content: center; box-shadow: 0 -4px 10px rgba(0,0,0,0.05); }
.nav-center-img { width: 58px; height: 58px; border-radius: 50%; object-fit: cover; box-shadow: 0 4px 10px rgba(255, 136, 0, 0.4); }

.animate-scroll { opacity: 0; transform: translateY(40px); transition: all 0.7s cubic-bezier(0.25, 0.8, 0.25, 1); }
.animate-scroll.visible { opacity: 1; transform: translateY(0); }
.toast { position: fixed; left: 50%; top: 14%; transform: translateX(-50%) scale(.8); background: #000c; color: #fff; padding: 12px 24px; border-radius: 26px; font-weight: 800; font-size: 14px; z-index: 200; opacity: 0; pointer-events: none; transition: .25s; }
.toast.show { opacity: 1; transform: translateX(-50%) scale(1); }

/* POPUP STYLES */
.modal-overlay { position: fixed; top: 0; left: 0; right: 0; bottom: 0; background: rgba(0, 0, 0, 0.75); display: none; align-items: center; justify-content: center; z-index: 9999; }
.modal-overlay.show { display: flex; animation: fadeIn 0.3s ease; }
@keyframes fadeIn { from { opacity: 0; } to { opacity: 1; } }
.p1-content { background: #fff; border-radius: 16px; width: 85%; max-width: 360px; overflow: hidden; text-align: center; box-shadow: 0 10px 30px rgba(0,0,0,0.5); transform: scale(0.9); transition: transform 0.3s; }
.modal-overlay.show .p1-content { transform: scale(1); }
.p1-header { background: #eef3ff; color: #4781ff; font-weight: 800; font-size: 16px; padding: 14px; display: flex; justify-content: center; align-items: center; border-bottom: 2px solid #e0e8fa; }
.p1-body { padding: 15px; }
.p1-body img { width: 100%; border-radius: 10px; }
.p1-footer { padding: 0 20px 20px; }
.p1-btn { background: #4781ff; color: #fff; border: none; padding: 12px 0; border-radius: 25px; width: 100%; font-size: 16px; font-weight: 800; cursor: pointer; transition: 0.2s; }
.p1-btn:active { transform: scale(0.95); }

.p2-wrapper { position: relative; width: 90%; max-width: 400px; display: flex; flex-direction: column; align-items: center; }
.p2-content { background: linear-gradient(180deg, #37336b 0%, #201e43 100%); width: 100%; border-radius: 16px; overflow: hidden; box-shadow: 0 10px 30px rgba(0,0,0,0.5); transform: scale(0.9); transition: transform 0.3s; position: relative; }
.modal-overlay.show .p2-content { transform: scale(1); }
.p2-header { text-align: center; padding: 20px 15px 15px; color: #fff; }
.p2-header h3 { font-size: 18px; font-weight: 700; margin-bottom: 5px; color: #fff; }
.p2-header p { font-size: 12px; color: #b7b5d3; }
.p2-list { padding: 0 15px 15px; max-height: 55vh; overflow-y: auto; }
.p2-item { background: #333160; border-radius: 12px; padding: 14px; margin-bottom: 12px; }
.p2-top { display: flex; justify-content: space-between; align-items: center; margin-bottom: 6px; }
.p2-title { color: #fff; font-size: 14px; font-weight: 600; display: flex; align-items: center; gap: 4px; }
.p2-title span { color: #e6a265; font-weight: 800; font-size: 15px; }
.p2-amt { color: #e6a265; font-size: 14px; font-weight: 700; }
.p2-desc { color: #b7b5d3; font-size: 11.5px; line-height: 1.4; margin-bottom: 12px; }
.p2-action { display: flex; justify-content: space-between; align-items: center; gap: 10px; }
.p2-progress { background: #16142c; flex: 1; height: 20px; border-radius: 10px; position: relative; overflow: hidden; display: flex; align-items: center; justify-content: center; }
.p2-prog-fill { background: #262447; position: absolute; left: 0; top: 0; bottom: 0; z-index: 1; transition: width 0.3s; }
.p2-prog-text { position: relative; z-index: 2; color: #fff; font-size: 11px; font-weight: 700; }
.p2-btn { border-radius: 8px; padding: 6px 18px; font-size: 13px; font-weight: 700; cursor: pointer; transition: 0.2s; white-space: nowrap; }
.p2-btn:active { transform: scale(0.95); }
.p2-btn.deposit { background: transparent; border: 1.5px solid #e6a265; color: #e6a265; }
.p2-btn.claim { background: linear-gradient(90deg, #e6a265, #d2803b); border: none; color: #fff; box-shadow: 0 2px 8px rgba(230,162,101,0.4); }
.p2-footer { padding: 10px 15px 15px; display: flex; justify-content: space-between; align-items: center; border-top: 1px solid rgba(255,255,255,0.05); }
.p2-check { display: flex; align-items: center; gap: 6px; color: #b7b5d3; font-size: 12px; cursor: pointer; user-select: none; }
.p2-check input { display: none; }
.p2-check .checkmark { width: 16px; height: 16px; border: 1.5px solid #b7b5d3; border-radius: 50%; display: inline-block; position: relative; }
.p2-check input:checked + .checkmark::after { content: ''; width: 8px; height: 8px; background: #e6a265; border-radius: 50%; position: absolute; top: 50%; left: 50%; transform: translate(-50%, -50%); }
.p2-act-btn { background: linear-gradient(90deg, #ff9d70, #e65893); color: #fff; border: none; padding: 6px 16px; border-radius: 15px; font-size: 13px; font-weight: 700; cursor: pointer; }
.p2-close-wrap { margin-top: 15px; display: flex; justify-content: center; }
.p2-close-btn { width: 36px; height: 36px; border-radius: 50%; background: transparent; border: 2px solid #fff; color: #fff; font-size: 16px; font-weight: bold; cursor: pointer; display: flex; align-items: center; justify-content: center; opacity: 0.8; transition: 0.2s; }
.p2-close-btn:active { transform: scale(0.9); }
</style>
</head>
<body>
<div class="app-container">
<!-- Top Header -->
<div class="top-header">
<div class="brand"><span class="material-icons-round">sports_esports</span> 3win</div>
<div class="header-actions">
<a href="download.php"><span class="material-icons-round" style="font-size:24px;">download</span></a>
</div>
</div>

<div class="banner-wrap animate-scroll">
<div class="promo-banner">
<h2>NEW WEEKLY<br>MISSIONS</h2>
<p>Claim Exclusive Chest Rewards</p>
<div style="font-size:32px; font-weight:900; color:#ffda44; margin-top:5px; text-shadow: 1px 1px 2px #000;">UP TO 499,999 RS</div>
</div>
</div>

<div class="notice-bar animate-scroll">
<span class="material-icons-round">volume_up</span>
<marquee>Welcome to 3win! Get the best gaming experience and instant withdrawals...</marquee>
<button class="detail-btn"><span class="material-icons-round" style="font-size:14px;">local_fire_department</span> Detail</button>
</div>

<div class="section-header animate-scroll">Mini games</div>
<div class="games-grid animate-scroll">
<a href="wingo.php" class="game-card gc-1"><img src="https://i.ibb.co/dskcSc8F/lotterycategory-20230710190121isq8.png"><div class="gname">WIN GO</div></a>
<a href="k3.php" class="game-card gc-2"><img src="https://i.ibb.co/nvqK5WK/lotterycategory-202307102058012cme.png"><div class="gname">K3</div></a>
<a href="aviator.php" class="game-card gc-3"><img src="https://i.ibb.co/pBSrcdtF/800.jpg"><div class="gname">AVIATOR</div></a>
<a href="go-rush.php" class="game-card gc-4"><img src="https://i.ibb.co/VWt47K8f/224.png"><div class="gname">GO RUSH</div></a>
<a href="pappu.php" class="game-card gc-5"><img src="https://i.ibb.co/XfT6n5S6/200.png"><div class="gname">PAPPU</div></a>
<a href="mines.php" class="game-card gc-6"><img src="https://i.ibb.co/gMvjq7VX/100.jpg"><div class="gname">MINES</div></a>
<a href="vortex.php" class="game-card gc-7"><img src="https://i.ibb.co/qLC6ZZ1x/124.png"><div class="gname">VORTEX</div></a>
<a href="moneycoming.php" class="game-card gc-8"><img src="https://i.ibb.co/bgxwVLLj/51-1.png"><div class="gname">MONEY COMING</div></a>
</div>

<div class="list-games-container animate-scroll">
    <a href="wingo.php" class="list-game-card">
        <div class="lg-text"><div class="lg-title">Win Go</div><div class="lg-sub">Guess Number<br>Green/Red/Violet to win</div></div>
        <img src="https://i.ibb.co/dskcSc8F/lotterycategory-20230710190121isq8.png" class="lg-img">
    </a>
    <a href="k3.php" class="list-game-card">
        <div class="lg-text"><div class="lg-title">K3</div><div class="lg-sub">Guess Number<br>Big/Small/Odd/Even</div></div>
        <img src="https://i.ibb.co/nvqK5WK/lotterycategory-202307102058012cme.png" class="lg-img">
    </a>
    <a href="aviator.php" class="list-game-card">
        <div class="lg-text"><div class="lg-title">Aviator</div><div class="lg-sub">Crash Game<br>Cash out before it flies</div></div>
        <img src="https://i.ibb.co/pBSrcdtF/800.jpg" class="lg-img aviator-img">
    </a>
</div>

<div class="section-header animate-scroll">Winning information</div>
<div class="winning-list animate-scroll">
<div class="winner-item"><div class="winner-left"><img src="https://i.ibb.co/n94NrJ3/1-Cz2mt-nl.png"><span>Mem***WZD</span></div><div class="winner-right"><img src="https://i.ibb.co/pBSrcdtF/800.jpg" class="winner-img"><div class="winner-amount"><h4>Receive ₹90.00</h4><p>Winning amount</p></div></div></div>
<div class="winner-item"><div class="winner-left"><img src="https://i.ibb.co/7NT8YtST/6-Bpt-Td-Cuy.png"><span>Mem***GYX</span></div><div class="winner-right"><img src="https://i.ibb.co/dskcSc8F/lotterycategory-20230710190121isq8.png" class="winner-img"><div class="winner-amount"><h4>Receive ₹12.00</h4><p>Winning amount</p></div></div></div>
<div class="winner-item"><div class="winner-left"><img src="https://i.ibb.co/bMdXnJHX/4-Fz-E5-Gsk-B.png"><span>Mem***NXY</span></div><div class="winner-right"><img src="https://i.ibb.co/nvqK5WK/lotterycategory-202307102058012cme.png" class="winner-img"><div class="winner-amount"><h4>Receive ₹18.00</h4><p>Winning amount</p></div></div></div>
</div>

<div class="section-header animate-scroll">Today's earnings chart</div>
<div class="podium-section animate-scroll">
<div class="podium-container">
    <div class="podium-col rank-2"><img src="https://i.ibb.co/bMdXnJHX/4-Fz-E5-Gsk-B.png" class="podium-avatar"><div class="podium-box"><span class="rank-badge">NO2</span><span class="podium-user">Ad***ii</span><span class="podium-amt">₹139M</span></div></div>
    <div class="podium-col rank-1"><img src="https://cdn-icons-png.flaticon.com/512/5777/5777598.png" class="podium-crown"><img src="https://i.ibb.co/n94NrJ3/1-Cz2mt-nl.png" class="podium-avatar"><div class="podium-box"><span class="rank-badge" style="color:#ff4757; background:white;">NO1</span><span class="podium-user">Mem***7IJ</span><span class="podium-amt" style="background:rgba(0,0,0,0.2);">₹362,913,047</span></div></div>
    <div class="podium-col rank-3"><img src="https://i.ibb.co/7NT8YtST/6-Bpt-Td-Cuy.png" class="podium-avatar"><div class="podium-box"><span class="rank-badge">NO3</span><span class="podium-user">Mem***5PS</span><span class="podium-amt">₹5,488,000</span></div></div>
</div>
<div class="lb-list">
    <div class="lb-item"><div class="lb-rank">4</div><img src="https://i.ibb.co/kVQkM2S4/2-Dz-Tt-Sg-I1.png" class="lb-avatar"><div class="lb-name">Mem***S8J</div><div class="lb-amt">₹2,016,840.00</div></div>
</div>
</div>

<div class="floating-actions">
<a href="#" class="float-icon"><img src="https://i.ibb.co/YYwGN9L/icon-sevice-BIWTN-c-L-1.png"></a>
<a href="#" class="float-icon"><img src="https://i.ibb.co/Z1FDw46L/Telegram-2019-Logo-svg.webp"></a>
</div>

<a href="download.php" class="add-desktop">
    <span class="material-icons-round" style="font-size:20px;">add_to_home_screen</span> Add to Desktop
</a>

<!-- FIXED BOTTOM NAVIGATION -->
<div class="bottom-nav">
<a href="dashboard.php" class="nav-item <?php echo (basename($_SERVER['PHP_SELF']) == 'dashboard.php') ? 'active' : ''; ?>">
<span class="material-icons-round">home</span>Home
</a>
<a href="activity.php" class="nav-item <?php echo (basename($_SERVER['PHP_SELF']) == 'activity.php') ? 'active' : ''; ?>">
<span class="material-icons-round">local_activity</span>Activity
</a>
<a href="spin.php" class="nav-center">
<div class="nav-center-bg">
<img src="https://i.ibb.co/KxgzgMNB/images.png" class="nav-center-img">
</div>
<span>Get ₹500</span>
</a>
<a href="promotion.php" class="nav-item <?php echo (basename($_SERVER['PHP_SELF']) == 'promotion.php') ? 'active' : ''; ?>">
<span class="material-icons-round">card_giftcard</span>Promotion
</a>
<a href="account.php" class="nav-item <?php echo (basename($_SERVER['PHP_SELF']) == 'account.php') ? 'active' : ''; ?>">
<span class="material-icons-round">person</span>Account
</a>
</div>

</div>
<div class="toast" id="toast"></div>

<!-- POPUP 1: RECHARGE BONUS -->
<div class="modal-overlay" id="popup1">
    <div class="p1-content">
        <div class="p1-header">🎁 RECHARGE BONUS UP 5% 🎁</div>
        <div class="p1-body"><img src="https://i.ibb.co/DDPTRDBS/file-000000007920820bbbcf570bf3bdd93d.png"></div>
        <div class="p1-footer"><button class="p1-btn" id="closeP1">Confirm</button></div>
    </div>
</div>

<!-- POPUP 2: EXTRA FIRST DEPOSIT BONUS (Only if NOT claimed yet) -->
<?php if(!$has_claimed_any): ?>
<?php
function renderBonusItem($tier, $bonus, $max_single_deposit, $eligible_tier) {
    // Only the highest eligible tier is 'ready', all others remain Deposit
    $is_ready = ($eligible_tier === $tier);
    // Show progress maxed out if eligible, else show actual max
    $progress = min($max_single_deposit, $tier);
    $percent = min(($progress / $tier) * 100, 100);
?>
<div class="p2-item">
    <div class="p2-top">
        <span class="p2-title">First deposit <span><?php echo $tier; ?></span></span>
        <span class="p2-amt">+ ₹<?php echo number_format($bonus, 2); ?></span>
    </div>
    <div class="p2-desc">Deposit <?php echo $tier; ?> and you will receive <?php echo $bonus; ?> bonus</div>
    <div class="p2-action">
        <div class="p2-progress">
            <div class="p2-prog-fill" style="width: <?php echo $percent; ?>%;"></div>
            <div class="p2-prog-text"><?php echo number_format($progress, 0); ?>/<?php echo $tier; ?></div>
        </div>
        <?php if($is_ready): ?>
            <button class="p2-btn claim" onclick="claimBonus(<?php echo $tier; ?>)">Claim</button>
        <?php else: ?>
            <button class="p2-btn deposit" onclick="window.location.href='deposit.php'">Deposit</button>
        <?php endif; ?>
    </div>
</div>
<?php } ?>

<div class="modal-overlay" id="popup2">
    <div class="p2-wrapper">
        <div class="p2-content">
            <div class="p2-header">
                <h3>Extra first deposit bonus</h3>
                <p>Each account can only receive rewards once</p>
            </div>
            <div class="p2-list">
                <?php 
                    renderBonusItem(300, 48, $max_single_deposit, $eligible_tier); 
                    renderBonusItem(500, 108, $max_single_deposit, $eligible_tier); 
                    renderBonusItem(1000, 188, $max_single_deposit, $eligible_tier); 
                    renderBonusItem(5000, 488, $max_single_deposit, $eligible_tier); 
                ?>
            </div>
            <div class="p2-footer">
                <label class="p2-check">
                    <input type="checkbox" id="noReminder"><span class="checkmark"></span> No more reminders today
                </label>
                <button class="p2-act-btn" onclick="window.location.href='activity.php'">Activity</button>
            </div>
        </div>
        <div class="p2-close-wrap"><button class="p2-close-btn" id="closeP2">✕</button></div>
    </div>
</div>
<?php endif; ?>

<script>
document.addEventListener("DOMContentLoaded", function() {
    const observer = new IntersectionObserver((entries) => { entries.forEach(entry => { if (entry.isIntersecting) { entry.target.classList.add('visible'); } }); }, { threshold: 0.1 });
    document.querySelectorAll('.animate-scroll').forEach((el) => observer.observe(el));
    
    const todayDate = new Date().toISOString().split('T')[0];
    const hidePopupsKey = 'hideDepPopups_' + todayDate;
    
    <?php if(!$has_claimed_any): ?>
    if (!localStorage.getItem(hidePopupsKey) && !sessionStorage.getItem('popupShownNow')) {
        document.getElementById('popup1').classList.add('show');
        sessionStorage.setItem('popupShownNow', 'true');
    }
    
    document.getElementById('closeP1').onclick = function() {
        document.getElementById('popup1').classList.remove('show');
        setTimeout(() => { let p2 = document.getElementById('popup2'); if(p2) p2.classList.add('show'); }, 150);
    };

    document.getElementById('closeP2').onclick = function() {
        if (document.getElementById('noReminder').checked) { localStorage.setItem(hidePopupsKey, 'true'); }
        document.getElementById('popup2').classList.remove('show');
    };
    <?php endif; ?>
});

function claimBonus(tier) {
    const t = document.getElementById('toast');
    const fd = new FormData();
    fd.append('action', 'claim_dep_bonus');
    fd.append('tier', tier);

    fetch('dashboard.php', { method: 'POST', body: fd })
    .then(response => response.json())
    .then(data => {
        t.textContent = data.message;
        t.classList.add('show');
        if (data.success) { setTimeout(() => { location.reload(); }, 1500); } 
        else { setTimeout(() => t.classList.remove('show'), 1500); }
    }).catch(error => { t.textContent = 'Network error!'; t.classList.add('show'); setTimeout(() => t.classList.remove('show'), 1500); });
}
</script>
</body>
</html>