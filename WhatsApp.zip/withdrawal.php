<?php
// withdrawal.php
require_once 'config.php';

if (!isset($_SESSION['phone'])) {
    header('Location: login.php');
    exit;
}

$phone = $_SESSION['phone'];
$userData = firebase_read("users/" . $phone);
$balance = $userData['balance'] ?? 0;
$bankInfo = $userData['bank_info'] ?? null;
$upiInfo = $userData['upi_info'] ?? null;

// Handle AJAX
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    header('Content-Type: application/json');
    $action = $_POST['action'];

    // Save Bank Info
    if ($action === 'save_bank') {
        $bankName = trim($_POST['bank_name'] ?? '');
        $accountName = trim($_POST['account_name'] ?? '');
        $accountNumber = trim($_POST['account_number'] ?? '');
        $confirmNumber = trim($_POST['confirm_number'] ?? '');
        $phoneNum = trim($_POST['phone_number'] ?? '');
        $ifsc = trim($_POST['ifsc_code'] ?? '');

        if (empty($bankName) || empty($accountName) || empty($accountNumber) || empty($ifsc)) {
            echo json_encode(['success' => false, 'message' => 'All fields are required!']);
            exit;
        }
        if ($accountNumber !== $confirmNumber) {
            echo json_encode(['success' => false, 'message' => 'Account numbers do not match!']);
            exit;
        }
        if (!preg_match('/^[A-Z]{4}0[A-Z0-9]{6}$/', strtoupper($ifsc))) {
            echo json_encode(['success' => false, 'message' => 'Invalid IFSC code format!']);
            exit;
        }

        $bankData = [
            'bank_name' => $bankName,
            'account_name' => $accountName,
            'account_number' => $accountNumber,
            'phone_number' => $phoneNum,
            'ifsc_code' => strtoupper($ifsc)
        ];

        $currentUser = firebase_read("users/" . $phone);
        $currentUser['bank_info'] = $bankData;
        firebase_write("users/" . $phone, $currentUser);
        echo json_encode(['success' => true, 'message' => 'Bank account saved successfully!', 'data' => $bankData]);
        exit;
    }

    // Save UPI Info
    if ($action === 'save_upi') {
        $upiId = trim($_POST['upi_id'] ?? '');
        $upiName = trim($_POST['upi_name'] ?? '');

        if (empty($upiId) || empty($upiName)) {
            echo json_encode(['success' => false, 'message' => 'All fields are required!']);
            exit;
        }
        if (!preg_match('/^[\w.\-]+@[\w]+$/', $upiId)) {
            echo json_encode(['success' => false, 'message' => 'Invalid UPI ID format!']);
            exit;
        }

        $upiData = ['upi_id' => $upiId, 'upi_name' => $upiName];
        $currentUser = firebase_read("users/" . $phone);
        $currentUser['upi_info'] = $upiData;
        firebase_write("users/" . $phone, $currentUser);
        echo json_encode(['success' => true, 'message' => 'UPI saved successfully!', 'data' => $upiData]);
        exit;
    }

    // Withdraw
    if ($action === 'withdraw') {
        $amount = floatval($_POST['amount'] ?? 0);
        $type = $_POST['type'] ?? 'BANK CARD';
        $currentUser = firebase_read("users/" . $phone);
        $currentBalance = $currentUser['balance'] ?? 0;

        if ($amount < 110) {
            echo json_encode(['success' => false, 'message' => 'Minimum withdrawal is ₹110!']);
            exit;
        }
        if ($amount > 50000) {
            echo json_encode(['success' => false, 'message' => 'Maximum withdrawal is ₹50,000!']);
            exit;
        }
        if ($amount > $currentBalance) {
            echo json_encode(['success' => false, 'message' => 'Insufficient balance!']);
            exit;
        }

        // Check daily limit
        $today = date('Y-m-d');
        $withdrawals = firebase_read("withdrawals/" . $phone) ?? [];
        $todayCount = 0;
        foreach ($withdrawals as $w) {
            if (isset($w['date']) && $w['date'] === $today) {
                $todayCount++;
            }
        }
        if ($todayCount >= 3) {
            echo json_encode(['success' => false, 'message' => 'Daily withdrawal limit reached (3 times)!']);
            exit;
        }

        // Deduct balance
        $newBalance = $currentBalance - $amount;
        $currentUser['balance'] = $newBalance;
        firebase_write("users/" . $phone, $currentUser);

        // Save withdrawal record
        $orderId = 'WD' . date('YmdHis') . rand(1000, 9999) . substr($phone, -4);
        $withdrawRecord = [
            'order_id' => $orderId,
            'amount' => $amount,
            'type' => $type,
            'status' => 'Pending',
            'date' => $today,
            'time' => date('Y-m-d H:i:s'),
            'phone' => $phone
        ];

        $withdrawals[$orderId] = $withdrawRecord;
        firebase_write("withdrawals/" . $phone, $withdrawals);

        echo json_encode([
            'success' => true,
            'message' => 'Withdrawal request submitted!',
            'new_balance' => $newBalance,
            'order_id' => $orderId
        ]);
        exit;
    }

    // Get balance (refresh)
    if ($action === 'get_balance') {
        $freshUser = firebase_read("users/" . $phone);
        $freshBalance = $freshUser['balance'] ?? 0;
        echo json_encode(['success' => true, 'balance' => $freshBalance]);
        exit;
    }
}

// Get withdrawal history
$withdrawals = firebase_read("withdrawals/" . $phone) ?? [];
if (!is_array($withdrawals)) $withdrawals = [];
// Sort by time desc
usort($withdrawals, function($a, $b) {
    return strcmp($b['time'] ?? '', $a['time'] ?? '');
});

// Today remaining withdrawals
$today = date('Y-m-d');
$todayCount = 0;
foreach ($withdrawals as $w) {
    if (isset($w['date']) && $w['date'] === $today) {
        $todayCount++;
    }
}
$remainingToday = 3 - $todayCount;
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
<title>Withdraw</title>
<style>
  * { margin: 0; padding: 0; box-sizing: border-box; -webkit-tap-highlight-color: transparent; }
  body {
    font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif;
    background: #f4f5f8;
    min-height: 100vh;
    max-width: 480px;
    margin: 0 auto;
    position: relative;
    padding-bottom: 80px;
  }

  /* Header */
  .header {
    background: #fff;
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: 14px 16px;
    position: sticky;
    top: 0;
    z-index: 100;
  }
  .header-back {
    width: 32px;
    display: flex;
    align-items: center;
    cursor: pointer;
  }
  .header-back svg { width: 20px; height: 20px; fill: #333; }
  .header-title {
    font-size: 17px;
    font-weight: 500;
    color: #333;
  }
  .header-history {
    font-size: 14px;
    color: #666;
    text-decoration: none;
    cursor: pointer;
  }

  /* Balance Card */
  .balance-card {
    background: linear-gradient(135deg, #4a81ff 0%, #3b5998 100%);
    margin: 15px;
    border-radius: 12px;
    padding: 20px;
    color: #fff;
    position: relative;
    box-shadow: 0 4px 10px rgba(74, 129, 255, 0.2);
  }
  .balance-label {
    display: flex;
    align-items: center;
    gap: 8px;
    font-size: 14px;
    margin-bottom: 10px;
  }
  .balance-label img { width: 18px; height: 18px; }
  .balance-amount {
    display: flex;
    align-items: center;
    gap: 10px;
    font-size: 32px;
    font-weight: 700;
    margin-bottom: 20px;
  }
  .refresh-btn {
    background: none;
    border: none;
    cursor: pointer;
    padding: 4px;
    display: flex;
    align-items: center;
    justify-content: center;
  }
  .refresh-btn img { width: 22px; height: 22px; transition: transform 0.5s; filter: brightness(0) invert(1); }
  .refresh-btn.spinning img { transform: rotate(360deg); }
  .balance-dots {
    position: absolute;
    bottom: 15px; right: 20px;
    font-size: 16px;
    letter-spacing: 2px;
  }

  /* Payment Type Tabs */
  .payment-tabs {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 10px;
    margin: 0 15px 15px;
  }
  .pay-tab {
    background: #fff;
    border-radius: 8px;
    padding: 15px 10px;
    text-align: center;
    cursor: pointer;
    transition: all 0.2s;
    box-shadow: 0 2px 5px rgba(0,0,0,0.02);
    border: 1px solid transparent;
  }
  .pay-tab.active {
    background: #4a81ff;
    color: #fff;
  }
  .pay-tab img { width: 36px; height: 36px; object-fit: contain; margin-bottom: 8px; }
  .pay-tab-label {
    font-size: 13px;
    font-weight: 500;
    color: #666;
  }
  .pay-tab.active .pay-tab-label { color: #fff; }

  /* Account Info Box */
  .account-box {
    margin: 0 15px 15px;
  }
  .add-account {
    background: #fff;
    border-radius: 10px;
    padding: 25px 15px;
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    cursor: pointer;
    box-shadow: 0 2px 5px rgba(0,0,0,0.02);
  }
  .add-icon {
    width: 40px; height: 40px;
    border: 1px dashed #ccc;
    border-radius: 8px;
    display: flex; align-items: center; justify-content: center;
    margin-bottom: 10px;
  }
  .add-icon svg { width: 20px; height: 20px; fill: #ccc; }
  .add-account-text { font-size: 14px; color: #999; }
  
  .add-beneficiary-warn {
    color: #ff4757;
    font-size: 12px;
    text-align: center;
    margin-top: 10px;
  }

  .account-added {
    background: #fff;
    border-radius: 10px;
    padding: 15px;
    display: flex;
    align-items: center;
    gap: 15px;
    box-shadow: 0 2px 5px rgba(0,0,0,0.02);
    cursor: pointer;
  }
  .bank-icon-box {
    width: 40px; height: 40px;
    background: #f0f4ff;
    border-radius: 8px;
    display: flex; align-items: center; justify-content: center;
  }
  .bank-icon-box img { width: 24px; height: 24px; object-fit: contain; }
  .bank-name-text { font-size: 12px; color: #999; margin-top: 4px; }
  .bank-account-num { font-size: 15px; font-weight: 500; color: #333; }
  .account-arrow { margin-left: auto; }
  .account-arrow svg { width: 16px; height: 16px; fill: #ccc; }

  /* Amount Section */
  .amount-section {
    background: #fff;
    margin: 0 15px 15px;
    border-radius: 10px;
    padding: 20px 15px;
    box-shadow: 0 2px 5px rgba(0,0,0,0.02);
  }
  .amount-input-row {
    display: flex;
    align-items: center;
    gap: 10px;
    background: #f4f5f8;
    border-radius: 30px;
    padding: 12px 20px;
    margin-bottom: 20px;
  }
  .rupee-icon { font-size: 18px; color: #4a81ff; font-weight: 600; }
  .amount-input {
    flex: 1;
    border: none;
    background: none;
    font-size: 15px;
    color: #333;
    outline: none;
  }
  .amount-input::placeholder { color: #999; }
  
  .balance-info-row {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 12px;
    font-size: 13px;
  }
  .balance-info-label { color: #666; }
  .balance-info-val { color: #ff8c00; font-weight: 500; }
  .all-btn {
    border: 1px solid #4a81ff;
    background: none;
    color: #4a81ff;
    font-size: 12px;
    padding: 2px 15px;
    border-radius: 15px;
    cursor: pointer;
    margin-left: 10px;
  }
  
  .withdraw-btn {
    width: 100%;
    padding: 14px;
    border: none;
    border-radius: 30px;
    font-size: 16px;
    font-weight: 500;
    cursor: pointer;
    margin-top: 15px;
    transition: all 0.3s;
  }
  .withdraw-btn.disabled {
    background: #dcdcdc;
    color: #999;
    cursor: not-allowed;
  }
  .withdraw-btn.active-btn {
    background: #4a81ff;
    color: #fff;
    box-shadow: 0 4px 10px rgba(74, 129, 255, 0.3);
  }

  /* Rules */
  .rules-box {
    background: #fff;
    margin: 0 15px 15px;
    border-radius: 10px;
    padding: 20px 15px;
    box-shadow: 0 2px 5px rgba(0,0,0,0.02);
  }
  .rule-item {
    display: flex;
    align-items: flex-start;
    gap: 8px;
    margin-bottom: 12px;
    font-size: 12px;
    color: #666;
    line-height: 1.5;
  }
  .rule-item:last-child { margin-bottom: 0; }
  .rule-dot {
    color: #4a81ff;
    font-size: 10px;
    margin-top: 2px;
  }
  .rule-highlight { color: #ff4757; }

  /* Withdrawal History (Bottom - Top 3) */
  .history-section {
    margin: 0 15px 20px;
  }
  .history-header {
    display: flex;
    align-items: center;
    gap: 10px;
    margin-bottom: 15px;
  }
  .history-header svg { width: 20px; height: 20px; fill: #4a81ff; }
  .history-title { font-size: 16px; font-weight: 600; color: #333; }

  .history-card {
    background: #fff;
    border-radius: 10px;
    padding: 15px;
    margin-bottom: 10px;
    box-shadow: 0 2px 5px rgba(0,0,0,0.02);
  }
  .history-card-top {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 15px;
  }
  .history-badge {
    background: #ff4757;
    color: #fff;
    font-size: 12px;
    padding: 4px 12px;
    border-radius: 4px;
  }
  .history-status-completed { color: #28a745; font-size: 14px; font-weight: 500; }
  .history-status-pending { color: #ff8c00; font-size: 14px; font-weight: 500; }
  .history-status-failed { color: #ff4757; font-size: 14px; font-weight: 500; }
  
  .history-row {
    display: flex;
    justify-content: space-between;
    margin-bottom: 10px;
    font-size: 13px;
  }
  .history-row:last-child { margin-bottom: 0; }
  .history-row-label { color: #999; }
  .history-row-val { color: #333; }
  .history-row-val.orange { color: #ff8c00; }
  .order-copy {
    display: flex;
    align-items: center;
    gap: 5px;
    cursor: pointer;
  }
  .order-copy svg { width: 14px; height: 14px; fill: #999; }

  /* Full Screen History Modal */
  .full-screen-modal {
    position: fixed;
    top: 0; left: 0; width: 100%; height: 100%;
    background: #f4f5f8;
    z-index: 1000;
    display: none;
    flex-direction: column;
  }
  .full-screen-modal.show { display: flex; }
  
  /* History Filters */
  .history-filters {
    display: flex;
    gap: 10px;
    padding: 15px;
    background: #fff;
    box-shadow: 0 2px 5px rgba(0,0,0,0.02);
  }
  .filter-select, .filter-date {
    flex: 1;
    padding: 10px;
    border: 1px solid #eee;
    border-radius: 8px;
    font-size: 13px;
    color: #333;
    background: #fafafa;
    outline: none;
  }
  .history-list-container {
    flex: 1;
    overflow-y: auto;
    padding: 15px;
  }

  /* Input Modals (Bank/UPI) */
  .modal-overlay {
    display: none;
    position: fixed;
    top: 0; left: 0; right: 0; bottom: 0;
    background: rgba(0,0,0,0.5);
    z-index: 500;
    justify-content: center;
    align-items: flex-end;
  }
  .modal-overlay.show { display: flex; }
  .modal-box {
    background: #fff;
    width: 100%;
    max-width: 480px;
    border-radius: 20px 20px 0 0;
    padding: 20px 15px 30px;
    animation: slideUp 0.3s ease;
  }
  @keyframes slideUp {
    from { transform: translateY(100%); }
    to { transform: translateY(0); }
  }
  .modal-header {
    display: flex;
    align-items: center;
    margin-bottom: 20px;
  }
  .modal-back { cursor: pointer; margin-right: 15px; }
  .modal-back svg { width: 20px; height: 20px; fill: #333; }
  .modal-title { font-size: 16px; font-weight: 500; color: #333; }
  
  .modal-warning {
    background: #fff5f5;
    border-radius: 8px;
    padding: 12px;
    margin-bottom: 20px;
    display: flex;
    gap: 10px;
    align-items: flex-start;
    font-size: 12px;
    color: #ff4757;
  }
  .modal-warning svg { width: 16px; height: 16px; fill: #ff4757; flex-shrink: 0; }
  
  .field-group { margin-bottom: 20px; }
  .field-label {
    display: flex;
    align-items: center;
    gap: 8px;
    font-size: 13px;
    color: #333;
    margin-bottom: 10px;
  }
  .field-label svg { width: 18px; height: 18px; fill: #4a81ff; }
  .field-input {
    width: 100%;
    padding: 14px 15px;
    border: none;
    border-radius: 8px;
    font-size: 14px;
    color: #333;
    background: #f4f5f8;
    outline: none;
  }
  .field-input::placeholder { color: #999; }
  
  .save-btn {
    width: 100%;
    padding: 14px;
    background: #dcdcdc;
    color: #fff;
    border: none;
    border-radius: 30px;
    font-size: 16px;
    cursor: pointer;
    margin-top: 10px;
    transition: background 0.3s;
  }
  .save-btn.active { background: #4a81ff; }

  /* Toast */
  .toast {
    position: fixed;
    top: 50%; left: 50%;
    transform: translate(-50%, -50%) scale(0.8);
    background: rgba(0,0,0,0.8);
    color: #fff;
    padding: 15px 25px;
    border-radius: 8px;
    font-size: 14px;
    text-align: center;
    z-index: 9999;
    opacity: 0;
    transition: all 0.3s;
    pointer-events: none;
  }
  .toast.show {
    opacity: 1;
    transform: translate(-50%, -50%) scale(1);
  }
  .toast svg { width: 30px; height: 30px; fill: #fff; display: block; margin: 0 auto 10px; }

  .no-history {
    text-align: center;
    padding: 40px 20px;
    color: #999;
    font-size: 14px;
  }
  .no-history svg { width: 60px; height: 60px; fill: #ddd; margin-bottom: 15px; }
</style>
</head>
<body>

<!-- Header -->
<div class="header">
  <div class="header-back" onclick="history.back()">
    <svg viewBox="0 0 24 24"><path d="M15.41 16.59L10.83 12l4.58-4.59L14 6l-6 6 6 6 1.41-1.41z"/></svg>
  </div>
  <span class="header-title">Withdraw</span>
  <span class="header-history" onclick="openFullHistory()">Withdrawal history</span>
</div>

<!-- Balance Card -->
<div class="balance-card">
  <div class="balance-label">
    <img src="https://www.goaok.org/assets/png/balance-DmuJO3Yz.png" alt="wallet">
    <span>Available balance</span>
  </div>
  <div class="balance-amount">
    <span>₹<span id="balance-display"><?php echo number_format($balance, 2); ?></span></span>
    <button class="refresh-btn" onclick="refreshBalance()" id="refreshBtn">
      <img src="https://www.goaok.org/assets/png/refresh-C_mIC898.png" alt="refresh">
    </button>
  </div>
  <div class="balance-dots">**** ****</div>
</div>

<!-- Payment Type Tabs -->
<div class="payment-tabs">
  <div class="pay-tab active" id="tab-bank" onclick="switchTab('bank')">
    <img src="https://bindassgame.bet/GoaGame/payNameIcon/WithBeforeImgIcon2_20230912191848epbg.png" alt="Bank Card">
    <div class="pay-tab-label">BANK CARD</div>
  </div>
  <div class="pay-tab" id="tab-upi" onclick="switchTab('upi')">
    <img src="https://bindassgame.bet/GoaGame/payNameIcon/WithBeforeImgIcon_20250803165241robn.jpg" alt="UPI">
    <div class="pay-tab-label">UPI</div>
  </div>
</div>

<!-- Account Info Box -->
<div class="account-box" id="account-box">
  <?php if ($bankInfo): ?>
    <div class="account-added" onclick="openBankModal()">
      <div class="bank-icon-box">
        <img src="https://bindassgame.bet/GoaGame/payNameIcon/WithBeforeImgIcon2_20230912191848epbg.png" alt="Bank">
      </div>
      <div>
        <div class="bank-account-num">
          <?php
            $accNum = $bankInfo['account_number'] ?? '';
            $masked = substr($accNum, 0, 6) . '****' . substr($accNum, -3);
            echo $masked;
          ?>
        </div>
        <div class="bank-name-text"><?php echo htmlspecialchars($bankInfo['bank_name'] ?? ''); ?></div>
      </div>
      <div class="account-arrow">
        <svg viewBox="0 0 24 24"><path d="M8.59 16.59L13.17 12 8.59 7.41 10 6l6 6-6 6-1.41-1.41z"/></svg>
      </div>
    </div>
  <?php else: ?>
    <div class="add-account" onclick="openBankModal()">
      <div class="add-icon">
        <svg viewBox="0 0 24 24"><path d="M19 13h-6v6h-2v-6H5v-2h6V5h2v6h6v2z"/></svg>
      </div>
      <div class="add-account-text">Add a bank account number</div>
    </div>
    <div class="add-beneficiary-warn">Need to add beneficiary information to be able to withdraw money</div>
  <?php endif; ?>
</div>

<!-- Amount Section -->
<div class="amount-section">
  <div class="amount-input-row">
    <span class="rupee-icon">₹</span>
    <input type="number" class="amount-input" id="withdrawAmount"
           placeholder="Please enter the amount"
           min="110" max="50000"
           oninput="checkWithdrawBtn()">
  </div>
  <div class="balance-info-row">
    <span class="balance-info-label">Withdrawable balance <span style="color:#ff8c00;">₹<span id="bal-display2"><?php echo number_format($balance, 2); ?></span></span></span>
    <button class="all-btn" onclick="setAllAmount()">All</button>
  </div>
  <div class="balance-info-row">
    <span class="balance-info-label">Withdrawal amount received</span>
    <span class="balance-info-val" id="receiveAmount">₹0.00</span>
  </div>
  <button class="withdraw-btn disabled" id="withdrawBtn" onclick="doWithdraw()">Withdraw</button>
</div>

<!-- Rules -->
<div class="rules-box">
  <div class="rule-item">
    <span class="rule-dot">◆</span>
    <span>Need to bet <span class="rule-highlight">₹0.00</span> to be able to withdraw</span>
  </div>
  <div class="rule-item">
    <span class="rule-dot">◆</span>
    <span>Withdraw time <span class="rule-highlight">00:00-23:59</span></span>
  </div>
  <div class="rule-item">
    <span class="rule-dot">◆</span>
    <span>Inday Remaining Withdrawal Times<span class="rule-highlight"><?php echo $remainingToday; ?></span></span>
  </div>
  <div class="rule-item">
    <span class="rule-dot">◆</span>
    <span>Withdrawal amount range <span class="rule-highlight">₹110.00-₹50,000.00</span></span>
  </div>
  <div class="rule-item">
    <span class="rule-dot">◆</span>
    <span>Please check your registered bank information again before making a withdrawal. If your registered bank information is incorrect, our company will not be responsible for any losses you may incur.</span>
  </div>
  <div class="rule-item">
    <span class="rule-dot">◆</span>
    <span>If your registered bank information is incorrect, please contact customer service.</span>
  </div>
</div>

<!-- Withdrawal History (Bottom - Top 3) -->
<div class="history-section">
  <div class="history-header">
    <svg viewBox="0 0 24 24"><path d="M14 2H6c-1.1 0-1.99.9-1.99 2L4 20c0 1.1.89 2 1.99 2H18c1.1 0 2-.9 2-2V8l-6-6zm2 16H8v-2h8v2zm0-4H8v-2h8v2zm-3-5V3.5L18.5 9H13z"/></svg>
    <div class="history-title">Withdrawal history</div>
  </div>

  <?php if (empty($withdrawals)): ?>
    <div class="no-history">
      <svg viewBox="0 0 24 24"><path d="M19 3H5c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2zm0 16H5V5h14v14zM7 10h2v7H7zm4-3h2v10h-2zm4 6h2v4h-2z"/></svg>
      <div>No data</div>
    </div>
  <?php else: ?>
    <?php $showCount = 0; foreach ($withdrawals as $w): if ($showCount >= 3) break; $showCount++; ?>
    <div class="history-card">
      <div class="history-card-top">
        <span class="history-badge">Withdraw</span>
        <span class="history-status-<?php echo strtolower($w['status'] ?? 'pending'); ?>">
          <?php echo $w['status'] ?? 'Pending'; ?>
        </span>
      </div>
      <div class="history-row">
        <span class="history-row-label">Balance</span>
        <span class="history-row-val orange">₹<?php echo number_format($w['amount'] ?? 0, 2); ?></span>
      </div>
      <div class="history-row">
        <span class="history-row-label">Type</span>
        <span class="history-row-val"><?php echo htmlspecialchars($w['type'] ?? 'BANK CARD'); ?></span>
      </div>
      <div class="history-row">
        <span class="history-row-label">Time</span>
        <span class="history-row-val"><?php echo htmlspecialchars($w['time'] ?? ''); ?></span>
      </div>
      <div class="history-row">
        <span class="history-row-label">Order number</span>
        <div class="order-copy" onclick="copyText('<?php echo $w['order_id'] ?? ''; ?>')">
          <span><?php echo htmlspecialchars($w['order_id'] ?? ''); ?></span>
          <svg viewBox="0 0 24 24"><path d="M16 1H4c-1.1 0-2 .9-2 2v14h2V3h12V1zm3 4H8c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h11c1.1 0 2-.9 2-2V7c0-1.1-.9-2-2-2zm0 16H8V7h11v14z"/></svg>
        </div>
      </div>
    </div>
    <?php endforeach; ?>
  <?php endif; ?>
</div>

<!-- Full Screen History Modal (With Filters) -->
<div class="full-screen-modal" id="fullHistoryModal">
  <div class="header">
    <div class="header-back" onclick="closeFullHistory()">
      <svg viewBox="0 0 24 24"><path d="M15.41 16.59L10.83 12l4.58-4.59L14 6l-6 6 6 6 1.41-1.41z"/></svg>
    </div>
    <span class="header-title">Withdrawal history</span>
    <span style="width:32px;"></span> <!-- Spacer -->
  </div>
  
  <!-- Filters -->
  <div class="history-filters">
    <select class="filter-select" id="statusFilter" onchange="filterHistory()">
      <option value="all">All Status</option>
      <option value="completed">Completed</option>
      <option value="pending">Pending</option>
      <option value="failed">Failed</option>
    </select>
    <input type="date" class="filter-date" id="dateFilter" onchange="filterHistory()">
  </div>

  <div class="history-list-container" id="historyListContainer">
    <?php if (empty($withdrawals)): ?>
      <div class="no-history">
        <svg viewBox="0 0 24 24"><path d="M19 3H5c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2zm0 16H5V5h14v14zM7 10h2v7H7zm4-3h2v10h-2zm4 6h2v4h-2z"/></svg>
        <div>No data</div>
      </div>
    <?php else: ?>
      <?php foreach ($withdrawals as $w): ?>
      <div class="history-card history-item" data-status="<?php echo strtolower($w['status'] ?? 'pending'); ?>" data-date="<?php echo $w['date'] ?? ''; ?>">
        <div class="history-card-top">
          <span class="history-badge">Withdraw</span>
          <span class="history-status-<?php echo strtolower($w['status'] ?? 'pending'); ?>">
            <?php echo $w['status'] ?? 'Pending'; ?>
          </span>
        </div>
        <div class="history-row">
          <span class="history-row-label">Balance</span>
          <span class="history-row-val orange">₹<?php echo number_format($w['amount'] ?? 0, 2); ?></span>
        </div>
        <div class="history-row">
          <span class="history-row-label">Type</span>
          <span class="history-row-val"><?php echo htmlspecialchars($w['type'] ?? 'BANK CARD'); ?></span>
        </div>
        <div class="history-row">
          <span class="history-row-label">Time</span>
          <span class="history-row-val"><?php echo htmlspecialchars($w['time'] ?? ''); ?></span>
        </div>
        <div class="history-row">
          <span class="history-row-label">Order number</span>
          <div class="order-copy" onclick="copyText('<?php echo $w['order_id'] ?? ''; ?>')">
            <span><?php echo htmlspecialchars($w['order_id'] ?? ''); ?></span>
            <svg viewBox="0 0 24 24"><path d="M16 1H4c-1.1 0-2 .9-2 2v14h2V3h12V1zm3 4H8c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h11c1.1 0 2-.9 2-2V7c0-1.1-.9-2-2-2zm0 16H8V7h11v14z"/></svg>
          </div>
        </div>
      </div>
      <?php endforeach; ?>
    <?php endif; ?>
  </div>
</div>

<!-- Bank Modal -->
<div class="modal-overlay" id="bankModal">
  <div class="modal-box">
    <div class="modal-header">
      <div class="modal-back" onclick="closeBankModal()">
        <svg viewBox="0 0 24 24"><path d="M15.41 16.59L10.83 12l4.58-4.59L14 6l-6 6 6 6 1.41-1.41z"/></svg>
      </div>
      <span class="modal-title">Add a bank account number</span>
    </div>
    <div class="modal-warning">
      <svg viewBox="0 0 24 24"><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm1 15h-2v-2h2v2zm0-4h-2V7h2v6z"/></svg>
      <span>To ensure the safety of your funds, please bind your bank account</span>
    </div>

    <div class="field-group">
      <div class="field-label">
        <svg viewBox="0 0 24 24"><path d="M4 10h3v7H4zM10.5 10h3v7h-3zM2 19h20v3H2zM17 10h3v7h-3zM12 1L2 6v2h20V6z"/></svg>
        <span>Bank Name</span>
      </div>
      <input type="text" class="field-input" id="bankName" placeholder="Please enter your bank name" oninput="checkBankForm()">
    </div>

    <div class="field-group">
      <div class="field-label">
        <svg viewBox="0 0 24 24"><path d="M12 12c2.21 0 4-1.79 4-4s-1.79-4-4-4-4 1.79-4 4 1.79 4 4 4zm0 2c-2.67 0-8 1.34-8 4v2h16v-2c0-2.66-5.33-4-8-4z"/></svg>
        <span>Full recipient's name</span>
      </div>
      <input type="text" class="field-input" id="accountName" placeholder="Please enter the recipient's name" oninput="checkBankForm()">
    </div>

    <div class="field-group">
      <div class="field-label">
        <svg viewBox="0 0 24 24"><path d="M21 4H3c-1.11 0-2 .89-2 2v12c0 1.1.89 2 2 2h18c1.1 0 2-.9 2-2V6c0-1.11-.9-2-2-2zm0 14H3V6h18v12zm-6-5h4v2h-4z"/></svg>
        <span>Bank account number</span>
      </div>
      <input type="number" class="field-input" id="accountNumber" placeholder="Please enter your bank account number" oninput="checkBankForm()">
    </div>

    <div class="field-group">
      <div class="field-label">
        <svg viewBox="0 0 24 24"><path d="M19 3H5c-1.11 0-2 .9-2 2v14c0 1.1.89 2 2 2h14c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2zm-9 14l-5-5 1.41-1.41L10 14.17l7.59-7.59L19 8l-9 9z"/></svg>
        <span>Confirm account number</span>
      </div>
      <input type="number" class="field-input" id="confirmNumber" placeholder="Please confirm your account number" oninput="checkBankForm()">
    </div>

    <div class="field-group">
      <div class="field-label">
        <svg viewBox="0 0 24 24"><path d="M17 1.01L7 1c-1.1 0-2 .9-2 2v18c0 1.1.9 2 2 2h10c1.1 0 2-.9 2-2V3c0-1.1-.9-1.99-2-1.99zM17 19H7V5h10v14z"/></svg>
        <span>Phone number</span>
      </div>
      <input type="tel" class="field-input" id="phoneNumber" placeholder="Please enter your phone number" value="<?php echo htmlspecialchars($phone); ?>" oninput="checkBankForm()">
    </div>

    <div class="field-group">
      <div class="field-label">
        <svg viewBox="0 0 24 24"><path d="M15.5 14h-.79l-.28-.27C15.41 12.59 16 11.11 16 9.5 16 5.91 13.09 3 9.5 3S3 5.91 3 9.5 5.91 16 9.5 16c1.61 0 3.09-.59 4.23-1.57l.27.28v.79l5 4.99L20.49 19l-4.99-5zm-6 0C7.01 14 5 11.99 5 9.5S7.01 5 9.5 5 14 7.01 14 9.5 11.99 14 9.5 14z"/></svg>
        <span>IFSC code</span>
      </div>
      <input type="text" class="field-input" id="ifscCode" placeholder="Please enter IFSC code" style="text-transform:uppercase;" maxlength="11" oninput="checkBankForm()">
    </div>

    <button class="save-btn" id="saveBankBtn" onclick="saveBank()">Save</button>
  </div>
</div>

<!-- UPI Modal -->
<div class="modal-overlay" id="upiModal">
  <div class="modal-box">
    <div class="modal-header">
      <div class="modal-back" onclick="closeUpiModal()">
        <svg viewBox="0 0 24 24"><path d="M15.41 16.59L10.83 12l4.58-4.59L14 6l-6 6 6 6 1.41-1.41z"/></svg>
      </div>
      <span class="modal-title">Add UPI ID</span>
    </div>
    <div class="modal-warning">
      <svg viewBox="0 0 24 24"><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm1 15h-2v-2h2v2zm0-4h-2V7h2v6z"/></svg>
      <span>Please enter your valid UPI ID to receive payments</span>
    </div>

    <div class="field-group">
      <div class="field-label">
        <svg viewBox="0 0 24 24"><path d="M3 5v14h18V5H3zm16 12H5V7h14v10zm-2-7h-3V8h-2v2H9v2h3v2h2v-2h3v-2z"/></svg>
        <span>UPI ID</span>
      </div>
      <input type="text" class="field-input" id="upiId" placeholder="e.g. yourname@upi" oninput="checkUpiForm()">
    </div>

    <div class="field-group">
      <div class="field-label">
        <svg viewBox="0 0 24 24"><path d="M12 12c2.21 0 4-1.79 4-4s-1.79-4-4-4-4 1.79-4 4 1.79 4 4 4zm0 2c-2.67 0-8 1.34-8 4v2h16v-2c0-2.66-5.33-4-8-4z"/></svg>
        <span>Account Holder Name</span>
      </div>
      <input type="text" class="field-input" id="upiName" placeholder="Please enter your name" oninput="checkUpiForm()">
    </div>

    <button class="save-btn" id="saveUpiBtn" onclick="saveUpi()">Save</button>
  </div>
</div>

<!-- Toast -->
<div class="toast" id="toast">
  <svg viewBox="0 0 24 24" id="toast-icon"><path d="M9 16.17L4.83 12l-1.42 1.41L9 19 21 7l-1.41-1.41z"/></svg>
  <span id="toast-msg">Success</span>
</div>

<script>
  let currentTab = 'bank';
  let currentBalance = <?php echo $balance; ?>;
  let hasBankInfo = <?php echo $bankInfo ? 'true' : 'false'; ?>;
  let hasUpiInfo = <?php echo $upiInfo ? 'true' : 'false'; ?>;
  let bankData = <?php echo $bankInfo ? json_encode($bankInfo) : 'null'; ?>;
  let upiData = <?php echo $upiInfo ? json_encode($upiInfo) : 'null'; ?>;

  // ============ TAB SWITCH ============
  function switchTab(tab) {
    currentTab = tab;
    document.querySelectorAll('.pay-tab').forEach(t => t.classList.remove('active'));
    document.getElementById('tab-' + tab).classList.add('active');
    updateAccountBox();
    checkWithdrawBtn();
  }

  function updateAccountBox() {
    const box = document.getElementById('account-box');
    if (currentTab === 'bank') {
      if (hasBankInfo && bankData) {
        const accNum = bankData.account_number || '';
        const masked = accNum.substring(0, 6) + '****' + accNum.substring(accNum.length - 3);
        box.innerHTML = `
          <div class="account-added" onclick="openBankModal()">
            <div class="bank-icon-box">
              <img src="https://bindassgame.bet/GoaGame/payNameIcon/WithBeforeImgIcon2_20230912191848epbg.png" alt="Bank">
            </div>
            <div>
              <div class="bank-account-num">${masked}</div>
              <div class="bank-name-text">${bankData.bank_name || ''}</div>
            </div>
            <div class="account-arrow">
              <svg viewBox="0 0 24 24"><path d="M8.59 16.59L13.17 12 8.59 7.41 10 6l6 6-6 6-1.41-1.41z"/></svg>
            </div>
          </div>`;
      } else {
        box.innerHTML = `
          <div class="add-account" onclick="openBankModal()">
            <div class="add-icon">
              <svg viewBox="0 0 24 24"><path d="M19 13h-6v6h-2v-6H5v-2h6V5h2v6h6v2z"/></svg>
            </div>
            <div class="add-account-text">Add a bank account number</div>
          </div>
          <div class="add-beneficiary-warn">Need to add beneficiary information to be able to withdraw money</div>`;
      }
    } else if (currentTab === 'upi') {
      if (hasUpiInfo && upiData) {
        box.innerHTML = `
          <div class="account-added" onclick="openUpiModal()">
            <div class="bank-icon-box">
              <img src="https://bindassgame.bet/GoaGame/payNameIcon/WithBeforeImgIcon_20250803165241robn.jpg" alt="UPI">
            </div>
            <div>
              <div class="bank-account-num">${upiData.upi_id || ''}</div>
              <div class="bank-name-text">${upiData.upi_name || ''}</div>
            </div>
            <div class="account-arrow">
              <svg viewBox="0 0 24 24"><path d="M8.59 16.59L13.17 12 8.59 7.41 10 6l6 6-6 6-1.41-1.41z"/></svg>
            </div>
          </div>`;
      } else {
        box.innerHTML = `
          <div class="add-account" onclick="openUpiModal()">
            <div class="add-icon">
              <svg viewBox="0 0 24 24"><path d="M19 13h-6v6h-2v-6H5v-2h6V5h2v6h6v2z"/></svg>
            </div>
            <div class="add-account-text">Add UPI</div>
          </div>
          <div class="add-beneficiary-warn">Need to add UPI information to be able to withdraw money</div>`;
      }
    }
  }

  // ============ REFRESH BALANCE ============
  function refreshBalance() {
    const btn = document.getElementById('refreshBtn');
    btn.classList.add('spinning');
    fetch('withdrawal.php', {
      method: 'POST',
      headers: {'Content-Type': 'application/x-www-form-urlencoded'},
      body: 'action=get_balance'
    })
    .then(r => r.json())
    .then(data => {
      if (data.success) {
        currentBalance = data.balance;
        document.getElementById('balance-display').textContent = parseFloat(data.balance).toFixed(2);
        document.getElementById('bal-display2').textContent = parseFloat(data.balance).toFixed(2);
        showToast('Refresh successfully', true);
      }
      setTimeout(() => btn.classList.remove('spinning'), 600);
    })
    .catch(() => {
      setTimeout(() => btn.classList.remove('spinning'), 600);
    });
  }

  // ============ AMOUNT LOGIC ============
  function setAllAmount() {
    document.getElementById('withdrawAmount').value = currentBalance.toFixed(0);
    updateReceiveAmount();
    checkWithdrawBtn();
  }

  function checkWithdrawBtn() {
    const amt = parseFloat(document.getElementById('withdrawAmount').value) || 0;
    const btn = document.getElementById('withdrawBtn');
    const hasAccount = (currentTab === 'bank' && hasBankInfo) || (currentTab === 'upi' && hasUpiInfo);

    if (amt >= 110 && amt <= currentBalance && amt <= 50000 && hasAccount) {
      btn.className = 'withdraw-btn active-btn';
    } else {
      btn.className = 'withdraw-btn disabled';
    }
    updateReceiveAmount();
  }

  function updateReceiveAmount() {
    const amt = parseFloat(document.getElementById('withdrawAmount').value) || 0;
    document.getElementById('receiveAmount').textContent = '₹' + amt.toFixed(2);
  }

  // ============ WITHDRAW ============
  function doWithdraw() {
    const btn = document.getElementById('withdrawBtn');
    if (btn.classList.contains('disabled')) return;

    const amount = parseFloat(document.getElementById('withdrawAmount').value) || 0;
    btn.textContent = 'Processing...';
    btn.className = 'withdraw-btn disabled';

    const typeMap = { bank: 'BANK CARD', upi: 'UPI' };
    const type = typeMap[currentTab] || 'BANK CARD';

    const fd = new FormData();
    fd.append('action', 'withdraw');
    fd.append('amount', amount);
    fd.append('type', type);

    fetch('withdrawal.php', { method: 'POST', body: fd })
    .then(r => r.json())
    .then(data => {
      if (data.success) {
        currentBalance = data.new_balance;
        document.getElementById('balance-display').textContent = parseFloat(data.new_balance).toFixed(2);
        document.getElementById('bal-display2').textContent = parseFloat(data.new_balance).toFixed(2);
        document.getElementById('withdrawAmount').value = '';
        document.getElementById('receiveAmount').textContent = '₹0.00';
        showToast('Withdrawal request submitted!', true);
        setTimeout(() => location.reload(), 2000);
      } else {
        showToast(data.message || 'Failed!', false);
      }
      btn.textContent = 'Withdraw';
      checkWithdrawBtn();
    })
    .catch(() => {
      btn.textContent = 'Withdraw';
      showToast('Network error!', false);
      checkWithdrawBtn();
    });
  }

  // ============ FULL SCREEN HISTORY & FILTERS ============
  function openFullHistory() {
    document.getElementById('fullHistoryModal').classList.add('show');
    document.body.style.overflow = 'hidden';
  }
  function closeFullHistory() {
    document.getElementById('fullHistoryModal').classList.remove('show');
    document.body.style.overflow = '';
  }

  function filterHistory() {
    const statusVal = document.getElementById('statusFilter').value;
    const dateVal = document.getElementById('dateFilter').value;
    const items = document.querySelectorAll('.history-item');
    let visibleCount = 0;

    items.forEach(item => {
      const itemStatus = item.getAttribute('data-status');
      const itemDate = item.getAttribute('data-date');
      
      let statusMatch = (statusVal === 'all' || itemStatus === statusVal);
      let dateMatch = (!dateVal || itemDate === dateVal);

      if (statusMatch && dateMatch) {
        item.style.display = 'block';
        visibleCount++;
      } else {
        item.style.display = 'none';
      }
    });

    // Show "No data" if nothing matches
    const container = document.getElementById('historyListContainer');
    let noDataEl = container.querySelector('.no-history');
    
    if (visibleCount === 0) {
      if (!noDataEl) {
        container.innerHTML += `
          <div class="no-history">
            <svg viewBox="0 0 24 24"><path d="M19 3H5c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2zm0 16H5V5h14v14zM7 10h2v7H7zm4-3h2v10h-2zm4 6h2v4h-2z"/></svg>
            <div>No data</div>
          </div>`;
      } else {
        noDataEl.style.display = 'block';
      }
    } else if (noDataEl) {
      noDataEl.style.display = 'none';
    }
  }

  // ============ BANK MODAL ============
  function openBankModal() {
    if (bankData) {
      document.getElementById('bankName').value = bankData.bank_name || '';
      document.getElementById('accountName').value = bankData.account_name || '';
      document.getElementById('accountNumber').value = bankData.account_number || '';
      document.getElementById('confirmNumber').value = bankData.account_number || '';
      document.getElementById('phoneNumber').value = bankData.phone_number || '';
      document.getElementById('ifscCode').value = bankData.ifsc_code || '';
    }
    document.getElementById('bankModal').classList.add('show');
    document.body.style.overflow = 'hidden';
    checkBankForm();
  }

  function closeBankModal() {
    document.getElementById('bankModal').classList.remove('show');
    document.body.style.overflow = '';
  }

  function checkBankForm() {
    const btn = document.getElementById('saveBankBtn');
    const b1 = document.getElementById('bankName').value.trim();
    const b2 = document.getElementById('accountName').value.trim();
    const b3 = document.getElementById('accountNumber').value.trim();
    const b4 = document.getElementById('confirmNumber').value.trim();
    const b5 = document.getElementById('ifscCode').value.trim();
    
    if(b1 && b2 && b3 && b4 && b5) {
      btn.classList.add('active');
    } else {
      btn.classList.remove('active');
    }
  }

  function saveBank() {
    const btn = document.getElementById('saveBankBtn');
    if(!btn.classList.contains('active')) return;

    const bankName = document.getElementById('bankName').value.trim();
    const accountName = document.getElementById('accountName').value.trim();
    const accountNumber = document.getElementById('accountNumber').value.trim();
    const confirmNumber = document.getElementById('confirmNumber').value.trim();
    const phoneNumber = document.getElementById('phoneNumber').value.trim();
    const ifscCode = document.getElementById('ifscCode').value.trim().toUpperCase();

    if (accountNumber !== confirmNumber) { showToast('Account numbers do not match!', false); return; }

    btn.textContent = 'Saving...';
    btn.classList.remove('active');

    const fd = new FormData();
    fd.append('action', 'save_bank');
    fd.append('bank_name', bankName);
    fd.append('account_name', accountName);
    fd.append('account_number', accountNumber);
    fd.append('confirm_number', confirmNumber);
    fd.append('phone_number', phoneNumber);
    fd.append('ifsc_code', ifscCode);

    fetch('withdrawal.php', { method: 'POST', body: fd })
    .then(r => r.json())
    .then(data => {
      btn.textContent = 'Save';
      if (data.success) {
        hasBankInfo = true;
        bankData = data.data;
        closeBankModal();
        updateAccountBox();
        showToast('Bank account saved!', true);
        checkWithdrawBtn();
      } else {
        showToast(data.message || 'Failed!', false);
        btn.classList.add('active');
      }
    })
    .catch(() => {
      btn.textContent = 'Save';
      btn.classList.add('active');
      showToast('Network error!', false);
    });
  }

  // ============ UPI MODAL ============
  function openUpiModal() {
    if (upiData) {
      document.getElementById('upiId').value = upiData.upi_id || '';
      document.getElementById('upiName').value = upiData.upi_name || '';
    }
    document.getElementById('upiModal').classList.add('show');
    document.body.style.overflow = 'hidden';
    checkUpiForm();
  }

  function closeUpiModal() {
    document.getElementById('upiModal').classList.remove('show');
    document.body.style.overflow = '';
  }

  function checkUpiForm() {
    const btn = document.getElementById('saveUpiBtn');
    const u1 = document.getElementById('upiId').value.trim();
    const u2 = document.getElementById('upiName').value.trim();
    if(u1 && u2) {
      btn.classList.add('active');
    } else {
      btn.classList.remove('active');
    }
  }

  function saveUpi() {
    const btn = document.getElementById('saveUpiBtn');
    if(!btn.classList.contains('active')) return;

    const upiId = document.getElementById('upiId').value.trim();
    const upiName = document.getElementById('upiName').value.trim();

    btn.textContent = 'Saving...';
    btn.classList.remove('active');

    const fd = new FormData();
    fd.append('action', 'save_upi');
    fd.append('upi_id', upiId);
    fd.append('upi_name', upiName);

    fetch('withdrawal.php', { method: 'POST', body: fd })
    .then(r => r.json())
    .then(data => {
      btn.textContent = 'Save';
      if (data.success) {
        hasUpiInfo = true;
        upiData = data.data;
        closeUpiModal();
        updateAccountBox();
        showToast('UPI saved successfully!', true);
        checkWithdrawBtn();
      } else {
        showToast(data.message || 'Failed!', false);
        btn.classList.add('active');
      }
    })
    .catch(() => {
      btn.textContent = 'Save';
      btn.classList.add('active');
      showToast('Network error!', false);
    });
  }

  // ============ TOAST ============
  function showToast(msg, isSuccess) {
    const toast = document.getElementById('toast');
    const icon = document.getElementById('toast-icon');
    document.getElementById('toast-msg').textContent = msg;
    
    if(isSuccess) {
      icon.innerHTML = '<path d="M9 16.17L4.83 12l-1.42 1.41L9 19 21 7l-1.41-1.41z"/>';
    } else {
      icon.innerHTML = '<path d="M19 6.41L17.59 5 12 10.59 6.41 5 5 6.41 10.59 12 5 17.59 6.41 19 12 13.41 17.59 19 19 17.59 13.41 12z"/>';
    }
    
    toast.classList.add('show');
    setTimeout(() => toast.classList.remove('show'), 2500);
  }

  // ============ COPY ============
  function copyText(text) {
    if (navigator.clipboard) {
      navigator.clipboard.writeText(text).then(() => showToast('Copied successfully', true));
    } else {
      const el = document.createElement('textarea');
      el.value = text;
      document.body.appendChild(el);
      el.select();
      document.execCommand('copy');
      document.body.removeChild(el);
      showToast('Copied successfully', true);
    }
  }

  // Close modals on overlay click
  document.getElementById('bankModal').addEventListener('click', function(e) {
    if (e.target === this) closeBankModal();
  });
  document.getElementById('upiModal').addEventListener('click', function(e) {
    if (e.target === this) closeUpiModal();
  });

  // IFSC uppercase
  document.getElementById('ifscCode').addEventListener('input', function() {
    this.value = this.value.toUpperCase();
  });
</script>
</body>
</html>