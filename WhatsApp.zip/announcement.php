<?php
session_start();
error_reporting(0);
date_default_timezone_set('Asia/Kolkata');
require_once 'config.php';

$phone = $_SESSION['user_phone'] ?? $_SESSION['phone'] ?? '';
if ($phone === '') {
    header('Location: index.php');
    exit;
}
$_SESSION['user_phone'] = $phone;
$_SESSION['phone'] = $phone;

function jsonOut(array $data): void {
    header('Content-Type: application/json');
    echo json_encode($data);
    exit;
}

// =========================================================================
// 1. AUTO-SYNC DEPOSIT NOTIFICATIONS (Pending, Success, Rejected with Order ID)
// =========================================================================
function syncDepositNotifications(string $phone): void {
    $deposits = firebase_read("deposits/$phone");
    if (!is_array($deposits)) return;

    $userNotifs = firebase_read("users/$phone/notifications");
    if (!is_array($userNotifs)) $userNotifs = [];

    // Track which orders are already notified with which status
    $notifiedKeys = [];
    foreach ($userNotifs as $nid => $n) {
        if (!empty($n['order_id']) && !empty($n['status_track'])) {
            $notifiedKeys[$n['order_id'] . '_' . $n['status_track']] = true;
        }
    }

    foreach ($deposits as $orderId => $dep) {
        if (!is_array($dep)) continue;
        $status = strtolower($dep['status'] ?? 'pending');
        $amount = number_format((float)($dep['amount'] ?? 0), 2);
        $orderNo = $dep['order_id'] ?? $orderId;
        $dateNow = date('Y-m-d H:i:s');

        // Check if this status for this order is already notified
        $trackKey = $orderNo . '_' . $status;
        if (isset($notifiedKeys[$trackKey])) continue;

        $newNotif = null;
        $nid = 'notif_dep_' . preg_replace('/[^a-zA-Z0-9]/', '', $orderNo) . '_' . $status;

        if ($status === 'pending' || $status === 'processing') {
            $newNotif = [
                'id' => $nid,
                'title' => 'Deposit Pending',
                'order_id' => $orderNo,
                'status_track' => $status,
                'type' => 'deposit_pending',
                'date' => $dep['created_at'] ?? $dep['time'] ?? $dateNow,
                'message' => "Your deposit of ₹{$amount} with Order ID: {$orderNo} has been submitted successfully. It is currently under review. Your balance will be updated automatically upon approval."
            ];
        } elseif ($status === 'approved' || $status === 'completed' || $status === 'success') {
            $newNotif = [
                'id' => $nid,
                'title' => 'Deposit Successful',
                'order_id' => $orderNo,
                'status_track' => $status,
                'type' => 'deposit_success',
                'date' => $dep['processed_at'] ?? $dateNow,
                'message' => "Congratulations! Your deposit of ₹{$amount} with Order ID: {$orderNo} has been successfully verified and credited to your 3win wallet. Enjoy your gaming experience!"
            ];
        } elseif ($status === 'rejected' || $status === 'failed') {
            $newNotif = [
                'id' => $nid,
                'title' => 'Deposit Rejected',
                'order_id' => $orderNo,
                'status_track' => $status,
                'type' => 'deposit_rejected',
                'date' => $dep['processed_at'] ?? $dateNow,
                'message' => "Alert: Your deposit request of ₹{$amount} with Order ID: {$orderNo} could not be verified and has been rejected. Please verify your UTR details or submit a fresh deposit."
            ];
        }

        if ($newNotif !== null) {
            firebase_write("users/$phone/notifications/$nid", $newNotif);
        }
    }
}

// Run the sync
syncDepositNotifications($phone);

// =========================================================================
// 2. SEED WELCOME NOTIFICATIONS (If empty, set 3win Branding)
// =========================================================================
$existingUserNotifs = firebase_read("users/$phone/notifications");
if (!is_array($existingUserNotifs) || empty($existingUserNotifs)) {
    $welcomeUserNotif = [
        'id' => 'notif_welcome_' . time(),
        'title' => 'New Member',
        'type' => 'welcome',
        'date' => date('Y-m-d H:i:s'),
        'message' => 'Thank you for becoming a beloved member of this platform. We provide many industry leading games. This is the world\'s leading gaming platform. Try the lottery game developed by us. While enjoying the best gaming experience, you can also join unlimited agents and stay at home to earn money.'
    ];
    firebase_write("users/$phone/notifications/{$welcomeUserNotif['id']}", $welcomeUserNotif);
}

// Global System Announcements (Information Tab)
$globalInfo = firebase_read("system_announcements");
if (!is_array($globalInfo) || empty($globalInfo)) {
    $welcomeGlobal = [
        'info_1' => [
            'id' => 'info_1',
            'title' => 'Welcome',
            'date' => '2024-01-01 12:00:00',
            'message' => 'Thank you for being a member of the 3win platform, we provide many industry-leading games. This is the world\'s leading gaming platform. Try our lottery games. While enjoying the best gaming experience, you can also join unlimited agents and earn money without leaving your home.'
        ]
    ];
    firebase_write("system_announcements", $welcomeGlobal);
    $globalInfo = $welcomeGlobal;
}

// =========================================================================
// 3. POST API ACTIONS (Delete notification, Admin Send message)
// =========================================================================
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';

    // Action: Delete personal notification
    if ($action === 'delete_notification') {
        $notifId = preg_replace('/[^a-zA-Z0-9_-]/', '', $_POST['id'] ?? '');
        if (!empty($notifId)) {
            firebase_delete("users/$phone/notifications/$notifId");
            jsonOut(['success' => true, 'message' => 'Notification deleted']);
        }
        jsonOut(['success' => false, 'message' => 'Invalid ID']);
    }

    // Action: Admin broadcast or send to specific user
    if ($action === 'admin_send_message') {
        $target = trim($_POST['target'] ?? ''); // 'all' or phone number
        $title = trim($_POST['title'] ?? 'Notice from 3win');
        $msg = trim($_POST['message'] ?? '');

        if ($msg === '') {
            jsonOut(['success' => false, 'message' => 'Message cannot be empty']);
        }

        $nowTime = date('Y-m-d H:i:s');
        $msgId = 'custom_' . time() . '_' . rand(100, 999);

        if ($target === 'all') {
            // Write to Global System Announcements
            $newAnnounce = [
                'id' => $msgId,
                'title' => $title,
                'date' => $nowTime,
                'message' => $msg
            ];
            firebase_write("system_announcements/$msgId", $newAnnounce);
            jsonOut(['success' => true, 'message' => 'Broadcast sent to all users successfully!']);
        } else {
            // Write to specific user's notification box
            $targetPhone = preg_replace('/[^0-9]/', '', $target);
            if (empty($targetPhone)) {
                jsonOut(['success' => false, 'message' => 'Invalid target phone number']);
            }
            $userMsg = [
                'id' => $msgId,
                'title' => $title,
                'type' => 'admin_direct',
                'date' => $nowTime,
                'message' => $msg
            ];
            firebase_write("users/$targetPhone/notifications/$msgId", $userMsg);
            jsonOut(['success' => true, 'message' => "Message sent to {$targetPhone} successfully!"]);
        }
    }

    jsonOut(['success' => false, 'message' => 'Unknown action']);
}

// Fetch list for rendering
$userNotifsList = firebase_read("users/$phone/notifications");
$userNotifsList = is_array($userNotifsList) ? array_values($userNotifsList) : [];

// Sort latest first
usort($userNotifsList, function($a, $b) {
    return strcmp($b['date'] ?? '', $a['date'] ?? '');
});

$infoList = firebase_read("system_announcements");
$infoList = is_array($infoList) ? array_values($infoList) : [];
usort($infoList, function($a, $b) {
    return strcmp($b['date'] ?? '', $a['date'] ?? '');
});

// Latest notification for Chrome Browser push
$latestNotif = !empty($userNotifsList) ? $userNotifsList[0] : null;
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
<title>Notification - 3win</title>
<style>
* { margin: 0; padding: 0; box-sizing: border-box; font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif; -webkit-tap-highlight-color: transparent; }
body { background: #f5f6fa; color: #333; min-height: 100vh; display: flex; justify-content: center; }
.app { width: 100%; max-width: 480px; min-height: 100vh; background: #f5f6fa; display: flex; flex-direction: column; position: relative; }

/* TOP HEADER */
.header { height: 50px; background: #fff; display: flex; align-items: center; justify-content: center; position: sticky; top: 0; z-index: 50; border-bottom: 1px solid #f0f1f5; }
.back-btn { position: absolute; left: 16px; font-size: 26px; color: #333; text-decoration: none; cursor: pointer; line-height: 1; display: flex; align-items: center; justify-content: center; }
.header-title { font-size: 18px; font-weight: 500; color: #222; }

/* TABS CONTAINER */
.tabs-wrap { padding: 14px 16px 10px; background: #f5f6fa; }
.tabs-nav { display: flex; background: #fff; border-radius: 8px; overflow: hidden; box-shadow: 0 1px 3px rgba(0,0,0,0.03); }
.tab-btn { flex: 1; height: 42px; border: none; background: transparent; font-size: 15px; font-weight: 500; color: #666; cursor: pointer; transition: all 0.2s ease; display: flex; align-items: center; justify-content: center; }
.tab-btn.active { background: #4175fc; color: #fff; font-weight: 600; border-radius: 6px; }

/* CONTENT WRAPPER */
.content-area { flex: 1; padding: 8px 16px 30px; display: flex; flex-direction: column; }
.tab-pane { display: none; flex-direction: column; gap: 12px; }
.tab-pane.active { display: flex; }

/* NOTIFICATION CARD */
.notif-card { background: #fff; border-radius: 12px; padding: 16px; box-shadow: 0 2px 6px rgba(0,0,0,0.02); display: flex; flex-direction: column; position: relative; transition: all 0.3s ease; }
.notif-card.removing { opacity: 0; transform: translateX(30px); }

.card-top { display: flex; align-items: center; justify-content: space-between; margin-bottom: 6px; }
.card-top-left { display: flex; align-items: center; gap: 8px; }
.card-icon { width: 22px; height: 22px; display: flex; align-items: center; justify-content: center; flex-shrink: 0; }
.card-icon svg { width: 100%; height: 100%; }

.card-title { font-size: 16px; font-weight: 700; color: #222; letter-spacing: 0.2px; }
.del-btn { background: none; border: none; cursor: pointer; padding: 4px; display: flex; align-items: center; justify-content: center; opacity: 0.65; transition: opacity 0.2s; }
.del-btn:hover { opacity: 1; }
.del-btn svg { width: 18px; height: 18px; stroke: #4175fc; fill: none; }

.card-date { font-size: 12px; color: #9aa1b4; margin-bottom: 12px; }
.card-body { font-size: 13.5px; line-height: 1.55; color: #5a6275; word-break: break-word; }

/* NO MORE FOOTER TEXT */
.no-more { text-align: center; color: #222; font-size: 14px; font-weight: 400; padding: 20px 0 10px; }

/* TOAST */
.toast { position: fixed; top: 50%; left: 50%; transform: translate(-50%, -50%) scale(0.85); background: rgba(0,0,0,0.82); color: #fff; padding: 12px 24px; border-radius: 25px; font-size: 14px; font-weight: 500; opacity: 0; pointer-events: none; transition: 0.25s; z-index: 1000; text-align: center; max-width: 80%; }
.toast.show { opacity: 1; transform: translate(-50%, -50%) scale(1); }
</style>
</head>
<body>

<div class="app">
    <!-- HEADER -->
    <div class="header">
        <a href="account.php" class="back-btn">‹</a>
        <div class="header-title">Notification</div>
    </div>

    <!-- TABS NAV -->
    <div class="tabs-wrap">
        <div class="tabs-nav">
            <button class="tab-btn active" id="tabBtnNotif" onclick="switchTab('notif')">Notification</button>
            <button class="tab-btn" id="tabBtnInfo" onclick="switchTab('info')">Information</button>
        </div>
    </div>

    <!-- MAIN CONTENT -->
    <div class="content-area">
        
        <!-- PANE 1: NOTIFICATION TAB -->
        <div class="tab-pane active" id="paneNotif">
            <?php if (empty($userNotifsList)): ?>
                <div style="text-align: center; color: #999; padding: 40px 0; font-size: 14px;">No notifications yet.</div>
            <?php else: ?>
                <?php foreach ($userNotifsList as $n): ?>
                    <div class="notif-card" id="card_<?= htmlspecialchars($n['id']) ?>">
                        <div class="card-top">
                            <div class="card-top-left">
                                <div class="card-icon">
                                    <?php if (($n['type'] ?? '') === 'deposit_success'): ?>
                                        <!-- Green Checked Envelope -->
                                        <svg viewBox="0 0 24 24" fill="#22b573"><path d="M20 4H4c-1.1 0-2 .9-2 2v12c0 1.1.9 2 2 2h16c1.1 0 2-.9 2-2V6c0-1.1-.9-2-2-2zm-9 14l-4-4 1.4-1.4 2.6 2.6 6.6-6.6 1.4 1.4-8 8z"/></svg>
                                    <?php elseif (($n['type'] ?? '') === 'deposit_rejected'): ?>
                                        <!-- Red Alert Envelope -->
                                        <svg viewBox="0 0 24 24" fill="#ff4d4f"><path d="M20 4H4c-1.1 0-2 .9-2 2v12c0 1.1.9 2 2 2h16c1.1 0 2-.9 2-2V6c0-1.1-.9-2-2-2zm-7 13h-2v-2h2v2zm0-4h-2V8h2v5z"/></svg>
                                    <?php elseif (($n['type'] ?? '') === 'deposit_pending'): ?>
                                        <!-- Orange Clock/Pending Envelope -->
                                        <svg viewBox="0 0 24 24" fill="#faad14"><path d="M20 4H4c-1.1 0-2 .9-2 2v12c0 1.1.9 2 2 2h16c1.1 0 2-.9 2-2V6c0-1.1-.9-2-2-2zm-8 13c-2.8 0-5-2.2-5-5s2.2-5 5-5 5 2.2 5 5-2.2 5-5 5zm.5-7.5H11V12l2.6 1.6.8-1.2-2-1.2V9.5z"/></svg>
                                    <?php else: ?>
                                        <!-- Default Grey Mail Icon (Matching Screenshot 1) -->
                                        <svg viewBox="0 0 24 24" fill="#7a8291"><path d="M20 4H4c-1.1 0-2 .9-2 2v12c0 1.1.9 2 2 2h16c1.1 0 2-.9 2-2V6c0-1.1-.9-2-2-2zm0 4l-8 5-8-5V6l8 5 8-5v2z"/></svg>
                                    <?php endif; ?>
                                </div>
                                <span class="card-title"><?= htmlspecialchars($n['title'] ?? 'Notification') ?></span>
                            </div>
                            <button class="del-btn" onclick="deleteNotif('<?= htmlspecialchars($n['id']) ?>')" title="Delete">
                                <svg viewBox="0 0 24 24" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                    <polyline points="3 6 5 6 21 6"></polyline>
                                    <path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"></path>
                                </svg>
                            </button>
                        </div>
                        <div class="card-date"><?= htmlspecialchars($n['date'] ?? '') ?></div>
                        <div class="card-body"><?= nl2br(htmlspecialchars($n['message'] ?? '')) ?></div>
                    </div>
                <?php endforeach; ?>
            <?php endif; ?>
            <div class="no-more">No more</div>
        </div>

        <!-- PANE 2: INFORMATION TAB -->
        <div class="tab-pane" id="paneInfo">
            <?php if (empty($infoList)): ?>
                <div style="text-align: center; color: #999; padding: 40px 0; font-size: 14px;">No announcements yet.</div>
            <?php else: ?>
                <?php foreach ($infoList as $inf): ?>
                    <div class="notif-card">
                        <div class="card-top" style="margin-bottom: 10px;">
                            <div class="card-top-left">
                                <div class="card-icon">
                                    <!-- Blue Megaphone matching Screenshot 2 -->
                                    <svg viewBox="0 0 24 24" fill="#4175fc">
                                        <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm1 14.5h-2v-2h2v2zm0-4h-2V7h2v5.5z" style="display:none;"/>
                                        <path d="M21.5 6.5l-3.5 2V4c0-.55-.45-1-1-1H4c-.55 0-1 .45-1 1v12c0 .55.45 1 1 1h13c.55 0 1-.45 1-1v-4.5l3.5 2c.55.31 1-.09 1-.64V7.14c0-.55-.45-.95-1-.64zM10 18.5H7v2.5c0 .55.45 1 1 1h1c.55 0 1-.45 1-1v-2.5z"/>
                                    </svg>
                                </div>
                                <span class="card-title"><?= htmlspecialchars($inf['title'] ?? 'Announcement') ?></span>
                            </div>
                        </div>
                        <div class="card-body" style="margin-bottom: 12px;">
                            <?= nl2br(htmlspecialchars($inf['message'] ?? '')) ?>
                        </div>
                        <div class="card-date" style="margin-bottom: 0; color: #9aa1b4;"><?= htmlspecialchars($inf['date'] ?? '') ?></div>
                    </div>
                <?php endforeach; ?>
            <?php endif; ?>
            <div class="no-more">No more</div>
        </div>

    </div>
</div>

<div class="toast" id="toast"></div>

<script>
// Tab Navigation Switcher
function switchTab(tab) {
    const btnNotif = document.getElementById('tabBtnNotif');
    const btnInfo = document.getElementById('tabBtnInfo');
    const paneNotif = document.getElementById('paneNotif');
    const paneInfo = document.getElementById('paneInfo');

    if (tab === 'notif') {
        btnNotif.classList.add('active');
        btnInfo.classList.remove('active');
        paneNotif.classList.add('active');
        paneInfo.classList.remove('active');
    } else {
        btnInfo.classList.add('active');
        btnNotif.classList.remove('active');
        paneInfo.classList.add('active');
        paneNotif.classList.remove('active');
    }
}

// Toast Popup Function
function showToast(msg) {
    const t = document.getElementById('toast');
    t.textContent = msg;
    t.classList.add('show');
    clearTimeout(window._t);
    window._t = setTimeout(() => t.classList.remove('show'), 2000);
}

// Delete Notification via Ajax
async function deleteNotif(id) {
    const card = document.getElementById('card_' + id);
    if (card) {
        card.classList.add('removing');
    }
    
    const fd = new FormData();
    fd.append('action', 'delete_notification');
    fd.append('id', id);

    try {
        const res = await fetch(location.href, { method: 'POST', body: fd });
        const data = await res.json();
        if (data.success) {
            setTimeout(() => {
                if (card) card.remove();
            }, 300);
            showToast('Notification deleted');
        } else {
            if (card) card.classList.remove('removing');
            showToast(data.message || 'Failed to delete');
        }
    } catch (e) {
        if (card) card.classList.remove('removing');
        showToast('Network error');
    }
}

// =========================================================================
// 4. BROWSER PUSH NOTIFICATION SYSTEM (Shows in Phone's Top Notification Bar)
// =========================================================================
document.addEventListener('DOMContentLoaded', () => {
    // Request permission if not granted
    if ("Notification" in window) {
        if (Notification.permission === "default") {
            Notification.requestPermission();
        }
        
        <?php if ($latestNotif): ?>
        const latestId = <?= json_encode($latestNotif['id']) ?>;
        const latestTitle = <?= json_encode($latestNotif['title']) ?>;
        const latestBody = <?= json_encode($latestNotif['message']) ?>;
        const lastPushedId = localStorage.getItem('3win_last_pushed_notif');

        // If a new deposit or notification occurred, trigger Chrome OS push notification
        if (lastPushedId !== latestId && Notification.permission === "granted") {
            try {
                const notif = new Notification(latestTitle + " — 3win", {
                    body: latestBody,
                    icon: 'https://cdn-icons-png.flaticon.com/512/1490/1490853.png',
                    badge: 'https://cdn-icons-png.flaticon.com/512/1490/1490853.png'
                });
                notif.onclick = function() {
                    window.focus();
                    window.location.href = 'notification.php';
                };
                localStorage.setItem('3win_last_pushed_notif', latestId);
            } catch (err) {
                console.log("Notification trigger err:", err);
            }
        }
        <?php endif; ?>
    }
});
</script>
</body>
</html>