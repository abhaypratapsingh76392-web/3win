<?php
session_start();
error_reporting(0);
date_default_timezone_set('Asia/Kolkata');
require_once 'config.php';

$phone = $_SESSION['user_phone'] ?? $_SESSION['phone'] ?? '';
if ($phone === '') {
    header('Location: index.php');
    exit;
}
$_SESSION['user_phone'] = $phone;
$_SESSION['phone'] = $phone;

function jsonOut(array $data): void {
    header('Content-Type: application/json');
    echo json_encode($data);
    exit;
}

// Handle Feedback Submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';

    if ($action === 'submit_feedback') {
        $message = trim($_POST['message'] ?? '');

        if ($message === '') {
            jsonOut(['success' => false, 'message' => 'Please enter your feedback description']);
        }

        if (mb_strlen($message) < 5) {
            jsonOut(['success' => false, 'message' => 'Feedback is too short (minimum 5 characters)']);
        }

        $feedbackId = 'fb_' . time() . '_' . rand(100, 999);
        $dateNow = date('Y-m-d H:i:s');

        $feedbackData = [
            'id' => $feedbackId,
            'phone' => $phone,
            'message' => $message,
            'created_at' => $dateNow,
            'status' => 'Pending'
        ];

        // Write to Global Admin Feedbacks collection & User's personal collection
        firebase_write("feedbacks/$feedbackId", $feedbackData);
        firebase_write("users/$phone/feedbacks/$feedbackId", $feedbackData);

        jsonOut(['success' => true, 'message' => 'Feedback submitted successfully! Thank you.']);
    }

    jsonOut(['success' => false, 'message' => 'Unknown action']);
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
<title>Feedback</title>
<style>
* { margin: 0; padding: 0; box-sizing: border-box; font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif; -webkit-tap-highlight-color: transparent; }
body { background: #f5f6fa; color: #222; min-height: 100vh; display: flex; justify-content: center; }
.app { width: 100%; max-width: 480px; min-height: 100vh; background: #f5f6fa; display: flex; flex-direction: column; position: relative; padding-bottom: 25px; }

/* HEADER */
.header { height: 50px; background: #fff; display: flex; align-items: center; justify-content: center; position: sticky; top: 0; z-index: 50; border-bottom: 1px solid #f0f1f5; }
.back-btn { position: absolute; left: 16px; font-size: 26px; color: #333; text-decoration: none; cursor: pointer; line-height: 1; display: flex; align-items: center; justify-content: center; }
.header-title { font-size: 18px; font-weight: 500; color: #222; }

/* MAIN CONTAINER */
.content { flex: 1; padding: 14px 16px; display: flex; flex-direction: column; align-items: center; }

/* FEEDBACK TEXTAREA CARD */
.feedback-card { width: 100%; background: #fff; border-radius: 16px; padding: 16px; height: 360px; box-shadow: 0 1px 4px rgba(0,0,0,0.02); display: flex; flex-direction: column; margin-bottom: 24px; }
.feedback-textarea { width: 100%; height: 100%; border: none; outline: none; resize: none; background: transparent; font-size: 14.5px; line-height: 1.5; color: #333; }
.feedback-textarea::placeholder { color: #b0b7c3; font-size: 14px; line-height: 1.45; }

/* REWARD PROMO SECTION */
.promo-section { text-align: center; display: flex; flex-direction: column; align-items: center; margin-bottom: 18px; }
.promo-title { font-size: 15px; color: #333; font-weight: 400; margin-bottom: 4px; }
.promo-subtitle { font-size: 16px; color: #1e2229; font-weight: 500; margin-bottom: 16px; }

/* ILLUSTRATION IMAGE */
.promo-img-wrap { width: 100%; max-width: 250px; display: flex; align-items: center; justify-content: center; }
.promo-img { width: 100%; height: auto; object-fit: contain; }

/* BOTTOM SUBMIT BUTTON */
.btn-wrap { width: 100%; padding: 0 16px; margin-top: auto; }
.submit-btn { width: 100%; height: 48px; border-radius: 26px; background: #418dfd; color: #fff; border: none; font-size: 16px; font-weight: 600; cursor: pointer; display: flex; align-items: center; justify-content: center; transition: all 0.2s ease; box-shadow: 0 4px 12px rgba(65, 141, 253, 0.25); }
.submit-btn:active { transform: scale(0.98); background: #357ae8; }
.submit-btn.disabled { opacity: 0.6; pointer-events: none; }

/* TOAST POPUP */
.toast { position: fixed; top: 50%; left: 50%; transform: translate(-50%, -50%) scale(0.85); background: rgba(0,0,0,0.82); color: #fff; padding: 12px 24px; border-radius: 25px; font-size: 14px; font-weight: 500; opacity: 0; pointer-events: none; transition: 0.25s; z-index: 1000; text-align: center; max-width: 80%; }
.toast.show { opacity: 1; transform: translate(-50%, -50%) scale(1); }
</style>
</head>
<body>

<div class="app">
    <!-- TOP BAR -->
    <div class="header">
        <a href="account.php" class="back-btn">‹</a>
        <div class="header-title">Feedback</div>
    </div>

    <!-- MAIN BODY -->
    <div class="content">
        <!-- TEXTAREA CARD (Exact placeholder from screenshot) -->
        <div class="feedback-card">
            <textarea 
                id="feedbackText" 
                class="feedback-textarea" 
                placeholder="Welcome to feedback, please give feedback-please describe the problem in detail when providing feedback, preferably attach a screenshot of the problem you encountered, we will immediately process your feedback!"></textarea>
        </div>

        <!-- REWARD PROMPT & ILLUSTRATION -->
        <div class="promo-section">
            <div class="promo-title">Send helpful feedback</div>
            <div class="promo-subtitle">Chance to win Mystery Rewards</div>
            <div class="promo-img-wrap">
                <img 
                    src="https://www.goaok.org/assets/png/feedbackImg-BEw7MHRr.png" 
                    alt="Mystery Rewards" 
                    class="promo-img"
                    onerror="this.onerror=null; this.src='https://cdn-icons-png.flaticon.com/512/7486/7486744.png';">
            </div>
        </div>
    </div>

    <!-- SUBMIT BUTTON -->
    <div class="btn-wrap">
        <button type="button" class="submit-btn" id="submitBtn" onclick="submitFeedback()">Submit</button>
    </div>
</div>

<div class="toast" id="toast"></div>

<script>
// Toast Notification
function showToast(msg) {
    const t = document.getElementById('toast');
    t.textContent = msg;
    t.classList.add('show');
    clearTimeout(window._t);
    window._t = setTimeout(() => t.classList.remove('show'), 2200);
}

// Submit Feedback via AJAX to Firebase
async function submitFeedback() {
    const textarea = document.getElementById('feedbackText');
    const btn = document.getElementById('submitBtn');
    const text = textarea.value.trim();

    if (!text) {
        showToast('Please enter your feedback description');
        textarea.focus();
        return;
    }

    if (text.length < 5) {
        showToast('Feedback is too short (min 5 characters)');
        return;
    }

    btn.classList.add('disabled');
    btn.textContent = 'Submitting...';

    const fd = new FormData();
    fd.append('action', 'submit_feedback');
    fd.append('message', text);

    try {
        const res = await fetch(location.href, { method: 'POST', body: fd });
        const data = await res.json();

        if (data.success) {
            showToast(data.message);
            textarea.value = ''; // clear textarea
            setTimeout(() => {
                window.location.href = 'account.php';
            }, 1500);
        } else {
            showToast(data.message || 'Failed to submit');
            btn.classList.remove('disabled');
            btn.textContent = 'Submit';
        }
    } catch (e) {
        showToast('Network error, please try again');
        btn.classList.remove('disabled');
        btn.textContent = 'Submit';
    }
}
</script>
</body>
</html>