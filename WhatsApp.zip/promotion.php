<?php
declare(strict_types=1);

session_start();
require_once __DIR__ . '/config.php';

if (!isset($_SESSION['user_phone']) || empty($_SESSION['user_phone'])) {
    header('Location: index.php');
    exit;
}

$phone = (string)$_SESSION['user_phone'];

/*
|--------------------------------------------------------------------------
| Firebase config adapter
|--------------------------------------------------------------------------
| config.php ko change nahi kiya gaya.
| Ye common variable names automatically read karega.
|--------------------------------------------------------------------------
*/

function cfg_value(array $constantNames, array $variableNames): string
{
    foreach ($constantNames as $name) {
        if (defined($name) && constant($name) !== '') {
            return (string)constant($name);
        }
    }

    foreach ($variableNames as $name) {
        if (isset($GLOBALS[$name]) && $GLOBALS[$name] !== '') {
            return (string)$GLOBALS[$name];
        }
    }

    return '';
}

$FIREBASE_URL = rtrim(cfg_value(
    ['FIREBASE_DATABASE_URL', 'FIREBASE_URL', 'DATABASE_URL'],
    [
        'firebase_database_url',
        'firebase_url',
        'database_url',
        'databaseURL',
        'firebaseDatabaseUrl',
        'databaseUrl'
    ]
), '/');

$FIREBASE_TOKEN = cfg_value(
    [
        'FIREBASE_DATABASE_SECRET',
        'FIREBASE_AUTH_TOKEN',
        'FIREBASE_ID_TOKEN',
        'DATABASE_SECRET'
    ],
    [
        'firebase_database_secret',
        'firebase_secret',
        'firebase_token',
        'firebase_auth_token',
        'database_secret',
        'database_token'
    ]
);

$FB_ERROR = '';
$FB_OK = false;

/*
|--------------------------------------------------------------------------
| Firebase REST helper
|--------------------------------------------------------------------------
*/

function firebase_request(
    string $path,
    string $method = 'GET',
    $payload = null
) {
    global $FIREBASE_URL, $FIREBASE_TOKEN, $FB_ERROR, $FB_OK;

    $FB_ERROR = '';
    $FB_OK = false;

    if ($FIREBASE_URL === '') {
        $FB_ERROR = 'Firebase database URL config.php me nahi mila.';
        return null;
    }

    $cleanPath = trim($path, '/');

    $url = $FIREBASE_URL . '/';

    if ($cleanPath !== '') {
        $url .= $cleanPath . '/';
    }

    $url .= '.json';

    if ($FIREBASE_TOKEN !== '') {
        $url .= '?auth=' . rawurlencode($FIREBASE_TOKEN);
    }

    $body = null;

    if ($payload !== null) {
        $body = json_encode(
            $payload,
            JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES
        );
    }

    if (!function_exists('curl_init')) {
        $FB_ERROR = 'PHP cURL extension enabled nahi hai.';
        return null;
    }

    $ch = curl_init($url);

    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_CUSTOMREQUEST  => strtoupper($method),
        CURLOPT_CONNECTTIMEOUT => 10,
        CURLOPT_TIMEOUT        => 20,
        CURLOPT_HTTPHEADER     => [
            'Content-Type: application/json'
        ]
    ]);

    if ($body !== null) {
        curl_setopt($ch, CURLOPT_POSTFIELDS, $body);
    }

    $response = curl_exec($ch);
    $curlError = curl_error($ch);
    $httpCode = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);

    curl_close($ch);

    if ($response === false || $curlError !== '') {
        $FB_ERROR = $curlError ?: 'Firebase request failed.';
        return null;
    }

    if ($httpCode < 200 || $httpCode >= 300) {
        $FB_ERROR = 'Firebase HTTP error: ' . $httpCode;
        return null;
    }

    $FB_OK = true;

    if ($response === '' || $response === 'null') {
        return null;
    }

    $decoded = json_decode($response, true);

    return $decoded;
}

function firebase_get(string $path)
{
    return firebase_request($path, 'GET');
}

function firebase_put(string $path, $data)
{
    return firebase_request($path, 'PUT', $data);
}

function firebase_patch_root(array $data)
{
    return firebase_request('', 'PATCH', $data);
}

/*
|--------------------------------------------------------------------------
| General helpers
|--------------------------------------------------------------------------
*/

function esc($value): string
{
    return htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8');
}

function db_key(string $value): string
{
    /*
     * Firebase key me ye characters allowed nahi hote:
     * . # $ [ ] /
     */
    return str_replace(
        ['.', '#', '$', '[', ']', '/'],
        '_',
        trim($value)
    );
}

function db_path_key(string $value): string
{
    return rawurlencode(db_key($value));
}

function number_value($value): float
{
    if (is_bool($value)) {
        return $value ? 1 : 0;
    }

    if ($value === null || $value === '') {
        return 0;
    }

    $value = str_replace(['₹', ',', ' '], '', (string)$value);

    return (float)$value;
}

function money($value): string
{
    return '₹' . number_format(number_value($value), 2);
}

function get_field(array $row, array $keys, $default = null)
{
    foreach ($keys as $key) {
        if (array_key_exists($key, $row)) {
            return $row[$key];
        }
    }

    return $default;
}

function timestamp_value($value): int
{
    if ($value === null || $value === '') {
        return 0;
    }

    if (is_numeric($value)) {
        $number = (int)$value;

        if ($number > 20000000000) {
            return (int)floor($number / 1000);
        }

        return $number;
    }

    $time = strtotime((string)$value);

    return $time ?: 0;
}

function date_text($value): string
{
    $time = timestamp_value($value);

    if (!$time) {
        return '—';
    }

    return date('d M Y, h:i A', $time);
}

function masked_phone(string $phone): string
{
    $phone = trim($phone);

    if (strlen($phone) <= 4) {
        return $phone;
    }

    return substr($phone, 0, 3) . '****' . substr($phone, -3);
}

function make_invite_code(string $phone): string
{
    return '3W' . strtoupper(substr(hash('sha256', '3win|' . $phone), 0, 8));
}

function is_claimed(array $claims, int $level): bool
{
    $key = (string)$level;

    if (!array_key_exists($key, $claims) && !array_key_exists($level, $claims)) {
        return false;
    }

    $value = $claims[$key] ?? $claims[$level];

    return $value !== null && $value !== false && $value !== '';
}

function period_match(int $time, string $period): bool
{
    if (!$time) {
        return true;
    }

    $today = strtotime('today');

    if ($period === 'today') {
        return $time >= $today;
    }

    if ($period === 'yesterday') {
        return $time >= strtotime('yesterday') && $time < $today;
    }

    if ($period === 'month') {
        return $time >= strtotime(date('Y-m-01 00:00:00'));
    }

    return true;
}

/*
|--------------------------------------------------------------------------
| User profile
|--------------------------------------------------------------------------
*/

$phoneDbKey = db_key($phone);

$profile = firebase_get('users/' . db_path_key($phone));

if (!is_array($profile)) {
    $profile = [];
}

$inviteCode = (string)get_field(
    $profile,
    ['inviteCode', 'invite_code', 'referralCode', 'referral_code'],
    ''
);

if ($inviteCode === '') {
    $inviteCode = make_invite_code($phone);

    /*
     * Existing user ke profile me invite code save hoga.
     * Agar Firebase rules allow na kare to page phir bhi code show karega.
     */
    firebase_put(
        'users/' . db_path_key($phone) . '/inviteCode',
        $inviteCode
    );

    firebase_put(
        'inviteCodes/' . rawurlencode($inviteCode),
        $phone
    );
}

/*
|--------------------------------------------------------------------------
| Invitation URL
|--------------------------------------------------------------------------
*/

$scheme = (
    (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off')
    ? 'https'
    : 'http'
);

$host = $_SERVER['HTTP_HOST'] ?? 'localhost';

$directory = str_replace(
    '\\',
    '/',
    dirname($_SERVER['SCRIPT_NAME'] ?? '')
);

if ($directory === '/' || $directory === '.') {
    $directory = '';
}

/*
 * Agar signup page index.php nahi hai to sirf neeche wali line change karein.
 */
$signupPage = 'index.php';

$inviteUrl = $scheme . '://' . $host .
    ($directory ? $directory . '/' : '/') .
    $signupPage .
    '?invite=' . rawurlencode($inviteCode);

$qrUrl = 'https://api.qrserver.com/v1/create-qr-code/?size=600x600&margin=12&data=' .
    rawurlencode($inviteUrl);

/*
|--------------------------------------------------------------------------
| Referrals
|--------------------------------------------------------------------------
| Expected path:
| referrals/{ownerPhone}/{newUserPhone}
|--------------------------------------------------------------------------
*/

$referralRaw = firebase_get(
    'referrals/' . db_path_key($phone)
);

if (!is_array($referralRaw)) {
    $referralRaw = [];
}

if (
    empty($referralRaw) &&
    isset($profile['referrals']) &&
    is_array($profile['referrals'])
) {
    $referralRaw = $profile['referrals'];
}

$referrals = [];

foreach ($referralRaw as $key => $row) {
    if (!is_array($row)) {
        $row = [
            'phone' => (string)$row
        ];
    }

    $referredPhone = (string)get_field(
        $row,
        ['phone', 'userPhone', 'mobile', 'subordinatePhone'],
        $key
    );

    if ($referredPhone === '' || $referredPhone === 'meta') {
        continue;
    }

    $deposit = max(
        number_value(get_field($row, [
            'totalRecharge',
            'total_recharge',
            'rechargeAmount',
            'recharge_amount',
            'depositAmount',
            'deposit_amount',
            'firstRecharge',
            'first_recharge',
            'firstDeposit',
            'first_deposit'
        ], 0))
    );

    $registeredAt = get_field($row, [
        'registeredAt',
        'registered_at',
        'createdAt',
        'created_at',
        'date'
    ], '');

    $referrals[] = [
        'phone' => $referredPhone,
        'deposit' => $deposit,
        'registeredAt' => $registeredAt,
        'time' => timestamp_value($registeredAt),
        'status' => $deposit > 0 ? 'Deposited' : 'Registered'
    ];
}

/*
|--------------------------------------------------------------------------
| Commission records
|--------------------------------------------------------------------------
| Expected path:
| commissions/{ownerPhone}/{commissionId}
|--------------------------------------------------------------------------
*/

$commissionRaw = firebase_get(
    'commissions/' . db_path_key($phone)
);

if (!is_array($commissionRaw)) {
    $commissionRaw = [];
}

$commissions = [];

foreach ($commissionRaw as $key => $row) {
    if (!is_array($row)) {
        $row = [
            'amount' => $row
        ];
    }

    $amount = number_value(get_field($row, [
        'amount',
        'commission',
        'bonus',
        'value'
    ], 0));

    $createdAt = get_field($row, [
        'createdAt',
        'created_at',
        'date',
        'time'
    ], '');

    $commissions[] = [
        'id' => $key,
        'amount' => $amount,
        'type' => (string)get_field($row, [
            'type',
            'source',
            'title'
        ], 'Commission'),
        'createdAt' => $createdAt,
        'time' => timestamp_value($createdAt)
    ];
}

/*
|--------------------------------------------------------------------------
| Claimed bonuses
|--------------------------------------------------------------------------
| Expected path:
| promotionClaims/{ownerPhone}/{level}
|--------------------------------------------------------------------------
*/

$claims = firebase_get(
    'promotionClaims/' . db_path_key($phone)
);

if (!is_array($claims)) {
    $claims = [];
}

/*
|--------------------------------------------------------------------------
| Bonus levels
|--------------------------------------------------------------------------
*/

$tiers = [
    ['people' => 1,    'recharge' => 300,  'bonus' => 58],
    ['people' => 3,    'recharge' => 500,  'bonus' => 188],
    ['people' => 10,   'recharge' => 600,  'bonus' => 588],
    ['people' => 30,   'recharge' => 700,  'bonus' => 1588],
    ['people' => 70,   'recharge' => 800,  'bonus' => 3588],
    ['people' => 150,  'recharge' => 900,  'bonus' => 5888],
    ['people' => 300,  'recharge' => 1000, 'bonus' => 12888],
    ['people' => 500,  'recharge' => 1100, 'bonus' => 25888],
    ['people' => 1000, 'recharge' => 1200, 'bonus' => 58888],
    ['people' => 3000, 'recharge' => 1200, 'bonus' => 158888],
    ['people' => 6000, 'recharge' => 1200, 'bonus' => 358888],
    ['people' => 10000,'recharge' => 1200, 'bonus' => 588888]
];

$registeredCount = count($referrals);

$depositCount = 0;
$totalDeposit = 0;

foreach ($referrals as $referral) {
    if ($referral['deposit'] > 0) {
        $depositCount++;
        $totalDeposit += $referral['deposit'];
    }
}

$totalCommission = 0;
$todayCommission = 0;
$yesterdayCommission = 0;
$monthCommission = 0;

foreach ($commissions as $commission) {
    $totalCommission += $commission['amount'];

    if (period_match($commission['time'], 'today')) {
        $todayCommission += $commission['amount'];
    }

    if (period_match($commission['time'], 'yesterday')) {
        $yesterdayCommission += $commission['amount'];
    }

    if (period_match($commission['time'], 'month')) {
        $monthCommission += $commission['amount'];
    }
}

/*
|--------------------------------------------------------------------------
| Claim action
|--------------------------------------------------------------------------
*/

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';

    if ($action === 'claim_bonus') {
        $csrf = (string)($_POST['csrf'] ?? '');

        if (
            empty($_SESSION['promotion_csrf']) ||
            !hash_equals($_SESSION['promotion_csrf'], $csrf)
        ) {
            header('Location: promotion.php?view=rules&msg=security');
            exit;
        }

        $level = (int)($_POST['level'] ?? 0);

        if (!isset($tiers[$level])) {
            header('Location: promotion.php?view=rules&msg=invalid');
            exit;
        }

        $tier = $tiers[$level];

        if (is_claimed($claims, $level)) {
            header('Location: promotion.php?view=rules&msg=already');
            exit;
        }

        $qualifiedPeople = 0;

        foreach ($referrals as $referral) {
            if ($referral['deposit'] >= $tier['recharge']) {
                $qualifiedPeople++;
            }
        }

        if ($qualifiedPeople < $tier['people']) {
            header('Location: promotion.php?view=rules&msg=unfinished');
            exit;
        }

        /*
         * Wallet balance field detect.
         * Aapke user record me jo field milegi usi me bonus add hoga.
         */
        $balanceField = 'balance';

        foreach (['balance', 'walletBalance', 'wallet_balance', 'money'] as $field) {
            if (array_key_exists($field, $profile)) {
                $balanceField = $field;
                break;
            }
        }

        $oldBalance = number_value($profile[$balanceField] ?? 0);
        $newBalance = $oldBalance + (float)$tier['bonus'];

        $claimData = [
            'level' => $level + 1,
            'amount' => (float)$tier['bonus'],
            'people' => (int)$tier['people'],
            'minimumRecharge' => (float)$tier['recharge'],
            'claimedAt' => date('c'),
            'phone' => $phone
        ];

        $transactionId = 'invite_bonus_' . ($level + 1);

        /*
         * Multi-location update:
         * - claim record
         * - commission record
         * - wallet balance
         */
        $updates = [];

        $updates[
            'promotionClaims/' . $phoneDbKey . '/' . ($level + 1)
        ] = $claimData;

        $updates[
            'commissions/' . $phoneDbKey . '/' . $transactionId
        ] = [
            'amount' => (float)$tier['bonus'],
            'type' => 'Invitation Bonus ' . ($level + 1),
            'source' => 'promotion',
            'createdAt' => date('c'),
            'createdBy' => $phone
        ];

        $updates[
            'users/' . $phoneDbKey . '/' . $balanceField
        ] = $newBalance;

        firebase_patch_root($updates);

        if ($FB_OK) {
            header('Location: promotion.php?view=rules&msg=claimed');
            exit;
        }

        header('Location: promotion.php?view=rules&msg=failed');
        exit;
    }
}

if (!isset($_SESSION['promotion_csrf'])) {
    $_SESSION['promotion_csrf'] = bin2hex(random_bytes(24));
}

$csrfToken = $_SESSION['promotion_csrf'];

$view = $_GET['view'] ?? 'home';

$allowedViews = [
    'home',
    'invite',
    'rules',
    'records',
    'subordinates',
    'commissions',
    'rebate'
];

if (!in_array($view, $allowedViews, true)) {
    $view = 'home';
}

/*
|--------------------------------------------------------------------------
| JSON endpoint for live refresh
|--------------------------------------------------------------------------
*/

if (isset($_GET['data']) && $_GET['data'] === '1') {
    header('Content-Type: application/json; charset=utf-8');

    echo json_encode([
        'registered' => $registeredCount,
        'deposits' => $depositCount,
        'depositAmount' => $totalDeposit,
        'commission' => $totalCommission,
        'todayCommission' => $todayCommission,
        'code' => $inviteCode
    ], JSON_UNESCAPED_UNICODE);

    exit;
}

$message = $_GET['msg'] ?? '';

$messageText = [
    'claimed' => 'Bonus successfully claim ho gaya.',
    'already' => 'Ye bonus pehle hi claim ho chuka hai.',
    'unfinished' => 'Is bonus ke liye condition complete nahi hui.',
    'security' => 'Security verification failed.',
    'invalid' => 'Invalid bonus level.',
    'failed' => 'Claim fail hua. Firebase rules check karein.'
];

$pageTitle = 'Agency';
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">

<title><?= esc($pageTitle) ?></title>

<link href="https://fonts.googleapis.com/icon?family=Material+Icons+Round" rel="stylesheet">

<style>
:root {
    --blue: #4781ff;
    --blue2: #63a9ff;
    --light: #f4f6ff;
    --text: #252b3d;
    --muted: #7b8499;
    --green: #16b96b;
    --orange: #ffad4a;
    --red: #f15d68;
    --white: #ffffff;
}

* {
    box-sizing: border-box;
    margin: 0;
    padding: 0;
    font-family: Arial, Helvetica, sans-serif;
    -webkit-tap-highlight-color: transparent;
}

html {
    scroll-behavior: smooth;
}

body {
    background: var(--light);
    color: var(--text);
    padding-bottom: 88px;
}

.app {
    width: 100%;
    max-width: 480px;
    margin: auto;
    min-height: 100vh;
    background: var(--light);
    overflow-x: hidden;
}

.topbar {
    height: 72px;
    background: var(--white);
    display: flex;
    align-items: center;
    justify-content: center;
    position: sticky;
    top: 0;
    z-index: 20;
    border-bottom: 1px solid #eef0f8;
}

.topbar h1 {
    font-size: 25px;
    font-weight: 500;
}

.back {
    position: absolute;
    left: 17px;
    color: var(--text);
    text-decoration: none;
    display: flex;
    align-items: center;
}

.back span {
    font-size: 34px;
}

.header-action {
    position: absolute;
    right: 18px;
    color: var(--blue);
}

.content {
    padding: 16px;
}

.hero {
    background: linear-gradient(135deg, #4380ff, #65b2ff);
    color: white;
    border-radius: 0 0 28px 28px;
    padding: 28px 18px 23px;
    margin: -16px -16px 16px;
    text-align: center;
}

.hero small {
    display: inline-block;
    background: white;
    color: var(--blue);
    padding: 10px 19px;
    border-radius: 30px;
    font-size: 16px;
}

.hero h2 {
    font-size: 45px;
    font-weight: 400;
    margin-bottom: 10px;
}

.hero p {
    margin-top: 14px;
    font-size: 14px;
}

.stats-card {
    background: white;
    border-radius: 18px;
    overflow: hidden;
    box-shadow: 0 5px 20px rgba(63, 89, 170, .08);
}

.stats-head {
    background: var(--blue);
    color: white;
    display: grid;
    grid-template-columns: 1fr 1fr;
    text-align: center;
    padding: 17px 5px;
    font-size: 18px;
}

.stats-body {
    display: grid;
    grid-template-columns: 1fr 1fr;
    text-align: center;
}

.stat-box {
    padding: 17px 8px;
    min-height: 125px;
    border-right: 1px solid #edf0f7;
}

.stat-box:last-child {
    border-right: 0;
}

.stat-number {
    font-size: 25px;
    margin: 10px 0;
}

.stat-number.green {
    color: var(--green);
}

.stat-number.orange {
    color: var(--orange);
}

.stat-label {
    color: var(--text);
    font-size: 14px;
    line-height: 1.3;
}

.primary-btn,
.secondary-btn {
    width: 100%;
    min-height: 56px;
    border-radius: 30px;
    display: flex;
    align-items: center;
    justify-content: center;
    text-decoration: none;
    border: 0;
    cursor: pointer;
    font-size: 18px;
    font-weight: bold;
    margin: 16px 0;
}

.primary-btn {
    background: linear-gradient(90deg, #4382ff, #60adff);
    color: white;
}

.secondary-btn {
    background: white;
    color: var(--blue);
    border: 1px solid var(--blue);
}

.menu-list {
    display: flex;
    flex-direction: column;
    gap: 12px;
    margin-top: 16px;
}

.menu-item {
    background: white;
    min-height: 78px;
    border-radius: 18px;
    padding: 15px 16px;
    display: flex;
    align-items: center;
    gap: 14px;
    color: var(--text);
    text-decoration: none;
    box-shadow: 0 5px 18px rgba(63, 89, 170, .05);
}

.menu-icon {
    width: 48px;
    height: 48px;
    border-radius: 14px;
    background: #cfe0ff;
    color: var(--blue);
    display: flex;
    align-items: center;
    justify-content: center;
    flex-shrink: 0;
}

.menu-icon span {
    font-size: 29px;
}

.menu-title {
    font-size: 18px;
    flex: 1;
}

.menu-item .arrow {
    color: var(--text);
    font-size: 30px;
}

.promotion-data {
    background: white;
    border-radius: 18px;
    padding: 17px 8px;
    margin-top: 16px;
    box-shadow: 0 5px 18px rgba(63, 89, 170, .05);
}

.promotion-data h3 {
    font-size: 19px;
    margin: 0 9px 18px;
}

.promotion-grid {
    display: grid;
    grid-template-columns: 1fr 1fr;
    text-align: center;
}

.promotion-grid div {
    padding: 12px 5px;
    border-right: 1px solid #edf0f7;
}

.promotion-grid div:nth-child(2n) {
    border-right: 0;
}

.promotion-grid strong {
    display: block;
    font-size: 22px;
    margin-bottom: 7px;
}

.promotion-grid span {
    color: var(--muted);
    font-size: 14px;
}

.invite-box {
    background: white;
    border-radius: 18px;
    padding: 20px;
    text-align: center;
    box-shadow: 0 5px 18px rgba(63, 89, 170, .06);
}

.invite-box img.qr {
    width: 230px;
    height: 230px;
    object-fit: contain;
    display: block;
    margin: 10px auto 18px;
    border-radius: 12px;
}

.invite-title {
    color: var(--muted);
    font-size: 16px;
    margin-bottom: 8px;
}

.invite-code {
    background: #f0f4ff;
    color: var(--blue);
    border-radius: 12px;
    padding: 14px 10px;
    font-size: 23px;
    font-weight: bold;
    letter-spacing: 1px;
}

.link-box {
    background: #f5f6fa;
    color: #666e80;
    padding: 12px;
    border-radius: 11px;
    word-break: break-all;
    font-size: 12px;
    margin-top: 12px;
}

.share-row {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 10px;
}

.share-row a,
.share-row button {
    border: 0;
    min-height: 48px;
    border-radius: 25px;
    cursor: pointer;
    text-decoration: none;
    background: var(--blue);
    color: white;
    font-weight: bold;
    display: flex;
    align-items: center;
    justify-content: center;
}

.poster {
    background: linear-gradient(145deg, #0668ba, #1ec6d1);
    border-radius: 20px;
    color: white;
    padding: 24px 18px;
    margin: 16px 0;
    text-align: center;
    overflow: hidden;
}

.poster h2 {
    font-size: 27px;
    margin-bottom: 13px;
}

.poster p {
    font-size: 15px;
    line-height: 1.6;
}

.poster strong {
    color: #ffe96d;
}

.rule-card {
    background: white;
    border-radius: 18px;
    margin-bottom: 16px;
    overflow: hidden;
    box-shadow: 0 5px 18px rgba(63, 89, 170, .06);
}

.rule-head {
    display: flex;
    justify-content: space-between;
    align-items: center;
    background: var(--green);
    color: white;
    padding: 18px;
}

.rule-head strong {
    font-size: 20px;
}

.rule-bonus {
    font-size: 22px;
    font-weight: bold;
    color: var(--orange);
}

.rule-body {
    padding: 14px;
}

.rule-line {
    display: flex;
    justify-content: space-between;
    background: #f6f6f6;
    padding: 12px;
    margin-bottom: 8px;
    border-radius: 7px;
    font-size: 15px;
}

.progress-area {
    border-top: 1px dashed #d7d9e2;
    margin-top: 17px;
    padding-top: 17px;
    text-align: center;
}

.progress-number {
    color: var(--orange);
    font-size: 28px;
    font-weight: bold;
}

.progress-label {
    color: var(--muted);
    margin: 5px 0 15px;
}

.claim-btn {
    width: 100%;
    border: 0;
    border-radius: 26px;
    padding: 13px;
    background: var(--green);
    color: white;
    font-size: 16px;
    font-weight: bold;
    cursor: pointer;
}

.claim-btn:disabled,
.claim-disabled {
    background: #c9ccd9;
    cursor: not-allowed;
}

.records-tabs {
    display: grid;
    grid-template-columns: repeat(3, 1fr);
    gap: 8px;
    margin-bottom: 16px;
}

.records-tabs a {
    background: white;
    color: var(--muted);
    text-decoration: none;
    text-align: center;
    padding: 14px 5px;
    border-radius: 14px;
    font-size: 13px;
}

.records-tabs a.active {
    background: var(--blue);
    color: white;
}

.record-list {
    display: flex;
    flex-direction: column;
    gap: 10px;
}

.record {
    background: white;
    border-radius: 16px;
    padding: 15px;
    display: flex;
    justify-content: space-between;
    gap: 8px;
    align-items: center;
}

.record-left strong {
    display: block;
    font-size: 16px;
    margin-bottom: 5px;
}

.record-left small {
    color: var(--muted);
}

.record-right {
    text-align: right;
}

.record-right strong {
    color: var(--green);
}

.status {
    display: inline-block;
    padding: 5px 9px;
    border-radius: 20px;
    font-size: 11px;
    font-weight: bold;
    margin-top: 5px;
}

.status.done {
    color: #0b9954;
    background: #d9f9e8;
}

.status.wait {
    color: #9b7b00;
    background: #fff3c7;
}

.empty {
    background: white;
    padding: 45px 20px;
    text-align: center;
    border-radius: 18px;
    color: var(--muted);
}

.table-wrap {
    overflow-x: auto;
    background: white;
    border-radius: 18px;
}

table {
    width: 100%;
    border-collapse: collapse;
    min-width: 440px;
}

th {
    background: var(--blue);
    color: white;
    padding: 15px 10px;
    text-align: left;
    font-size: 14px;
}

td {
    padding: 14px 10px;
    border-bottom: 1px solid #eeeeF5;
    font-size: 14px;
}

tr:nth-child(even) td {
    background: #fafafa;
}

.info-card {
    background: white;
    border-radius: 18px;
    padding: 20px;
    line-height: 1.7;
    color: var(--muted);
    margin-bottom: 16px;
}

.copy-code {
    background: white;
    border-radius: 17px;
    padding: 16px;
    display: flex;
    align-items: center;
    gap: 10px;
    margin-bottom: 14px;
}

.copy-code .material-icons-round {
    color: var(--blue);
    font-size: 32px;
}

.copy-code span.value {
    flex: 1;
    color: var(--muted);
    font-size: 17px;
    word-break: break-all;
}

.copy-small {
    border: 0;
    background: transparent;
    color: var(--blue);
    cursor: pointer;
}

.alert {
    background: #fff3cd;
    color: #7c5e00;
    padding: 12px 15px;
    border-radius: 12px;
    margin-bottom: 14px;
    font-size: 14px;
}

.success-alert {
    background: #d9f9e8;
    color: #087c43;
}

.bottom-nav {
    position: fixed;
    left: 50%;
    bottom: 0;
    transform: translateX(-50%);
    width: 100%;
    max-width: 480px;
    height: 78px;
    background: white;
    display: grid;
    grid-template-columns: repeat(5, 1fr);
    align-items: end;
    z-index: 50;
    box-shadow: 0 -5px 22px rgba(0,0,0,.08);
    border-radius: 20px 20px 0 0;
}

.bottom-nav a {
    color: #8b91a1;
    text-decoration: none;
    display: flex;
    align-items: center;
    flex-direction: column;
    justify-content: center;
    gap: 3px;
    height: 70px;
    font-size: 11px;
    font-weight: bold;
}

.bottom-nav a.active {
    color: var(--blue);
}

.bottom-nav .material-icons-round {
    font-size: 26px;
}

.spin-nav {
    margin-top: -28px;
}

.spin-circle {
    width: 65px;
    height: 65px;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    background: white;
    box-shadow: 0 0 0 7px white, 0 5px 15px rgba(0,0,0,.2);
    color: var(--blue);
}

.spin-circle .material-icons-round {
    font-size: 45px;
    color: #f39b32;
}

.toast {
    position: fixed;
    top: 15%;
    left: 50%;
    transform: translateX(-50%);
    background: #111827;
    color: white;
    padding: 13px 20px;
    border-radius: 25px;
    z-index: 100;
    opacity: 0;
    pointer-events: none;
    transition: .2s;
}

.toast.show {
    opacity: 1;
}

@media (max-width: 360px) {
    .hero h2 {
        font-size: 37px;
    }

    .menu-title {
        font-size: 16px;
    }

    .rule-line {
        font-size: 13px;
    }
}
</style>
</head>

<body>

<div class="app">

<?php if ($message !== '' && isset($messageText[$message])): ?>
    <div class="toast show" id="serverToast">
        <?= esc($messageText[$message]) ?>
    </div>
<?php endif; ?>

<?php if ($view === 'home'): ?>

<header class="topbar">
    <a class="back" href="dashboard.php">
        <span class="material-icons-round">arrow_back</span>
    </a>
    <h1>Agency</h1>
</header>

<main class="content">

    <section class="hero">
        <h2 id="liveCommission">
            <?= money($yesterdayCommission) ?>
        </h2>

        <small>Yesterday's total commission</small>

        <p>Upgrade the level to increase commission income</p>
    </section>

    <section class="stats-card">
        <div class="stats-head">
            <div>Direct subordinates</div>
            <div>Team subordinates</div>
        </div>

        <div class="stats-body">
            <div class="stat-box">
                <div class="stat-number" id="registeredCount">
                    <?= $registeredCount ?>
                </div>
                <div class="stat-label">Number of register</div>

                <div class="stat-number green" id="depositCount">
                    <?= $depositCount ?>
                </div>
                <div class="stat-label">Deposit number</div>

                <div class="stat-number orange">
                    <?= money($totalDeposit) ?>
                </div>
                <div class="stat-label">Deposit amount</div>
            </div>

            <div class="stat-box">
                <div class="stat-number">0</div>
                <div class="stat-label">Number of register</div>

                <div class="stat-number green">0</div>
                <div class="stat-label">Deposit number</div>

                <div class="stat-number orange">₹0.00</div>
                <div class="stat-label">Deposit amount</div>
            </div>
        </div>
    </section>

    <a href="promotion.php?view=invite" class="primary-btn">
        INVITATION LINK
    </a>

    <div class="copy-code">
        <span class="material-icons-round">badge</span>
        <span class="value">
            Invitation code: <b><?= esc($inviteCode) ?></b>
        </span>
        <button class="copy-small" onclick="copyText('<?= esc($inviteCode) ?>')">
            <span class="material-icons-round">content_copy</span>
        </button>
    </div>

    <div class="menu-list">

        <a class="menu-item" href="promotion.php?view=subordinates">
            <div class="menu-icon">
                <span class="material-icons-round">description</span>
            </div>
            <div class="menu-title">Subordinate data</div>
            <span class="material-icons-round arrow">chevron_right</span>
        </a>

        <a class="menu-item" href="promotion.php?view=commissions">
            <div class="menu-icon">
                <span class="material-icons-round">attach_money</span>
            </div>
            <div class="menu-title">Commission detail</div>
            <span class="material-icons-round arrow">chevron_right</span>
        </a>

        <a class="menu-item" href="promotion.php?view=rules">
            <div class="menu-icon">
                <span class="material-icons-round">card_giftcard</span>
            </div>
            <div class="menu-title">Invitation rules</div>
            <span class="material-icons-round arrow">chevron_right</span>
        </a>

        <a class="menu-item" href="customer-service.php">
            <div class="menu-icon">
                <span class="material-icons-round">support_agent</span>
            </div>
            <div class="menu-title">Agent line customer service</div>
            <span class="material-icons-round arrow">chevron_right</span>
        </a>

        <a class="menu-item" href="promotion.php?view=rebate">
            <div class="menu-icon">
                <span class="material-icons-round">savings</span>
            </div>
            <div class="menu-title">Rebate ratio</div>
            <span class="material-icons-round arrow">chevron_right</span>
        </a>

    </div>

    <section class="promotion-data">
        <h3>Promotion data</h3>

        <div class="promotion-grid">
            <div>
                <strong><?= money($todayCommission) ?></strong>
                <span>This Week</span>
            </div>

            <div>
                <strong><?= money($totalCommission) ?></strong>
                <span>Total commission</span>
            </div>

            <div>
                <strong><?= $registeredCount ?></strong>
                <span>Direct Subordinate</span>
            </div>

            <div>
                <strong><?= $registeredCount ?></strong>
                <span>Total number of subordinates</span>
            </div>
        </div>
    </section>

</main>

<?php elseif ($view === 'invite'): ?>

<header class="topbar">
    <a class="back" href="promotion.php">
        <span class="material-icons-round">arrow_back</span>
    </a>
    <h1>Invite</h1>
</header>

<main class="content">

    <div class="poster">
        <h2>Invite friends and earn rewards</h2>
        <p>
            Share your invitation link with friends.
            When an invited user registers and completes the required recharge,
            the eligible bonus will appear in your invitation rules.
        </p>
        <br>
        <strong>Fair and transparent rewards</strong>
    </div>

    <div class="invite-box">
        <div class="invite-title">Your invitation QR code</div>

        <img
            class="qr"
            src="<?= esc($qrUrl) ?>"
            alt="Invitation QR Code"
        >

        <div class="invite-title">Invitation code</div>
        <div class="invite-code"><?= esc($inviteCode) ?></div>

        <div class="link-box" id="inviteLink">
            <?= esc($inviteUrl) ?>
        </div>

        <div class="share-row">
            <button onclick="copyInvite()">
                Copy link
            </button>

            <a
                href="<?= esc($qrUrl) ?>"
                download="invitation-qr.png"
                target="_blank"
            >
                Download QR
            </a>
        </div>

        <button class="primary-btn" onclick="shareInvite()">
            Share invitation
        </button>

        <div class="share-row">
            <a target="_blank" href="https://wa.me/?text=<?= rawurlencode($inviteUrl) ?>">
                WhatsApp
            </a>

            <a target="_blank" href="https://t.me/share/url?url=<?= rawurlencode($inviteUrl) ?>">
                Telegram
            </a>
        </div>
    </div>

</main>

<?php elseif ($view === 'rules'): ?>

<header class="topbar">
    <a class="back" href="promotion.php">
        <span class="material-icons-round">arrow_back</span>
    </a>
    <h1>Invitation bonus</h1>
</header>

<main class="content">

    <div class="info-card">
        Invite friends and help them complete the required recharge.
        Eligible bonus complete hone par claim button active ho jayega.
    </div>

    <?php foreach ($tiers as $level => $tier): ?>

        <?php
        $qualified = 0;

        foreach ($referrals as $referral) {
            if ($referral['deposit'] >= $tier['recharge']) {
                $qualified++;
            }
        }

        $claimed = is_claimed($claims, $level);
        $completed = $qualified >= $tier['people'];
        ?>

        <section class="rule-card">

            <div class="rule-head">
                <strong>Bonus <?= $level + 1 ?></strong>
                <div class="rule-bonus">
                    <?= money($tier['bonus']) ?>
                </div>
            </div>

            <div class="rule-body">

                <div class="rule-line">
                    <span>Number of invitees</span>
                    <b><?= $tier['people'] ?></b>
                </div>

                <div class="rule-line">
                    <span>Recharge per person</span>
                    <b><?= money($tier['recharge']) ?></b>
                </div>

                <div class="progress-area">
                    <div class="progress-number">
                        <?= $qualified ?> / <?= $tier['people'] ?>
                    </div>

                    <div class="progress-label">
                        Qualified deposit invitees
                    </div>

                    <?php if ($claimed): ?>

                        <button class="claim-btn claim-disabled" disabled>
                            Claimed
                        </button>

                    <?php elseif ($completed): ?>

                        <form method="post" action="promotion.php?view=rules">
                            <input type="hidden" name="action" value="claim_bonus">
                            <input type="hidden" name="level" value="<?= $level ?>">
                            <input type="hidden" name="csrf" value="<?= esc($csrfToken) ?>">

                            <button class="claim-btn" type="submit">
                                Claim <?= money($tier['bonus']) ?>
                            </button>
                        </form>

                    <?php else: ?>

                        <button class="claim-btn claim-disabled" disabled>
                            Unfinished
                        </button>

                    <?php endif; ?>
                </div>
            </div>
        </section>

    <?php endforeach; ?>

</main>

<?php elseif ($view === 'records' || $view === 'subordinates'): ?>

<header class="topbar">
    <a class="back" href="promotion.php">
        <span class="material-icons-round">arrow_back</span>
    </a>
    <h1>Invitation record</h1>
</header>

<main class="content">

    <?php
    $period = $_GET['period'] ?? 'today';

    if (!in_array($period, ['today', 'yesterday', 'month'], true)) {
        $period = 'today';
    }
    ?>

    <div class="records-tabs">
        <a class="<?= $period === 'today' ? 'active' : '' ?>"
           href="promotion.php?view=records&period=today">
            Today
        </a>

        <a class="<?= $period === 'yesterday' ? 'active' : '' ?>"
           href="promotion.php?view=records&period=yesterday">
            Yesterday
        </a>

        <a class="<?= $period === 'month' ? 'active' : '' ?>"
           href="promotion.php?view=records&period=month">
            This month
        </a>
    </div>

    <div class="record-list">

        <?php
        $hasRecord = false;

        foreach ($referrals as $referral):
            if (!period_match($referral['time'], $period)) {
                continue;
            }

            $hasRecord = true;
        ?>

            <div class="record">
                <div class="record-left">
                    <strong><?= esc(masked_phone($referral['phone'])) ?></strong>
                    <small><?= esc(date_text($referral['registeredAt'])) ?></small>
                </div>

                <div class="record-right">
                    <strong><?= money($referral['deposit']) ?></strong>

                    <br>

                    <?php if ($referral['deposit'] > 0): ?>
                        <span class="status done">Deposit complete</span>
                    <?php else: ?>
                        <span class="status wait">Waiting recharge</span>
                    <?php endif; ?>
                </div>
            </div>

        <?php endforeach; ?>

        <?php if (!$hasRecord): ?>
            <div class="empty">
                No invitation data available.
            </div>
        <?php endif; ?>

    </div>

</main>

<?php elseif ($view === 'commissions'): ?>

<header class="topbar">
    <a class="back" href="promotion.php">
        <span class="material-icons-round">arrow_back</span>
    </a>
    <h1>Commission detail</h1>
</header>

<main class="content">

    <div class="promotion-data">
        <div class="promotion-grid">
            <div>
                <strong><?= money($todayCommission) ?></strong>
                <span>Today</span>
            </div>

            <div>
                <strong><?= money($monthCommission) ?></strong>
                <span>This month</span>
            </div>

            <div>
                <strong><?= money($totalCommission) ?></strong>
                <span>Total commission</span>
            </div>

            <div>
                <strong><?= $depositCount ?></strong>
                <span>Deposit users</span>
            </div>
        </div>
    </div>

    <br>

    <div class="record-list">

        <?php if (empty($commissions)): ?>

            <div class="empty">
                No commission record found.
            </div>

        <?php else: ?>

            <?php foreach (array_reverse($commissions) as $commission): ?>

                <div class="record">
                    <div class="record-left">
                        <strong><?= esc($commission['type']) ?></strong>
                        <small><?= esc(date_text($commission['createdAt'])) ?></small>
                    </div>

                    <div class="record-right">
                        <strong><?= money($commission['amount']) ?></strong>
                    </div>
                </div>

            <?php endforeach; ?>

        <?php endif; ?>

    </div>

</main>

<?php elseif ($view === 'rebate'): ?>

<header class="topbar">
    <a class="back" href="promotion.php">
        <span class="material-icons-round">arrow_back</span>
    </a>
    <h1>Rebate ratio</h1>
</header>

<main class="content">

    <div class="info-card">
        Rebate ratio aapke game aur account level ke hisaab se apply hoga.
        Neeche current display rules hain.
    </div>

    <div class="table-wrap">
        <table>
            <thead>
                <tr>
                    <th>Game</th>
                    <th>Direct rebate</th>
                    <th>Team rebate</th>
                </tr>
            </thead>

            <tbody>
                <tr>
                    <td>Win Go</td>
                    <td>1.00%</td>
                    <td>0.20%</td>
                </tr>
                <tr>
                    <td>K3</td>
                    <td>1.00%</td>
                    <td>0.20%</td>
                </tr>
                <tr>
                    <td>Aviator</td>
                    <td>0.80%</td>
                    <td>0.15%</td>
                </tr>
                <tr>
                    <td>Mini Games</td>
                    <td>0.50%</td>
                    <td>0.10%</td>
                </tr>
            </tbody>
        </table>
    </div>

</main>

<?php endif; ?>

<nav class="bottom-nav">

    <a href="dashboard.php">
        <span class="material-icons-round">home</span>
        Home
    </a>

    <a href="activity.php">
        <span class="material-icons-round">local_activity</span>
        Activity
    </a>

    <a class="spin-nav" href="spin.php">
        <div class="spin-circle">
            <span class="material-icons-round">casino</span>
        </div>
        Get ₹500
    </a>

    <a class="active" href="promotion.php">
        <span class="material-icons-round">card_giftcard</span>
        Promotion
    </a>

    <a href="account.php">
        <span class="material-icons-round">person</span>
        Account
    </a>

</nav>

</div>

<script>
function showToast(message) {
    let toast = document.getElementById('clientToast');

    if (!toast) {
        toast = document.createElement('div');
        toast.id = 'clientToast';
        toast.className = 'toast';
        document.body.appendChild(toast);
    }

    toast.textContent = message;
    toast.classList.add('show');

    clearTimeout(window.toastTimer);

    window.toastTimer = setTimeout(function () {
        toast.classList.remove('show');
    }, 1800);
}

function copyText(text) {
    if (navigator.clipboard) {
        navigator.clipboard.writeText(text).then(function () {
            showToast('Copied successfully');
        });
        return;
    }

    const input = document.createElement('textarea');
    input.value = text;
    document.body.appendChild(input);
    input.select();
    document.execCommand('copy');
    input.remove();

    showToast('Copied successfully');
}

function copyInvite() {
    const link = document.getElementById('inviteLink');

    if (link) {
        copyText(link.textContent.trim());
    }
}

function shareInvite() {
    const linkElement = document.getElementById('inviteLink');

    if (!linkElement) {
        return;
    }

    const link = linkElement.textContent.trim();

    if (navigator.share) {
        navigator.share({
            title: 'Join and get rewards',
            text: 'Use my invitation link',
            url: link
        }).catch(function () {});
    } else {
        copyText(link);
    }
}

/*
 * Firebase data ko har 12 seconds me refresh karega.
 * Page ko reload nahi karta, sirf basic numbers update karta hai.
 */
setInterval(function () {
    fetch('promotion.php?data=1', {
        cache: 'no-store'
    })
    .then(function (response) {
        return response.json();
    })
    .then(function (data) {
        const reg = document.getElementById('registeredCount');
        const dep = document.getElementById('depositCount');

        if (reg) {
            reg.textContent = data.registered;
        }

        if (dep) {
            dep.textContent = data.deposits;
        }
    })
    .catch(function () {});
}, 12000);

setTimeout(function () {
    const serverToast = document.getElementById('serverToast');

    if (serverToast) {
        serverToast.classList.remove('show');
    }
}, 2200);
</script>

</body>
</html>