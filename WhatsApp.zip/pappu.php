<?php
session_start();
require_once 'config.php'; // Aapka firebase connection file

if (!isset($_SESSION['phone'])) {
    header('Location: login.php');
    exit;
}

$phone = $_SESSION['phone'];
$userData = firebase_read("users/" . $phone);
$balance = $userData['balance'] ?? 0;

// ========== AJAX HANDLERS ==========
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    header('Content-Type: application/json');
    $action = $_POST['action'];

    // --- GET ROUND & GAME STATE ---
    if ($action === 'get_round') {
        $round = firebase_read("pappu/current_round");
        $ud = firebase_read("users/" . $phone);
        $now = time();

        // Round timing logic: 8s (Bet) + 5s (Scratch/Animation) + 3s (Gap) = 16s Total
        if (!$round || ($now - $round['start_time']) >= 16) {
            $fillIdx = isset($round['fillIdx']) ? $round['fillIdx'] + 1 : 0;
            $board = isset($round['board']) ? $round['board'] : array_fill(0, 42, null);
            
            // List palatna (Reset board after 42 boxes)
            if ($fillIdx >= 42) {
                $fillIdx = 0;
                $board = array_fill(0, 42, null);
            }

            $roundData = [
                'id' => $now,
                'start_time' => $now,
                'phase' => 'bet',
                'winner' => '',
                'fillIdx' => $fillIdx,
                'board' => $board
            ];
            firebase_write("pappu/current_round", $roundData);
            firebase_write("pappu/bets/" . $roundData['id'], []); // Clear bets
            $round = $roundData;
        }

        $elapsed = $now - $round['start_time'];
        
        // --- PHASE CHANGES ---
        if ($elapsed >= 8 && $round['phase'] === 'bet') {
            $round['phase'] = 'locked';
            
            // Winner Decide (SABSE KAM PAISA KIS PAR LAGA HAI)
            $allBets = firebase_read("pappu/bets/" . $round['id']) ?? [];
            $syms = ['chatri','football','sun','diya','cow','bucket','patang','lattu','rose','titali','kabutar','khargosh'];
            $totals = array_fill_keys($syms, 0);
            
            foreach ($allBets as $uphone => $symBets) {
                if (is_array($symBets)) {
                    foreach ($symBets as $sym => $amt) {
                        $totals[$sym] += $amt;
                    }
                }
            }
            
            $minVal = min($totals);
            $minSyms = array_keys(array_filter($totals, function($v) use ($minVal) { return $v == $minVal; }));
            $winner = $minSyms[array_rand($minSyms)]; // Agar draw hua to randomly ek le lo
            
            $round['winner'] = $winner;
            $round['board'][$round['fillIdx']] = $winner; // Board update karein

            // Payout distribute karein
            foreach ($allBets as $uphone => $symBets) {
                if (is_array($symBets)) {
                    $winAmt = 0;
                    foreach ($symBets as $sym => $amt) {
                        if ($sym === $winner) {
                            $mult = in_array($winner, ['titali', 'kabutar']) ? 15 : 10;
                            $winAmt += $amt * $mult;
                        }
                    }
                    if ($winAmt > 0) {
                        $wud = firebase_read("users/" . $uphone);
                        if ($wud) {
                            $wud['balance'] = ($wud['balance'] ?? 0) + $winAmt;
                            firebase_write("users/" . $uphone, $wud);
                        }
                    }
                }
            }
            
            // History me save karein
            $hist = firebase_read("pappu/history") ?? [];
            array_unshift($hist, ['no' => $round['fillIdx'] + 1, 'sym' => $winner]);
            if(count($hist) > 60) array_pop($hist); // Sirf last 60 history rakhein
            firebase_write("pappu/history", $hist);
            
            firebase_write("pappu/current_round", $round);
        }

        echo json_encode([
            'round' => $round,
            'elapsed' => $elapsed,
            'balance' => $ud['balance'] ?? 0,
            'history' => firebase_read("pappu/history") ?? []
        ]);
        exit;
    }

    // --- PLACE BET ---
    if ($action === 'place_bet') {
        $sym = $_POST['symbol'] ?? '';
        $amt = (int)($_POST['amount'] ?? 0);
        
        $round = firebase_read("pappu/current_round");
        if (!$round || $round['phase'] !== 'bet') {
            echo json_encode(['success' => false, 'msg' => 'Betting band ho gayi hai!']); exit;
        }
        
        $ud = firebase_read("users/" . $phone);
        $bal = $ud['balance'] ?? 0;
        if ($bal < $amt) { 
            echo json_encode(['success' => false, 'msg' => 'Balance kam hai!']); exit; 
        }
        
        // Bet save
        $roundId = $round['id'];
        $existing = firebase_read("pappu/bets/" . $roundId . "/" . $phone . "/" . $sym) ?? 0;
        
        if ($existing + $amt > 200) {
            echo json_encode(['success' => false, 'msg' => 'Ek picture par max ₹200!']); exit; 
        }

        firebase_write("pappu/bets/" . $roundId . "/" . $phone . "/" . $sym, $existing + $amt);
        
        // Deduct balance
        $ud['balance'] = $bal - $amt;
        firebase_write("users/" . $phone, $ud);
        
        echo json_encode(['success' => true, 'balance' => $ud['balance']]);
        exit;
    }
    
    exit;
}
?>

<!DOCTYPE html>
<html lang="hi">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no,viewport-fit=cover">
<title>Pappu Playing Pictures</title>
<style>
/* SAARA PURANA CSS HAI BAS COLOR/SHADOW REAL UI JAISE KIYE HAIN */
*{margin:0;padding:0;box-sizing:border-box;-webkit-tap-highlight-color:transparent;user-select:none;-webkit-user-select:none}
html,body{height:100%;overflow:hidden;background:#000}
body{font-family:"Segoe UI",Roboto,Arial,sans-serif}

#app{
  position:relative;width:100%;max-width:440px;height:100%;margin:0 auto;
  display:flex;flex-direction:column;overflow:hidden;
  background:#095b1f; /* Casino green base */
  background-image: 
    linear-gradient(rgba(0,0,0,0.06) 1px, transparent 1px),
    linear-gradient(90deg, rgba(0,0,0,0.06) 1px, transparent 1px);
  background-size: 20px 20px;
}

.topbar{flex:0 0 auto;height:52px;background:#08080c;display:flex;align-items:center;justify-content:space-between;padding:0 12px;position:relative;z-index:40}
.tb-back{background:none;border:none;color:#fff;font-size:27px;line-height:1;padding:0 8px;cursor:pointer;font-weight:300}
.tb-mid{display:flex;align-items:center;gap:10px}
.tb-pill{display:flex;align-items:center;height:34px;border-radius:18px;background:linear-gradient(180deg,#2f5fd8,#1a3aa0);border:1px solid #4d78e8;padding-right:16px;position:relative;min-width:150px}
.tb-pill .coin{width:34px;height:34px;margin-left:-2px;flex:0 0 auto}
.tb-amt{color:#fff;font-size:15px;font-weight:700;margin-left:6px;letter-spacing:.3px}
.tb-plus{width:32px;height:32px;border-radius:9px;background:#0d1430;border:1.5px solid #4d78e8;color:#7fa2ff;font-size:20px;font-weight:700;display:flex;align-items:center;justify-content:center;cursor:pointer}
.tb-av{width:30px;height:30px;border-radius:50%;overflow:hidden;flex:0 0 auto}

.histbar{flex:0 0 auto;margin:6px 8px 0;height:44px;border-radius:8px;background:linear-gradient(180deg,#197825,#115818);border:1px solid #30983d;display:flex;align-items:center;gap:5px;padding:4px;overflow:hidden}
.hb-btn{flex:0 0 auto;width:52px;height:100%;border-radius:6px;background:linear-gradient(180deg,#d5efbf,#9ad178);border:1px solid #77b855;display:flex;flex-direction:column;align-items:center;justify-content:center;cursor:pointer}
.hb-btn svg{width:20px;height:12px}
.hb-btn span{font-size:9px;font-weight:700;color:#14400f}
.hb-slot{flex:1 1 0;height:100%;display:flex;align-items:center;gap:4px;min-width:0}
.hb-cell{flex:0 0 auto;width:36px;height:100%;border-radius:5px;background:linear-gradient(180deg,#e9f6dd,#b9dfa0);border:1px solid #7cbf5e;display:flex;align-items:center;justify-content:center;padding:2px}
.hb-cell svg{width:100%;height:100%}
.hb-pct{font-size:14px;font-weight:800;color:#ffe14d;text-shadow:0 1px 2px #000;flex:0 0 auto;width:34px}

.paphdr{flex:0 0 auto;height:74px;margin:4px 8px 2px;position:relative;display:flex;align-items:center;justify-content:center;
  background:linear-gradient(180deg,rgba(9,80,25,.65),rgba(9,80,25,.3));border-radius:6px;overflow:hidden}
.dots-l,.dots-r{position:absolute;top:6px;bottom:6px;width:42px;opacity:.3;
  background-image:radial-gradient(#053d10 1.6px,transparent 1.7px);background-size:9px 9px}
.dots-l{left:0}.dots-r{right:0}
.extra-sym{position:absolute;top:50%;transform:translateY(-50%);display:flex;flex-direction:column;align-items:center;gap:1px;z-index:2}
.extra-sym.l{left:40px}.extra-sym.r{right:62px}
.extra-sym .nm{font-size:11px;color:#a0e0ab;font-style:italic;letter-spacing:.5px;text-shadow:0 1px 1px #000}
.extra-box{width:46px;height:42px;border:1px solid rgba(120,220,140,.5);border-radius:4px;background:rgba(0,60,15,.45);display:flex;align-items:center;justify-content:center;padding:3px}
.extra-box svg{width:100%;height:100%;opacity:.85}
.logo{position:relative;z-index:3;display:flex;align-items:center;gap:2px}
.logo-face{width:52px;height:52px;flex:0 0 auto;margin-right:-6px}
.logo-txt{display:flex;flex-direction:column;align-items:center;position:relative}
.logo-main{font-size:34px;font-weight:900;font-style:italic;letter-spacing:-1px;line-height:.95;
  background:linear-gradient(180deg,#fff36b 0%,#ffd21a 40%,#ff9d00 70%,#ffe66b 100%);
  -webkit-background-clip:text;background-clip:text;color:transparent;
  -webkit-text-stroke:1.6px #6b2d00;
  filter:drop-shadow(0 2px 0 #4a1d00) drop-shadow(0 0 4px rgba(0,0,0,.6))}
.logo-sub{margin-top:-2px;font-size:11px;font-weight:800;font-style:italic;color:#fff;letter-spacing:.6px;
  -webkit-text-stroke:.6px #1e4d15;text-shadow:0 1px 2px #000}
.extrapay{position:absolute;top:-11px;right:-14px;background:linear-gradient(180deg,#ff5d3a,#c9260c);border:1px solid #ffb199;color:#fff;font-size:8.5px;font-weight:800;padding:1px 5px;border-radius:8px;white-space:nowrap;box-shadow:0 1px 3px rgba(0,0,0,.5)}
.star{position:absolute;left:-9px;top:6px;font-size:15px;color:#ff4a3d;text-shadow:0 1px 2px #000}

.cdring{position:absolute;right:-4px;top:50%;transform:translateY(-50%);width:56px;height:56px;z-index:5;display:flex;align-items:center;justify-content:center}
.cdring svg{position:absolute;inset:0;transform:rotate(-90deg)}
.cdring .num{font-size:21px;font-weight:800;color:#ffcf3d;text-shadow:0 1px 3px #000;z-index:2}
.cdring.hide{opacity:0;transition:opacity .3s}

.gamewrap{flex:1 1 auto;position:relative;margin:0 6px;min-height:0}
.board{position:absolute;inset:0 14px 0 16px;display:grid;grid-template-columns:repeat(6,1fr);grid-template-rows:repeat(7,1fr);gap:3px}
.cell{position:relative}
/* Screenshot matching purple pentagons */
.pent{position:absolute;inset:0;clip-path:polygon(0 0,100% 0,100% 74%,50% 100%,0 74%);
  background:linear-gradient(180deg,#8358bf,#6b3ea8);box-shadow:inset 0 0 0 1px rgba(180,140,250,.4)}
.cell .flowers{position:absolute;inset:0;clip-path:polygon(0 0,100% 0,100% 74%,50% 100%,0 74%);opacity:.4;
  background-image:radial-gradient(circle 2.2px at 6px 8px,#dcbcff 99%,transparent),radial-gradient(circle 2.2px at 30px 26px,#dcbcff 99%,transparent);background-size:100% 100%}
.tile{position:absolute;left:9%;right:9%;top:8%;height:64%;border-radius:2px;
  background:linear-gradient(150deg,#fcfcfc 0%,#e8e8e8 45%,#f2f2f2 100%);
  box-shadow:inset 0 0 0 1px rgba(255,255,255,.9),0 1px 2px rgba(0,0,0,.4);
  display:flex;align-items:center;justify-content:center;overflow:hidden}
.tile svg{width:88%;height:88%}
/* Empty state looks like blank silver with stars */
.tile.empty{background:linear-gradient(150deg,#e8e3f0 0%,#c6b8dc 45%,#d8cee3 100%);opacity:.95}
.tile.empty::after{content:"";position:absolute;inset:0;
  background-image:radial-gradient(circle 1.5px at 20% 30%,rgba(255,255,255,.9) 99%,transparent),radial-gradient(circle 1.2px at 70% 60%,rgba(255,255,255,.8) 99%,transparent),radial-gradient(circle 1.4px at 45% 80%,rgba(255,255,255,.7) 99%,transparent)}
.cell .fl{position:absolute;color:#d5b0ff;font-size:12px;opacity:.9;pointer-events:none;line-height:1}
.cell .fl.a{left:1px;top:0}.cell .fl.b{right:1px;top:0}
.cell .fl.c{left:1px;bottom:24%}.cell .fl.d{right:1px;bottom:24%}
.cell.pop .tile{animation:popin .45s cubic-bezier(.2,1.6,.4,1)}
@keyframes popin{0%{transform:scale(.2);opacity:0}100%{transform:scale(1);opacity:1}}
.cell.target .pent{box-shadow:inset 0 0 0 2px #7dff9a,0 0 12px #48e06a}

.side-jili{position:absolute;left:-4px;bottom:60px;width:22px;height:70px;z-index:6;
  background:linear-gradient(180deg,#d99a1c,#9b5e00);border:1.5px solid #ffcc66;border-radius:0 8px 8px 0;
  display:flex;align-items:center;justify-content:center;box-shadow:0 2px 6px rgba(0,0,0,.5)}
.side-jili span{writing-mode:vertical-rl;transform:rotate(180deg);font-size:11px;font-weight:900;color:#4a2300;letter-spacing:2px}
.gear{position:absolute;left:-4px;bottom:14px;width:26px;height:30px;z-index:6;cursor:pointer;
  background:linear-gradient(180deg,#d99a1c,#9b5e00);border:1.5px solid #ffcc66;border-radius:0 8px 8px 0;
  display:flex;align-items:center;justify-content:center;box-shadow:0 2px 6px rgba(0,0,0,.5)}
.gear svg{width:17px;height:17px}
.side-r{position:absolute;right:-4px;top:10px;width:14px;height:72px;z-index:6;border-radius:8px 0 0 8px;
  background:linear-gradient(180deg,#e87c25,#b32c1c);border:1px solid #ffb982}

.dim{position:absolute;inset:0;background:rgba(0,0,0,.45);z-index:12;opacity:0;pointer-events:none;transition:opacity .25s}
.dim.on{opacity:1}
.banner{position:absolute;left:0;right:0;top:52%;transform:translateY(-50%) scale(.85);z-index:14;
  opacity:0;pointer-events:none;transition:opacity .25s,transform .3s;
  background:linear-gradient(180deg,rgba(40,15,5,.0),rgba(50,20,5,.8) 25%,rgba(50,20,5,.8) 75%,rgba(40,15,5,0));
  border-top:1px solid rgba(255,180,80,.4);border-bottom:1px solid rgba(255,180,80,.4);
  padding:12px 6px;text-align:center}
.banner.on{opacity:1;transform:translateY(-50%) scale(1)}
.banner b{font-size:32px;font-weight:900;font-style:italic;letter-spacing:.5px;
  background:linear-gradient(180deg,#fff8c9,#ffd54a 45%,#ff9c00 60%,#ffe58a);
  -webkit-background-clip:text;background-clip:text;color:transparent;
  -webkit-text-stroke:1.2px #5a2a00;filter:drop-shadow(0 3px 3px rgba(0,0,0,.8))}
.banner.small b{font-size:22px;-webkit-text-stroke:.8px #4a2200;
  background:linear-gradient(180deg,#ffffff,#e8e8e8 60%,#bdbdbd)}
.banner .arrow{margin-top:6px;font-size:22px;color:#ffd11a;filter:drop-shadow(0 2px 2px #000);animation:bob .8s infinite alternate}
@keyframes bob{from{transform:translateY(0)}to{transform:translateY(6px)}}

.scratch{position:absolute;z-index:20;display:none;align-items:center;justify-content:center;
  transition:transform .45s cubic-bezier(.4,0,.2,1),opacity .3s}
.scratch.on{display:flex}
.sc-glow{position:absolute;inset:-10px;border-radius:6px;background:linear-gradient(180deg,#6cff8a,#22c04a);
  clip-path:polygon(0 0,100% 0,100% 74%,50% 100%,0 74%);filter:blur(1px);animation:gl .9s infinite alternate}
@keyframes gl{from{filter:brightness(.85)}to{filter:brightness(1.35) drop-shadow(0 0 10px #7dff9a)}}
.sc-pent{position:absolute;inset:0;clip-path:polygon(0 0,100% 0,100% 74%,50% 100%,0 74%);
  background:linear-gradient(180deg,#a275d8,#814ec9)}
.sc-flowers{position:absolute;inset:0;clip-path:polygon(0 0,100% 0,100% 74%,50% 100%,0 74%);color:#d9b6f7;font-size:15px}
.sc-flowers i{position:absolute;font-style:normal;opacity:.9}
.sc-inner{position:absolute;left:8%;right:8%;top:7%;height:63%;background:#fff;border:3px solid #f3eefb;border-radius:2px;overflow:hidden;
  box-shadow:0 2px 8px rgba(0,0,0,.4)}
.sc-sym{position:absolute;inset:6%;display:flex;align-items:center;justify-content:center}
.sc-sym svg{width:100%;height:100%}
#scCanvas{position:absolute;inset:0;width:100%;height:100%}
.sc-coin{position:absolute;width:52px;height:52px;z-index:5;pointer-events:none;filter:drop-shadow(0 3px 5px rgba(0,0,0,.5))}
.scratch.fly{transition:transform .5s cubic-bezier(.5,0,.7,1),opacity .5s}

.winpop{position:absolute;z-index:22;left:50%;top:26%;transform:translateX(-50%);display:none;text-align:center}
.winpop.on{display:block;animation:wp .5s cubic-bezier(.2,1.6,.4,1)}
@keyframes wp{0%{transform:translateX(-50%) scale(.3);opacity:0}100%{transform:translateX(-50%) scale(1);opacity:1}}
.winpop b{font-size:26px;font-weight:900;color:#fff;-webkit-text-stroke:1px #7a4b00;
  background:linear-gradient(180deg,#fffde0,#ffd23a 55%,#ff8a00);-webkit-background-clip:text;background-clip:text;color:transparent;
  filter:drop-shadow(0 2px 3px #000)}

.cdbar{flex:0 0 auto;height:30px;display:flex;align-items:center;gap:4px;padding:0 6px;
  background:linear-gradient(180deg,#0b4a16,#06320d);border-top:1px solid #1c6827;border-bottom:1px solid #032107}
.cd-min{width:24px;height:24px;border-radius:50%;background:#111;border:1.5px solid #fff;color:#fff;font-size:11px;font-weight:800;display:flex;align-items:center;justify-content:center;flex:0 0 auto}
.cd-tabs{flex:1;display:flex;align-items:center;justify-content:center;gap:6px}
.cd-tab{font-size:12.5px;color:#cfe8cf;font-weight:600;cursor:pointer;padding:0 4px}
.cd-tab.act{color:#fff;font-size:14px;font-weight:700;text-shadow:0 1px 2px #000}
.tri{width:0;height:0;border-left:6px solid transparent;border-right:6px solid transparent;border-bottom:9px solid #ffb300}
.cd-mm{font-size:11.5px;color:#dfe;flex:0 0 auto;white-space:nowrap}
.cd-mm i{font-style:normal;color:#7cff7c;font-weight:700}
.cd-mm u{text-decoration:none;color:#ff5b4a;font-weight:700}

/* Refined Betting Panel as per screenshot */
.betwrap{flex:0 0 auto;padding:6px;background:linear-gradient(180deg,#ffd147,#e69212)}
.symgrid{display:grid;grid-template-columns:repeat(6,1fr);gap:4px;padding:4px;border-radius:4px;
  background:rgba(255,255,255,0.2);box-shadow:0 0 10px rgba(255,200,60,.4);transition:filter .3s,box-shadow .3s}
.symgrid.locked{filter:saturate(.2) brightness(.8); pointer-events:none;}
.sbtn{position:relative;aspect-ratio:1/1;border-radius:6px;border:2px solid #fff2c2;cursor:pointer;overflow:visible;
  background:linear-gradient(180deg,#ffffff 0%,#f5f5f5 45%,#eaeaea 100%);
  display:flex;align-items:center;justify-content:center;padding:5%;transition:transform .1s, box-shadow .2s}
.sbtn:active{transform:scale(.95)}
.sbtn svg{width:100%;height:100%;pointer-events:none}
.sbtn.hit{box-shadow: 0 0 8px 2px rgba(255, 100, 0, 0.8);}
.sbtn.win{animation:wglow .5s infinite alternate}
@keyframes wglow{from{box-shadow:0 0 0 0 #ff9900}to{box-shadow:0 0 12px 4px #ff9900}}
.bdg{position:absolute;top:-6px;right:-6px;min-width:24px;height:24px;border-radius:50%;
  background:radial-gradient(circle at 35% 30%,#f2f2f2,#9aa0a6);border:2px solid #fff;
  color:#1a1a1a;font-size:11px;font-weight:800;display:flex;align-items:center;justify-content:center;
  box-shadow:0 2px 4px rgba(0,0,0,.6);z-index:4;padding:0 2px}

/* Refined Bottom Bar as per screenshot */
.botrow{flex:0 0 auto;display:flex;align-items:flex-start;padding:3px 6px 0;gap:4px;height:82px}
.botl{width:74px;flex:0 0 auto;display:flex;flex-direction:column;align-items:center;margin-top:14px}
.bot-av{width:52px;height:52px;border-radius:50%;overflow:hidden;border:2px solid rgba(255,255,255,.3)}
.bot-ph{font-size:10px;color:#b9d6b9;margin-top:2px;white-space:nowrap;font-weight:600;}
.botc{flex:1;display:flex;flex-direction:column;align-items:center;justify-content:flex-start}
.bb{display:flex;gap:26px}
.bb div{color:#a9d1a9;font-size:13px}
.bb b{color:#fff;font-weight:700;margin-left:5px;font-size:15px}
.actbtns{display:flex;align-items:center;gap:6px;margin-top:6px}
.abtn{width:48px;height:48px;border-radius:50%;border:none;cursor:pointer;position:relative;
  background:radial-gradient(circle at 50% 32%,#2fa349,#176b29 62%,#0f4a1c);
  border: 2px solid #32a84e;
  box-shadow:0 3px 6px rgba(0,0,0,.5);
  display:flex;flex-direction:column;align-items:center;justify-content:center;color:#fff;gap:0}
.abtn:active{transform:translateY(2px);box-shadow:0 1px 2px rgba(0,0,0,.5)}
.abtn .ic{font-size:18px;line-height:1;font-weight:800}
.abtn .lb{font-size:9px;opacity:.95;margin-top:2px}
.abtn.clear{background:radial-gradient(circle at 50% 32%,#2fa349,#176b29 62%,#0f4a1c);}
.chip{width:64px;height:64px;border-radius:50%;cursor:pointer;position:relative;flex:0 0 auto;
  background:conic-gradient(#fff 0 8%,#208a31 8% 17%,#fff 17% 25%,#208a31 25% 33%,#fff 33% 41%,#208a31 41% 50%,#fff 50% 58%,#208a31 58% 66%,#fff 66% 75%,#208a31 75% 83%,#fff 83% 91%,#208a31 91% 100%);
  box-shadow:0 4px 10px rgba(0,0,0,.6);display:flex;align-items:center;justify-content:center; margin-top:-4px;}
.chip::before{content:"";position:absolute;inset:7px;border-radius:50%;background:radial-gradient(circle at 50% 30%,#fff,#e6e6e6);box-shadow:inset 0 0 0 2px #208a31}
.chip span{position:relative;z-index:2;font-size:22px;font-weight:900;color:#123}
.chip.frame::after{content:"";position:absolute;inset:-6px;border:2px solid #ffca28;border-radius:8px;border-top-color:transparent}

.rndbar{flex:0 0 auto;height:20px;display:flex;align-items:center;justify-content:flex-end;gap:8px;padding:0 10px 2px}
.rnd-id{font-size:11px;color:#dfe8df}
.rnd-wifi{width:14px;height:14px}

.toast{position:absolute;left:50%;bottom:120px;transform:translateX(-50%);z-index:200;
  background:rgba(0,0,0,.85);color:#fff;font-size:13px;padding:8px 16px;border-radius:20px;
  display:none;white-space:nowrap;border:1px solid rgba(255,255,255,.2)}
.toast.on{display:block;animation:tst .3s}
@keyframes tst{from{opacity:0;transform:translateX(-50%) translateY(8px)}to{opacity:1}}

.modal{position:absolute;inset:0;background:rgba(0,0,0,.72);z-index:300;display:none;align-items:center;justify-content:center;padding:18px}
.modal.on{display:flex}
.mbox{width:100%;max-width:330px;max-height:78%;overflow-y:auto;border-radius:12px;padding:14px;
  background:linear-gradient(180deg,#15631f,#0a3a10);border:2px solid #3fbf52;box-shadow:0 8px 30px rgba(0,0,0,.6)}
.mbox h3{color:#ffd54a;font-size:16px;text-align:center;margin-bottom:10px}
.mrow{display:flex;align-items:center;justify-content:space-between;gap:8px;padding:8px 4px;border-bottom:1px solid rgba(255,255,255,.12);color:#fff;font-size:13px}
.mrow:last-child{border-bottom:none}
.mrow .msym{width:26px;height:26px}
.mclose{width:100%;margin-top:12px;padding:10px;border:none;border-radius:8px;background:linear-gradient(180deg,#37c94d,#1a7a29);color:#fff;font-size:14px;font-weight:700;cursor:pointer}
.sw{width:48px;height:26px;border-radius:14px;background:#444;position:relative;cursor:pointer;flex:0 0 auto;transition:background .2s}
.sw.on{background:#2ecc40}
.sw::after{content:"";position:absolute;top:3px;left:3px;width:20px;height:20px;border-radius:50%;background:#fff;transition:left .2s}
.sw.on::after{left:25px}
.mbtn{padding:7px 12px;border:none;border-radius:7px;background:linear-gradient(180deg,#ffc93c,#e08a12);color:#3a2000;font-weight:800;font-size:12px;cursor:pointer}

.coinfly{position:absolute;width:30px;height:30px;z-index:250;pointer-events:none}
@keyframes cfly{0%{opacity:1;transform:translate(0,0) scale(1) rotate(0)}
100%{opacity:0;transform:translate(var(--dx),var(--dy)) scale(.4) rotate(540deg)}}

.flipall{animation:flipall .9s ease-in-out}
@keyframes flipall{0%{transform:rotateX(0)}50%{transform:rotateX(90deg);opacity:.4}100%{transform:rotateX(0)}}
</style>
</head>
<body>
<div id="app">
  <!-- TOP BAR -->
  <div class="topbar">
    <button class="tb-back" onclick="window.history.back()">&#8249;</button>
    <div class="tb-mid">
      <div class="tb-pill">
        <svg class="coin" viewBox="0 0 40 40"><defs><radialGradient id="cg" cx="35%" cy="30%"><stop offset="0" stop-color="#ffe98a"/><stop offset="55%" stop-color="#ffb61a"/><stop offset="100%" stop-color="#d17a00"/></radialGradient></defs><circle cx="20" cy="20" r="15" fill="url(#cg)" stroke="#a35c00" stroke-width="1.5"/><circle cx="20" cy="20" r="11" fill="none" stroke="#fff0a8" stroke-width="1.4" opacity=".8"/><text x="20" y="26" font-size="15" font-weight="900" text-anchor="middle" fill="#8a4a00" font-family="Arial">$</text></svg>
        <span class="tb-amt" id="topBal">₹<?=number_format($balance,2)?></span>
      </div>
      <button class="tb-plus" onclick="location.href='recharge.php'">+</button>
      <div class="tb-av"><svg viewBox="0 0 40 40"><circle cx="20" cy="20" r="20" fill="#1c9ad6"/><path d="M4 22c6-3 10 2 16-1s12 1 16-3v22H4z" fill="#39c07a"/><circle cx="14" cy="12" r="5" fill="#7fe0ff"/></svg></div>
    </div>
  </div>

  <!-- HISTORY BAR -->
  <div class="histbar">
    <div class="hb-btn" onclick="openHist()">
      <svg viewBox="0 0 32 16"><polyline points="2,13 9,5 15,10 22,2 30,7" fill="none" stroke="#bdfaae" stroke-width="2.2" stroke-linejoin="round" stroke-linecap="round"/><circle cx="9" cy="5" r="2" fill="#e04a2f"/><circle cx="22" cy="2" r="2" fill="#e04a2f"/></svg>
      <span>History</span>
    </div>
    <div class="hb-slot" id="hbSlot"></div>
  </div>

  <!-- PAPPU HEADER -->
  <div class="paphdr">
    <div class="dots-l"></div><div class="dots-r"></div>
    <div class="extra-sym l"><span class="nm">Titali</span><div class="extra-box" id="exL"></div></div>
    <div class="extra-sym r"><span class="nm">Kabutar</span><div class="extra-box" id="exR"></div></div>
    <div class="logo">
      <svg class="logo-face" viewBox="0 0 60 60">
        <ellipse cx="30" cy="52" rx="21" ry="10" fill="#1e4fa0"/>
        <path d="M10 26c0-13 9-20 20-20s20 7 20 20c0 13-9 22-20 22S10 39 10 26z" fill="#f6c9a0"/>
        <path d="M9 24c1-14 11-20 21-20s20 6 21 20c-3-3-6-9-10-10-5 4-18 6-25 2-3 2-5 5-7 8z" fill="#2b2118"/>
        <ellipse cx="22" cy="29" rx="4.2" ry="4.6" fill="#fff"/><ellipse cx="38" cy="29" rx="4.2" ry="4.6" fill="#fff"/>
        <circle cx="22.6" cy="29.6" r="2.3" fill="#20160f"/><circle cx="38.6" cy="29.6" r="2.3" fill="#20160f"/>
        <path d="M17 22c2-2 6-2.5 8-1M35 21c2-1.5 6-1 8 1" stroke="#2b2118" stroke-width="2" fill="none" stroke-linecap="round"/>
        <path d="M22 38c4 5 12 5 16 0-2 6-14 6-16 0z" fill="#8c2f18"/>
        <path d="M23 39c4 3 10 3 14 0z" fill="#fff"/>
        <circle cx="15" cy="36" r="3.4" fill="#eb8a7a" opacity=".7"/><circle cx="45" cy="36" r="3.4" fill="#eb8a7a" opacity=".7"/>
      </svg>
      <div class="logo-txt">
        <span class="star">✳</span>
        <span class="extrapay">Extra Pay</span>
        <span class="logo-main">PAPPU</span>
        <span class="logo-sub">Playing Pictures</span>
      </div>
    </div>
    <div class="cdring" id="cdRing">
      <svg viewBox="0 0 56 56"><circle cx="28" cy="28" r="23" fill="rgba(0,0,0,.45)" stroke="#5a3a00" stroke-width="4"/>
      <circle id="ringArc" cx="28" cy="28" r="23" fill="none" stroke="#ff9a00" stroke-width="4" stroke-linecap="round" stroke-dasharray="144.5" stroke-dashoffset="0"/></svg>
      <span class="num" id="cdNum">8</span>
    </div>
  </div>

  <!-- BOARD -->
  <div class="gamewrap" id="gamewrap">
    <div class="board" id="board"></div>
    <div class="side-jili"><span>JILI</span></div>
    <div class="gear" onclick="openSet()"><svg viewBox="0 0 24 24" fill="#5b2b00"><path d="M12 8a4 4 0 100 8 4 4 0 000-8zm9.4 4c0-.6-.1-1.2-.2-1.8l2-1.5-2-3.4-2.3 1a7.6 7.6 0 00-3-1.8L15.5 2h-4l-.4 2.5c-1.1.3-2.1.9-3 1.7l-2.3-1-2 3.4 2 1.5a7.9 7.9 0 000 3.6l-2 1.5 2 3.4 2.3-1c.9.8 1.9 1.4 3 1.7l.4 2.7h4l.4-2.7c1.1-.3 2.1-.9 3-1.7l2.3 1 2-3.4-2-1.5c.1-.6.2-1.2.2-1.8z"/></svg></div>
    <div class="side-r"></div>

    <div class="dim" id="dim"></div>
    <div class="banner" id="banner"><b id="banTxt">Please Bet Now</b><div class="arrow" id="banArrow" style="display:none">▼</div></div>

    <!-- SCRATCH CARD -->
    <div class="scratch" id="scratch">
      <div class="sc-glow"></div>
      <div class="sc-pent"></div>
      <div class="sc-flowers"><i style="left:6%;top:6%">✳</i><i style="right:6%;top:6%">✳</i><i style="left:6%;top:52%">✳</i><i style="right:6%;top:52%">✳</i><i style="left:44%;top:76%">✳</i></div>
      <div class="sc-inner">
        <div class="sc-sym" id="scSym"></div>
        <canvas id="scCanvas"></canvas>
      </div>
      <svg class="sc-coin" id="scCoin" viewBox="0 0 40 40"><defs><radialGradient id="cg2" cx="35%" cy="30%"><stop offset="0" stop-color="#fff0a0"/><stop offset="55%" stop-color="#ffb61a"/><stop offset="100%" stop-color="#c97600"/></radialGradient></defs><circle cx="20" cy="20" r="18" fill="url(#cg2)" stroke="#9c5900" stroke-width="2"/><circle cx="20" cy="20" r="13" fill="none" stroke="#fff3b0" stroke-width="2"/><text x="20" y="27" font-size="18" font-weight="900" text-anchor="middle" fill="#8a4a00" font-family="Arial">$</text></svg>
    </div>

    <div class="winpop" id="winpop"><b id="winpopTxt"></b></div>
  </div>

  <!-- CD BAR -->
  <div class="cdbar">
    <div class="cd-min" id="cdMini">8</div>
    <div class="cd-tabs">
      <span class="cd-tab" onclick="openHist()">Roadmap</span><div class="tri"></div>
      <span class="cd-tab act">Multiple Mode</span><div class="tri"></div>
    </div>
    <div class="cd-mm">Min <i>10</i> &nbsp;Max <u>200</u></div>
  </div>

  <!-- BET PANEL -->
  <div class="betwrap"><div class="symgrid" id="symgrid"></div></div>

  <!-- BOTTOM -->
  <div class="botrow">
    <div class="botl">
      <div class="bot-av"><svg viewBox="0 0 52 52"><rect width="52" height="52" fill="#5b6b7d"/><circle cx="26" cy="19" r="11" fill="#e8b48c"/><path d="M15 14c2-8 20-8 22 0 1 4-2 5-2 5-1-5-17-6-18-1 0 0-3 0-2-4z" fill="#241a12"/><path d="M4 52c2-13 11-18 22-18s20 5 22 18z" fill="#22304a"/><path d="M20 34l6 8 6-8-6-3z" fill="#f0f0f0"/></svg></div>
      <div class="bot-ph" id="botPh"><?= htmlspecialchars($phone) ?></div>
    </div>
    <div class="botc">
      <div class="bb"><div>Balance <b id="balShow">₹<?=floor($balance)?></b></div><div>Your Bet <b id="betShow">₹0</b></div></div>
      <div class="actbtns">
        <button class="abtn" onclick="toast('Please bet manually for server sync')"><span class="ic">↻</span><span class="lb">again</span></button>
        <div class="chip frame" onclick="cycleChip()"><span id="chipAmt">10</span></div>
        <button class="abtn" onclick="toast('Double limit is controlled')"><span class="ic">×2</span><span class="lb">double</span></button>
        <button class="abtn" onclick="toast('Clear works before bet processing')"><span class="ic">↩</span><span class="lb">undo</span></button>
        <button class="abtn clear" onclick="doClear()"><span class="ic">✕</span><span class="lb">clear</span></button>
      </div>
    </div>
  </div>

  <div class="rndbar"><span class="rnd-id" id="rndId">—</span>
    <svg class="rnd-wifi" viewBox="0 0 24 24" fill="#3fe06a"><path d="M12 20l3-4H9zM5 9a10 10 0 0114 0l-2 2a7 7 0 00-10 0zM1.5 5.5a15 15 0 0121 0l-2 2a12 12 0 00-17 0z"/></svg>
  </div>

  <div class="toast" id="toast"></div>

  <!-- HISTORY MODAL -->
  <div class="modal" id="histModal">
    <div class="mbox">
      <h3>📈 Roadmap / History</h3>
      <div id="histList"></div>
      <button class="mclose" onclick="closeModal('histModal')">Close</button>
    </div>
  </div>

  <!-- SETTINGS MODAL -->
  <div class="modal" id="setModal">
    <div class="mbox">
      <h3>⚙️ Settings</h3>
      <div class="mrow"><span>🔊 Voice (Hindi)</span><div class="sw on" id="swVoice" onclick="tog('voice',this)"></div></div>
      <div class="mrow"><span>🎵 Sound effects</span><div class="sw on" id="swSfx" onclick="tog('sfx',this)"></div></div>
      <div class="mrow" style="font-size:11px;color:#bfe0bf;display:block;line-height:1.5">
        Payout: normal picture <b>×10</b>, Extra Pay (Titali / Kabutar) <b>×15</b>.<br>
        Winner = jis picture par sabse <b>kam paisa</b> laga ho. (SERVER LOGIC)
      </div>
      <button class="mclose" onclick="closeModal('setModal')">Close</button>
    </div>
  </div>
</div>

<script>
/* =======================================================
   PAPPU PLAYING PICTURES — PHP SERVER SYNCED
   ======================================================= */

/* ---------- SVG ART ---------- */
// SVG ART OBJECT DITTO SAME AS YOUR ORIGINAL CODE
const ART = {
chatri:`<svg viewBox="0 0 100 100"><defs><linearGradient id="uh" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#c98a4b"/><stop offset="1" stop-color="#8a5222"/></linearGradient>
<clipPath id="ucl"><path d="M6 55C7 28 26 13 50 13s43 15 44 42c-6 8-13 8-15 0-6 8-13 8-15 0-6 8-14 8-15 0-6 8-13 8-15 0-6 8-13 8-15 0-6 8-11 6-13 0z"/></clipPath></defs>
<path d="M50 55v25c0 7-9 9-11 2" stroke="url(#uh)" stroke-width="5" fill="none" stroke-linecap="round"/>
<g clip-path="url(#ucl)"><rect x="0" y="8" width="17" height="60" fill="#e8412f"/><rect x="17" y="8" width="17" height="60" fill="#ff8c1a"/><rect x="34" y="8" width="16" height="60" fill="#ffd21a"/><rect x="50" y="8" width="16" height="60" fill="#35c05a"/><rect x="66" y="8" width="17" height="60" fill="#2a7de1"/><rect x="83" y="8" width="17" height="60" fill="#a03bd6"/><path d="M0 8h100v14H0z" fill="#fff" opacity=".18"/></g>
<path d="M6 55C7 28 26 13 50 13s43 15 44 42c-6 8-13 8-15 0-6 8-13 8-15 0-6 8-14 8-15 0-6 8-13 8-15 0-6 8-13 8-15 0-6 8-11 6-13 0z" fill="none" stroke="#5a2e00" stroke-width="1.6" stroke-linejoin="round"/>
<circle cx="50" cy="11" r="3.4" fill="#ffd21a" stroke="#8a5222" stroke-width="1.2"/></svg>`,
football:`<svg viewBox="0 0 100 100"><defs><radialGradient id="fb" cx="35%" cy="26%"><stop offset="0" stop-color="#fff"/><stop offset="68%" stop-color="#f0f3f5"/><stop offset="100%" stop-color="#a9b0b6"/></radialGradient>
<clipPath id="fcl"><circle cx="50" cy="52" r="39"/></clipPath></defs>
<circle cx="50" cy="52" r="39" fill="url(#fb)" stroke="#4e565c" stroke-width="2"/>
<g clip-path="url(#fcl)" fill="#1a1a1a"><path d="M0-13L12.4-4 7.6 10.5-7.6 10.5-12.4-4Z" transform="translate(50 52)"/><path d="M0-12L11.4-3.7 7 9.7-7 9.7-11.4-3.7Z" transform="translate(50 19) rotate(180)"/><path d="M0-12L11.4-3.7 7 9.7-7 9.7-11.4-3.7Z" transform="translate(81.4 41.8) rotate(252)"/><path d="M0-12L11.4-3.7 7 9.7-7 9.7-11.4-3.7Z" transform="translate(69.4 78.7) rotate(324)"/><path d="M0-12L11.4-3.7 7 9.7-7 9.7-11.4-3.7Z" transform="translate(30.6 78.7) rotate(36)"/><path d="M0-12L11.4-3.7 7 9.7-7 9.7-11.4-3.7Z" transform="translate(18.6 41.8) rotate(108)"/></g>
<g stroke="#6b7378" stroke-width="1.4" fill="none" clip-path="url(#fcl)" opacity=".7"><path d="M50 39V29M62.4 48l9.6-3.4M57.6 62.5l6.2 8.4M42.4 62.5l-6.2 8.4M37.6 48l-9.6-3.4"/></g>
<circle cx="50" cy="52" r="39" fill="none" stroke="#4e565c" stroke-width="2"/><path d="M24 28a39 39 0 0119-13" stroke="#fff" stroke-width="5" fill="none" opacity=".6" stroke-linecap="round"/></svg>`,
sun:`<svg viewBox="0 0 100 100"><defs><radialGradient id="sg" cx="42%" cy="35%"><stop offset="0" stop-color="#fff7a8"/><stop offset="55%" stop-color="#ffd21a"/><stop offset="100%" stop-color="#f59300"/></radialGradient></defs>
<g fill="#ffc400" stroke="#e08600" stroke-width="1.2"><path d="M50 2l7 16H43z"/><path d="M50 98l-7-16h14z"/><path d="M2 50l16-7v14z"/><path d="M98 50l-16 7V43z"/><path d="M16 16l16 6-10 10z"/><path d="M84 16l-6 16-10-10z"/><path d="M16 84l6-16 10 10z"/><path d="M84 84l-16-6 10-10z"/></g>
<circle cx="50" cy="50" r="29" fill="url(#sg)" stroke="#e08600" stroke-width="1.8"/><ellipse cx="40" cy="40" rx="10" ry="7" fill="#fff9c4" opacity=".55" transform="rotate(-25 40 40)"/></svg>`,
diya:`<svg viewBox="0 0 100 100"><defs><radialGradient id="fl" cx="50%" cy="70%"><stop offset="0" stop-color="#fff6c0"/><stop offset="45%" stop-color="#ffd21a"/><stop offset="100%" stop-color="#ff7a00"/></radialGradient><linearGradient id="bw" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#e0762f"/><stop offset="45%" stop-color="#b5401b"/><stop offset="100%" stop-color="#6d1f0c"/></linearGradient></defs>
<ellipse cx="50" cy="72" rx="34" ry="6" fill="#000" opacity=".18"/><ellipse cx="50" cy="30" rx="13" ry="17" fill="#ffd21a" opacity=".22"/><path d="M50 10c9 12 12 20 8 26-4 6-13 6-16-1-3-6 1-13 8-25z" fill="url(#fl)"/><path d="M50 22c4 6 5 10 3 13-2 3-7 3-8-1-1-4 2-7 5-12z" fill="#fff7d0"/><path d="M16 52h68c-2 14-16 22-34 22S18 66 16 52z" fill="url(#bw)" stroke="#4e1607" stroke-width="1.6"/><ellipse cx="50" cy="52" rx="34" ry="8" fill="#ffb648" stroke="#7d2b10" stroke-width="1.4"/><ellipse cx="50" cy="52" rx="27" ry="5.5" fill="#e08a2e"/><path d="M44 50c3-2 9-2 12 0-4 1-8 1-12 0z" fill="#5a3a1a"/><path d="M22 62c8 6 48 6 56 0" stroke="#8a3315" stroke-width="2" fill="none" opacity=".6"/></svg>`,
cow:`<svg viewBox="0 0 100 100"><defs><linearGradient id="cwb" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#f8eed8"/><stop offset="55%" stop-color="#e6d1a9"/><stop offset="100%" stop-color="#c2a577"/></linearGradient></defs>
<ellipse cx="54" cy="88" rx="34" ry="4" fill="#000" opacity=".15"/><path d="M84 44c8 6 9 20 6 30" stroke="#c9ae80" stroke-width="3" fill="none" stroke-linecap="round"/><path d="M89 72c3 3 3 10 0 12-3-2-3-9 0-12z" fill="#8b6a3c"/><g stroke="#8f7145" stroke-width="1.2"><path d="M74 60h6.5v24H74z" fill="#d3bb90"/><path d="M62 60h6.5v24H62z" fill="#eddfbd"/><path d="M40 60h6.5v24H40z" fill="#d3bb90"/><path d="M30 60h6.5v24H30z" fill="#eddfbd"/></g><g fill="#6b5233"><rect x="74" y="79" width="6.5" height="6" rx="1.5"/><rect x="62" y="79" width="6.5" height="6" rx="1.5"/><rect x="40" y="79" width="6.5" height="6" rx="1.5"/><rect x="30" y="79" width="6.5" height="6" rx="1.5"/></g><path d="M30 50c1-9 9-14 22-15 15-1 28 3 33 11 4 8 2 16-4 20-6 4-40 5-46 2-4-2-5-11-5-18z" fill="url(#cwb)" stroke="#8f7145" stroke-width="1.6"/><path d="M40 36c4-5 12-6 17-3-6-1-12 0-17 3z" fill="#fdf6e6" opacity=".85"/><path d="M32 47c-6 1-11 4-14 9-3 5-3 10 1 13 4 4 12 3 16-1 4-3 5-9 4-14" fill="url(#cwb)" stroke="#8f7145" stroke-width="1.5"/><path d="M18 56c-6 1-10 5-11 10-1 5 3 8 8 8 6 0 10-4 11-9 1-5-3-9-8-9z" fill="#f0e2c6" stroke="#8f7145" stroke-width="1.4"/><ellipse cx="10" cy="70" rx="6" ry="5" fill="#f5e9d2" stroke="#8f7145" stroke-width="1.3"/><ellipse cx="8" cy="69" rx="1.5" ry="1.1" fill="#a58058"/><ellipse cx="12" cy="72" rx="1.5" ry="1.1" fill="#a58058"/><circle cx="20" cy="60" r="2.4" fill="#3b2a17"/><circle cx="19.4" cy="59.3" r=".8" fill="#fff"/><path d="M26 55c-7-4-13-2-12 2 1 4 8 6 13 3z" fill="#dcc59c" stroke="#8f7145" stroke-width="1.2"/><path d="M18 51c-3-6-1-10 1-9 3 1 4 6 3 9zM27 49c0-6 3-9 5-7 1 2 0 6-2 8z" fill="#f7f0dc" stroke="#8f7145" stroke-width="1.1"/><path d="M58 40c3 6 2 12-2 15" stroke="#bda276" stroke-width="1.3" fill="none" opacity=".65"/><path d="M56 66c3 4 3 8 1 11" stroke="#bda276" stroke-width="1.2" fill="none" opacity=".5"/></svg>`,
bucket:`<svg viewBox="0 0 100 100"><defs><linearGradient id="bk" x1="0" y1="0" x2="1" y2="0"><stop offset="0" stop-color="#2f6fb0"/><stop offset="25%" stop-color="#7fb8e8"/><stop offset="55%" stop-color="#3d84c4"/><stop offset="100%" stop-color="#1c4f86"/></linearGradient><linearGradient id="wt" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#9fe0ff"/><stop offset="100%" stop-color="#3aa0dd"/></linearGradient></defs>
<path d="M18 26a32 9 0 0164 0c-3 16-6 40-8 50-2 6-46 6-48 0-2-10-5-34-8-50z" fill="url(#bk)" stroke="#123f6d" stroke-width="1.8"/><ellipse cx="50" cy="26" rx="32" ry="9" fill="#1b5c96" stroke="#123f6d" stroke-width="1.6"/><ellipse cx="50" cy="27" rx="27" ry="7" fill="url(#wt)"/><path d="M28 27c8-3 18-3 26 0" stroke="#dff4ff" stroke-width="2" fill="none" opacity=".8"/><path d="M20 30c14 5 46 5 60 0" stroke="#bfe4ff" stroke-width="2.5" fill="none" opacity=".35"/><path d="M18 22a32 12 0 0164 0" fill="none" stroke="#8fc7f2" stroke-width="2.4" opacity=".8"/><path d="M24 44c18 4 34 4 52 0M23 58c18 4 36 4 54 0" stroke="#0f3a63" stroke-width="1.6" fill="none" opacity=".45"/><path d="M32 32c-2 14-3 32-3 42" stroke="#cfe9ff" stroke-width="3" fill="none" opacity=".45"/></svg>`,
patang:`<svg viewBox="0 0 100 100"><path d="M50 6L86 44 50 88 14 44z" fill="#f2f2f2" stroke="#7a2b8a" stroke-width="1.6"/><path d="M50 6L86 44H50z" fill="#ff3fa4"/><path d="M50 6L14 44h36z" fill="#2f8ce0"/><path d="M50 44h36L50 88z" fill="#ff3fa4"/><path d="M50 44H14l36 44z" fill="#2f8ce0"/><circle cx="50" cy="44" r="14" fill="#ffd21a" stroke="#c98f00" stroke-width="1.4"/><circle cx="50" cy="44" r="7" fill="#fff6c0"/><path d="M50 6v82M14 44h72" stroke="#7a2b8a" stroke-width="1.4" opacity=".7"/><path d="M50 88c-6 4-4 8 1 6M50 88c6 5 3 9-2 8" stroke="#e8412f" stroke-width="3" fill="none" stroke-linecap="round"/><path d="M43 88c-8 6-6 12 2 12" stroke="#e8412f" stroke-width="3.4" fill="none" stroke-linecap="round"/></svg>`,
lattu:`<svg viewBox="0 0 100 100"><defs><linearGradient id="lt1" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#ffb154"/><stop offset="100%" stop-color="#e07b1a"/></linearGradient></defs>
<ellipse cx="50" cy="88" rx="20" ry="4" fill="#000" opacity=".15"/><path d="M50 74c-9 0-2 14 0 14s9-14 0-14z" fill="#c98a4b" stroke="#8a5222" stroke-width="1.2"/><path d="M18 46c0-16 14-26 32-26s32 10 32 26c0 14-14 24-32 24s-32-10-32-24z" fill="url(#lt1)" stroke="#a05a00" stroke-width="1.6"/><path d="M19 40c8-6 54-6 62 0-1 5-3 8-3 8-14-6-42-6-56 0 0 0-2-3-3-8z" fill="#2fb8e0"/><path d="M20 56c14 6 46 6 60 0-1 4-4 8-8 10-12 5-32 5-44 0-4-2-7-6-8-10z" fill="#2fb8e0"/><path d="M32 24c8-4 28-4 36 0-9-2-27-2-36 0z" fill="#fff" opacity=".5"/><ellipse cx="50" cy="20" rx="14" ry="5" fill="#ffd97a" stroke="#a05a00" stroke-width="1.2"/><path d="M50 4v14" stroke="#8a5222" stroke-width="4" stroke-linecap="round"/><ellipse cx="36" cy="36" rx="7" ry="4" fill="#fff" opacity=".4" transform="rotate(-20 36 36)"/></svg>`,
rose:`<svg viewBox="0 0 100 100"><defs><radialGradient id="rs" cx="40%" cy="32%"><stop offset="0" stop-color="#ff8b6b"/><stop offset="55%" stop-color="#e8281f"/><stop offset="100%" stop-color="#9c0b12"/></radialGradient><linearGradient id="lf" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#6fd14a"/><stop offset="100%" stop-color="#1f7a1f"/></linearGradient></defs>
<path d="M54 64c14 12 34 14 44 4-4 16-34 18-46-1z" fill="url(#lf)" stroke="#1a6b18" stroke-width="1.4"/><path d="M58 68c12 3 24 5 34 3" stroke="#2f8f2a" stroke-width="1.3" fill="none"/><path d="M44 68C33 80 15 80 6 70c13-3 27-4 38-2z" fill="url(#lf)" stroke="#1a6b18" stroke-width="1.4"/><path d="M40 70c-10 2-20 3-28 2" stroke="#2f8f2a" stroke-width="1.3" fill="none"/><g stroke="#8d0d12" stroke-width="1.3"><ellipse cx="50" cy="20" rx="17" ry="13" fill="#d81b23"/><ellipse cx="76" cy="34" rx="17" ry="13" fill="#c1141c" transform="rotate(58 76 34)"/><ellipse cx="72" cy="62" rx="17" ry="13" fill="#d81b23" transform="rotate(122 72 62)"/><ellipse cx="46" cy="70" rx="17" ry="13" fill="#c1141c"/><ellipse cx="24" cy="58" rx="17" ry="13" fill="#d81b23" transform="rotate(58 24 58)"/><ellipse cx="24" cy="30" rx="17" ry="13" fill="#c1141c" transform="rotate(122 24 30)"/></g><circle cx="49" cy="44" r="22" fill="url(#rs)" stroke="#8d0d12" stroke-width="1.5"/><path d="M49 28c10 0 17 7 17 15s-7 14-15 14-13-5-13-11 5-9 10-9 7 4 6 7" fill="none" stroke="#ff9d86" stroke-width="3.4" stroke-linecap="round"/><circle cx="49" cy="44" r="6" fill="#a80f14"/><path d="M32 30c5-7 12-11 20-12-9 4-16 7-20 12z" fill="#ff9d86" opacity=".6"/></svg>`,
titali:`<svg viewBox="0 0 100 100"><defs><linearGradient id="bw1" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#7fe4ff"/><stop offset="45%" stop-color="#1f7fe0"/><stop offset="100%" stop-color="#12308f"/></linearGradient></defs>
<path d="M48 50C36 22 16 10 8 20c-8 10 6 30 22 34-14 4-22 16-14 26 8 9 26-2 32-24z" fill="url(#bw1)" stroke="#0d2a6b" stroke-width="1.6"/><path d="M52 50c12-28 32-40 40-30 8 10-6 30-22 34 14 4 22 16 14 26-8 9-26-2-32-24z" fill="url(#bw1)" stroke="#0d2a6b" stroke-width="1.6"/><path d="M40 34c-8-8-18-14-24-10M60 34c8-8 18-14 24-10" stroke="#8fe9ff" stroke-width="2" fill="none" opacity=".7"/><circle cx="26" cy="34" r="4" fill="#bff0ff" opacity=".8"/><circle cx="74" cy="34" r="4" fill="#bff0ff" opacity=".8"/><circle cx="24" cy="70" r="3" fill="#bff0ff" opacity=".7"/><circle cx="76" cy="70" r="3" fill="#bff0ff" opacity=".7"/><path d="M50 26c3 0 4 4 4 10v34c0 6-1 12-4 12s-4-6-4-12V36c0-6 1-10 4-10z" fill="#2a2a3a"/><path d="M47 24c-4-8-10-12-14-12M53 24c4-8 10-12 14-12" stroke="#2a2a3a" stroke-width="2" fill="none" stroke-linecap="round"/><circle cx="33" cy="12" r="2.4" fill="#2a2a3a"/><circle cx="67" cy="12" r="2.4" fill="#2a2a3a"/></svg>`,
kabutar:`<svg viewBox="0 0 100 100"><defs><linearGradient id="pg" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#f4f6f9"/><stop offset="50%" stop-color="#c3ccd6"/><stop offset="100%" stop-color="#7f8a96"/></linearGradient></defs>
<ellipse cx="52" cy="88" rx="26" ry="4" fill="#000" opacity=".15"/><path d="M76 50l22 6-20 12-6-8z" fill="#94a0ac" stroke="#67727d" stroke-width="1.4" stroke-linejoin="round"/><path d="M30 52c5-13 22-18 35-12 13 6 18 19 13 28-5 9-18 13-31 11-13-2-22-14-17-27z" fill="url(#pg)" stroke="#67727d" stroke-width="1.5"/><path d="M38 54c13-5 27-2 33 8 3 6-1 13-9 16-11 4-24 0-28-7-3-6-1-15 4-17z" fill="#96a2ae" stroke="#69747f" stroke-width="1.2"/><path d="M43 62c11-3 21 0 27 6M41 68c11-2 21 1 26 6" stroke="#69747f" stroke-width="1.2" fill="none"/><path d="M33 44c-5-9-2-18 5-22 8-5 18-1 20 7 2 7-2 13-8 16" fill="#f6f8fa" stroke="#67727d" stroke-width="1.4"/><circle cx="38" cy="26" r="11.5" fill="#f8fafc" stroke="#67727d" stroke-width="1.4"/><path d="M28 24c-4 0-7 2-7 3.5s3 3.5 7 3.5z" fill="#f8fafc" stroke="#67727d" stroke-width="1.2"/><path d="M22 25l-8 2.6 8 3z" fill="#41474d"/><path d="M21 24.6c2 .3 2.6 1 2.4 1.8" stroke="#c9d3db" stroke-width="1" fill="none"/><circle cx="36" cy="24" r="3" fill="#e8a020" stroke="#7a5200" stroke-width=".9"/><circle cx="36.4" cy="24" r="1.4" fill="#141414"/><path d="M46 78v9M58 78v9" stroke="#e0688f" stroke-width="3.2" stroke-linecap="round"/><path d="M41 88h10M53 88h10" stroke="#e0688f" stroke-width="3" stroke-linecap="round"/><path d="M44 20c-3-4-8-5-12-3" stroke="#cfd8e0" stroke-width="1.6" fill="none"/><path d="M30 36c5 3 12 3 16 0" stroke="#b9c4cf" stroke-width="1.3" fill="none"/></svg>`,
khargosh:`<svg viewBox="0 0 100 100"><defs><linearGradient id="rb" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#d7a271"/><stop offset="100%" stop-color="#9a6a3c"/></linearGradient></defs>
<ellipse cx="52" cy="88" rx="30" ry="4" fill="#000" opacity=".15"/><circle cx="82" cy="70" r="9" fill="#f0e2d2" stroke="#8a5f34" stroke-width="1.3"/><path d="M28 62c4-18 22-26 38-22 14 4 20 18 18 30-1 8-8 14-20 15-16 2-40 0-36-23z" fill="url(#rb)" stroke="#7d5228" stroke-width="1.6"/><path d="M24 54c-8-2-14 4-12 12 2 8 10 12 18 12 6 0 10-4 10-10 0-8-8-13-16-14z" fill="#c99560" stroke="#7d5228" stroke-width="1.5"/><ellipse cx="18" cy="66" rx="7" ry="6" fill="#dbb083" stroke="#7d5228" stroke-width="1.2"/><circle cx="14" cy="65" r="2.2" fill="#5c3a18"/><circle cx="26" cy="58" r="3" fill="#3a2412"/><circle cx="27" cy="57" r="1" fill="#fff"/><path d="M30 44c-4-14-2-24 2-24 5 0 8 12 6 24z" fill="#c99560" stroke="#7d5228" stroke-width="1.4"/><path d="M44 44c-2-14 2-24 6-22 4 2 4 14 0 24z" fill="#c99560" stroke="#7d5228" stroke-width="1.4"/><path d="M32 42c-2-10-1-17 1-17 3 0 4 9 3 17z" fill="#e8b7a0"/><path d="M46 42c-1-10 1-17 3-16 2 1 2 9 0 16z" fill="#e8b7a0"/><path d="M40 78c4 4 12 4 16 0M60 80c4 3 12 3 16-1" stroke="#7d5228" stroke-width="1.4" fill="none"/><path d="M22 74c6 4 16 5 22 3" stroke="#7d5228" stroke-width="1.3" fill="none"/></svg>`
};

const SYMS = ['chatri','football','sun','diya','cow','bucket','patang','lattu','rose','titali','kabutar','khargosh'];
const NAMES = {chatri:'Chatri',football:'Football',sun:'Suraj',diya:'Diya',cow:'Gaay',bucket:'Balti',
  patang:'Patang',lattu:'Lattu',rose:'Gulab',titali:'Titali',kabutar:'Kabutar',khargosh:'Khargosh'};
const HI = {chatri:'छतरी',football:'फुटबॉल',sun:'सूरज',diya:'दीया',cow:'गाय',bucket:'बाल्टी',
  patang:'पतंग',lattu:'लट्टू',rose:'गुलाब',titali:'तितली',kabutar:'कबूतर',khargosh:'खरगोश'};
const EXTRA = ['titali','kabutar']; 
const CHIPS = [10,20,30,50,100,200];
const TOTAL = 42;

let balance = <?= (float)$balance ?>;
let myBets = {};
let myTotal = 0;
let chipIdx = 0;
let historyData = [];
let localPhase = '';
let currentRoundId = 0;
let locked = true;
let boardState = new Array(TOTAL).fill(null);

let opt = {voice:true, sfx:true};

/* ---------- DOM ELEMENTS ---------- */
const $ = id => document.getElementById(id);
const sleep = ms => new Promise(r=>setTimeout(r,ms));

function fmt(n){ return '₹'+Number(n).toLocaleString('en-IN'); }
function updBal(){
  $('balShow').textContent = fmt(Math.floor(balance));
  $('topBal').textContent = '₹'+Number(balance).toFixed(2);
}
function updBet(){ $('betShow').textContent = fmt(myTotal); }
function toast(m){
  const t = $('toast'); t.textContent = m; t.classList.add('on');
  clearTimeout(window._tt); window._tt = setTimeout(()=>t.classList.remove('on'),2000);
}
function showBan(txt,small,arrow){
  const b = $('banner');
  $('banTxt').textContent = txt;
  b.classList.toggle('small', !!small);
  $('banArrow').style.display = arrow ? 'block' : 'none';
  b.classList.add('on'); $('dim').classList.add('on');
}
function hideBan(){ $('banner').classList.remove('on'); $('dim').classList.remove('on'); }

/* ---------- SOUND / VOICE ---------- */
let AC = null;
function ac(){ if(!AC){ try{ AC = new (window.AudioContext||window.webkitAudioContext)(); }catch(e){} } return AC; }
function beep(freq,dur,type,vol){
  if(!opt.sfx) return; const a = ac(); if(!a) return;
  try{
    const o=a.createOscillator(), g=a.createGain();
    o.type=type||'sine'; o.frequency.value=freq;
    g.gain.setValueAtTime(vol||0.09,a.currentTime);
    g.gain.exponentialRampToValueAtTime(0.001,a.currentTime+dur);
    o.connect(g); g.connect(a.destination); o.start(); o.stop(a.currentTime+dur);
  }catch(e){}
}
function sfxTick(){ beep(880,0.06,'square',0.05); }
function sfxBet(){ beep(660,0.08,'triangle',0.08); setTimeout(()=>beep(990,0.08,'triangle',0.06),60); }
function sfxLock(){ beep(220,0.25,'sawtooth',0.07); }
function sfxScratch(){ beep(180+Math.random()*120,0.05,'sawtooth',0.03); }
function sfxWin(){ [523,659,784,1046].forEach((f,i)=>setTimeout(()=>beep(f,0.18,'sine',0.1),i*110)); }
function sfxLose(){ beep(320,0.15,'sine',0.06); setTimeout(()=>beep(240,0.22,'sine',0.06),150); }

const synth = window.speechSynthesis;
let vVoice = null;
function pickVoice(){
  if(!synth) return;
  const vs = synth.getVoices() || [];
  if(!vs.length) return;
  vVoice = vs.find(v=>/hi[-_]IN/i.test(v.lang) && /female/i.test(v.name)) || vs[0];
}
if(synth){ pickVoice(); synth.onvoiceschanged = pickVoice; }
function say(txt, force){
  if(!opt.voice || !synth || !txt) return;
  if(force) synth.cancel();
  try{
    let u = new SpeechSynthesisUtterance(txt);
    if(vVoice) u.voice = vVoice;
    u.lang = 'hi-IN'; u.rate = 1.0;
    synth.speak(u);
  }catch(e){}
}
function unlock(){ const a=ac(); if(a&&a.state==='suspended')a.resume(); if(synth&&!vVoice)pickVoice(); }
document.addEventListener('click', unlock);

/* ---------- BUILD UI ---------- */
function buildBoard(){
  const bd = $('board'); bd.innerHTML = '';
  for(let i=0;i<TOTAL;i++){
    const c = document.createElement('div');
    c.className = 'cell'; c.id = 'c'+i;
    c.innerHTML = '<div class="pent"></div><span class="fl a">✳</span><span class="fl b">✳</span><span class="fl c">✳</span><span class="fl d">✳</span><div class="tile empty"></div>';
    bd.appendChild(c);
  }
}
function buildBetPanel(){
  const g = $('symgrid'); g.innerHTML = '';
  SYMS.forEach(s=>{
    const b = document.createElement('div');
    b.className='sbtn'; b.id='sb-'+s; b.innerHTML = ART[s];
    b.onclick = ()=>doBet(s);
    g.appendChild(b);
  });
}
$('exL').innerHTML = ART.titali; $('exR').innerHTML = ART.kabutar;

function setCell(i, sym){
  if(!sym) return;
  const c = $('c'+i); if(!c) return;
  const t = c.querySelector('.tile');
  t.classList.remove('empty');
  t.innerHTML = ART[sym];
  c.classList.add('pop');
  setTimeout(()=>c.classList.remove('pop'),500);
}
function syncBoard(serverBoard){
    for(let i=0; i<TOTAL; i++){
        if(serverBoard[i] && serverBoard[i] !== boardState[i]){
            boardState[i] = serverBoard[i];
            setCell(i, serverBoard[i]);
        } else if (!serverBoard[i] && boardState[i]) {
            boardState[i] = null;
            $('c'+i).querySelector('.tile').classList.add('empty');
            $('c'+i).querySelector('.tile').innerHTML = '';
        }
    }
}

/* ---------- GAME ANIMATIONS ---------- */
const RING = 2*Math.PI*23;
function setRing(sec, total){
  const arc = $('ringArc');
  let pct = Math.max(0, 1 - sec/total);
  arc.style.strokeDashoffset = RING * pct;
  $('cdNum').textContent = sec;
  $('cdMini').textContent = sec;
}

function placeScratchOverCell(i){
  const cell = $('c'+i), wrap = $('gamewrap'), sc = $('scratch');
  const cr = cell.getBoundingClientRect(), wr = wrap.getBoundingClientRect();
  const w = Math.min(wr.width*0.46, 180), h = w*1.12;
  let left = cr.left - wr.left + cr.width/2 - w/2;
  let top  = cr.top  - wr.top  + cr.height/2 - h/2;
  left = Math.max(6, Math.min(left, wr.width - w - 6));
  top  = Math.max(6, Math.min(top,  wr.height - h - 6));
  sc.style.width = w+'px'; sc.style.height = h+'px';
  sc.style.left = left+'px'; sc.style.top = top+'px';
  return {left, top, w, h, cr, wr};
}

function drawFoil(cv){
  const ctx = cv.getContext('2d');
  const w = cv.width, h = cv.height;
  ctx.globalCompositeOperation = 'source-over';
  const g = ctx.createLinearGradient(0,0,w,h);
  g.addColorStop(0,'#e9e6f2'); g.addColorStop(.35,'#cfc8e0');
  g.addColorStop(.55,'#efeaf7'); g.addColorStop(1,'#c4bcd8');
  ctx.fillStyle = g; ctx.fillRect(0,0,w,h);
  for(let i=0;i<220;i++){
    ctx.fillStyle = 'rgba(255,255,255,'+(Math.random()*0.5)+')';
    ctx.fillRect(Math.random()*w, Math.random()*h, 1.4, 1.4);
  }
}

async function scratchReveal(winner, cellIdx){
  const sc = $('scratch'), cv = $('scCanvas'), coin = $('scCoin');
  $('scSym').innerHTML = ART[winner];
  const geo = placeScratchOverCell(cellIdx);
  sc.classList.add('on'); sc.classList.remove('fly');
  sc.style.transform = 'scale(.4)'; sc.style.opacity = '0';
  await sleep(30);
  sc.style.transform = 'scale(1)'; sc.style.opacity = '1';
  await sleep(200);

  const inner = sc.querySelector('.sc-inner').getBoundingClientRect();
  cv.width = Math.round(inner.width); cv.height = Math.round(inner.height);
  drawFoil(cv);
  const ctx = cv.getContext('2d');
  ctx.globalCompositeOperation = 'destination-out';
  ctx.lineCap = 'round'; ctx.lineJoin = 'round';

  const W = cv.width, H = cv.height;
  const brush = Math.max(W,H)*0.25;

  let y = H * 0.2;
  ctx.lineWidth = brush;
  for(let i=0; i<3; i++) {
     let xStart = i%2==0 ? W*0.1 : W*0.9;
     let xEnd = i%2==0 ? W*0.9 : W*0.1;
     ctx.beginPath(); ctx.moveTo(xStart, y); ctx.lineTo(xEnd, y); ctx.stroke();
     coin.style.left = (xEnd - 26)+'px'; coin.style.top = (y - 26)+'px';
     sfxScratch();
     await sleep(150);
     y += H*0.3;
  }
  
  ctx.lineWidth = W*2;
  ctx.beginPath(); ctx.moveTo(0,H/2); ctx.lineTo(W,H/2); ctx.stroke();
  cv.style.transition='opacity .2s'; cv.style.opacity='0';
  coin.style.transition='opacity .2s'; coin.style.opacity='0';
  await sleep(250);
  cv.style.transition=''; cv.style.opacity='1'; coin.style.transition=''; coin.style.opacity='1';
}

async function flyToCell(cellIdx){
  const sc = $('scratch'), wrap = $('gamewrap');
  const cell = $('c'+cellIdx);
  const cr = cell.getBoundingClientRect(), sr = sc.getBoundingClientRect();
  const dx = (cr.left + cr.width/2) - (sr.left + sr.width/2);
  const dy = (cr.top + cr.height/2) - (sr.top + sr.height/2);
  const scale = cr.width / sr.width;
  sc.classList.add('fly');
  sc.style.transform = `translate(${dx}px,${dy}px) scale(${scale})`;
  sc.style.opacity = '0.15';
  await sleep(480);
  sc.classList.remove('on'); sc.classList.remove('fly');
  sc.style.transform=''; sc.style.opacity='';
}

function coinRain(){
  const wrap = $('gamewrap');
  for(let i=0;i<12;i++){
    setTimeout(()=>{
      const d = document.createElement('div'); d.className = 'coinfly';
      d.innerHTML = '<svg viewBox="0 0 40 40"><circle cx="20" cy="20" r="18" fill="#ffc21a" stroke="#a35c00" stroke-width="2"/><text x="20" y="27" font-size="18" font-weight="900" text-anchor="middle" fill="#8a4a00" font-family="Arial">$</text></svg>';
      d.style.left = (20+Math.random()*60)+'%'; d.style.top = '55%';
      d.style.setProperty('--dx',(Math.random()*160-80)+'px');
      d.style.setProperty('--dy',(-120-Math.random()*140)+'px');
      d.style.animation = 'cfly 1.1s ease-out forwards';
      wrap.appendChild(d); setTimeout(()=>d.remove(),1200);
    }, i*70);
  }
}

async function triggerResultSequence(winner, fillIdx) {
    if(localPhase === 'revealing') return; 
    localPhase = 'revealing';
    
    // Scratch Animation
    await scratchReveal(winner, fillIdx);

    // Calc Local Win
    const stake = myBets[winner] || 0;
    const mult = EXTRA.includes(winner) ? 15 : 10;
    const won = stake * mult;

    $('sb-'+winner).classList.add('win');
    
    if(won > 0) {
        $('winpopTxt').textContent = 'WIN  +'+fmt(won);
        $('winpop').classList.add('on');
        coinRain(); sfxWin();
        say(HI[winner]+' jita! Aapne '+won+' rupaye jeete.');
    } else {
        sfxLose();
        say(HI[winner]+' jita.');
    }
    
    await sleep(1400);
    
    // Set cell and fly
    boardState[fillIdx] = winner;
    setCell(fillIdx, winner);
    await flyToCell(fillIdx);
    
    $('winpop').classList.remove('on');
    $('c'+fillIdx).classList.remove('target');
    updHistBar();
}


/* ---------- FIX 1: SMOOTH LOCAL TIMER ---------- */
let localElapsedTimer = 0;

setInterval(() => {
    // Ye local UI timer har 100ms me update hota rahega bina atke
    if(localPhase === 'bet' && localElapsedTimer <= 8) {
        localElapsedTimer += 0.1;
        let secLeft = Math.max(0, 8 - localElapsedTimer);
        let ceilSec = Math.ceil(secLeft);
        setRing(ceilSec, 8);
    }
}, 100);

/* ---------- SERVER POLL ---------- */
function pollServer() {
    const fd = new URLSearchParams();
    fd.append('action', 'get_round');
    
    fetch(window.location.href, { method: 'POST', body: fd })
      .then(r => r.json())
      .then(d => {
          if(!d || !d.round) return;
          const r = d.round;
          const serverElapsed = d.elapsed;
          
          balance = d.balance;
          updBal();
          
          historyData = d.history || [];
          updHistBar();

          // Sync local timer with server if difference is > 0.5s (Fixes network lag)
          if(Math.abs(localElapsedTimer - serverElapsed) > 0.5) {
              localElapsedTimer = serverElapsed;
          }

          if (r.id !== currentRoundId) {
              // NEW ROUND TRIGGER
              currentRoundId = r.id;
              localPhase = 'bet';
              localElapsedTimer = 0; // Reset local timer
              locked = false;
              myBets = {}; myTotal = 0; updBet(); clearBadges();
              
              $('symgrid').classList.remove('locked');
              $('cdRing').classList.remove('hide');
              $('rndId').textContent = r.id;
              
              document.querySelectorAll('.cell.target').forEach(c=>c.classList.remove('target'));
              if(r.fillIdx === 0) { 
                 $('board').classList.add('flipall');
                 setTimeout(()=>$('board').classList.remove('flipall'), 900);
              }
              $('c'+r.fillIdx).classList.add('target');
              
              syncBoard(r.board);
              showBan('Please Bet Now');
              say('Bet lagaiye', true);
              beep(760,0.12,'sine',0.08);
              setTimeout(hideBan, 1500);
          }

          // > 8 SECONDS -> LOCKED
          if (serverElapsed > 8 && r.phase === 'locked' && localPhase === 'bet') {
              locked = true;
              $('symgrid').classList.add('locked');
              $('cdRing').classList.add('hide');
              showBan('Bet Locked', true);
              sfxLock(); say('Bet lock', true);
              
              setTimeout(hideBan, 1200);
              // Trigger animations logic
              if(r.winner) {
                 setTimeout(() => triggerResultSequence(r.winner, r.fillIdx), 1200);
              }
          }
      }).catch(e => console.log('Poll Err'));
}

/* ---------- BET ACTION TO SERVER ---------- */
function doBet(sym) {
    if(locked){ toast('Bet band ho gayi!'); return; }
    const chip = CHIPS[chipIdx];
    if(balance < chip){ toast('Balance kam hai!'); return; }
    const cur = (myBets[sym]||0);
    if(cur + chip > 200){ toast('Ek picture par max ₹200'); return; }
    
    // Optimistic UI Update
    myBets[sym] = cur + chip;
    myTotal += chip;
    balance -= chip;
    updBal(); updBet(); badge(sym);
    const b = $('sb-'+sym); b.classList.remove('hit'); void b.offsetWidth; b.classList.add('hit');
    sfxBet();

    const fd = new URLSearchParams();
    fd.append('action', 'place_bet');
    fd.append('symbol', sym);
    fd.append('amount', chip);
    
    fetch(window.location.href, { method: 'POST', body: fd })
       .then(r => r.json())
       .then(d => {
           if(!d.success) {
               toast(d.msg);
               // rollback
               myBets[sym] -= chip; myTotal -= chip; balance += chip;
               updBal(); updBet(); badge(sym);
           } else {
               balance = d.balance; updBal();
           }
       });
}

function badge(sym){
  const b = $('sb-'+sym); if(!b) return;
  let d = b.querySelector('.bdg');
  const v = myBets[sym]||0;
  if(!v){ if(d) d.remove(); return; }
  if(!d){ d = document.createElement('div'); d.className='bdg'; b.appendChild(d); }
  d.textContent = v;
}
function clearBadges(){ SYMS.forEach(s=>{ const b=$('sb-'+s); if(b){ const d=b.querySelector('.bdg'); if(d)d.remove(); b.classList.remove('win'); } }); }

function cycleChip(){ chipIdx=(chipIdx+1)%CHIPS.length; $('chipAmt').textContent=CHIPS[chipIdx]; beep(700,0.05,'square',0.05); }

function doClear() { toast('Server bets cannot be cleared easily in live sync'); }

function updHistBar(){
  const slot = $('hbSlot'); slot.innerHTML = '';
  if(!historyData.length) {
     ['chatri','sun','patang'].forEach(s=>{
        slot.innerHTML += `<div style="display:flex;align-items:center;gap:4px;flex:0 0 auto;opacity:.55"><div class="hb-cell">${ART[s]}</div><span class="hb-pct">—</span></div>`;
     });
     return;
  }
  
  let cnt = {}; let tot = 0;
  historyData.forEach(h => { cnt[h.sym] = (cnt[h.sym]||0)+1; tot++; });
  let top = Object.keys(cnt).sort((a,b)=>cnt[b]-cnt[a]).slice(0,3);
  
  top.forEach(s=>{
    const pct = Math.round(cnt[s]/tot*100);
    slot.innerHTML += `<div style="display:flex;align-items:center;gap:4px;flex:0 0 auto"><div class="hb-cell">${ART[s]}</div><span class="hb-pct">${pct}%</span></div>`;
  });
}

function openHist(){
  const l = $('histList'); l.innerHTML='';
  if(!historyData.length) l.innerHTML='<div class="mrow">Abhi koi result nahi.</div>';
  historyData.forEach(h=>{
    const r = document.createElement('div'); r.className='mrow';
    r.innerHTML = `<span>#${h.no}</span><div class="msym">${ART[h.sym]}</div><span>${NAMES[h.sym]}</span>`;
    l.appendChild(r);
  });
  $('histModal').classList.add('on');
}
function openSet(){ $('setModal').classList.add('on'); }
function closeModal(id){ $(id).classList.remove('on'); }
function tog(k,el){
  opt[k] = !opt[k]; el.classList.toggle('on', opt[k]);
  if(k==='voice' && !opt[k]){ try{ synth.cancel(); }catch(e){} }
}

/* ---------- START LOOP ---------- */
buildBoard();
buildBetPanel();
setInterval(pollServer, 1000); 

</script>
</body>
</html>