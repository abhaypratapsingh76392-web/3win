<?php
session_start();
error_reporting(0);
date_default_timezone_set('Asia/Kolkata');
require_once 'config.php';

$phone = $_SESSION['user_phone'] ?? $_SESSION['phone'] ?? '';
if ($phone === '') {
    header('Location: index.php');
    exit;
}
$_SESSION['user_phone'] = $phone;
$_SESSION['phone'] = $phone;
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
<title>Beginner's Guide - 3win</title>
<style>
* { margin: 0; padding: 0; box-sizing: border-box; font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif; -webkit-tap-highlight-color: transparent; }
body { background: #f5f7fb; color: #222; min-height: 100vh; display: flex; justify-content: center; }
.app { width: 100%; max-width: 480px; min-height: 100vh; background: #f5f7fb; display: flex; flex-direction: column; position: relative; padding-bottom: 40px; }

/* HEADER */
.header { height: 50px; background: #fff; display: flex; align-items: center; justify-content: center; position: sticky; top: 0; z-index: 50; border-bottom: 1px solid #edf0f5; }
.back-btn { position: absolute; left: 16px; font-size: 26px; color: #333; text-decoration: none; cursor: pointer; line-height: 1; display: flex; align-items: center; justify-content: center; }
.header-title { font-size: 18px; font-weight: 600; color: #1e2229; }

/* SEARCH BAR */
.search-wrap { padding: 12px 16px 6px; }
.search-box { display: flex; align-items: center; background: #fff; border-radius: 12px; padding: 10px 14px; box-shadow: 0 2px 6px rgba(0,0,0,0.03); border: 1px solid #eef1f6; }
.search-box svg { width: 18px; height: 18px; stroke: #8a92a6; fill: none; stroke-width: 2; margin-right: 10px; flex-shrink: 0; }
.search-input { border: none; outline: none; background: transparent; width: 100%; font-size: 14px; color: #222; }
.search-input::placeholder { color: #a0a6b5; }

/* HERO BANNER */
.hero-card { margin: 8px 16px 14px; background: linear-gradient(135deg, #4175fc 0%, #1e52db 100%); border-radius: 16px; padding: 20px 18px; color: #fff; box-shadow: 0 6px 18px rgba(65, 117, 252, 0.28); position: relative; overflow: hidden; }
.hero-card::after { content: ''; position: absolute; right: -25px; bottom: -35px; width: 130px; height: 130px; border-radius: 50%; background: rgba(255,255,255,0.1); pointer-events: none; }
.hero-badge { display: inline-flex; align-items: center; gap: 4px; background: rgba(255,255,255,0.2); border-radius: 20px; padding: 4px 10px; font-size: 11px; font-weight: 700; text-transform: uppercase; letter-spacing: 0.5px; margin-bottom: 8px; }
.hero-title { font-size: 20px; font-weight: 800; line-height: 1.25; margin-bottom: 6px; }
.hero-desc { font-size: 13px; opacity: 0.9; line-height: 1.45; }

/* CATEGORY HORIZONTAL PILL TABS */
.tabs-scroll { display: flex; gap: 8px; overflow-x: auto; padding: 0 16px 14px; scrollbar-width: none; }
.tabs-scroll::-webkit-scrollbar { display: none; }
.tab-pill { padding: 9px 16px; border-radius: 24px; background: #fff; color: #667085; font-size: 13px; font-weight: 600; border: 1px solid #eef1f6; cursor: pointer; white-space: nowrap; transition: all 0.2s ease; box-shadow: 0 2px 5px rgba(0,0,0,0.02); display: flex; align-items: center; gap: 6px; }
.tab-pill.active { background: #4175fc; color: #fff; border-color: #4175fc; box-shadow: 0 4px 12px rgba(65, 117, 252, 0.3); }

/* MAIN CONTENT */
.content { padding: 0 16px; display: flex; flex-direction: column; gap: 14px; }

/* GUIDE CARDS */
.guide-card { background: #fff; border-radius: 16px; padding: 18px; box-shadow: 0 2px 8px rgba(0,0,0,0.03); border: 1px solid #f0f2f7; transition: all 0.2s ease; }
.card-head { display: flex; align-items: center; justify-content: space-between; cursor: pointer; }
.card-head-left { display: flex; align-items: center; gap: 12px; }
.icon-wrap { width: 44px; height: 44px; border-radius: 12px; display: flex; align-items: center; justify-content: center; font-size: 22px; flex-shrink: 0; }
.icon-wingo { background: #eef4ff; color: #4175fc; }
.icon-k3 { background: #fef0f2; color: #f5586a; }
.icon-aviator { background: #fff8eb; color: #f7a04c; }
.icon-mines { background: #f0fdf4; color: #22b573; }
.icon-money { background: #fbf0ff; color: #b57bee; }
.icon-rules { background: #ebfbff; color: #00b4d8; }

.card-title-group h3 { font-size: 16px; font-weight: 700; color: #1e2229; line-height: 1.2; margin-bottom: 2px; }
.card-title-group span { font-size: 12px; color: #8a92a6; font-weight: 500; }

.chevron-icon { width: 20px; height: 20px; stroke: #9aa1b4; fill: none; stroke-width: 2.5; stroke-linecap: round; stroke-linejoin: round; transition: transform 0.25s ease; }
.guide-card.open .chevron-icon { transform: rotate(180deg); stroke: #4175fc; }

/* ACCORDION BODY */
.card-details { display: none; padding-top: 16px; margin-top: 14px; border-top: 1px solid #f2f4f8; font-size: 13.5px; line-height: 1.6; color: #4b5565; }
.guide-card.open .card-details { display: block; animation: fadeIn 0.25s ease; }
@keyframes fadeIn { from { opacity: 0; transform: translateY(-4px); } to { opacity: 1; transform: translateY(0); } }

/* HIGHLIGHT BOXES */
.alert-box { border-radius: 12px; padding: 12px 14px; margin: 12px 0; font-size: 13px; line-height: 1.5; display: flex; gap: 10px; align-items: flex-start; }
.alert-dos { background: #f0fdf4; border: 1px solid #bbf7d0; color: #166534; }
.alert-donts { background: #fef2f2; border: 1px solid #fecaca; color: #991b1b; }
.alert-icon { font-size: 16px; font-weight: bold; line-height: 1; }

/* STRATEGY TABLE */
.rule-table { width: 100%; border-collapse: collapse; margin: 12px 0; font-size: 12.5px; }
.rule-table th { background: #f8fafc; padding: 9px 8px; text-align: left; color: #64748b; font-weight: 700; border-bottom: 1px solid #e2e8f0; }
.rule-table td { padding: 9px 8px; border-bottom: 1px solid #f1f5f9; color: #334155; }
.tag-win { display: inline-block; padding: 2px 8px; border-radius: 6px; font-weight: 800; font-size: 11px; }
.tag-green { background: #e8f8f0; color: #22b573; }
.tag-blue { background: #edf4fe; color: #4175fc; }
.tag-red { background: #feefef; color: #f5586a; }

/* BOTTOM ACTION BAR */
.btn-play-wrap { margin-top: 25px; padding: 0 16px; }
.btn-play { width: 100%; height: 50px; border-radius: 25px; background: linear-gradient(135deg, #4175fc 0%, #1e52db 100%); color: #fff; font-size: 16px; font-weight: 700; border: none; cursor: pointer; display: flex; align-items: center; justify-content: center; gap: 8px; box-shadow: 0 6px 18px rgba(65, 117, 252, 0.35); text-decoration: none; transition: transform 0.15s ease; }
.btn-play:active { transform: scale(0.98); }
</style>
</head>
<body>

<div class="app">
    <!-- HEADER -->
    <div class="header">
        <a href="account.php" class="back-btn">‹</a>
        <div class="header-title">Beginner's Guide</div>
    </div>

    <!-- SEARCH BAR -->
    <div class="search-wrap">
        <div class="search-box">
            <svg viewBox="0 0 24 24"><circle cx="11" cy="11" r="8"></circle><line x1="21" y1="21" x2="16.65" y2="16.65"></line></svg>
            <input type="text" id="searchInput" class="search-input" placeholder="Search rules (e.g. WinGo, Big Small, Aviator, Multiplier)..." oninput="filterGuides()">
        </div>
    </div>

    <!-- HERO PROMO BANNER -->
    <div class="hero-card">
        <div class="hero-badge">3win Official Academy</div>
        <div class="hero-title">Master The Games & Win Smart</div>
        <div class="hero-desc">Kahan bet lagana hai aur kahan NAHI lagana hai — sab kuch detail me seekhein aur apna profit badhayein!</div>
    </div>

    <!-- HORIZONTAL TABS SCROLL -->
    <div class="tabs-scroll">
        <button class="tab-pill active" onclick="switchCategory('all', this)">📋 All Guides</button>
        <button class="tab-pill" onclick="switchCategory('dos-donts', this)">⚡ Kahan Bet Lagayein?</button>
        <button class="tab-pill" onclick="switchCategory('wingo', this)">🎯 WinGo</button>
        <button class="tab-pill" onclick="switchCategory('k3', this)">🎲 K3 Dice</button>
        <button class="tab-pill" onclick="switchCategory('aviator', this)">🚀 Aviator</button>
        <button class="tab-pill" onclick="switchCategory('mines', this)">💣 Mines</button>
        <button class="tab-pill" onclick="switchCategory('money', this)">🎰 Money Coming</button>
    </div>

    <!-- GUIDES ACCORDION CONTAINER -->
    <div class="content" id="guidesContainer">

        <!-- CARD 0: GOLDEN BETTING RULES (Kahan Bet Lagayein Aur Kahan Nahi) -->
        <div class="guide-card open" data-cat="dos-donts">
            <div class="card-head" onclick="toggleCard(this)">
                <div class="card-head-left">
                    <div class="icon-wrap icon-rules">⚡</div>
                    <div class="card-title-group">
                        <h3>Kahan Bet Lagayein & Kahan NAHI?</h3>
                        <span>Pro Betting Strategy & Money Management</span>
                    </div>
                </div>
                <svg class="chevron-icon" viewBox="0 0 24 24"><polyline points="6 9 12 15 18 9"></polyline></svg>
            </div>
            <div class="card-details">
                <p>Platform par jeetne ke liye sabse zaroori cheez hai <strong>"Bankroll Discipline"</strong>. Agar aap bina plan ke kisi bhi number par bet lagate rahoge toh loss hoga. Niche diye rules hamesha follow karein:</p>
                
                <div class="alert-box alert-dos">
                    <span class="alert-icon">✅</span>
                    <div>
                        <strong>YAHAN BET LAGAYEIN (Safe & Smart Play):</strong>
                        <ul style="margin-top: 4px; padding-left: 18px;">
                            <li><strong>High Probability Bets:</strong> WinGo me <strong>Big / Small</strong> aur <strong>Red / Green</strong> (98% probability payout 2X).</li>
                            <li><strong>K3 Dice me:</strong> Sum Big (11-18) ya Small (3-10) aur Even / Odd chunein.</li>
                            <li><strong>Aviator / GoRush me:</strong> Auto Cash-Out ko <strong>1.30X se 1.80X</strong> par set karein. Chhota profit regular banayein.</li>
                            <li><strong>Mines me:</strong> Sirf 1 ya 2 Mines set karein aur 3-4 diamonds kholte hi <strong>Cash Out</strong> karein.</li>
                        </ul>
                    </div>
                </div>

                <div class="alert-box alert-donts">
                    <span class="alert-icon">❌</span>
                    <div>
                        <strong>YAHAN BET KABHI NA LAGAYEIN (Danger Zones):</strong>
                        <ul style="margin-top: 4px; padding-left: 18px;">
                            <li><strong>Single Number Greed:</strong> WinGo me apna saara balance kisi ek single number (9X) par kabhi na lagayein.</li>
                            <li><strong>All-In Betting:</strong> Wallet ka 100% balance ek hi round me lagana 100% loss ka sabse bada reason hai. Hamesha wallet ka sirf 5% se 10% per round lagayein.</li>
                            <li><strong>Aviator 100X Greed:</strong> Airplane ke 10X ya 50X tak jaane ka wait na karein, 75% flights 2X se pehle flew-away ho jaati hain.</li>
                            <li><strong>Chasing Losses:</strong> Agar lagatar 2 round loss ho, to turant ruk jayein aur 15 minute break lein.</li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>

        <!-- CARD 1: WINGO GUIDE -->
        <div class="guide-card" data-cat="wingo">
            <div class="card-head" onclick="toggleCard(this)">
                <div class="card-head-left">
                    <div class="icon-wrap icon-wingo">🎯</div>
                    <div class="card-title-group">
                        <h3>WinGo Color & Number Guide</h3>
                        <span>1 Min, 3 Min, 5 Min & 30 Sec Game</span>
                    </div>
                </div>
                <svg class="chevron-icon" viewBox="0 0 24 24"><polyline points="6 9 12 15 18 9"></polyline></svg>
            </div>
            <div class="card-details">
                <p>WinGo ek bahut simple color aur number prediction lottery game hai. Har round me 0 se 9 tak ka ek winning number nikalta hai.</p>
                
                <table class="rule-table">
                    <thead>
                        <tr>
                            <th>Bet Type</th>
                            <th>Rules & Numbers</th>
                            <th>Multiplier</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td><strong>Green</strong></td>
                            <td>Numbers 1, 3, 7, 9 (Agar 5 aaye to half win)</td>
                            <td><span class="tag-win tag-green">2.0X / 1.5X</span></td>
                        </tr>
                        <tr>
                            <td><strong>Red</strong></td>
                            <td>Numbers 2, 4, 6, 8 (Agar 0 aaye to half win)</td>
                            <td><span class="tag-win tag-red">2.0X / 1.5X</span></td>
                        </tr>
                        <tr>
                            <td><strong>Violet</strong></td>
                            <td>Special number 0 aur 5 par lagta hai</td>
                            <td><span class="tag-win tag-blue">4.5X</span></td>
                        </tr>
                        <tr>
                            <td><strong>Small</strong></td>
                            <td>Numbers 0, 1, 2, 3, 4</td>
                            <td><span class="tag-win tag-green">2.0X</span></td>
                        </tr>
                        <tr>
                            <td><strong>Big</strong></td>
                            <td>Numbers 5, 6, 7, 8, 9</td>
                            <td><span class="tag-win tag-green">2.0X</span></td>
                        </tr>
                        <tr>
                            <td><strong>Exact Number</strong></td>
                            <td>Koi bhi exact number (0 se 9 tak) predict karein</td>
                            <td><span class="tag-win tag-blue">9.0X</span></td>
                        </tr>
                    </tbody>
                </table>
                <p><strong>💡 Pro Tip:</strong> History chart dekh kar pattern samjhein. Agar lagatar 3 baar Big aaya hai to trend analysis ke sath bet karein.</p>
            </div>
        </div>

        <!-- CARD 2: K3 DICE GUIDE -->
        <div class="guide-card" data-cat="k3">
            <div class="card-head" onclick="toggleCard(this)">
                <div class="card-head-left">
                    <div class="icon-wrap icon-k3">🎲</div>
                    <div class="card-title-group">
                        <h3>K3 Dice Prediction Guide</h3>
                        <span>3 Dice Combination & Total Sum</span>
                    </div>
                </div>
                <svg class="chevron-icon" viewBox="0 0 24 24"><polyline points="6 9 12 15 18 9"></polyline></svg>
            </div>
            <div class="card-details">
                <p>K3 game me 3 Dice (paase) roll hote hain. Teenon paaso ke number jod kar total sum banaya jata hai (3 se 18 tak):</p>
                <ul style="padding-left: 18px; margin: 8px 0;">
                    <li><strong>Small:</strong> Agar 3 dice ka jod <strong>3 se 10</strong> ke beech ho (2X Payout).</li>
                    <li><strong>Big:</strong> Agar 3 dice ka jod <strong>11 se 18</strong> ke beech ho (2X Payout).</li>
                    <li><strong>Odd / Even:</strong> Agar total jod visham (Odd) ya sam (Even) ho (2X Payout).</li>
                    <li><strong>2 Same Dice:</strong> Agar 2 dice me same number aaye (Jaise 2-2, 5-5) ➔ <strong>5X Multiplier!</strong></li>
                    <li><strong>Any Triple (3 Same):</strong> Agar teeno dice same aayein (1-1-1 ya 6-6-6) ➔ <strong>24X se 207X Multiplier!</strong></li>
                </ul>
            </div>
        </div>

        <!-- CARD 3: AVIATOR & GORUSH -->
        <div class="guide-card" data-cat="aviator">
            <div class="card-head" onclick="toggleCard(this)">
                <div class="card-head-left">
                    <div class="icon-wrap icon-aviator">🚀</div>
                    <div class="card-title-group">
                        <h3>Aviator & GoRush Live Guide</h3>
                        <span>Crash Multiplier & Timing Strategy</span>
                    </div>
                </div>
                <svg class="chevron-icon" viewBox="0 0 24 24"><polyline points="6 9 12 15 18 9"></polyline></svg>
            </div>
            <div class="card-details">
                <p>Aviator aur GoRush me rocket/airplane udate hi multiplier <strong>1.00x</strong> se badhna shuru hota hai. Plane udne (Flew Away) se pehle aapko <strong>CASH OUT</strong> dabana hota hai.</p>
                
                <div class="alert-box alert-dos">
                    <span class="alert-icon">💡</span>
                    <div>
                        <strong>Winning Strategy:</strong>
                        <p>Naye players hamesha <strong>"Auto Cash Out"</strong> switch on karein aur use <strong>1.40x</strong> par set karein. Agar aap ₹100 lagate ho aur plane 1.40x cross karta hai, to bina risk aapko ₹140 mil jayenge!</p>
                    </div>
                </div>
            </div>
        </div>

        <!-- CARD 4: MINES GUIDE -->
        <div class="guide-card" data-cat="mines">
            <div class="card-head" onclick="toggleCard(this)">
                <div class="card-head-left">
                    <div class="icon-wrap icon-mines">💣</div>
                    <div class="card-title-group">
                        <h3>Mines Game Strategy</h3>
                        <span>25 Boxes Gold & Bomb Grid</span>
                    </div>
                </div>
                <svg class="chevron-icon" viewBox="0 0 24 24"><polyline points="6 9 12 15 18 9"></polyline></svg>
            </div>
            <div class="card-details">
                <p>Mines 5x5 ke 25 boxes ka game hai jisme Gold Stars aur Bomb chupe hote hain:</p>
                <ol style="padding-left: 18px; margin: 8px 0;">
                    <li>Mines count select karein (Best choice: <strong>1 ya 2 Mines</strong>).</li>
                    <li>Bet lagakar box open karein. Jitne stars khulenge multiplier utna badhta jayega.</li>
                    <li><strong>Sabse badi galti:</strong> Log saare 24 box kholne ki koshish me blast ho jaate hain. <strong>3 se 4 star khulte hi Cash Out karein!</strong></li>
                </ol>
            </div>
        </div>

        <!-- CARD 5: MONEY COMING (JILI SLOT) -->
        <div class="guide-card" data-cat="money">
            <div class="card-head" onclick="toggleCard(this)">
                <div class="card-head-left">
                    <div class="icon-wrap icon-money">🎰</div>
                    <div class="card-title-group">
                        <h3>Money Coming (JILI Slot)</h3>
                        <span>Reels, Unlocks & Lucky Wheel</span>
                    </div>
                </div>
                <svg class="chevron-icon" viewBox="0 0 24 24"><polyline points="6 9 12 15 18 9"></polyline></svg>
            </div>
            <div class="card-details">
                <p>Money Coming ek world-famous slot machine hai jisme 3 number reels aur 1 multiplier reel hoti hai:</p>
                <ul style="padding-left: 18px; margin: 8px 0;">
                    <li><strong>Bet ₹10 Unlock:</strong> Bet ₹10 ya usse upar karne par 4th box me <strong>10X Multiplier</strong> unlock hota hai.</li>
                    <li><strong>Bet ₹50 Unlock:</strong> Bet ₹50 karne par <strong>SCATTER (Wheel All)</strong> unlock hota hai jo upar ka Golden Wheel spin karta hai!</li>
                    <li><strong>Reels Math:</strong> Agar pehle box me 1, doosre me 0 aur teesre me 0 aata hai to base win 100 banta hai, jo 4th reel ke multiplier se multiply hota hai.</li>
                </ul>
            </div>
        </div>

    </div>

    <!-- START PLAYING NOW BUTTON -->
    <div class="btn-play-wrap">
        <a href="dashboard.php" class="btn-play">
            <span>Start Playing On 3win</span>
            <span style="font-size: 18px;">➔</span>
        </a>
    </div>
</div>

<script>
// Filter by horizontal tabs
function switchCategory(cat, btn) {
    document.querySelectorAll('.tab-pill').forEach(b => b.classList.remove('active'));
    btn.classList.add('active');

    const cards = document.querySelectorAll('.guide-card');
    cards.forEach(c => {
        if (cat === 'all' || c.dataset.cat === cat) {
            c.style.display = 'block';
            if (cat !== 'all') {
                c.classList.add('open');
            }
        } else {
            c.style.display = 'none';
        }
    });
}

// Toggle individual accordion
function toggleCard(head) {
    const card = head.parentElement;
    card.classList.toggle('open');
}

// Search Filter function
function filterGuides() {
    const q = document.getElementById('searchInput').value.toLowerCase().trim();
    const cards = document.querySelectorAll('.guide-card');

    cards.forEach(c => {
        const text = c.innerText.toLowerCase();
        if (text.includes(q)) {
            c.style.display = 'block';
            if (q.length > 2) c.classList.add('open');
        } else {
            c.style.display = 'none';
        }
    });
}
</script>
</body>
</html>