<?php
require_once 'config.php';

if (!isset($_SESSION['phone'])) {
    header('Location: login.php');
    exit;
}

$phone = $_SESSION['phone'];
$userData = firebase_read("users/" . $phone);
$balance = $userData['balance'] ?? 0;

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    header('Content-Type: application/json');
    $action = $_POST['action'];

    if ($action === 'create_order') {
        $amount = floatval($_POST['amount'] ?? 0);
        $type = $_POST['type'] ?? 'UPI_QR';
        if ($amount < 100) { echo json_encode(['success'=>false,'message'=>'Minimum deposit is Rs.100!']); exit; }
        if ($amount > 50000) { echo json_encode(['success'=>false,'message'=>'Maximum deposit is Rs.50,000!']); exit; }
        $adminSettings = firebase_read("admin_settings");
        $upiId = '';
        if ($type === 'UPI_QR') $upiId = $adminSettings['upi_qr_id'] ?? '';
        elseif ($type === 'PAYTM_QR') $upiId = $adminSettings['paytm_upi_id'] ?? '';
        elseif ($type === 'UPI') $upiId = $adminSettings['upi_direct_id'] ?? '';
        if (empty($upiId)) { echo json_encode(['success'=>false,'message'=>'Payment method not available. Contact admin!']); exit; }
        $bonus = round($amount * 0.05, 2);
        $totalGet = $amount + $bonus;
        $orderId = 'RC'.date('YmdHis').rand(100,999).substr($phone,-4).chr(rand(97,122));
        $orderData = [
            'order_id'=>$orderId,'amount'=>$amount,'bonus'=>$bonus,
            'total_get'=>$totalGet,'type'=>$type,'status'=>'Pending',
            'upi_id'=>$upiId,'date'=>date('Y-m-d'),'time'=>date('Y-m-d H:i:s'),
            'phone'=>$phone,'utr'=>''
        ];
        $deposits = firebase_read("deposits/".$phone) ?? [];
        if (!is_array($deposits)) $deposits = [];
        $deposits[$orderId] = $orderData;
        firebase_write("deposits/".$phone, $deposits);
        $adminDeposits = firebase_read("admin_deposits") ?? [];
        if (!is_array($adminDeposits)) $adminDeposits = [];
        $adminDeposits[$orderId] = $orderData;
        firebase_write("admin_deposits", $adminDeposits);
        echo json_encode(['success'=>true,'order_id'=>$orderId,'amount'=>$amount,
            'bonus'=>$bonus,'total_get'=>$totalGet,'upi_id'=>$upiId,'type'=>$type]);
        exit;
    }

    if ($action === 'submit_utr') {
        $orderId = $_POST['order_id'] ?? '';
        $utr = trim($_POST['utr'] ?? '');
        if (strlen($utr) < 10) { echo json_encode(['success'=>false,'message'=>'Please enter valid UTR!']); exit; }
        $deposits = firebase_read("deposits/".$phone) ?? [];
        if (isset($deposits[$orderId])) {
            $deposits[$orderId]['utr'] = $utr;
            $deposits[$orderId]['status'] = 'Processing';
            firebase_write("deposits/".$phone, $deposits);
            $adminDeposits = firebase_read("admin_deposits") ?? [];
            if (isset($adminDeposits[$orderId])) {
                $adminDeposits[$orderId]['utr'] = $utr;
                $adminDeposits[$orderId]['status'] = 'Processing';
                firebase_write("admin_deposits", $adminDeposits);
            }
            echo json_encode(['success'=>true,'message'=>'UTR submitted!']);
        } else {
            echo json_encode(['success'=>false,'message'=>'Order not found!']);
        }
        exit;
    }

    if ($action === 'get_balance') {
        $fresh = firebase_read("users/".$phone);
        echo json_encode(['success'=>true,'balance'=>$fresh['balance'] ?? 0]);
        exit;
    }
}

$deposits = firebase_read("deposits/".$phone) ?? [];
if (!is_array($deposits)) $deposits = [];
usort($deposits, function($a,$b){ return strcmp($b['time']??'',$a['time']??''); });
$recentDeposits = array_slice($deposits, 0, 5);
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
<title>Deposit</title>
<style>
*{margin:0;padding:0;box-sizing:border-box;-webkit-tap-highlight-color:transparent;}
body{
    font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',sans-serif;
    background:#f0f2f8;
    max-width:480px;
    margin:0 auto;
    min-height:100vh;
    padding-bottom:110px;
}

/* HEADER */
.hdr{
    background:#fff;
    display:flex;align-items:center;justify-content:space-between;
    padding:14px 16px;
    position:sticky;top:0;z-index:100;
    box-shadow:0 1px 4px rgba(0,0,0,0.08);
}
.hdr-back{
    width:32px;height:32px;
    display:flex;align-items:center;justify-content:center;
    text-decoration:none;cursor:pointer;
    border:none;background:none;
}
.back-arrow{
    width:10px;height:10px;
    border-left:2.5px solid #333;
    border-bottom:2.5px solid #333;
    transform:rotate(45deg);
    margin-left:4px;
    display:block;
}
.hdr-title{font-size:17px;font-weight:600;color:#222;}
.hdr-link{font-size:13px;color:#555;text-decoration:none;font-weight:500;}

/* BALANCE CARD */
.bal-card{
    background:linear-gradient(135deg,#4b7cf3 0%,#2f55d4 100%);
    margin:12px;border-radius:18px;
    padding:20px 20px 30px;
    color:#fff;position:relative;overflow:hidden;
}
.bal-card::before{
    content:'';position:absolute;
    top:-50px;right:-40px;
    width:170px;height:170px;
    background:rgba(255,255,255,0.07);border-radius:50%;
}
.bal-card::after{
    content:'';position:absolute;
    bottom:-55px;left:-35px;
    width:150px;height:150px;
    background:rgba(255,255,255,0.05);border-radius:50%;
}
.bal-top{
    display:flex;align-items:center;gap:8px;
    margin-bottom:10px;position:relative;z-index:1;
}
.bal-top img{
    width:22px;height:22px;
    object-fit:contain;
    filter:brightness(0) invert(1);
    opacity:0.9;
}
.bal-label{font-size:13px;opacity:0.9;font-weight:500;}
.bal-row{
    display:flex;align-items:center;gap:12px;
    position:relative;z-index:1;
}
.bal-number{font-size:34px;font-weight:800;letter-spacing:-0.5px;}
.ref-btn{
    background:rgba(255,255,255,0.2);
    border:none;border-radius:50%;
    width:36px;height:36px;
    display:flex;align-items:center;justify-content:center;
    cursor:pointer;transition:background 0.2s;flex-shrink:0;
}
.ref-btn:active{background:rgba(255,255,255,0.35);}
.ref-btn img{
    width:20px;height:20px;
    object-fit:contain;
    filter:brightness(0) invert(1);
}
.ref-btn.spinning img{animation:spinIt 0.6s linear;}
@keyframes spinIt{from{transform:rotate(0)}to{transform:rotate(360deg)}}
.bal-dots{
    position:absolute;bottom:16px;right:20px;
    font-size:14px;opacity:0.45;letter-spacing:5px;
    z-index:1;
}

/* PAY METHODS */
.card{
    background:#fff;margin:0 12px 10px;
    border-radius:16px;padding:14px;
    box-shadow:0 1px 6px rgba(0,0,0,0.06);
}
.pay-grid{
    display:grid;grid-template-columns:1fr 1fr 1fr;gap:10px;
}
.pay-item{
    position:relative;
    border:2px solid #e4eaf5;border-radius:14px;
    padding:10px 6px 8px;text-align:center;
    cursor:pointer;background:#f8f9fd;transition:all 0.2s;
}
.pay-item.active{border-color:#4b7cf3;background:#eef3fd;}
.pay-item img{
    width:56px;height:56px;
    object-fit:cover;border-radius:10px;
    display:block;margin:0 auto;
}
.pay-lbl{
    font-size:11px;font-weight:700;color:#555;margin-top:6px;
    white-space:nowrap;overflow:hidden;text-overflow:ellipsis;
}
.pay-item.active .pay-lbl{color:#4b7cf3;}

/* Bonus badge - CSS only, no emoji */
.bonus-tag{
    position:absolute;top:-7px;right:-3px;
    background:#d92b2b;color:#fff;
    font-size:9px;font-weight:800;
    padding:3px 6px;border-radius:5px;
    line-height:1.3;
    box-shadow:0 2px 4px rgba(217,43,43,0.4);
}
.bonus-tag::after{
    content:'';
    position:absolute;bottom:-4px;left:0;
    border-left:4px solid #8e1a1a;
    border-bottom:4px solid transparent;
}

/* SELECT CHANNEL */
.sec-hdr{display:flex;align-items:center;gap:10px;margin-bottom:12px;}
/* Pencil icon - CSS */
.icon-pencil{
    width:22px;height:22px;position:relative;flex-shrink:0;
}
.icon-pencil::before{
    content:'';position:absolute;
    top:2px;left:6px;
    width:10px;height:14px;
    background:#4b7cf3;border-radius:2px 2px 0 0;
    transform:rotate(-10deg);
}
.icon-pencil::after{
    content:'';position:absolute;
    bottom:0;left:5px;
    border-left:6px solid transparent;
    border-right:6px solid transparent;
    border-top:7px solid #4b7cf3;
    transform:rotate(-10deg);
}
.sec-title-txt{font-size:15px;font-weight:700;color:#222;}
.channel-box{
    background:linear-gradient(135deg,#4b7cf3,#2f55d4);
    border-radius:12px;padding:14px 16px;color:#fff;
}
.channel-name{font-size:15px;font-weight:700;margin-bottom:3px;}
.channel-info{font-size:12px;opacity:0.82;}

/* DEPOSIT AMOUNT */
/* Truck icon - CSS */
.icon-truck{
    width:34px;height:26px;position:relative;flex-shrink:0;
}
.icon-truck::before{
    content:'';position:absolute;
    top:0;right:0;
    width:24px;height:16px;
    background:#4b7cf3;border-radius:3px 3px 0 0;
}
.icon-truck::after{
    content:'';position:absolute;
    top:5px;left:0;
    width:14px;height:11px;
    background:#2f55d4;border-radius:2px 0 0 0;
}
.truck-base{
    position:absolute;bottom:0;left:0;right:0;
    height:4px;background:#4b7cf3;border-radius:0 0 2px 2px;
}
.truck-w1,.truck-w2{
    position:absolute;bottom:-4px;
    width:9px;height:9px;
    background:#1e293b;border-radius:50%;
    border:2px solid #e0e8ff;
}
.truck-w1{left:4px;}
.truck-w2{right:4px;}

.amt-grid{
    display:grid;grid-template-columns:1fr 1fr 1fr;
    gap:8px;margin-bottom:14px;
}
.amt-chip{
    border:1.5px solid #d0d8ee;border-radius:9px;
    padding:11px 8px;
    display:flex;align-items:center;gap:3px;
    font-size:14px;color:#4b7cf3;font-weight:700;
    cursor:pointer;background:#fff;transition:all 0.18s;
}
.amt-chip:active{transform:scale(0.97);}
.amt-chip.sel{background:#4b7cf3;border-color:#4b7cf3;color:#fff;}
.chip-rs{font-size:13px;}

/* You get box */
.yg-box{
    background:#f0f6ff;border-radius:12px;
    overflow:hidden;margin-bottom:12px;
    border:1.5px solid #d5e4fb;
}
.yg-head{
    background:#4b7cf3;padding:10px 14px;
    display:flex;justify-content:space-between;align-items:center;
    color:#fff;font-size:14px;font-weight:700;
}
.yg-val{font-size:18px;color:#b8ffd9;font-weight:800;}
.yg-row{
    padding:8px 14px;display:flex;
    justify-content:space-between;
    font-size:13px;color:#555;
    border-bottom:1px solid #ddeafb;
}
.yg-row:last-child{border-bottom:none;}
.yg-bonus{color:#15803d;font-weight:700;}

/* Custom amount input */
.amt-inp-box{
    display:flex;align-items:center;
    background:#f4f6fb;border-radius:10px;
    padding:12px 14px;gap:8px;
    border:1.5px solid #e0e8f5;
}
/* Rupee symbol box - CSS */
.rupee-box{
    width:28px;height:28px;
    background:#4b7cf3;border-radius:6px;
    display:flex;align-items:center;justify-content:center;
    flex-shrink:0;
    font-size:15px;font-weight:900;color:#fff;
    font-family:serif;
}
.amt-inp{
    flex:1;border:none;background:none;
    font-size:15px;color:#333;outline:none;font-weight:500;
}
.amt-inp::placeholder{color:#b0b8cc;font-size:13px;}
/* Clear button - CSS X */
.clear-x-btn{
    width:22px;height:22px;
    background:#bdc5d8;border:none;
    border-radius:50%;cursor:pointer;
    flex-shrink:0;position:relative;
    display:flex;align-items:center;justify-content:center;
}
.clear-x-btn::before,.clear-x-btn::after{
    content:'';position:absolute;
    width:11px;height:2px;
    background:#fff;border-radius:2px;
}
.clear-x-btn::before{transform:rotate(45deg);}
.clear-x-btn::after{transform:rotate(-45deg);}

/* RULES */
/* Book icon - CSS */
.icon-book{
    width:26px;height:28px;position:relative;flex-shrink:0;
}
.icon-book::before{
    content:'';position:absolute;
    top:0;left:4px;
    width:20px;height:26px;
    border:2.5px solid #4b7cf3;
    border-radius:1px 4px 4px 1px;
    background:#eef3fd;
}
.icon-book::after{
    content:'';position:absolute;
    top:0;left:2px;
    width:5px;height:26px;
    background:#4b7cf3;border-radius:2px 0 0 2px;
}
/* Diamond bullet */
.diamond{
    width:8px;height:8px;
    background:#4b7cf3;transform:rotate(45deg);
    flex-shrink:0;margin-top:4px;border-radius:1px;
}
.rule-row{
    display:flex;align-items:flex-start;gap:10px;
    margin-bottom:10px;font-size:13px;color:#555;line-height:1.55;
}
.rule-row:last-child{margin-bottom:0;}

/* DEPOSIT HISTORY */
.hist-wrap{margin:0 12px 10px;}
.hist-hdr{display:flex;align-items:center;gap:10px;margin-bottom:12px;}
/* List icon - CSS */
.icon-list{
    width:32px;height:30px;
    background:#eef3fd;border-radius:8px;
    position:relative;flex-shrink:0;
}
.icon-list::before{
    content:'';position:absolute;
    top:7px;left:7px;
    width:18px;height:2px;
    background:#4b7cf3;border-radius:2px;
    box-shadow:0 5px 0 #4b7cf3, 0 10px 0 #4b7cf3;
}
.hist-title{font-size:17px;font-weight:700;color:#222;}

.hist-card{
    background:#fff;border-radius:14px;
    padding:14px 16px;margin-bottom:10px;
    box-shadow:0 1px 5px rgba(0,0,0,0.06);
}
.hc-top{
    display:flex;justify-content:space-between;align-items:center;
    margin-bottom:10px;
}
.dep-badge{
    background:#16a34a;color:#fff;
    font-size:13px;font-weight:700;
    padding:5px 14px;border-radius:8px;
}
.st-complete{color:#16a34a;font-weight:700;font-size:14px;}
.st-pending{color:#d97706;font-weight:700;font-size:14px;}
.st-processing{color:#4b7cf3;font-weight:700;font-size:14px;}
.st-failed{color:#dc2626;font-weight:700;font-size:14px;}
.hc-row{
    display:flex;justify-content:space-between;
    padding:5px 0;border-bottom:1px solid #f3f4f6;
    font-size:13px;
}
.hc-row:last-child{border-bottom:none;}
.hc-lbl{color:#9ca3af;}
.hc-val{color:#374151;font-weight:500;}
.hc-val.org{color:#ea580c;font-weight:700;}
.hc-val.grn{color:#16a34a;font-weight:700;}
/* Copy row */
.copy-row{display:flex;align-items:center;gap:6px;cursor:pointer;}
.copy-row-txt{font-size:11px;color:#6b7280;}
/* Copy icon - CSS double square */
.copy-ico{
    width:15px;height:15px;position:relative;flex-shrink:0;
}
.copy-ico::before{
    content:'';position:absolute;
    top:0;left:2px;
    width:11px;height:12px;
    border:1.5px solid #9ca3af;border-radius:2px;background:#fff;
}
.copy-ico::after{
    content:'';position:absolute;
    bottom:0;left:0;
    width:11px;height:12px;
    border:1.5px solid #9ca3af;border-radius:2px;background:#f5f5f5;
}
.utr-hist-btn{
    width:100%;
    background:linear-gradient(135deg,#4b7cf3,#2f55d4);
    color:#fff;border:none;border-radius:10px;
    padding:13px;font-size:15px;font-weight:700;
    cursor:pointer;margin-top:10px;
}
.all-hist-btn{
    display:block;text-align:center;
    padding:14px;background:#fff;
    border-radius:14px;color:#4b7cf3;
    font-size:15px;font-weight:700;
    margin:0 0 16px;text-decoration:none;
    box-shadow:0 1px 5px rgba(0,0,0,0.06);
}
.no-hist{text-align:center;padding:40px;color:#bbb;font-size:14px;}
/* No history folder icon - CSS */
.no-hist-ico{
    width:50px;height:42px;margin:0 auto 12px;position:relative;
}
.no-hist-ico::before{
    content:'';position:absolute;
    bottom:0;left:0;
    width:50px;height:34px;
    border:2.5px solid #dde3f0;border-radius:0 4px 4px 4px;
    background:#f8faff;
}
.no-hist-ico::after{
    content:'';position:absolute;
    top:0;left:0;
    width:22px;height:10px;
    border:2.5px solid #dde3f0;border-top-right-radius:6px;
    border-bottom:none;background:#f8faff;
}

/* BOTTOM BAR */
.btm-bar{
    position:fixed;bottom:0;left:50%;
    transform:translateX(-50%);
    width:100%;max-width:480px;
    background:#fff;
    padding:12px 16px;
    box-shadow:0 -2px 12px rgba(0,0,0,0.09);
    display:flex;align-items:center;justify-content:space-between;
    z-index:200;
}
.btm-left-lbl{font-size:12px;color:#9ca3af;margin-bottom:2px;}
.btm-left-name{font-size:14px;font-weight:700;color:#222;}
.dep-main-btn{
    background:linear-gradient(135deg,#4b7cf3,#2f55d4);
    color:#fff;border:none;border-radius:24px;
    padding:13px 26px;font-size:15px;font-weight:700;
    cursor:pointer;min-width:140px;transition:all 0.2s;
}
.dep-main-btn.dis{background:#d1d5db;cursor:not-allowed;}

/* CS FAB */
.cs-fab{
    position:fixed;bottom:88px;right:16px;
    width:54px;height:54px;border-radius:50%;
    background:#fff;
    box-shadow:0 4px 16px rgba(0,0,0,0.14);
    display:flex;align-items:center;justify-content:center;
    z-index:201;text-decoration:none;
}
.cs-fab img{width:38px;height:38px;border-radius:50%;object-fit:contain;}

/* QR MODAL */
.modal-bg{
    display:none;position:fixed;
    top:0;left:0;right:0;bottom:0;
    background:rgba(0,0,0,0.6);
    z-index:400;
    align-items:flex-end;justify-content:center;
}
.modal-bg.show{display:flex;}
.modal-sheet{
    background:#fff;width:100%;max-width:480px;
    border-radius:22px 22px 0 0;
    max-height:93vh;overflow-y:auto;
    animation:slideUp 0.3s ease;
}
@keyframes slideUp{from{transform:translateY(100%)}to{transform:translateY(0)}}

.qr-hdr{
    display:flex;align-items:center;justify-content:space-between;
    padding:16px 16px 12px;
    border-bottom:1px solid #f3f4f6;
}
.qr-title{font-size:17px;font-weight:700;color:#222;}
/* Close btn - CSS */
.close-btn{
    width:30px;height:30px;
    background:#f3f4f6;border:none;border-radius:50%;
    cursor:pointer;position:relative;
    display:flex;align-items:center;justify-content:center;
}
.close-btn::before,.close-btn::after{
    content:'';position:absolute;
    width:14px;height:2px;background:#6b7280;border-radius:2px;
}
.close-btn::before{transform:rotate(45deg);}
.close-btn::after{transform:rotate(-45deg);}

.qr-amt-bar{
    padding:16px;display:flex;
    justify-content:space-between;align-items:center;
    background:#f8faff;
}
.qr-amt-num{
    font-size:30px;font-weight:800;color:#1a1a2e;
    display:flex;align-items:center;gap:10px;
}
/* Copy icon for amount - CSS */
.copy-amt-btn{
    width:28px;height:28px;
    border:1.5px solid #d1d5db;border-radius:6px;
    background:#fff;cursor:pointer;
    position:relative;flex-shrink:0;
}
.copy-amt-btn::before{
    content:'';position:absolute;
    top:3px;left:3px;
    width:14px;height:16px;
    border:1.5px solid #9ca3af;border-radius:2px;background:#fff;
}
.copy-amt-btn::after{
    content:'';position:absolute;
    bottom:3px;right:3px;
    width:14px;height:16px;
    border:1.5px solid #9ca3af;border-radius:2px;background:#f8faff;
}
.qr-timer{font-size:20px;font-weight:800;color:#dc2626;}

/* Bullet section title */
.bullet-row{
    display:flex;align-items:center;gap:8px;
    font-size:15px;font-weight:700;color:#1e3a8a;
    padding:14px 16px 8px;
}
.bullet-dot{
    width:10px;height:10px;
    background:#4b7cf3;border-radius:50%;flex-shrink:0;
}

/* App buttons */
.app-grid{
    display:grid;grid-template-columns:1fr 1fr;
    gap:10px;padding:0 16px 12px;
}
.app-btn{
    border:1.5px solid #e0e8f8;border-radius:12px;
    padding:12px;display:flex;align-items:center;gap:10px;
    cursor:pointer;background:#f5f8ff;text-decoration:none;
}
/* App icons - colored CSS boxes with text */
.app-ic{
    width:32px;height:32px;border-radius:8px;
    display:flex;align-items:center;justify-content:center;
    flex-shrink:0;font-size:10px;font-weight:900;
    color:#fff;letter-spacing:-0.5px;
}
.ic-pt{background:linear-gradient(135deg,#00baf2,#0077aa);}
.ic-gp{background:linear-gradient(135deg,#4285f4,#0f9d58);}
.ic-bh{background:linear-gradient(135deg,#0e4f8b,#1565c0);}
.ic-up{background:linear-gradient(135deg,#6b2fa0,#9c27b0);}
.app-name{font-size:13px;font-weight:700;color:#1e293b;}
.app-sub{font-size:10px;color:#9ca3af;margin-top:1px;}

/* QR Code box */
.qr-code-box{
    margin:0 16px 12px;
    background:#f8faff;border-radius:14px;
    padding:18px;text-align:center;
    border:1.5px solid #dde8fb;
}
.qr-note{font-size:12px;color:#9ca3af;line-height:1.6;margin-top:12px;}

/* UTR */
.utr-section{padding:0 16px 12px;}
.utr-warning{
    color:#dc2626;font-size:13px;font-weight:600;
    margin-bottom:10px;line-height:1.4;
}
.utr-inp-row{
    display:flex;gap:8px;align-items:center;
    background:#f8faff;border-radius:10px;
    padding:12px 14px;border:1.5px solid #dde8fb;
}
.utr-input{
    flex:1;border:none;background:none;
    font-size:15px;color:#333;outline:none;
}
.utr-input::placeholder{color:#c0cad8;font-size:14px;}
.paste-btn{
    background:#4b7cf3;color:#fff;border:none;
    border-radius:8px;padding:8px 14px;
    font-size:13px;font-weight:700;cursor:pointer;
}

/* Important */
.imp-box{
    margin:0 16px 14px;
    background:#fff5f5;border-radius:12px;
    padding:14px;border:1.5px solid #fde0e0;
}
.imp-title{font-size:14px;font-weight:700;color:#4b7cf3;margin-bottom:8px;}
.imp-item{font-size:12px;color:#9ca3af;margin-bottom:5px;line-height:1.4;}
.imp-item:last-child{margin-bottom:0;}

/* QR bottom btns */
.qr-btns{display:flex;gap:10px;padding:4px 16px 20px;}
.qr-cancel-btn{
    flex:1;padding:14px;
    border:1.5px solid #e5e7eb;border-radius:30px;
    background:#fff;font-size:15px;font-weight:700;
    color:#6b7280;cursor:pointer;
}
.qr-sub-btn{
    flex:2;padding:14px;border:none;border-radius:30px;
    background:linear-gradient(135deg,#4b7cf3,#2f55d4);
    color:#fff;font-size:15px;font-weight:700;cursor:pointer;
}
.qr-sub-btn.grey{background:#d1d5db;}

/* UTR HISTORY MODAL */
.utr-modal-bg{
    display:none;position:fixed;
    top:0;left:0;right:0;bottom:0;
    background:rgba(0,0,0,0.5);
    z-index:500;align-items:flex-end;justify-content:center;
}
.utr-modal-bg.show{display:flex;}
.utr-modal-sheet{
    background:#fff;width:100%;max-width:480px;
    border-radius:22px 22px 0 0;
    padding:0 0 24px;animation:slideUp 0.3s ease;
}
.utr-mhdr{
    display:flex;justify-content:space-between;align-items:center;
    padding:16px;border-bottom:1px solid #f3f4f6;
}
.utr-mtitle{font-size:16px;font-weight:700;color:#222;}
.utr-mcancel{font-size:14px;color:#9ca3af;background:none;border:none;cursor:pointer;}
.utr-msub{
    background:#4b7cf3;color:#fff;border:none;
    border-radius:20px;padding:8px 18px;
    font-size:14px;font-weight:700;cursor:pointer;
}
.utr-mbody{padding:16px;}
.utr-mlabel{font-size:14px;font-weight:600;color:#555;margin-bottom:8px;}
.utr-minput{
    width:100%;padding:13px 14px;
    border:1.5px solid #e5e7eb;border-radius:10px;
    font-size:15px;color:#333;outline:none;
    background:#fafafa;margin-bottom:14px;
}
.utr-minput:focus{border-color:#4b7cf3;}
.ud-row{
    display:flex;justify-content:space-between;
    padding:8px 0;font-size:13px;
    border-bottom:1px solid #f3f4f6;
}
.ud-row:last-child{border-bottom:none;}
.ud-lbl{color:#9ca3af;}
.ud-val{color:#374151;font-weight:500;}
.ud-val.org{color:#ea580c;font-weight:700;}

/* TOAST */
.toast{
    position:fixed;top:50%;left:50%;
    transform:translate(-50%,-50%) scale(0.85);
    background:rgba(15,23,42,0.88);
    color:#fff;padding:22px 28px;
    border-radius:16px;font-size:15px;
    text-align:center;z-index:999;
    opacity:0;transition:all 0.25s;
    pointer-events:none;min-width:170px;
}
.toast.show{opacity:1;transform:translate(-50%,-50%) scale(1);}
/* Toast check icon - CSS */
.t-check{
    width:38px;height:38px;border-radius:50%;
    border:3px solid #22c55e;margin:0 auto 8px;position:relative;
}
.t-check::after{
    content:'';position:absolute;
    top:8px;left:7px;
    width:8px;height:14px;
    border-right:3px solid #22c55e;
    border-bottom:3px solid #22c55e;
    transform:rotate(45deg);
}
/* Toast cross icon - CSS */
.t-cross{
    width:38px;height:38px;border-radius:50%;
    border:3px solid #ef4444;margin:0 auto 8px;position:relative;
}
.t-cross::before,.t-cross::after{
    content:'';position:absolute;
    top:50%;left:50%;
    width:18px;height:3px;
    background:#ef4444;border-radius:2px;
}
.t-cross::before{transform:translate(-50%,-50%) rotate(45deg);}
.t-cross::after{transform:translate(-50%,-50%) rotate(-45deg);}
/* Toast warn icon - CSS */
.t-warn{
    width:38px;height:38px;border-radius:50%;
    border:3px solid #f59e0b;margin:0 auto 8px;
    display:flex;align-items:center;justify-content:center;
    font-size:20px;font-weight:900;color:#f59e0b;
}
/* Toast copy icon - CSS */
.t-copy{
    width:38px;height:32px;margin:0 auto 8px;position:relative;
}
.t-copy::before{
    content:'';position:absolute;
    top:0;left:6px;width:24px;height:28px;
    border:3px solid #60a5fa;border-radius:3px;
}
.t-copy::after{
    content:'';position:absolute;
    top:5px;left:1px;width:24px;height:28px;
    border:3px solid #60a5fa;border-radius:3px;
    background:rgba(15,23,42,0.88);
}
/* Spinner */
.spin-ic{
    display:inline-block;width:16px;height:16px;
    border:2.5px solid rgba(255,255,255,0.3);
    border-top-color:#fff;border-radius:50%;
    animation:spinIt 0.7s linear infinite;
    vertical-align:middle;margin-right:6px;
}
</style>
</head>
<body>

<!-- HEADER -->
<div class="hdr">
    <button class="hdr-back" onclick="history.back()">
        <span class="back-arrow"></span>
    </button>
    <span class="hdr-title">Deposit</span>
    <a href="deposit-history.php" class="hdr-link">Deposit history</a>
</div>

<!-- BALANCE CARD -->
<div class="bal-card">
    <div class="bal-top">
        <img src="https://www.goaok.org/assets/png/balance-DmuJO3Yz.png" alt="balance">
        <span class="bal-label">Balance</span>
    </div>
    <div class="bal-row">
        <div class="bal-number">&#8377;<span id="balDisp"><?php echo number_format($balance,2); ?></span></div>
        <button class="ref-btn" id="refBtn" onclick="doRefresh()">
            <img src="https://www.goaok.org/assets/png/refresh-C_mIC898.png" alt="refresh">
        </button>
    </div>
    <div class="bal-dots">* * * * *&nbsp;&nbsp;* * * * *</div>
</div>

<!-- PAYMENT METHODS -->
<div class="card">
    <div class="pay-grid">
        <div class="pay-item active" id="pm-UPI_QR" onclick="pickMethod('UPI_QR')">
            <div class="bonus-tag">+5%</div>
            <img src="https://bindassgame.bet/GoaGame/payNameIcon/payNameIcon2_20250514192004oqqi.jpg" alt="UPI QR">
            <div class="pay-lbl">UPI x QR</div>
        </div>
        <div class="pay-item" id="pm-PAYTM_QR" onclick="pickMethod('PAYTM_QR')">
            <div class="bonus-tag">+5%</div>
            <img src="https://bindassgame.bet/GoaGame/payNameIcon/payNameIcon_20231123112348mygk.jpg" alt="Paytm QR">
            <div class="pay-lbl">Paytm X QR</div>
        </div>
        <div class="pay-item" id="pm-UPI" onclick="pickMethod('UPI')">
            <div class="bonus-tag">+5%</div>
            <img src="https://bindassgame.bet/GoaGame/payNameIcon/payNameIcon_20231215123948l6y1.jpg" alt="UPI">
            <div class="pay-lbl">UPI</div>
        </div>
    </div>
</div>

<!-- SELECT CHANNEL -->
<div class="card">
    <div class="sec-hdr">
        <div class="icon-pencil"></div>
        <span class="sec-title-txt">Select channel</span>
    </div>
    <div class="channel-box">
        <div class="channel-name" id="chanName">UPI x QR</div>
        <div class="channel-info">Balance: &#8377;100 - &#8377;50K &nbsp;|&nbsp; Bonus: 5%</div>
    </div>
</div>

<!-- DEPOSIT AMOUNT -->
<div class="card">
    <div class="sec-hdr">
        <div class="icon-truck">
            <div class="truck-base"></div>
            <div class="truck-w1"></div>
            <div class="truck-w2"></div>
        </div>
        <span class="sec-title-txt">Deposit amount</span>
    </div>
    <div class="amt-grid">
        <div class="amt-chip" onclick="pickAmt(100,this)"><span class="chip-rs">&#8377;</span>100</div>
        <div class="amt-chip" onclick="pickAmt(200,this)"><span class="chip-rs">&#8377;</span>200</div>
        <div class="amt-chip" onclick="pickAmt(300,this)"><span class="chip-rs">&#8377;</span>300</div>
        <div class="amt-chip" onclick="pickAmt(400,this)"><span class="chip-rs">&#8377;</span>400</div>
        <div class="amt-chip" onclick="pickAmt(500,this)"><span class="chip-rs">&#8377;</span>500</div>
        <div class="amt-chip" onclick="pickAmt(1000,this)"><span class="chip-rs">&#8377;</span>1K</div>
        <div class="amt-chip" onclick="pickAmt(2000,this)"><span class="chip-rs">&#8377;</span>2K</div>
        <div class="amt-chip" onclick="pickAmt(3000,this)"><span class="chip-rs">&#8377;</span>3K</div>
        <div class="amt-chip" onclick="pickAmt(5000,this)"><span class="chip-rs">&#8377;</span>5K</div>
    </div>
    <!-- You Get -->
    <div class="yg-box" id="ygBox" style="display:none;">
        <div class="yg-head">
            <span>You get</span>
            <span class="yg-val" id="ygAmt">&#8377;0.00</span>
        </div>
        <div class="yg-row"><span>You pay</span><span id="ygPay">&#8377;0.00</span></div>
        <div class="yg-row"><span>Bonus</span><span class="yg-bonus" id="ygBonus">+&#8377;0.00</span></div>
    </div>
    <!-- Custom Input -->
    <div class="amt-inp-box">
        <div class="rupee-box">&#8377;</div>
        <input type="number" class="amt-inp" id="custAmt"
               placeholder="&#8377;100.00 - &#8377;50,000.00"
               min="100" max="50000" oninput="onCustAmt()">
        <button class="clear-x-btn" onclick="clearAmt()"></button>
    </div>
</div>

<!-- RECHARGE INSTRUCTIONS -->
<div class="card">
    <div class="sec-hdr">
        <div class="icon-book"></div>
        <span class="sec-title-txt">Recharge instructions</span>
    </div>
    <div class="rule-row"><div class="diamond"></div><span>If the transfer time is up, please fill out the deposit form again.</span></div>
    <div class="rule-row"><div class="diamond"></div><span>The transfer amount must match the order you created, otherwise the money cannot be credited successfully.</span></div>
    <div class="rule-row"><div class="diamond"></div><span>If you transfer the wrong amount, our company will not be responsible for the lost amount!</span></div>
    <div class="rule-row"><div class="diamond"></div><span>Note: do not cancel the deposit order after the money has been transferred.</span></div>
</div>

<!-- DEPOSIT HISTORY -->
<div class="hist-wrap">
    <div class="hist-hdr">
        <div class="icon-list"></div>
        <span class="hist-title">Deposit history</span>
    </div>

    <?php if(empty($recentDeposits)): ?>
    <div class="no-hist">
        <div class="no-hist-ico"></div>
        No deposit history yet
    </div>
    <?php else: ?>
    <?php foreach($recentDeposits as $dep):
        $st = $dep['status'] ?? 'Pending';
        $sc = 'st-pending'; $stxt = $st;
        if($st==='Complete'||$st==='Completed'){$sc='st-complete';$stxt='Complete';}
        elseif($st==='Failed'){$sc='st-failed';}
        elseif($st==='Processing'){$sc='st-processing';}
    ?>
    <div class="hist-card">
        <div class="hc-top">
            <span class="dep-badge">Deposit</span>
            <span class="<?php echo $sc;?>"><?php echo $stxt;?></span>
        </div>
        <div class="hc-row">
            <span class="hc-lbl">Order amount</span>
            <span class="hc-val org">&#8377;<?php echo number_format($dep['amount']??0,2);?></span>
        </div>
        <?php if(in_array($st,['Complete','Completed'])): ?>
        <div class="hc-row">
            <span class="hc-lbl">You get</span>
            <span class="hc-val grn">&#8377;<?php echo number_format($dep['total_get']??0,2);?></span>
        </div>
        <?php endif; ?>
        <div class="hc-row">
            <span class="hc-lbl">Type</span>
            <span class="hc-val"><?php echo htmlspecialchars($dep['type']??'');?></span>
        </div>
        <div class="hc-row">
            <span class="hc-lbl">Time</span>
            <span class="hc-val"><?php echo htmlspecialchars($dep['time']??'');?></span>
        </div>
        <div class="hc-row">
            <span class="hc-lbl">Order number</span>
            <div class="copy-row" onclick="doCopy('<?php echo htmlspecialchars($dep['order_id']??'');?>')">
                <span class="copy-row-txt"><?php echo htmlspecialchars($dep['order_id']??'');?></span>
                <div class="copy-ico"></div>
            </div>
        </div>
        <?php if(in_array($st,['Pending','Failed'])): ?>
        <button class="utr-hist-btn"
            onclick="openUtrMod('<?php echo $dep['order_id'];?>','<?php echo $dep['amount'];?>','<?php echo $dep['type'];?>','<?php echo $dep['time'];?>')">
            Submit Utr
        </button>
        <?php endif; ?>
    </div>
    <?php endforeach; ?>
    <?php if(count($deposits)>5): ?>
    <a href="deposit-history.php" class="all-hist-btn">All history</a>
    <?php endif; ?>
    <?php endif; ?>
</div>

<!-- BOTTOM BAR -->
<div class="btm-bar">
    <div>
        <div class="btm-left-lbl">Recharge Method:</div>
        <div class="btm-left-name" id="btmName">UPI x QR</div>
    </div>
    <button class="dep-main-btn dis" id="depBtn" onclick="startDeposit()">Deposit</button>
</div>

<!-- CS FAB -->
<a href="customer-service.php" class="cs-fab">
    <img src="https://www.goaok.org/assets/png/icon_sevice-BIWTN_cL.png" alt="Customer Service">
</a>

<!-- QR PAYMENT MODAL -->
<div class="modal-bg" id="qrModal">
    <div class="modal-sheet">
        <div class="qr-hdr">
            <span class="qr-title" id="qrTitle">Payment</span>
            <button class="close-btn" onclick="closeQrMod()"></button>
        </div>
        <div class="qr-amt-bar">
            <div class="qr-amt-num">
                &#8377;<span id="qrAmt">0.00</span>
                <button class="copy-amt-btn" onclick="doCopy(document.getElementById('qrAmt').textContent)"></button>
            </div>
            <div class="qr-timer" id="qrTimer">15:00</div>
        </div>
        <!-- App buttons (UPI direct only) -->
        <div id="appSection">
            <div class="bullet-row"><div class="bullet-dot"></div>Choose a payment method to pay</div>
            <div class="app-grid" id="appGrid"></div>
        </div>
        <!-- QR Code -->
        <div class="bullet-row"><div class="bullet-dot"></div>Use Mobile Scan code to pay</div>
        <div class="qr-code-box">
            <div id="qrWrap"></div>
            <p class="qr-note">
                1. Please use another device to scan the QR code with your payment app<br>
                2. If you scan from this device's gallery, payment may be limited (&#8804;2000).
            </p>
        </div>
        <!-- UTR Input -->
        <div class="utr-section">
            <div class="bullet-row" style="padding:0 0 8px;"><div class="bullet-dot"></div>Input UTR / Paste UTR</div>
            <p class="utr-warning">If you do not back fill UTR / paste UTR, 100% will fail.</p>
            <div class="utr-inp-row">
                <input type="number" class="utr-input" id="qrUtrInp"
                       placeholder="Input 12 digits here" oninput="chkUtr()">
                <button class="paste-btn" onclick="pasteUtr()">Paste</button>
            </div>
        </div>
        <!-- Important -->
        <div class="imp-box">
            <div class="imp-title">Important reminder:</div>
            <div class="imp-item">1. Do not pay for the same link repeatedly!</div>
            <div class="imp-item">2. Transfer the exact amount shown above.</div>
            <div class="imp-item">3. Submit UTR after payment is done.</div>
        </div>
        <div class="qr-btns">
            <button class="qr-cancel-btn" onclick="closeQrMod()">Cancel</button>
            <button class="qr-sub-btn grey" id="qrSubBtn" onclick="doQrSub()">Submit (UTR not entered)</button>
        </div>
    </div>
</div>

<!-- UTR HISTORY MODAL -->
<div class="utr-modal-bg" id="utrModal">
    <div class="utr-modal-sheet">
        <div class="utr-mhdr">
            <button class="utr-mcancel" onclick="closeUtrMod()">Cancel</button>
            <span class="utr-mtitle">Submit Utr</span>
            <button class="utr-msub" onclick="doHistUtr()">Submit</button>
        </div>
        <div class="utr-mbody">
            <div class="utr-mlabel">Utr</div>
            <input type="number" class="utr-minput" id="histUtrInp"
                   placeholder="Input 12 digits here">
            <div class="ud-row"><span class="ud-lbl">Balance</span><span class="ud-val org" id="ud_bal">&#8377;0.00</span></div>
            <div class="ud-row"><span class="ud-lbl">Type</span><span class="ud-val" id="ud_type">-</span></div>
            <div class="ud-row"><span class="ud-lbl">Time</span><span class="ud-val" id="ud_time">-</span></div>
            <div class="ud-row"><span class="ud-lbl">Order number</span><span class="ud-val" id="ud_ord" style="font-size:11px;">-</span></div>
        </div>
    </div>
</div>

<!-- TOAST -->
<div class="toast" id="toast">
    <div id="tIco"></div>
    <div id="tMsg"></div>
</div>

<script src="https://cdnjs.cloudflare.com/ajax/libs/qrcodejs/1.0.0/qrcode.min.js"></script>
<script>
let selM='UPI_QR', selAmt=0, curOrd='', curData={}, tmrI=null, histOrd='';
const mNames={'UPI_QR':'UPI x QR','PAYTM_QR':'Paytm X QR','UPI':'UPI'};

function pickMethod(m){
    selM=m;
    document.querySelectorAll('.pay-item').forEach(e=>e.classList.remove('active'));
    document.getElementById('pm-'+m).classList.add('active');
    document.getElementById('chanName').textContent=mNames[m];
    document.getElementById('btmName').textContent=mNames[m];
    chkBtn();
}

function pickAmt(a,el){
    selAmt=a;
    document.getElementById('custAmt').value=a;
    document.querySelectorAll('.amt-chip').forEach(c=>c.classList.remove('sel'));
    el.classList.add('sel');
    updYG(a); chkBtn();
}

function onCustAmt(){
    const v=parseFloat(document.getElementById('custAmt').value)||0;
    selAmt=v;
    document.querySelectorAll('.amt-chip').forEach(c=>c.classList.remove('sel'));
    updYG(v); chkBtn();
}

function clearAmt(){
    selAmt=0;
    document.getElementById('custAmt').value='';
    document.querySelectorAll('.amt-chip').forEach(c=>c.classList.remove('sel'));
    document.getElementById('ygBox').style.display='none';
    chkBtn();
}

function updYG(a){
    if(a>=100){
        const b=(a*0.05).toFixed(2);
        const t=(a+parseFloat(b)).toFixed(2);
        document.getElementById('ygBox').style.display='block';
        document.getElementById('ygAmt').innerHTML='&#8377;'+t;
        document.getElementById('ygPay').innerHTML='&#8377;'+parseFloat(a).toFixed(2);
        document.getElementById('ygBonus').innerHTML='+&#8377;'+b;
    } else {
        document.getElementById('ygBox').style.display='none';
    }
}

function chkBtn(){
    const btn=document.getElementById('depBtn');
    if(selAmt>=100&&selAmt<=50000){
        btn.classList.remove('dis');
        btn.innerHTML='Deposit &#8377;'+selAmt.toFixed(2);
    } else {
        btn.classList.add('dis');
        btn.textContent='Deposit';
    }
}

function startDeposit(){
    const btn=document.getElementById('depBtn');
    if(btn.classList.contains('dis')) return;
    btn.innerHTML='<span class="spin-ic"></span>';
    btn.classList.add('dis');
    const fd=new FormData();
    fd.append('action','create_order');
    fd.append('amount',selAmt);
    fd.append('type',selM);
    fetch('deposit.php',{method:'POST',body:fd})
    .then(r=>r.json())
    .then(d=>{
        btn.innerHTML='Deposit &#8377;'+selAmt.toFixed(2);
        btn.classList.remove('dis');
        if(d.success){curOrd=d.order_id;curData=d;openQrMod(d);}
        else showToast('cross',d.message||'Failed!');
    })
    .catch(()=>{
        btn.innerHTML='Deposit &#8377;'+selAmt.toFixed(2);
        btn.classList.remove('dis');
        showToast('cross','Network error!');
    });
}

function openQrMod(d){
    document.getElementById('qrModal').classList.add('show');
    document.body.style.overflow='hidden';
    document.getElementById('qrTitle').textContent=mNames[d.type]||d.type;
    document.getElementById('qrAmt').textContent=parseFloat(d.amount).toFixed(2);
    document.getElementById('qrUtrInp').value='';
    document.getElementById('qrSubBtn').className='qr-sub-btn grey';
    document.getElementById('qrSubBtn').textContent='Submit (UTR not entered)';
    makeQR(d.upi_id,d.amount,d.type);
    buildApps(d.upi_id,d.amount,d.type);
    startTimer(15*60);
}

function makeQR(upiId,amt,type){
    const wrap=document.getElementById('qrWrap');
    wrap.innerHTML='';
    if(!upiId){
        wrap.innerHTML='<div style="padding:20px;text-align:center;color:#dc2626;font-size:13px;line-height:1.6;">Admin ne UPI ID setup nahi ki.<br>Please contact admin.</div>';
        return;
    }
    const url='upi://pay?pa='+upiId+'&am='+amt+'&cu=INR&tn=Deposit';
    const d=document.createElement('div');
    d.style.cssText='width:190px;height:190px;margin:0 auto;';
    wrap.appendChild(d);
    try{
        new QRCode(d,{text:url,width:190,height:190,colorDark:'#000',colorLight:'#fff',correctLevel:QRCode.CorrectLevel.H});
    }catch(e){
        d.innerHTML='<img src="https://api.qrserver.com/v1/create-qr-code/?size=190x190&data='+encodeURIComponent(url)+'" style="width:190px;height:190px;border-radius:8px;">';
    }
}

function buildApps(upiId,amt,type){
    const sec=document.getElementById('appSection');
    const grid=document.getElementById('appGrid');
    if(type==='UPI'){
        sec.style.display='block';
        const url='upi://pay?pa='+upiId+'&am='+amt+'&cu=INR&tn=Deposit';
        grid.innerHTML=`
        <a href="${url}" class="app-btn">
            <div class="app-ic ic-pt">Pay</div>
            <div><div class="app-name">Paytm</div><div class="app-sub">Wake up support</div></div>
        </a>
        <a href="${url}" class="app-btn">
            <div class="app-ic ic-gp">GPay</div>
            <div><div class="app-name">Google Pay</div><div class="app-sub">Wake up support</div></div>
        </a>
        <a href="${url}" class="app-btn">
            <div class="app-ic ic-bh">BHIM</div>
            <div><div class="app-name">BHIM UPI</div><div class="app-sub">Wake up support</div></div>
        </a>
        <a href="${url}" class="app-btn">
            <div class="app-ic ic-up">UPI</div>
            <div><div class="app-name">Any UPI App</div><div class="app-sub">Wake up support</div></div>
        </a>`;
    } else {
        sec.style.display='none';
    }
}

function closeQrMod(){
    document.getElementById('qrModal').classList.remove('show');
    document.body.style.overflow='';
    if(tmrI) clearInterval(tmrI);
    location.reload();
}

function startTimer(s){
    if(tmrI) clearInterval(tmrI);
    let r=s;
    const el=document.getElementById('qrTimer');
    function tick(){
        const m=Math.floor(r/60),sec=r%60;
        el.textContent=String(m).padStart(2,'0')+':'+String(sec).padStart(2,'0');
        if(r<=0){clearInterval(tmrI);el.textContent='Expired';el.style.color='#9ca3af';}
        r--;
    }
    tick(); tmrI=setInterval(tick,1000);
}

function chkUtr(){
    const v=document.getElementById('qrUtrInp').value.trim();
    const btn=document.getElementById('qrSubBtn');
    if(v.length>=10){btn.className='qr-sub-btn';btn.textContent='Submit';}
    else{btn.className='qr-sub-btn grey';btn.textContent='Submit (UTR not entered)';}
}

function pasteUtr(){
    if(navigator.clipboard){
        navigator.clipboard.readText().then(t=>{
            document.getElementById('qrUtrInp').value=t.trim();chkUtr();
        }).catch(()=>showToast('warn','Please paste manually!'));
    } else showToast('warn','Please paste manually!');
}

function doQrSub(){submitUtrNow(curOrd,document.getElementById('qrUtrInp').value.trim());}

function openUtrMod(id,amt,type,time){
    histOrd=id;
    document.getElementById('histUtrInp').value='';
    document.getElementById('ud_bal').innerHTML='&#8377;'+parseFloat(amt).toFixed(2);
    document.getElementById('ud_type').textContent=type;
    document.getElementById('ud_time').textContent=time;
    document.getElementById('ud_ord').textContent=id;
    document.getElementById('utrModal').classList.add('show');
    document.body.style.overflow='hidden';
}

function closeUtrMod(){
    document.getElementById('utrModal').classList.remove('show');
    document.body.style.overflow='';
}

function doHistUtr(){
    submitUtrNow(histOrd,document.getElementById('histUtrInp').value.trim());
    closeUtrMod();
}

function submitUtrNow(ordId,utr){
    if(!utr||utr.length<10){showToast('warn','Enter valid UTR (min 10 digits)!');return;}
    const fd=new FormData();
    fd.append('action','submit_utr');
    fd.append('order_id',ordId);
    fd.append('utr',utr);
    fetch('deposit.php',{method:'POST',body:fd})
    .then(r=>r.json())
    .then(d=>{
        if(d.success){
            showToast('check','UTR submitted! Admin will verify.');
            setTimeout(()=>{closeQrMod();location.reload();},2200);
        } else showToast('cross',d.message||'Failed!');
    })
    .catch(()=>showToast('cross','Network error!'));
}

function doRefresh(){
    const btn=document.getElementById('refBtn');
    btn.classList.add('spinning');
    fetch('deposit.php',{method:'POST',
        headers:{'Content-Type':'application/x-www-form-urlencoded'},
        body:'action=get_balance'})
    .then(r=>r.json())
    .then(d=>{
        if(d.success) document.getElementById('balDisp').textContent=parseFloat(d.balance).toFixed(2);
        showToast('check','Refresh successfully');
        setTimeout(()=>btn.classList.remove('spinning'),700);
    })
    .catch(()=>setTimeout(()=>btn.classList.remove('spinning'),700));
}

function doCopy(txt){
    if(navigator.clipboard){
        navigator.clipboard.writeText(String(txt)).then(()=>showToast('copy','Copied!'));
    } else {
        const e=document.createElement('textarea');
        e.value=String(txt);document.body.appendChild(e);
        e.select();document.execCommand('copy');
        document.body.removeChild(e);showToast('copy','Copied!');
    }
}

function showToast(type,msg){
    const icons={
        'check':'<div class="t-check"></div>',
        'cross':'<div class="t-cross"></div>',
        'warn':'<div class="t-warn">!</div>',
        'copy':'<div class="t-copy"></div>'
    };
    document.getElementById('tIco').innerHTML=icons[type]||icons['check'];
    document.getElementById('tMsg').textContent=msg;
    const t=document.getElementById('toast');
    t.classList.add('show');
    setTimeout(()=>t.classList.remove('show'),2500);
}

document.getElementById('qrModal').addEventListener('click',function(e){
    if(e.target===this) closeQrMod();
});
document.getElementById('utrModal').addEventListener('click',function(e){
    if(e.target===this) closeUtrMod();
});
</script>
</body>
</html>