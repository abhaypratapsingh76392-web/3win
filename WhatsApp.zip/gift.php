<?php
// Yahan session_start() hata diya hai taaki error na aaye kyunki config.php me already hai.
require_once 'config.php';

// AJAX REQUEST HANDLE KARNE KA LOGIC (Jab "Receive" dabayega)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'claim_gift') {
    header('Content-Type: application/json');
    
    // Check if user is logged in
    if (!isset($_SESSION['phone'])) {
        echo json_encode(['success' => false, 'message' => 'Please login first!']);
        exit;
    }

    $phone = $_SESSION['phone'];
    $code = trim($_POST['code']);

    if (empty($code)) {
        echo json_encode(['success' => false, 'message' => 'Please enter a gift code!']);
        exit;
    }

    // 1. Firebase se Code ka data nikalna
    $giftData = firebase_read("gift_codes/" . $code);

    if (!$giftData) {
        echo json_encode(['success' => false, 'message' => 'Invalid or Expired Gift Code!']);
        exit;
    }

    // 2. Check karna ki is user ne pehle to use nahi kar liya
    if (isset($giftData['used_by']) && isset($giftData['used_by'][$phone])) {
        echo json_encode(['success' => false, 'message' => 'You have already claimed this code!']);
        exit;
    }

    // 3. Limit check karna (Kitne log use kar chuke hain)
    $current_uses = isset($giftData['used_by']) ? count($giftData['used_by']) : 0;
    $max_uses = isset($giftData['max_uses']) ? (int)$giftData['max_uses'] : 1;

    if ($current_uses >= $max_uses) {
        echo json_encode(['success' => false, 'message' => 'This gift code is fully claimed!']);
        exit;
    }

    // 4. User ka balance update karna
    $userData = firebase_read("users/" . $phone);
    $current_balance = isset($userData['balance']) ? (float)$userData['balance'] : 0;
    $reward_amount = (float)$giftData['amount'];
    
    $userData['balance'] = $current_balance + $reward_amount;
    firebase_write("users/" . $phone, $userData);

    // 5. Code mein user ka number daal dena taki dobara na le sake
    $giftData['used_by'][$phone] = true;
    firebase_write("gift_codes/" . $code, $giftData);

    // Success response bhejna
    echo json_encode([
        'success' => true, 
        'amount' => $reward_amount, 
        'message' => 'Gift received successfully!'
    ]);
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title>3 win - Gift</title>
    <!-- High quality App font -->
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    
    <style>
        * { 
            margin: 0; 
            padding: 0; 
            box-sizing: border-box; 
            font-family: 'Inter', sans-serif; 
            -webkit-tap-highlight-color: transparent; 
        }
        
        body { 
            background-color: #f7f8ff; /* App exact background */
            max-width: 450px; 
            margin: 0 auto; 
            min-height: 100vh; 
            position: relative; 
        }

        /* --- EXACT MATCH HEADER --- */
        .top-header {
            background: white;
            display: flex;
            align-items: center;
            justify-content: center;
            height: 55px;
            position: sticky;
            top: 0;
            z-index: 100;
        }
        .back-btn {
            position: absolute;
            left: 15px;
            color: #333;
            font-size: 20px;
            text-decoration: none;
            padding: 10px;
        }
        .page-title {
            font-size: 17px;
            font-weight: 600;
            color: #1e2637;
        }

        /* --- BANNER --- */
        .gift-banner {
            width: 100%;
            height: 240px;
            background: url('https://i.ibb.co/zjcmM7m/gift-D229-Mngm.png') center/cover no-repeat;
        }

        /* --- EXACT MATCH CARD --- */
        .gift-card {
            background: white;
            border-radius: 20px; /* Highly rounded corners */
            margin: -40px 15px 20px 15px;
            padding: 25px 20px;
            box-shadow: 0 4px 15px rgba(0,0,0,0.03);
            position: relative;
            z-index: 10;
        }

        .gift-card h3 {
            font-size: 17px;
            color: #1c1c1c;
            margin-bottom: 20px;
            font-weight: 700;
        }

        /* Input Box style exactly like screenshot */
        .input-group {
            display: flex;
            align-items: center;
            background: #f4f6fa; /* Light gray background */
            border-radius: 30px; /* Pill shape */
            padding: 0 15px;
            height: 52px;
            margin-bottom: 25px;
            border: 1px solid transparent;
            transition: all 0.3s;
        }
        .input-group:focus-within {
            border-color: #4295ff;
            background: white;
            box-shadow: 0 0 0 3px rgba(66, 149, 255, 0.1);
        }
        .input-group i {
            color: #4295ff;
            font-size: 20px;
            margin-right: 12px;
            margin-left: 5px;
        }
        .input-group input {
            border: none;
            background: transparent;
            width: 100%;
            height: 100%;
            font-size: 14.5px;
            outline: none;
            color: #333;
            font-weight: 500;
        }
        .input-group input::placeholder {
            color: #9ba3b5;
        }

        /* Receive Button exactly like screenshot */
        .receive-btn {
            width: 100%;
            background: #5097ff; /* Exact blue color */
            background: linear-gradient(180deg, #6fb2ff 0%, #428eff 100%); /* Slight gradient for 3D feel */
            color: white;
            border: none;
            height: 52px;
            border-radius: 30px;
            font-size: 16px;
            font-weight: 700;
            cursor: pointer;
            box-shadow: 0 4px 15px rgba(66, 149, 255, 0.3);
            transition: transform 0.1s;
        }
        .receive-btn:active { transform: scale(0.97); }

        /* --- RULES SECTION --- */
        .rules-section {
            padding: 10px 20px 30px 20px;
        }
        .rules-section h4 {
            font-size: 15px;
            color: #1e2637;
            margin-bottom: 15px;
            font-weight: 700;
        }
        .rules-section p {
            font-size: 12px;
            color: #8a92a3;
            line-height: 2; /* Spaced out lines like screenshot */
            margin-bottom: 4px;
            font-weight: 500;
        }

        /* --- POPUP MODAL --- */
        .modal-overlay {
            position: fixed;
            top: 0; left: 0; width: 100%; height: 100%;
            background: rgba(0, 0, 0, 0.5);
            display: none;
            justify-content: center;
            align-items: center;
            z-index: 1000;
            backdrop-filter: blur(2px);
        }
        .modal-box {
            background: white;
            width: 85%;
            max-width: 320px;
            border-radius: 20px;
            padding: 30px 20px 25px 20px;
            text-align: center;
            transform: scale(0.8);
            opacity: 0;
            transition: all 0.3s cubic-bezier(0.175, 0.885, 0.32, 1.275);
            box-shadow: 0 10px 30px rgba(0,0,0,0.15);
        }
        .modal-box.show {
            transform: scale(1);
            opacity: 1;
        }
        
        .success-icon {
            width: 65px;
            height: 65px;
            background: linear-gradient(135deg, #28c76f 0%, #48da89 100%);
            border-radius: 50%;
            display: flex;
            justify-content: center;
            align-items: center;
            margin: -60px auto 15px auto;
            border: 4px solid white;
        }
        .success-icon i { color: white; font-size: 28px; }
        
        .modal-title { font-size: 18px; font-weight: 700; color: #333; margin-bottom: 5px; }
        .modal-amount { font-size: 32px; font-weight: 800; color: #28c76f; margin-bottom: 10px; }
        .modal-msg { font-size: 13px; color: #777; margin-bottom: 25px; font-weight: 500; }
        
        .modal-btn {
            background: linear-gradient(180deg, #6fb2ff 0%, #428eff 100%);
            color: white;
            border: none;
            height: 45px;
            border-radius: 25px;
            font-size: 15px;
            font-weight: 700;
            cursor: pointer;
            width: 100%;
        }

        .modal-box.error .success-icon {
            background: linear-gradient(135deg, #ea5455 0%, #ff7373 100%);
        }
        .modal-box.error .modal-amount { display: none; }
        .modal-box.error .modal-btn { background: linear-gradient(180deg, #ff7373 0%, #ea5455 100%); }
    </style>
</head>
<body>

    <!-- Exact matching white header -->
    <div class="top-header">
        <a href="activity.php" class="back-btn"><i class="fa-solid fa-chevron-left"></i></a>
        <div class="page-title">Gift</div>
    </div>

    <!-- Banner -->
    <div class="gift-banner"></div>

    <!-- Exact match Card design -->
    <div class="gift-card">
        <h3>Hi, We have a gift for you</h3>
        <div class="input-group">
            <i class="fa-solid fa-gift"></i>
            <input type="text" id="giftCode" placeholder="Please enter gift code" autocomplete="off">
        </div>
        <button class="receive-btn" id="receiveBtn" onclick="claimGift()">Receive</button>
    </div>

    <!-- Rules Section -->
    <div class="rules-section">
        <h4>Rules</h4>
        <p>1. Each gift code can only be used once per account.</p>
        <p>2. Gift codes may have maximum usage limits or expire.</p>
        <p>3. The reward amount will be directly added to your balance.</p>
        <p>4. Please contact customer service if you encounter issues.</p>
    </div>

    <!-- Beautiful Popup Modal -->
    <div class="modal-overlay" id="popupModal">
        <div class="modal-box" id="modalContent">
            <div class="success-icon" id="modalIcon">
                <i class="fa-solid fa-check" id="iconSign"></i>
            </div>
            <div class="modal-title" id="modalTitle">Congratulations!</div>
            <div class="modal-amount" id="modalAmount">₹0.00</div>
            <div class="modal-msg" id="modalMsg">Gift received successfully.</div>
            <button class="modal-btn" onclick="closeModal()">OK</button>
        </div>
    </div>

    <script>
        function claimGift() {
            let codeInput = document.getElementById('giftCode').value;
            let btn = document.getElementById('receiveBtn');

            if (codeInput.trim() === '') {
                showModal(false, 'Error', 'Please enter a valid gift code!');
                return;
            }

            // Button Loading State
            btn.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i>';
            btn.disabled = true;

            // AJAX Request to this same PHP file
            let formData = new FormData();
            formData.append('action', 'claim_gift');
            formData.append('code', codeInput);

            fetch('gift.php', {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                btn.innerHTML = 'Receive';
                btn.disabled = false;

                if (data.success) {
                    showModal(true, 'Congratulations!', data.message, data.amount);
                    document.getElementById('giftCode').value = ''; // Input clear
                } else {
                    showModal(false, 'Failed', data.message);
                }
            })
            .catch(error => {
                btn.innerHTML = 'Receive';
                btn.disabled = false;
                showModal(false, 'Error', 'Network Error. Please try again!');
            });
        }

        function showModal(isSuccess, title, msg, amount = 0) {
            let modal = document.getElementById('popupModal');
            let content = document.getElementById('modalContent');
            let iconSign = document.getElementById('iconSign');
            
            document.getElementById('modalTitle').innerText = title;
            document.getElementById('modalMsg').innerText = msg;
            
            if (isSuccess) {
                content.classList.remove('error');
                iconSign.className = 'fa-solid fa-check';
                document.getElementById('modalAmount').style.display = 'block';
                document.getElementById('modalAmount').innerText = '₹' + parseFloat(amount).toFixed(2);
            } else {
                content.classList.add('error');
                iconSign.className = 'fa-solid fa-xmark';
                document.getElementById('modalAmount').style.display = 'none';
            }

            modal.style.display = 'flex';
            setTimeout(() => { content.classList.add('show'); }, 10);
        }

        function closeModal() {
            let modal = document.getElementById('popupModal');
            let content = document.getElementById('modalContent');
            
            content.classList.remove('show');
            setTimeout(() => { modal.style.display = 'none'; }, 300);
        }
    </script>
</body>
</html>