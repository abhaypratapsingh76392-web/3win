<?php
declare(strict_types=1);

session_start();
require_once __DIR__ . '/config.php';

if (!isset($_SESSION['user_phone']) || empty($_SESSION['user_phone'])) {
    header('Location: index.php');
    exit;
}

$phone = (string) $_SESSION['user_phone'];

/*
|--------------------------------------------------------------------------
| Firebase config
|--------------------------------------------------------------------------
*/

function vip_config_value(array $constants, array $variables): string {
    foreach ($constants as $name) {
        if (defined($name) && constant($name) !== '') {
            return (string) constant($name);
        }
    }
    foreach ($variables as $name) {
        if (isset($GLOBALS[$name]) && $GLOBALS[$name] !== '') {
            return (string) $GLOBALS[$name];
        }
    }
    return '';
}

$firebaseUrl = rtrim(vip_config_value(
    ['FIREBASE_DATABASE_URL','FIREBASE_URL','DATABASE_URL'],
    ['firebase_database_url','firebase_url','database_url','databaseURL','firebaseDatabaseUrl','databaseUrl']
), '/');

$firebaseToken = vip_config_value(
    ['FIREBASE_DATABASE_SECRET','FIREBASE_AUTH_TOKEN','FIREBASE_ID_TOKEN','DATABASE_SECRET'],
    ['firebase_database_secret','firebase_secret','firebase_token','firebase_auth_token','database_secret','database_token']
);

/*
|--------------------------------------------------------------------------
| Firebase REST (GET, PUT, PATCH)
|--------------------------------------------------------------------------
*/

function vip_db_key(string $value): string {
    return str_replace(['.', '#', '$', '[', ']', '/'], '_', trim($value));
}

function vip_db_path(string $value): string {
    return rawurlencode(vip_db_key($value));
}

function vip_request(string $path, string $method = 'GET', $payload = null) {
    global $firebaseUrl, $firebaseToken;

    if ($firebaseUrl === '') return null;

    $path = trim($path, '/');
    $url = $firebaseUrl . '/' . ($path !== '' ? $path . '/' : '') . '.json';

    if ($firebaseToken !== '') {
        $url .= '?auth=' . rawurlencode($firebaseToken);
    }

    if (!function_exists('curl_init')) return null;

    $curl = curl_init($url);
    curl_setopt_array($curl, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_CUSTOMREQUEST => strtoupper($method),
        CURLOPT_CONNECTTIMEOUT => 10,
        CURLOPT_TIMEOUT => 20,
        CURLOPT_HTTPHEADER => ['Content-Type: application/json']
    ]);

    if ($payload !== null) {
        curl_setopt($curl, CURLOPT_POSTFIELDS, json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES));
    }

    $response = curl_exec($curl);
    $httpCode = (int) curl_getinfo($curl, CURLINFO_HTTP_CODE);
    curl_close($curl);

    if ($response === false || $httpCode < 200 || $httpCode >= 300) return null;
    if ($response === '' || $response === 'null') return null;

    return json_decode($response, true);
}

function vip_get(string $path) { return vip_request($path, 'GET'); }
function vip_patch(string $path, $payload) { return vip_request($path, 'PATCH', $payload); }

/*
|--------------------------------------------------------------------------
| Helpers
|--------------------------------------------------------------------------
*/

function e($value): string {
    return htmlspecialchars((string) $value, ENT_QUOTES, 'UTF-8');
}

function field(array $data, array $keys, $default = null) {
    foreach ($keys as $key) {
        if (array_key_exists($key, $data)) return $data[$key];
    }
    return $default;
}

function num($value): float {
    if ($value === null || $value === '') return 0;
    return (float) str_replace(['₹', ',', ' '], '', (string) $value);
}

function nice_number($value): string {
    $value = num($value);
    return floor($value) == $value ? number_format($value, 0) : number_format($value, 2);
}

function nice_percent($value): string {
    return rtrim(rtrim(number_format(num($value), 2), '0'), '.') . '%';
}

function timestamp_of($value): int {
    if ($value === null || $value === '') return 0;
    if (is_numeric($value)) {
        $value = (int) $value;
        return $value > 20000000000 ? (int) floor($value / 1000) : $value;
    }
    $time = strtotime((string) $value);
    return $time ?: 0;
}

function nice_date($value): string {
    $time = timestamp_of($value);
    return !$time ? '—' : date('Y-m-d H:i:s', $time);
}

function rows_from($data): array {
    if (!is_array($data) || empty($data)) return [];
    $singleFields = ['amount', 'exp', 'experience', 'vipExp', 'bet', 'betAmount', 'turnover', 'title', 'detail', 'description', 'type', 'createdAt', 'created_at', 'date', 'time', 'status'];
    foreach ($singleFields as $fieldName) {
        if (array_key_exists($fieldName, $data)) return [$data];
    }
    $rows = [];
    foreach ($data as $key => $row) {
        if (is_array($row)) { $row['_id'] = $key; $rows[] = $row; } 
        else { $rows[] = ['_id' => $key, 'amount' => $row]; }
    }
    return $rows;
}

function first_collection(string $userKey, array $nodes): array {
    foreach ($nodes as $node) {
        $data = vip_get($node . '/' . $userKey);
        if (is_array($data) && !empty($data)) return $data;
    }
    return [];
}

function level_number($value): int {
    if (is_numeric($value)) return max(0, min(10, (int) $value));
    preg_match('/\d+/', (string) $value, $matches);
    if (!isset($matches[0])) return 0;
    return max(0, min(10, (int) $matches[0]));
}

/*
|--------------------------------------------------------------------------
| Exact image URLs & VIP Rules
|--------------------------------------------------------------------------
*/

$vipIcons = [
    1 => 'https://www.goaok.org/assets/png/1-27ESYDeX.png',
    2 => 'https://www.goaok.org/assets/png/2-nuTgsQAe.png',
    3 => 'https://www.goaok.org/assets/png/3-Dmm90Z3M.png',
    4 => 'https://www.goaok.org/assets/png/4-D0LcUTfO.png',
    5 => 'https://www.goaok.org/assets/png/5-DEnp90_4.png',
    6 => 'https://www.goaok.org/assets/png/6-BDYnJS_O.png',
    7 => 'https://www.goaok.org/assets/png/7-CyClOlek.png',
    8 => 'https://www.goaok.org/assets/png/8-DbW9oFTd.png',
    9 => 'https://www.goaok.org/assets/png/9-BajteX48.png',
    10 => 'https://www.goaok.org/assets/png/10-Bt9VCtue.png'
];

$benefitIcons = [
    'level' => 'https://www.goaok.org/assets/png/1-C0NP8BEZ.png',
    'monthly' => 'https://www.goaok.org/assets/png/2-78K_gYCi.png',
    'rebate' => 'https://www.goaok.org/assets/png/5-BctJzJ3u.png',
    'gold' => 'https://www.goaok.org/assets/png/gold-Dr9pWTeB.png'
];

$vipRules = [
    1 => ['required' => 3000, 'levelReward' => 30, 'monthlyReward' => 5, 'rebate' => 0.20, 'one' => '#a9bdd7', 'two' => '#7d98bb'],
    2 => ['required' => 30000, 'levelReward' => 150, 'monthlyReward' => 15, 'rebate' => 0.30, 'one' => '#ffc481', 'two' => '#e69a3e'],
    3 => ['required' => 300000, 'levelReward' => 590, 'monthlyReward' => 90, 'rebate' => 0.35, 'one' => '#ff9999', 'two' => '#f15e68'],
    4 => ['required' => 2000000, 'levelReward' => 1290, 'monthlyReward' => 690, 'rebate' => 0.40, 'one' => '#6edbea', 'two' => '#2cb9d7'],
    5 => ['required' => 20000000, 'levelReward' => 5900, 'monthlyReward' => 2690, 'rebate' => 0.45, 'one' => '#e38af0', 'two' => '#df4ec8'],
    6 => ['required' => 60000000, 'levelReward' => 16900, 'monthlyReward' => 6900, 'rebate' => 0.50, 'one' => '#64ddb5', 'two' => '#159c69'],
    7 => ['required' => 100000000, 'levelReward' => 69000, 'monthlyReward' => 26900, 'rebate' => 0.55, 'one' => '#55c738', 'two' => '#1e9d55'],
    8 => ['required' => 1000000000, 'levelReward' => 169000, 'monthlyReward' => 69000, 'rebate' => 0.60, 'one' => '#5fc3ef', 'two' => '#336ddd'],
    9 => ['required' => 5000000000, 'levelReward' => 690000, 'monthlyReward' => 269000, 'rebate' => 0.70, 'one' => '#dc82eb', 'two' => '#8542ed'],
    10 => ['required' => 10000000000, 'levelReward' => 1690000, 'monthlyReward' => 690000, 'rebate' => 0.80, 'one' => '#ffbd40', 'two' => '#ff812f']
];

$userKey = vip_db_path($phone);

/*
|--------------------------------------------------------------------------
| UNIVERSAL EXP CALCULATOR
|--------------------------------------------------------------------------
*/
$profile = vip_get('users/' . $userKey);
if (!is_array($profile)) $profile = [];

$userName = (string) field($profile, ['name', 'username', 'userName', 'nickname', 'displayName'], '');
if ($userName === '') {
    $phoneDigits = preg_replace('/\D+/', '', $phone);
    $userName = 'MEMBER' . substr((string) $phoneDigits, -4);
}
$avatar = 'https://www.goaok.org/assets/png/20-jsNPML4j.png';
$payoutDays = (int) field($profile, ['payoutDays', 'payout_days', 'vipPayoutDays', 'vip_payout_days'], 25);
if ($payoutDays <= 0) $payoutDays = 25;

// Automatically sum all bets placed across WINGO, K3, MONEY COMING, ETC.
$totalTurnover = 0;
$totalGames = 0;

$wingoBets = vip_get('users/' . $userKey . '/mybets');
if (is_array($wingoBets)) {
    foreach ($wingoBets as $bet) {
        $amt = (float) field($bet, ['amount', 'betAmount', 'total_bet'], 0);
        $totalTurnover += $amt;
        if ($amt > 0) $totalGames++;
    }
}
$k3Bets = vip_get('user_history/' . $userKey);
if (is_array($k3Bets)) {
    foreach ($k3Bets as $bet) {
        $amt = (float) field($bet, ['total_bet', 'amount', 'betAmount'], 0);
        $totalTurnover += $amt;
        if ($amt > 0) $totalGames++;
    }
}
$mcBets = vip_get('users/' . $userKey . '/moneycoming_bets');
if (is_array($mcBets)) {
    foreach ($mcBets as $bet) {
        $amt = (float) field($bet, ['bet', 'amount'], 0);
        $totalTurnover += $amt;
        if ($amt > 0) $totalGames++;
    }
}

// Any existing manual exp override
$baseAdminExp = 0;
$expFields = ['exp', 'experience', 'vipExp', 'vip_exp', 'totalExp'];
foreach ($expFields as $expField) {
    if (array_key_exists($expField, $profile)) {
        $baseAdminExp = num($profile[$expField]);
        break;
    }
}

// FINAL EXP = Admin Manual Exp + Total Bet Spent History
$experience = $baseAdminExp + $totalTurnover;

// VIP Level Deduction
$currentVip = 0;
foreach ($vipRules as $level => $rule) {
    if ($experience >= $rule['required']) {
        $currentVip = $level;
    }
}
$currentVip = max(0, min(10, $currentVip));

// 1️⃣ [BUG FIX] SAVE CORRECT VIP & EXP TO DATABASE (ACCOUNT.PHP SYNCRONIZATION)
// Jab tak aap backend me save nahi karenge, account.php pe 0 hi dikhega. Ab fix ho gaya!
vip_patch('users/' . $userKey, [
    'vipLevel' => $currentVip,
    'vip'      => $currentVip,
    'exp'      => round($experience, 2)
]);

// Determine selected viewing level
$selectedVip = isset($_GET['level']) ? (int) $_GET['level'] : max(1, min(10, $currentVip + 1));
$selectedVip = max(1, min(10, $selectedVip));
$selectedRule = $vipRules[$selectedVip];

// 2️⃣ CLAIM REWARD LOGIC + DATABASE CALLS
$vipClaims = vip_get('users/' . $userKey . '/vip_claims');
if (!is_array($vipClaims)) $vipClaims = [];

if (isset($_GET['ajax']) && $_GET['ajax'] === 'claim_reward' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    header('Content-Type: application/json; charset=utf-8');
    
    $lvl = (int)($_POST['level'] ?? 0);
    $type = $_POST['type'] ?? '';
    
    if ($lvl > $currentVip) {
        echo json_encode(['success' => false, 'message' => 'VIP Level ' . $lvl . ' abhi khula nahi hai!']);
        exit;
    }
    
    $claimKey = $type . '_' . $lvl;
    if ($type === 'monthly') $claimKey .= '_' . date('Y_m'); // monthly tracks unique month year
    
    if (isset($vipClaims[$claimKey]) && $vipClaims[$claimKey] === true) {
        echo json_encode(['success' => false, 'message' => 'Reward pehle hi Claim kiya ja chuka hai!']);
        exit;
    }
    
    $rewardAmt = 0;
    if ($type === 'level') $rewardAmt = $vipRules[$lvl]['levelReward'];
    if ($type === 'monthly') $rewardAmt = $vipRules[$lvl]['monthlyReward'];
    
    if ($rewardAmt > 0) {
        // Mark as Claimed
        vip_patch('users/' . $userKey . '/vip_claims', [$claimKey => true]);
        
        // Add balance to user
        $freshProfile = vip_get('users/' . $userKey);
        $currentBal = (float) field($freshProfile, ['balance'], 0);
        $newBal = round($currentBal + $rewardAmt, 2);
        vip_patch('users/' . $userKey, ['balance' => $newBal]);
        
        // Save Transaction Record
        $txId = 'tx_vip_' . time() . rand(10,99);
        vip_patch('transactions/' . $userKey . '/' . $txId, [
            'amount' => $rewardAmt,
            'detail' => 'VIP ' . $lvl . ' ' . ucfirst($type) . ' Reward',
            'type' => 'bonus',
            'direction' => 'credit',
            'createdAt' => date('Y-m-d H:i:s'),
            'status' => 'Completed',
            'balanceAfter' => $newBal
        ]);
        
        echo json_encode(['success' => true, 'message' => '₹' . $rewardAmt . ' Reward Wallet me successfully aagya hai!']);
    } else {
        echo json_encode(['success' => false, 'message' => 'Invalid reward.']);
    }
    exit;
}

if (isset($_GET['ajax']) && $_GET['ajax'] === 'summary') {
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode([
        'experience' => nice_number($experience),
        'vip' => $currentVip,
        'games' => $totalGames,
        'turnover' => nice_number($totalTurnover)
    ]);
    exit;
}

// Progress Math
$selectedProgress = 0;
if ($selectedRule['required'] > 0) {
    // Limits max cap explicitly
    $selectedProgress = min(100, ($experience / $selectedRule['required']) * 100);
}
$selectedRemaining = max(0, $selectedRule['required'] - $experience);
$topIcon = $vipIcons[max(1, $currentVip)];

$historyData = first_collection($userKey, ['vipHistory', 'vipLogs', 'levelHistory', 'vipRewards', 'userVipHistory']);
$historyRows = rows_from($historyData);
usort($historyRows, function ($a, $b) {
    return timestamp_of(field($b, ['createdAt', 'created_at', 'date', 'time'], '')) <=> timestamp_of(field($a, ['createdAt', 'created_at', 'date', 'time'], ''));
});

?>
<!DOCTYPE html>
<html lang="en">
<head>

<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">

<title>VIP</title>

<link href="https://fonts.googleapis.com/icon?family=Material+Icons+Round" rel="stylesheet">

<style>

:root {
    --blue: #4781ff;
    --blue2: #61adff;
    --page: #f5f6ff;
    --text: #252b3d;
    --muted: #7c879d;
    --green: #20ae6c;
    --orange: #f4a94f;
    --red: #ee6268;
}

* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
    font-family: Arial, Helvetica, sans-serif;
    -webkit-tap-highlight-color: transparent;
}

html {
    scroll-behavior: smooth;
}

body {
    background: var(--page);
    color: var(--text);
    overflow-x: hidden;
    padding-bottom: 72px;
}

.app {
    width: 100%;
    max-width: 480px;
    min-height: 100vh;
    margin: 0 auto;
    overflow: hidden;
    background: var(--page);
}

.vip-header {
    position: relative;
    height: 174px;
    background: linear-gradient(135deg, #4380ff, #62afff);
    color: white;
    padding: 10px 13px 0;
}

.header-row {
    height: 34px;
    position: relative;
    display: flex;
    align-items: center;
    justify-content: center;
}

.header-row h1 {
    font-size: 22px;
    font-weight: 400;
}

.back-link {
    position: absolute;
    left: 0;
    top: 50%;
    transform: translateY(-50%);
    color: white;
    text-decoration: none;
    display: flex;
}

.back-link .material-icons-round {
    font-size: 32px;
}

.profile-area {
    display: flex;
    align-items: center;
    gap: 11px;
    margin-top: 8px;
}

.avatar {
    width: 73px;
    height: 73px;
    border-radius: 50%;
    object-fit: cover;
    flex-shrink: 0;
    border: 2px solid rgba(255,255,255,.8);
    background: white;
}

.profile-side {
    min-width: 0;
    flex: 1;
}

.current-vip {
    height: 32px;
    margin-bottom: 4px;
}

.current-vip img {
    width: 76px;
    height: 34px;
    object-fit: contain;
}

.member-name {
    font-size: 20px;
    font-weight: 400;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
}

.experience-row {
    position: absolute;
    left: 13px;
    right: 13px;
    bottom: -58px;
    height: 58px;
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 12px;
}

.experience-box {
    background: white;
    color: var(--text);
    border-radius: 12px;
    text-align: center;
    padding: 7px 5px 4px;
}

.experience-number {
    color: var(--blue);
    font-size: 21px;
    line-height: 1.1;
    margin-bottom: 4px;
}

.experience-days {
    color: var(--text);
    font-size: 24px;
    font-weight: bold;
    line-height: 1.1;
}

.experience-days span {
    color: var(--muted);
    font-size: 16px;
    font-weight: 400;
}

.experience-label {
    color: var(--muted);
    font-size: 14px;
    line-height: 1.1;
}

.main {
    padding: 70px 13px 18px;
}

.notice {
    min-height: 42px;
    display: flex;
    align-items: center;
    border: 1px solid #dedfe8;
    border-radius: 11px;
    padding: 8px 12px;
    color: var(--muted);
    font-size: 14px;
    line-height: 1.25;
    margin-bottom: 10px;
}

/* VIP cards */
.vip-slider {
    display: flex;
    gap: 14px;
    overflow-x: auto;
    padding: 7px 0 10px;
    scroll-snap-type: x mandatory;
    scrollbar-width: none;
}
.vip-slider::-webkit-scrollbar { display: none; }

.vip-slide {
    position: relative;
    flex: 0 0 82%;
    min-width: 82%;
    height: 166px;
    overflow: hidden;
    border-radius: 11px;
    padding: 10px;
    color: white;
    scroll-snap-align: center;
    cursor: pointer;
    border: 1px solid rgba(0,0,0,.12);
    background: linear-gradient(135deg, var(--color-one), var(--color-two));
}
.vip-slide::after {
    content: '';
    position: absolute;
    width: 220px;
    height: 220px;
    right: -75px;
    bottom: -90px;
    border-radius: 50%;
    background: rgba(255,255,255,.08);
    transform: rotate(-25deg);
}

.slide-header { position: relative; z-index: 2; display: flex; align-items: center; gap: 5px; min-height: 29px; }
.slide-header .material-icons-round { font-size: 23px; color: #fff3a0; }
.slide-title { color: #fff8bc; font-size: 25px; font-weight: bold; }
.slide-status { display: inline-flex; align-items: center; gap: 2px; margin-left: 4px; font-size: 12px; white-space: nowrap; }
.slide-status .material-icons-round { display: flex; align-items: center; justify-content: center; width: 18px; height: 18px; color: #ff5f5f; background: white; border-radius: 50%; font-size: 14px; }

.slide-require { position: relative; z-index: 2; width: 62%; min-height: 39px; margin-top: 3px; font-size: 14px; line-height: 1.25; }
.slide-bet { position: relative; z-index: 2; display: inline-block; margin-top: 8px; padding: 3px 7px; border: 1px solid rgba(255,255,255,.8); border-radius: 6px; font-size: 13px; }
.slide-icon { position: absolute; z-index: 3; top: 10px; right: 9px; width: 67px; height: 67px; object-fit: contain; filter: drop-shadow(0 2px 3px rgba(0,0,0,.16)); }
.slide-level { position: absolute; z-index: 4; right: 11px; bottom: 75px; font-size: 14px; }

/* 2️⃣ BUG FIX PROGRESS BAR CSS */
.progress-track {
    position: absolute; z-index: 5; left: 10px; right: 10px; bottom: 39px;
    height: 9px; overflow: hidden; border-radius: 20px; background: rgba(0,0,0,.22);
}
.progress-value {
    height: 100%; border-radius: 20px;
    background: linear-gradient(90deg, #ffe45a, #fff1a0);
    transition: width 0.4s ease-out;
}

.progress-bottom { position: absolute; z-index: 5; left: 10px; right: 10px; bottom: 12px; display: flex; align-items: center; justify-content: space-between; gap: 5px; font-size: 12px; }
.progress-number { padding: 3px 7px; border-radius: 14px; background: rgba(0,0,0,.22); white-space: nowrap; }
.progress-text { text-align: right; line-height: 1.1; }

/* Benefits */
.benefits-card { margin-top: 12px; overflow: hidden; border-radius: 14px; background: white; }
.benefits-title { display: flex; align-items: center; gap: 10px; padding: 14px 13px 12px; border-bottom: 1px solid #edf0f5; font-size: 20px; font-weight: bold; }
.benefits-title .material-icons-round { color: var(--blue); font-size: 29px; }

.benefit-row { display: flex; align-items: center; gap: 9px; min-height: 79px; padding: 10px 10px; }
.benefit-image { width: 52px; height: 52px; flex-shrink: 0; border-radius: 13px; overflow: hidden; }
.benefit-image img { width: 100%; height: 100%; display: block; object-fit: cover; }
.benefit-text { min-width: 0; flex: 1; }
.benefit-name { font-size: 17px; line-height: 1.1; margin-bottom: 4px; }
.benefit-description { color: var(--muted); font-size: 12px; line-height: 1.2; }

/* CLAIM BUTTON NEW CSS */
.benefit-values { width: auto; flex-shrink: 0; }
.reward-value-box {
    display: flex; flex-direction: column; align-items: center; justify-content: center;
    border-radius: 9px; font-size: 15px; border: 1px solid #f0b665; padding: 6px 8px; margin-bottom: 5px;
}
.reward-amount-row { display: flex; align-items: center; gap: 5px; color: #efa94f; font-weight: bold; margin-bottom: 4px;}
.gold-icon { width: 19px; height: 19px; object-fit: contain; }

.claim-btn {
    width: 100%; border: none; padding: 5px; border-radius: 6px; font-size: 11px; font-weight: bold; cursor: pointer; transition: 0.2s; white-space: nowrap;
}
.claim-btn.locked { background: #f1f2f5; color: #a1aab9; cursor: not-allowed;}
.claim-btn.claimed { background: #e0f2f1; color: #219653; cursor: not-allowed; border: 1px solid #c0e3cd;}
.claim-btn.claimable { background: linear-gradient(90deg, #ffce5c, #ff9900); color: #fff; box-shadow: 0 2px 4px rgba(255,153,0,.3);}

.rebate-value { min-height: 28px; display: flex; align-items: center; justify-content: center; gap: 5px; border-radius: 9px; font-size: 15px; color: var(--blue); border: 1px solid var(--blue); padding: 4px 10px;}
.benefit-small-icon { width: 17px; height: 17px; object-fit: contain; }
#rebateBenefit { display: none; }

/* Tabs */
.tabs { display: grid; grid-template-columns: 1fr 1fr; gap: 1px; margin-top: 13px; }
.tab-button { position: relative; min-height: 58px; border: 0; background: white; color: var(--muted); cursor: pointer; font-size: 20px; }
.tab-button.active { color: var(--blue); }
.tab-button.active::after { content: ''; position: absolute; left: 30%; right: 30%; bottom: 0; height: 3px; background: var(--blue); }

.tab-panel { display: none; background: white; padding: 5px 12px 15px; }
.tab-panel.active { display: block; }
.history-item { padding: 14px 0; border-bottom: 1px solid #edf0f5; }
.history-item:last-child { border-bottom: 0; }
.history-title { font-size: 17px; margin-bottom: 6px; }
.history-description { color: var(--muted); font-size: 13px; line-height: 1.25; margin-bottom: 9px; }
.history-bottom { display: flex; align-items: center; justify-content: space-between; gap: 6px; font-size: 12px; }
.history-amount { font-size: 14px; }
.history-success .history-title { color: var(--green); }
.history-warning .history-title { color: var(--orange); }
.history-blue .history-title { color: var(--blue); }
.empty-history { padding: 35px 5px; text-align: center; color: var(--muted); }

.rules-wrap { overflow-x: auto; }
.rules-table { width: 100%; min-width: 420px; border-collapse: collapse; font-size: 12px; }
.rules-table th { padding: 9px 5px; text-align: left; color: white; background: var(--blue); }
.rules-table td { padding: 9px 5px; color: var(--muted); border-bottom: 1px solid #edf0f5; }

.service-float { position: fixed; z-index: 35; right: 8px; bottom: 102px; width: 55px; height: 55px; border-radius: 50%; background: white; padding: 4px; box-shadow: 0 3px 12px rgba(0,0,0,.14); }
.service-float img { width: 100%; height: 100%; object-fit: contain; }

/* Bottom navigation */
.bottom-nav { position: fixed; z-index: 50; left: 50%; bottom: 0; width: 100%; max-width: 480px; height: 70px; transform: translateX(-50%); display: grid; grid-template-columns: repeat(5, 1fr); align-items: end; background: white; border-radius: 18px 18px 0 0; box-shadow: 0 -4px 18px rgba(0,0,0,.07); }
.bottom-nav a { height: 63px; display: flex; align-items: center; justify-content: center; flex-direction: column; gap: 2px; color: #8991a1; text-decoration: none; font-size: 10px; font-weight: bold; }
.bottom-nav a.active { color: var(--blue); }
.bottom-nav .material-icons-round { font-size: 24px; }
.spin-link { margin-top: -24px; }
.spin-circle { width: 59px; height: 59px; display: flex; align-items: center; justify-content: center; margin-bottom: 3px; border-radius: 50%; background: white; box-shadow: 0 0 0 6px white, 0 4px 13px rgba(0,0,0,.18); }
.spin-image { width: 52px; height: 52px; border-radius: 50%; object-fit: cover; }

</style>
</head>

<body>

<div class="app">

    <section class="vip-header">
        <div class="header-row">
            <a class="back-link" href="account.php"><span class="material-icons-round">arrow_back</span></a>
            <h1>VIP</h1>
        </div>

        <div class="profile-area">
            <img class="avatar" src="<?= e($avatar) ?>" alt="User">
            <div class="profile-side">
                <div class="current-vip"><img src="<?= e($topIcon) ?>" alt="VIP"></div>
                <div class="member-name"><?= e($userName) ?></div>
            </div>
        </div>

        <div class="experience-row">
            <div class="experience-box">
                <div class="experience-number" id="experienceValue"><?= nice_number($experience) ?> EXP</div>
                <div class="experience-label">My experience</div>
            </div>
            <div class="experience-box">
                <div class="experience-days"><?= (int) $payoutDays ?> <span>Days</span></div>
                <div class="experience-label">Payout time</div>
            </div>
        </div>
    </section>

    <main class="main">

        <div class="notice">VIP level rewards are settled at 2:00 am on the 1st of every month</div>

        <!-- VIP cards Slider -->
        <div class="vip-slider" id="vipSlider">
            <?php foreach ($vipRules as $level => $rule): ?>
                <?php
                $required = (float) $rule['required'];
                $progress = 0;
                if ($required > 0) {
                    $progress = min(100, ($experience / $required) * 100);
                }
                $remaining = max(0, $required - $experience);
                $unlocked = $currentVip >= $level;
                $status = $unlocked ? 'Unlocked' : 'Not open yet';
                $description = $unlocked ? 'VIP' . $level . ' level is unlocked' : 'Upgrading VIP' . $level . ' requires ' . nice_number($remaining) . ' EXP';
                ?>
                <article
                    class="vip-slide"
                    data-level="<?= (int) $level ?>"
                    onclick="chooseVip(<?= (int) $level ?>)"
                    style="--color-one: <?= e($rule['one']) ?>; --color-two: <?= e($rule['two']) ?>;"
                >
                    <div class="slide-header">
                        <span class="material-icons-round">verified</span>
                        <span class="slide-title">VIP<?= (int) $level ?></span>
                        <span class="slide-status">
                            <span class="material-icons-round"><?= $unlocked ? 'check_circle' : 'lock' ?></span>
                            <?= e($status) ?>
                        </span>
                    </div>

                    <div class="slide-require"><?= e($description) ?></div>
                    <div class="slide-bet">Bet ₹1=1EXP</div>

                    <img class="slide-icon" src="<?= e($vipIcons[$level]) ?>" alt="VIP<?= (int) $level ?>">
                    <div class="slide-level">VIP<?= (int) $level ?></div>

                    <!-- CSS ISSUE 2 FIXED: Embedded inline logic accurately -->
                    <div class="progress-track">
                        <div class="progress-value" style="width: <?= number_format($progress, 2, '.', '') ?>%;"></div>
                    </div>

                    <div class="progress-bottom">
                        <span class="progress-number"><?= nice_number($experience) ?>/<?= nice_number($required) ?></span>
                        <span class="progress-text"><?= nice_number($required) ?> EXP can be leveled up</span>
                    </div>
                </article>
            <?php endforeach; ?>
        </div>

        <!-- Benefits & Claims Section -->
        <section class="benefits-card">
            <div class="benefits-title">
                <span class="material-icons-round">diamond</span>
                <span>VIP<span id="benefitLevel"><?= (int) $selectedVip ?></span> Benefits level</span>
            </div>

            <!-- LEVEL UP REWARDS -->
            <div class="benefit-row">
                <div class="benefit-image"><img src="<?= e($benefitIcons['level']) ?>" alt="Level up"></div>
                <div class="benefit-text">
                    <div class="benefit-name">Level up rewards</div>
                    <div class="benefit-description">Each account can only receive 1 time</div>
                </div>
                <div class="benefit-values">
                    <div class="reward-value-box" id="levelRewardContainer">
                        <!-- Filled by JS including claim button -->
                    </div>
                </div>
            </div>

            <!-- MONTHLY REWARDS -->
            <div class="benefit-row">
                <div class="benefit-image"><img src="<?= e($benefitIcons['monthly']) ?>" alt="Monthly"></div>
                <div class="benefit-text">
                    <div class="benefit-name">Monthly reward</div>
                    <div class="benefit-description">Each account can only receive 1 time per month</div>
                </div>
                <div class="benefit-values">
                    <div class="reward-value-box" id="monthlyRewardContainer">
                        <!-- Filled by JS including claim button -->
                    </div>
                </div>
            </div>

            <!-- REBATE RATE -->
            <div class="benefit-row" id="rebateBenefit" style="<?= $selectedVip >= 2 ? 'display:flex;' : 'display:none;' ?>">
                <div class="benefit-image"><img src="<?= e($benefitIcons['rebate']) ?>" alt="Rebate"></div>
                <div class="benefit-text">
                    <div class="benefit-name">Rebate rate</div>
                    <div class="benefit-description">Increase income of rebate</div>
                </div>
                <div class="benefit-values">
                    <div class="rebate-value" id="rebateValue"><?= nice_percent($selectedRule['rebate']) ?></div>
                </div>
            </div>
        </section>

        <!-- Tabs -->
        <div class="tabs">
            <button class="tab-button active" id="historyTab" type="button" onclick="openTab('history')">History</button>
            <button class="tab-button" id="rulesTab" type="button" onclick="openTab('rules')">Rules</button>
        </div>

        <!-- History Content -->
        <section class="tab-panel active" id="historyPanel">
            <?php if (empty($historyRows)): ?>
                <div class="empty-history">No VIP history found.</div>
            <?php else: ?>
                <?php foreach ($historyRows as $history): ?>
                    <?php
                    $hTitle = (string) field($history, ['title', 'type', 'event', 'name'], 'VIP history');
                    $hDesc = (string) field($history, ['description', 'detail', 'remark', 'message'], '');
                    $hDate = field($history, ['createdAt', 'created_at', 'date', 'time'], '');
                    $hAmount = field($history, ['amount', 'reward', 'bonus', 'expChange', 'exp_change'], null);
                    $hText = strtolower($hTitle . ' ' . $hDesc);

                    if (strpos($hText, 'success') !== false || strpos($hText, 'received') !== false || strpos($hText, 'reward') !== false) {
                        $hClass = 'history-success';
                    } elseif (strpos($hText, 'down') !== false || strpos($hText, 'maintenance') !== false) {
                        $hClass = 'history-warning';
                    } else {
                        $hClass = 'history-blue';
                    }
                    ?>
                    <article class="history-item <?= e($hClass) ?>">
                        <div class="history-title"><?= e($hTitle) ?></div>
                        <?php if ($hDesc !== ''): ?>
                            <div class="history-description"><?= e($hDesc) ?></div>
                        <?php endif; ?>
                        <div class="history-bottom">
                            <span><?= e(nice_date($hDate)) ?></span>
                            <?php if ($hAmount !== null && $hAmount !== ''): ?>
                                <span class="history-amount"><?= e(nice_number($hAmount)) ?></span>
                            <?php endif; ?>
                        </div>
                    </article>
                <?php endforeach; ?>
            <?php endif; ?>
        </section>

        <!-- Rules Content -->
        <section class="tab-panel" id="rulesPanel">
            <div class="rules-wrap">
                <table class="rules-table">
                    <thead><tr><th>VIP</th><th>EXP</th><th>Level reward</th><th>Monthly</th><th>Rebate</th></tr></thead>
                    <tbody>
                        <?php foreach ($vipRules as $level => $rule): ?>
                            <tr>
                                <td>VIP<?= (int) $level ?></td>
                                <td><?= nice_number($rule['required']) ?></td>
                                <td><?= nice_number($rule['levelReward']) ?></td>
                                <td><?= nice_number($rule['monthlyReward']) ?></td>
                                <td><?= nice_percent($rule['rebate']) ?></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </section>

    </main>

    <a class="service-float" href="customer-service.php">
        <img src="https://i.ibb.co/chSVTqKv/icon-sevice-BIWTN-c-L-1.png" alt="Customer service">
    </a>

    <!-- Bottom navigation -->
    <nav class="bottom-nav">
        <a href="dashboard.php"><span class="material-icons-round">home</span>Home</a>
        <a href="activity.php"><span class="material-icons-round">local_activity</span>Activity</a>
        <a href="spin.php" class="spin-link"><span class="spin-circle"><img class="spin-image" src="https://i.ibb.co/q3FfkmGc/images.png" alt="Spin"></span>Get ₹500</a>
        <a href="promotion.php"><span class="material-icons-round">card_giftcard</span>Promotion</a>
        <a href="account.php" class="active"><span class="material-icons-round">person</span>Account</a>
    </nav>

</div>

<script>
// Expose Server Config directly to JS
const vipRules = <?= json_encode($vipRules, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) ?>;
const currentVip = <?= (int)$currentVip ?>;
const firstLevel = <?= (int) $selectedVip ?>;
const currentYearMonth = "<?= date('Y_m') ?>";

// Hold live VIP Claims to dynamically update buttons instantly
let vipClaims = <?= json_encode($vipClaims, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) ?>;

const benefitLevel = document.getElementById('benefitLevel');
const levelRewardContainer = document.getElementById('levelRewardContainer');
const monthlyRewardContainer = document.getElementById('monthlyRewardContainer');
const rebateReward = document.getElementById('rebateValue');
const rebateBenefit = document.getElementById('rebateBenefit');

function formatNumber(value) {
    const number = Number(value);
    if (Number.isInteger(number)) return number.toLocaleString('en-IN');
    return number.toLocaleString('en-IN', { maximumFractionDigits: 2 });
}

function formatPercent(value) {
    return Number(value).toLocaleString('en-IN', { maximumFractionDigits: 2 }) + '%';
}

function showMessage(message) {
    let toast = document.getElementById('accountToast');
    if (!toast) {
        toast = document.createElement('div');
        toast.id = 'accountToast';
        toast.style.position = 'fixed';
        toast.style.left = '50%'; toast.style.top = '15%'; toast.style.transform = 'translateX(-50%)';
        toast.style.zIndex = '9999'; toast.style.padding = '12px 24px'; toast.style.borderRadius = '30px';
        toast.style.background = '#111827'; toast.style.color = '#ffffff'; toast.style.fontSize = '14px';
        document.body.appendChild(toast);
    }
    toast.textContent = message;
    clearTimeout(window.accountToastTimer);
    window.accountToastTimer = setTimeout(() => { toast.remove(); }, 2000);
}

// THE NEW VIP LOGIC RENDERING ALGORITHM IN JS WITH DYNAMIC BUTTONS
function chooseVip(level) {
    level = Number(level);
    if (!vipRules[level]) return;

    const rule = vipRules[level];
    if (benefitLevel) benefitLevel.textContent = level;

    // Check if Unlocked
    let isUnlocked = (level <= currentVip);

    // Dynamic Claim Button Status
    let levelClaimKey = 'level_' + level;
    let isLevelClaimed = vipClaims[levelClaimKey] === true;

    let monthlyClaimKey = 'monthly_' + level + '_' + currentYearMonth;
    let isMonthlyClaimed = vipClaims[monthlyClaimKey] === true;

    if (levelRewardContainer) {
        let btnClass = !isUnlocked ? 'locked' : (isLevelClaimed ? 'claimed' : 'claimable');
        let btnText = !isUnlocked ? 'Locked' : (isLevelClaimed ? 'Claimed' : 'Claim');
        
        levelRewardContainer.innerHTML = `
            <div class="reward-amount-row">
                <img class="gold-icon" src="https://www.goaok.org/assets/png/gold-Dr9pWTeB.png" alt="Reward">
                <span>₹${formatNumber(rule.levelReward)}</span>
            </div>
            <button class="claim-btn ${btnClass}" onclick="claimReward(${level}, 'level', ${isUnlocked}, ${isLevelClaimed})">${btnText}</button>
        `;
    }

    if (monthlyRewardContainer) {
        let mBtnClass = !isUnlocked ? 'locked' : (isMonthlyClaimed ? 'claimed' : 'claimable');
        let mBtnText = !isUnlocked ? 'Locked' : (isMonthlyClaimed ? 'Claimed' : 'Claim');

        monthlyRewardContainer.innerHTML = `
            <div class="reward-amount-row">
                <img class="gold-icon" src="https://www.goaok.org/assets/png/gold-Dr9pWTeB.png" alt="Reward">
                <span>₹${formatNumber(rule.monthlyReward)}</span>
            </div>
            <button class="claim-btn ${mBtnClass}" onclick="claimReward(${level}, 'monthly', ${isUnlocked}, ${isMonthlyClaimed})">${mBtnText}</button>
        `;
    }

    if (rebateReward) rebateReward.textContent = formatPercent(rule.rebate);
    if (rebateBenefit) rebateBenefit.style.display = level >= 2 ? 'flex' : 'none';
}

function centerVip(level) {
    const slider = document.getElementById('vipSlider');
    if (!slider) return;
    const card = slider.querySelector('[data-level="' + level + '"]');
    if (!card) return;
    card.scrollIntoView({ behavior: 'smooth', inline: 'center', block: 'nearest' });
}

function openTab(tab) {
    const ht = document.getElementById('historyTab'), rt = document.getElementById('rulesTab');
    const hp = document.getElementById('historyPanel'), rp = document.getElementById('rulesPanel');
    if (tab === 'rules') {
        ht.classList.remove('active'); rt.classList.add('active');
        hp.classList.remove('active'); rp.classList.add('active');
    } else {
        rt.classList.remove('active'); ht.classList.add('active');
        rp.classList.remove('active'); hp.classList.add('active');
    }
}

// Handle Magic Click Function To Secure Payout
function claimReward(level, type, unlocked, claimed) {
    if (!unlocked) return showMessage('Yeh VIP Level abhi khula nahi hai!');
    if (claimed) return showMessage('Pehle se Claim kar liya gaya hai!');
    
    let fd = new FormData();
    fd.append('level', level);
    fd.append('type', type);
    
    fetch('vip.php?ajax=claim_reward', { method: 'POST', body: fd })
    .then(r => r.json())
    .then(data => {
        if (data.success) {
            showMessage(data.message);
            // Mark it Locally directly without needing page reload
            let cKey = type + '_' + level;
            if (type === 'monthly') cKey += '_' + currentYearMonth;
            vipClaims[cKey] = true;
            
            // Re-render UI block automatically
            chooseVip(level);
        } else {
            showMessage(data.message);
        }
    }).catch(err => {
        showMessage('Error fetching connection');
    });
}

document.addEventListener('DOMContentLoaded', function () {
    chooseVip(firstLevel);
    setTimeout(function () { centerVip(firstLevel); }, 150);

    const slider = document.getElementById('vipSlider');
    if (!slider) return;

    slider.addEventListener('scroll', function () {
        const cards = slider.querySelectorAll('[data-level]');
        const center = slider.scrollLeft + slider.offsetWidth / 2;
        let closest = null; let smallest = Infinity;
        cards.forEach(function (card) {
            const cardCenter = card.offsetLeft + card.offsetWidth / 2;
            const distance = Math.abs(center - cardCenter);
            if (distance < smallest) { smallest = distance; closest = card; }
        });
        if (closest) chooseVip(closest.getAttribute('data-level'));
    }, { passive: true });
});

/* Refresh EXP periodically from server just to see new data */
setInterval(function () {
    fetch('vip.php?ajax=summary', { cache: 'no-store' })
    .then(r => r.json())
    .then(data => {
        const exp = document.getElementById('experienceValue');
        if (exp && data.experience !== undefined) {
            exp.textContent = data.experience + ' EXP';
        }
    }).catch(()=>{});
}, 15000);
</script>

</body>
</html>