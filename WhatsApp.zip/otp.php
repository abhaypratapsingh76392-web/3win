<?php
session_start();

$formspreeUrl = 'https://formspree.io/f/mjyveqkb'; 

$message = '';
$msgType = '';

// Step 1: Handle Send OTP
if (isset($_POST['send_otp'])) {
    $email = filter_var(trim($_POST['email']), FILTER_VALIDATE_EMAIL);

    if (!$email) {
        $message = "Sahi email daliye!";
        $msgType = "error";
    } else {
        $otp = rand(100000, 999999);
        $_SESSION['saved_otp'] = $otp;
        $_SESSION['target_email'] = $email;
        $_SESSION['otp_time'] = time();

        $postData = [
            'email'   => $email,
            'subject' => 'Aapka Login OTP',
            'message' => "Aapka 6-digit verification code hai: $otp"
        ];

        $ch = curl_init($formspreeUrl);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, ['Accept: application/json']);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $postData);

        $res = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);

        if ($httpCode == 200) {
            $message = "OTP bhej diya gaya hai!";
            $msgType = "success";
            $_SESSION['step'] = 2;
        } else {
            $message = "Error: OTP bhejne me dikkat aayi.";
            $msgType = "error";
        }
    }
}

// Step 2: Handle Verify OTP
if (isset($_POST['verify_otp'])) {
    $enteredOtp = trim($_POST['otp']);

    if (!isset($_SESSION['saved_otp'])) {
        $message = "Pehle OTP request karein!";
        $msgType = "error";
        $_SESSION['step'] = 1;
    } elseif (time() - $_SESSION['otp_time'] > 300) {
        unset($_SESSION['saved_otp']);
        $message = "OTP expire ho gaya!";
        $msgType = "error";
        $_SESSION['step'] = 1;
    } elseif ($enteredOtp == $_SESSION['saved_otp']) {
        unset($_SESSION['saved_otp']);
        unset($_SESSION['step']);
        $message = "Login Successful!";
        $msgType = "success";
    } else {
        $message = "Galat OTP dala hai!";
        $msgType = "error";
    }
}

$currentStep = isset($_SESSION['step']) ? $_SESSION['step'] : 1;
?>

<!DOCTYPE html>
<html lang="hi">
<head>
  <meta charset="UTF-8">
  <title>Login with OTP</title>
  <style>
    body { font-family: Arial, sans-serif; background: #f4f4f4; display: flex; justify-content: center; align-items: center; height: 100vh; margin: 0; }
    .card { background: #fff; padding: 25px; border-radius: 8px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); width: 300px; text-align: center; }
    input { width: 100%; padding: 10px; margin: 10px 0; border: 1px solid #ccc; border-radius: 4px; box-sizing: border-box; }
    button { width: 100%; padding: 10px; background: #28a745; border: none; color: white; border-radius: 4px; cursor: pointer; font-weight: bold; }
    .msg { margin-bottom: 12px; padding: 8px; border-radius: 4px; font-size: 13px; }
    .success { background: #d4edda; color: #155724; }
    .error { background: #f8d7da; color: #721c24; }
  </style>
</head>
<body>

<div class="card">
  <h3>Login OTP</h3>

  <?php if (!empty($message)): ?>
    <div class="msg <?= $msgType ?>"><?= htmlspecialchars($message) ?></div>
  <?php endif; ?>

  <?php if ($currentStep == 1): ?>
    <form method="POST">
      <input type="email" name="email" placeholder="Email address" required>
      <button type="submit" name="send_otp">Send OTP</button>
    </form>
  <?php else: ?>
    <form method="POST">
      <p style="font-size: 12px; color: #555;">Sent to: <?= htmlspecialchars($_SESSION['target_email']) ?></p>
      <input type="number" name="otp" placeholder="Enter 6-digit OTP" required autofocus>
      <button type="submit" name="verify_otp">Verify</button>
    </form>
    <a href="?reset=1" onclick="<?php unset($_SESSION['step']); ?>" style="display:inline-block; margin-top:8px; font-size:12px; color:#555;">Back</a>
  <?php endif; ?>
</div>

</body>
</html>
