<?php
session_start();
error_reporting(0);
date_default_timezone_set('Asia/Kolkata');

// Firebase Configuration Connection
require_once 'config.php';

$phone = $_SESSION['user_phone'] ?? $_SESSION['phone'] ?? '';
if ($phone === '') {
    header('Location: index.php');
    exit;
}

function jsonOut($data) {
    header('Content-Type: application/json');
    echo json_encode($data);
    exit;
}

// ==========================================
// BACKEND REAL SLOT MATHEMATICS
// ==========================================
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    
    if ($action === 'get_balance') {
        $user = firebase_read("users/" . $phone);
        jsonOut(['success' => true, 'balance' => round((float)($user['balance'] ?? 0), 2)]);
    }
    
    if ($action === 'spin') {
        $bet = (int)($_POST['bet'] ?? 10);
        $user = firebase_read("users/" . $phone);
        $balance = (float)($user['balance'] ?? 0);
        
        if ($bet > $balance) {
            jsonOut(['success' => false, 'message' => 'Insufficient Balance!']);
        }
        
        $newBalance = $balance - $bet;
        firebase_write("users/$phone/balance", round($newBalance, 2));

        // 1. SET PROBABILITIES: 15% WIN | 85% LOSS
        $rand = mt_rand(1, 100);
        $category = 'MISS';
        
        if ($bet >= 50 && $rand <= 2) { 
            $category = 'SCATTER'; // 2% chance for wheel (1 in 50 spins)
        } elseif ($rand > 2 && $rand <= 15) {
            $category = 'WIN'; // 13% Normal Win (Total 15% Win Chance)
        } else {
            $category = 'MISS'; // 85% Complete Loss
        }

        $baseStr = "";
        $r4_type = "1x";
        $wheelPrize = 0;

        if ($category === 'SCATTER') {
            $r4_type = 'SCATTER';
            $baseStr = "000"; 
            $wheelPrize = 200; // Always stops at 200 as requested
        } 
        else if ($category === 'WIN') {
            $bases = ["001", "005", "010", "050", "100"];
            $baseStr = $bases[array_rand($bases)];
            $xOpts = ['1x', '2x', '5x'];
            if ($bet >= 10) $xOpts[] = '10x';
            $r4_type = $xOpts[array_rand($xOpts)];
        } 
        else { // MISS (85% Chance)
            $bases = ["B00", "0B0", "00B", "BBB", "B0B"]; 
            $baseStr = $bases[array_rand($bases)];
            $r4_type = mt_rand(0,1) ? '1x' : '2x';
        }

        $r1 = ['v' => ($baseStr[0] == 'B') ? mt_rand(1,9) : (int)$baseStr[0], 'half' => ($baseStr[0] == 'B')];
        $r2 = ['v' => ($baseStr[1] == 'B') ? mt_rand(1,9) : (int)$baseStr[1], 'half' => ($baseStr[1] == 'B')];
        $r3 = ['v' => ($baseStr[2] == 'B') ? mt_rand(1,9) : (int)$baseStr[2], 'half' => ($baseStr[2] == 'B')];

        $strVal = "";
        $strVal .= $r1['half'] ? "" : (string)$r1['v'];
        $strVal .= $r2['half'] ? "" : (string)$r2['v'];
        $strVal .= $r3['half'] ? "" : (string)$r3['v'];
        $numericalBase = ($strVal === "") ? 0 : (int)$strVal;

        $mult = (int)str_replace('x', '', $r4_type);
        if ($mult === 0) $mult = 1;

        $winAmount = 0;
        if ($category === 'SCATTER') {
            $winAmount = $wheelPrize * ($bet / 10);
        } else {
            // FIXED MATH: If base is 5 and bet is 10, win is exactly 5.
            $winAmount = $numericalBase * $mult * ($bet / 10);
        }

        if ($winAmount > 0) {
            $newBalance += $winAmount;
            firebase_write("users/$phone/balance", round($newBalance, 2));
        }

        jsonOut([
            'success' => true,
            'r1' => $r1, 'r2' => $r2, 'r3' => $r3, 'r4' => $r4_type,
            'wheelPrize' => $wheelPrize,
            'win' => round($winAmount, 2),
            'balance' => round($newBalance, 2)
        ]);
    }
}
$user = firebase_read("users/" . $phone);
$balance = (float)($user['balance'] ?? 0);
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
<title>Money Coming - JILI</title>
<link href="https://fonts.googleapis.com/css2?family=Anton&family=Roboto:wght@700;900&display=swap" rel="stylesheet">
<style>
    * { box-sizing: border-box; margin: 0; padding: 0; user-select: none; -webkit-tap-highlight-color: transparent; }
    
    body, html { height: 100%; width: 100%; overflow: hidden; }
    
    body { 
        background-color: #3b1100;
        background-image: radial-gradient(#8a2505 2px, transparent 2px);
        background-size: 12px 12px;
        color: white; font-family: 'Roboto', sans-serif; 
        display: flex; justify-content: center; 
    }
    
    .app { 
        position: fixed; inset: 0; width: 100%; max-width: 480px; margin: 0 auto;
        display: flex; flex-direction: column;
        background: rgba(0,0,0,0.4);
    }

    /* TOP HEADER */
    .top-bar { flex: 0 0 auto; display: flex; justify-content: space-between; align-items: center; padding: 10px 15px; background: rgba(0,0,0,0.6); }
    .back-btn { font-size: 26px; color: white; text-decoration: none; font-weight: bold; }
    .wallet { background: linear-gradient(180deg, #1b3a82, #07173d); border: 2px solid #2d5db8; border-radius: 20px; padding: 5px 15px; display: flex; align-items: center; box-shadow: 0 2px 8px rgba(0,0,0,0.6); }
    .wallet img { width: 18px; margin-right: 8px; }
    .wallet span { font-weight: 900; font-size: 15px; letter-spacing: 0.5px; }
    .plus-btn { background: #4a77d4; color: white; border: none; border-radius: 50%; width: 22px; height: 22px; font-weight: bold; margin-left: 10px; }

    /* MACHINE AREA */
    .machine-wrapper { 
        flex: 1 1 auto; padding: 0 12px; display: flex; flex-direction: column; 
        justify-content: center; align-items: center; overflow: visible; 
    }
    
    .machine-frame {
        width: 100%; max-width: 380px;
        background: linear-gradient(180deg, #008822 0%, #003300 100%);
        border-radius: 200px 200px 10px 10px; padding: 15px 10px 10px 10px; position: relative;
        box-shadow: 0 10px 25px rgba(0,0,0,0.9), inset 0 0 20px rgba(0,0,0,0.9);
        border: 5px solid #e6b847; margin: auto; 
        transform: translateY(-15px);
    }
    /* Quilted Green Pattern */
    .machine-frame::after {
        content: ''; position: absolute; inset: 0;
        background-image: linear-gradient(45deg, rgba(0,0,0,0.2) 25%, transparent 25%), linear-gradient(-45deg, rgba(0,0,0,0.2) 25%, transparent 25%);
        background-size: 20px 20px; pointer-events: none; border-radius: inherit; z-index: 0;
    }

    .wheel-box {
        width: 240px; height: 240px; border-radius: 50%; margin: 0 auto; 
        border: 6px solid #e6b847; box-shadow: 0 5px 15px rgba(0,0,0,0.8);
        position: relative; background: #000; overflow: hidden; z-index: 2;
    }
    .pointer {
        position: absolute; top: -14px; left: 50%; transform: translateX(-50%);
        width: 0; height: 0; border-left: 14px solid transparent; border-right: 14px solid transparent; border-top: 30px solid #2bc966; z-index: 20;
    }
    .pointer::after { content: '$'; position: absolute; top: -28px; left: -5px; color: white; font-weight: 900; font-size: 13px; }
    
    .wheel {
        width: 100%; height: 100%; border-radius: 50%; position: relative;
        transition: transform 3.5s cubic-bezier(0.1, 0.9, 0.2, 1); transform: rotate(0deg);
        background: conic-gradient(from -22.5deg,
            #2bc966 0deg 45deg,    /* 50 */
            #ffd13b 45deg 90deg,   /* 200 */
            #d32222 90deg 135deg,  /* 2000 */
            #ffd13b 135deg 180deg, /* 500 */
            #2bc966 180deg 225deg, /* 100 */
            #ffd13b 225deg 270deg, /* 300 */
            #2bc966 270deg 315deg, /* 150 */
            #ffd13b 315deg 360deg  /* 1000 */
        );
    }
    .wheel-lines { position: absolute; inset: 0; border-radius: 50%; }
    .wheel-lines div { position: absolute; width: 2px; height: 50%; background: #553300; left: calc(50% - 1px); transform-origin: bottom center; }
    .wheel-lines div:nth-child(1) { transform: rotate(22.5deg); } .wheel-lines div:nth-child(2) { transform: rotate(67.5deg); } .wheel-lines div:nth-child(3) { transform: rotate(112.5deg); } .wheel-lines div:nth-child(4) { transform: rotate(157.5deg); } .wheel-lines div:nth-child(5) { transform: rotate(202.5deg); } .wheel-lines div:nth-child(6) { transform: rotate(247.5deg); } .wheel-lines div:nth-child(7) { transform: rotate(292.5deg); } .wheel-lines div:nth-child(8) { transform: rotate(337.5deg); }

    .wheel-nums .w-num {
        position: absolute; width: 60px; text-align: center; left: calc(50% - 30px); top: 8px;
        transform-origin: 50% 112px; font-family: 'Anton', sans-serif; font-size: 22px; color: #111; letter-spacing: 0.5px;
    }
    .wheel-nums .w-num:nth-child(1) { transform: rotate(0deg); } 
    .wheel-nums .w-num:nth-child(2) { transform: rotate(45deg); } 
    .wheel-nums .w-num:nth-child(3) { transform: rotate(90deg); color: #fff; text-shadow: 1px 1px 1px #000; } 
    .wheel-nums .w-num:nth-child(4) { transform: rotate(135deg); } 
    .wheel-nums .w-num:nth-child(5) { transform: rotate(180deg); } 
    .wheel-nums .w-num:nth-child(6) { transform: rotate(225deg); } 
    .wheel-nums .w-num:nth-child(7) { transform: rotate(270deg); } 
    .wheel-nums .w-num:nth-child(8) { transform: rotate(315deg); } 

    .wheel-center {
        position: absolute; top: 50%; left: 50%; transform: translate(-50%, -50%); width: 55px; height: 55px; border-radius: 50%; background: radial-gradient(circle, #ffcc33, #a67c00); border: 3px solid #593900; display: flex; justify-content: center; align-items: center; font-size: 28px; color: #fff; text-shadow: 0 2px 4px rgba(0,0,0,0.7); z-index: 5; font-family: 'Anton', sans-serif; box-shadow: 0 4px 10px rgba(0,0,0,0.6);
    }

    .logo-text { text-align: center; margin-top: -10px; position: relative; z-index: 10; font-family: 'Anton', sans-serif; font-size: 34px; letter-spacing: 1px; color: #e60000; text-shadow: -1px -1px 0 #fff, 1px -1px 0 #fff, -1px 1px 0 #fff, 1px 1px 0 #fff, 0 4px 6px rgba(0,0,0,0.9); transform: skewY(-2deg); }

    .unlock-box { background: linear-gradient(180deg, #5c1e02, #290b00); border: 2px solid #e6b847; border-radius: 6px; padding: 4px; margin: 10px 0; display: flex; flex-direction: column; gap: 4px; box-shadow: 0 4px 8px rgba(0,0,0,0.8); position: relative; z-index: 2; }
    .u-bar { background: #111; color: #777; font-size: 13px; font-weight: 900; text-align: center; padding: 6px; border-radius: 4px; transition: 0.3s; display: flex; justify-content: center; align-items: center; gap: 5px;}
    .u-bar.active { background: linear-gradient(90deg, #b37700, #ffcc66, #b37700); color: #000; text-shadow: 1px 1px 0px rgba(255,255,255,0.4); }
    
    .scatter-badge { background: radial-gradient(circle, #ff0000, #660000); color: white; font-size: 9px; padding: 2px 5px; border-radius: 10px; border: 1px solid #ffcc00; }
    .x10-badge { color: #ff00ff; text-shadow: 1px 1px 0 #fff, -1px -1px 0 #fff, 1px -1px 0 #fff, -1px 1px 0 #fff; font-weight: 900; font-size: 14px;}

    /* REELS */
    .reels-board { display: flex; gap: 4px; background: #3a0000; border: 3px solid #e6b847; border-radius: 6px; padding: 5px; height: 95px; box-shadow: inset 0 10px 20px rgba(0,0,0,0.9); position: relative; z-index: 2; }
    .reel { flex: 1; background: linear-gradient(180deg, #00b33c 0%, #004d1a 100%); border-radius: 4px; border: 1px solid #000; position: relative; overflow: hidden; display: flex; align-items: center; justify-content: center; box-shadow: inset 0 5px 10px rgba(0,0,0,0.5); }
    .reel:nth-child(4) { background: linear-gradient(180deg, #ffe680 0%, #b38f00 100%); flex: 1.2; }
    
    .r-text { font-family: 'Anton', sans-serif; font-size: 55px; color: #ffeb99; text-shadow: 2px 2px 4px #000; position: absolute; width: 100%; text-align: center; line-height: 1; transition: transform 0.1s, opacity 0.1s; }
    .reel:nth-child(4) .r-text { font-size: 38px; color: #4a0080; text-shadow: 1px 1px 0 #fff, -1px -1px 0 #fff, 1px -1px 0 #fff, -1px 1px 0 #fff, 2px 2px 5px rgba(0,0,0,0.6);}
    
    .r-text.half-stop { transform: translateY(60%); opacity: 0.35; filter: drop-shadow(0 -5px 5px #000); }
    
    .scatter-icon { font-size: 12px; font-weight: 900; color: #fff; background: radial-gradient(circle, #0055ff, #001166); border: 2px solid #ffcc00; border-radius: 50%; width: 50px; height: 50px; display: flex; align-items: center; justify-content: center; flex-direction: column; margin: 0 auto; box-shadow: 0 4px 6px #000; text-shadow: none; }
    .reel.spin .r-text { animation: scrollReel 0.1s linear infinite; filter: blur(2px); transform: translateY(0); opacity: 1;}
    @keyframes scrollReel { 0% { transform: translateY(-100%); } 100% { transform: translateY(100%); } }

    /* FOOTER */
    .footer-panel {
        flex: 0 0 auto;
        background: url('https://www.transparenttextures.com/patterns/dark-matter.png'), linear-gradient(0deg, #1a0500, #3a1100);
        padding: 5px 15px 15px 15px; 
        border-top: 3px solid #e6b847; 
        display: grid; grid-template-columns: 1fr 1fr 1fr; align-items: center;
        box-shadow: 0 -5px 15px rgba(0,0,0,0.9);
        position: relative; min-height: 90px;
    }
    
    .left-col { display: flex; flex-direction: column; gap: 8px; justify-content: center; }
    .icon-row { display: flex; gap: 8px; align-items: center; }
    
    .btn-sm { width: 34px; height: 34px; border-radius: 50%; border: 2px solid #e6b847; background: linear-gradient(180deg, #b34700, #4d1a00); color: #e6b847; display: flex; align-items: center; justify-content: center; font-size: 16px; font-weight: bold; cursor: pointer; box-shadow: 0 3px 5px rgba(0,0,0,0.6); }
    .btn-sm.active { background: #e6b847; color: #000; }

    .bet-btn-wrapper { position: relative; z-index: 100; }
    .bet-btn { background: linear-gradient(180deg, #331100, #000); border: 2px solid #e6b847; border-radius: 20px; padding: 4px 12px; text-align: center; cursor: pointer; min-width: 75px; box-shadow: 0 3px 6px rgba(0,0,0,0.8); display: flex; align-items: center; justify-content: center; gap: 5px;}
    .bet-btn span { font-size: 11px; color: #aaa; text-transform: uppercase; font-weight: bold;}
    .bet-btn b { font-size: 16px; color: #fff; font-family: 'Anton', sans-serif; letter-spacing: 1px;}

    .center-col { display: flex; justify-content: center; position: relative; }
    
    /* Green JILI Spin Button */
    .jili-spin-btn {
        width: 90px; height: 90px; border-radius: 50%; 
        position: absolute; top: -55px; 
        left: 50%; transform: translateX(-50%);
        background: radial-gradient(circle at 50% 30%, #00ff55, #006622);
        border: 5px solid #e6b847; box-shadow: 0 10px 20px rgba(0,0,0,1), inset 0 5px 10px rgba(255,255,255,0.6);
        display: flex; align-items: center; justify-content: center; cursor: pointer; z-index: 105; 
        font-family: 'Anton', sans-serif; font-size: 30px; color: #004d1a; text-shadow: 1px 1px 0px #88ffaa;
        letter-spacing: 1px; transition: transform 0.1s;
    }
    .jili-spin-btn:active { transform: translateX(-50%) scale(0.92); }
    .jili-spin-btn.disabled { filter: grayscale(100%); pointer-events: none; }

    .win-text-above-spin { 
        position: absolute; top: -90px; width: 140px; text-align: center;
        left: 50%; transform: translateX(-50%);
        font-size: 14px; font-weight: bold; color: #e6b847; text-shadow: 1px 1px 1px #000;
        z-index: 10; 
    }

    .right-col { display: flex; flex-direction: column; align-items: flex-end; gap: 8px; justify-content: center;}
    .balance-txt { font-size: 13px; color: #fff; font-weight: bold; }
    .balance-txt span { font-family: 'Anton', sans-serif; font-size: 15px;}

    .bet-menu {
        position: absolute; bottom: 85px; left: 10px; background: #1a0a00; 
        border: 2px solid #e6b847; border-radius: 6px; width: 80px; display: none; 
        flex-direction: column; z-index: 150; box-shadow: 0 10px 25px rgba(0,0,0,0.9);
    }
    .bet-menu.open { display: flex; animation: slideUp 0.2s ease;}
    @keyframes slideUp { from {opacity: 0; transform: translateY(10px);} to {opacity: 1; transform: translateY(0);}}
    .bet-opt { padding: 12px; text-align: center; color: #fff; font-weight: bold; font-size: 18px; border-bottom: 1px solid #3d2300; cursor: pointer; }
    .bet-opt:last-child { border-bottom: none; }
    .bet-opt.active { background: linear-gradient(90deg, #b37700, #ffcc66); color: #000; }

    .win-modal {
        position: fixed; inset: 0; background: rgba(0,0,0,0.85); z-index: 1000; display: none; flex-direction: column; align-items: center; justify-content: center; cursor: pointer;
    }
    .win-modal.show { display: flex; animation: fadeIn 0.2s; }
    @keyframes fadeIn { from { opacity: 0; } to { opacity: 1; } }
    .win-amt { font-family: 'Anton', sans-serif; font-size: 80px; color: #ffcc66; text-shadow: 0 0 40px #ff9900, 2px 2px 5px #000; margin-bottom: 20px; animation: scaleUp 0.4s cubic-bezier(0.175, 0.885, 0.32, 1.275); }
    @keyframes scaleUp { from { transform: scale(0.3); } to { transform: scale(1); } }
</style>
</head>
<body>

<div class="app">
    <!-- TOP HEADER -->
    <div class="top-bar">
        <a href="dashboard.php" class="back-btn">‹</a>
        <div class="wallet">
            <img src="https://cdn-icons-png.flaticon.com/512/1490/1490853.png" alt="coin">
            <span id="topBal"><?php echo number_format($balance, 2); ?></span>
            <button class="plus-btn" onclick="location.href='deposit.php'">+</button>
        </div>
    </div>

    <!-- MACHINE BODY -->
    <div class="machine-wrapper">
        <div class="machine-frame">
            <div class="pointer"></div>
            <div class="wheel-box">
                <div class="wheel" id="mainWheel">
                    <div class="wheel-lines">
                        <div></div><div></div><div></div><div></div>
                        <div></div><div></div><div></div><div></div>
                    </div>
                    <div class="wheel-nums">
                        <div class="w-num">50</div><div class="w-num">200</div><div class="w-num">2,000</div><div class="w-num">500</div>
                        <div class="w-num">100</div><div class="w-num">300</div><div class="w-num">150</div><div class="w-num">1,000</div>
                    </div>
                </div>
                <div class="wheel-center">$</div>
            </div>
            
            <div class="logo-text">Money Coming</div>
            
            <div class="unlock-box">
                <div class="u-bar" id="barScatter">Bet 50 <span class="scatter-badge">SCATTER</span> ➔ <span class="scatter-badge">SCATTER</span></div>
                <div class="u-bar" id="bar10x">Bet 10 unlock <span class="x10-badge">10x</span></div>
            </div>

            <div class="reels-board">
                <div class="reel" id="reel1"><div class="r-text" id="rt1">1</div></div>
                <div class="reel" id="reel2"><div class="r-text half-stop" id="rt2">0</div></div>
                <div class="reel" id="reel3"><div class="r-text half-stop" id="rt3">0</div></div>
                <div class="reel" id="reel4"><div class="r-text" id="rt4">1x</div></div>
            </div>
        </div>
    </div>

    <!-- FOOTER -->
    <div class="footer-panel">
        <div class="left-col">
            <div class="icon-row">
                <div class="btn-sm">⚙</div>
                <div class="btn-sm">ⓘ</div>
            </div>
            <div class="bet-btn-wrapper">
                <div class="bet-btn" onclick="toggleBetMenu()">
                    <span>Bet</span> <b id="betBtnVal">₹10</b>
                </div>
            </div>
        </div>

        <div class="center-col">
            <div class="win-text-above-spin">WIN <span style="color:#fff" id="winTxt">₹0.00</span></div>
            <div class="jili-spin-btn" id="spinBtn" onclick="playSpin()">JILI</div>
        </div>

        <div class="right-col">
            <div class="icon-row">
                <div class="btn-sm" id="autoBtn" onclick="toggleAuto()">🔄</div>
                <div class="btn-sm" id="speedBtn" onclick="toggleSpeed()">⚡</div>
            </div>
            <div class="balance-txt">Balance <span id="btmBal">₹<?php echo number_format($balance, 2); ?></span></div>
        </div>
    </div>

    <div class="bet-menu" id="betMenu">
        <div class="bet-opt" onclick="setBet(100)">100</div>
        <div class="bet-opt" onclick="setBet(50)">50</div>
        <div class="bet-opt active" onclick="setBet(10)">10</div>
        <div class="bet-opt" onclick="setBet(5)">5</div>
        <div class="bet-opt" onclick="setBet(1)">1</div>
    </div>
</div>

<!-- Collect Display Modal -->
<div class="win-modal" id="winModal" onclick="closeWin()">
    <div class="win-amt" id="bigWinText">₹0.00</div>
    <div style="color:#fff; font-weight:bold; font-size:18px;">Tap anywhere to collect</div>
</div>

<script>
let bet = 10;
let isSpinning = false;
let wheelRot = 0;
let isSpeed = false;
let isAuto = false;

// Updated Wheel Map to match the new exact UI layout
const wheelMap = { 50: 0, 200: 45, 2000: 90, 500: 135, 100: 180, 300: 225, 150: 270, 1000: 315 };

function toggleBetMenu() { if(!isSpinning) document.getElementById('betMenu').classList.toggle('open'); }
function setBet(v) {
    bet = v; document.getElementById('betBtnVal').innerText = '₹' + v;
    document.getElementById('betMenu').classList.remove('open');
    document.querySelectorAll('.bet-opt').forEach(el => { el.classList.remove('active'); if(parseInt(el.innerText) === v) el.classList.add('active'); });
    document.getElementById('barScatter').className = v >= 50 ? 'u-bar active' : 'u-bar';
    document.getElementById('bar10x').className = v >= 10 ? 'u-bar active' : 'u-bar';
}
setBet(10);

function toggleSpeed() { isSpeed = !isSpeed; document.getElementById('speedBtn').classList.toggle('active'); }
function toggleAuto() { 
    isAuto = !isAuto; document.getElementById('autoBtn').classList.toggle('active'); 
    if(isAuto && !isSpinning) playSpin(); 
}

async function reqAPI(d={}) {
    const fd = new FormData(); fd.append('action', 'spin'); fd.append('bet', bet);
    const r = await fetch(location.href, {method:'POST', body:fd}); return r.json();
}

function renderReel(id, vObj) {
    const box = document.getElementById(id).querySelector('.r-text');
    if(typeof vObj === 'string') {
        box.className = 'r-text';
        box.innerHTML = vObj === 'SCATTER' ? '<div class="scatter-icon">WHEEL<br>ALL</div>' : vObj;
    } else {
        box.innerText = vObj.v;
        box.className = vObj.half ? 'r-text half-stop' : 'r-text';
    }
}

let aCtx=null;
function beep(f, d, t='square', v=0.03) {
    try {
        if(!aCtx) aCtx = new (window.AudioContext||window.webkitAudioContext)(); 
        if(aCtx.state==='suspended') aCtx.resume();
        const o = aCtx.createOscillator(), g = aCtx.createGain();
        o.type = t; o.frequency.value = f; g.gain.setValueAtTime(v, aCtx.currentTime);
        g.gain.exponentialRampToValueAtTime(0.001, aCtx.currentTime + d);
        o.connect(g); g.connect(aCtx.destination); o.start(); o.stop(aCtx.currentTime + d);
    } catch(e){}
}

async function playSpin() {
    if(isSpinning) return;
    document.getElementById('betMenu').classList.remove('open');
    
    let bal = parseFloat(document.getElementById('topBal').innerText.replace(/,/g,''));
    if(bet > bal) { alert("Low Balance!"); isAuto=false; document.getElementById('autoBtn').classList.remove('active'); return; }

    isSpinning = true; document.getElementById('spinBtn').classList.add('disabled');
    document.getElementById('winTxt').innerText = '₹0.00';
    let nb = (bal - bet).toFixed(2);
    document.getElementById('topBal').innerText = nb; document.getElementById('btmBal').innerText = '₹'+nb;

    for(let i=1; i<=4; i++) document.getElementById('reel'+i).classList.add('spin');
    let snIt = setInterval(() => beep(400, 0.05, 'square', 0.01), 100);

    const res = await reqAPI();
    clearInterval(snIt);
    if(!res.success) { for(let i=1;i<=4;i++) document.getElementById('reel'+i).classList.remove('spin'); rState(); return; }

    let bTime = isSpeed ? 300 : 800;
    setTimeout(()=>{ document.getElementById('reel1').classList.remove('spin'); renderReel('reel1', res.r1); beep(150,0.1,'sawtooth'); }, bTime);
    setTimeout(()=>{ document.getElementById('reel2').classList.remove('spin'); renderReel('reel2', res.r2); beep(150,0.1,'sawtooth'); }, bTime + (isSpeed?100:400));
    setTimeout(()=>{ document.getElementById('reel3').classList.remove('spin'); renderReel('reel3', res.r3); beep(150,0.1,'sawtooth'); }, bTime + (isSpeed?200:800));
    setTimeout(()=>{ 
        document.getElementById('reel4').classList.remove('spin'); renderReel('reel4', res.r4); beep(200,0.2,'sawtooth', 0.1);
        if(res.r4 === 'SCATTER') trigWhl(res); else doneSpin(res);
    }, bTime + (isSpeed?300:1200));
}

function trigWhl(res) {
    const whl = document.getElementById('mainWheel');
    // Calculate rotation to stop exactly at the prize (200)
    wheelRot += 360 * (isSpeed?2:4) + (360 - wheelMap[res.wheelPrize]) - (wheelRot % 360);
    whl.style.transition = `transform ${isSpeed?'2s':'3.5s'} cubic-bezier(0.1,0.9,0.2,1)`;
    whl.style.transform = `rotate(${wheelRot}deg)`;
    
    let ws = setInterval(()=>beep(900,0.05,'triangle'), 100);
    setTimeout(()=>{ clearInterval(ws); doneSpin(res); }, isSpeed ? 2200 : 3800);
}

function doneSpin(res) {
    document.getElementById('topBal').innerText = parseFloat(res.balance).toFixed(2);
    document.getElementById('btmBal').innerText = '₹' + parseFloat(res.balance).toFixed(2);
    
    if(res.win > 0) {
        document.getElementById('winTxt').innerText = '₹' + parseFloat(res.win).toFixed(2);
        [523,659,784,1046,1318].forEach((f,i)=>setTimeout(()=>beep(f,0.3,'sine',0.1),i*100));
        
        document.getElementById('bigWinText').innerText = '₹' + parseFloat(res.win).toFixed(2);
        document.getElementById('winModal').classList.add('show');
        if(isAuto) setTimeout(closeWin, isSpeed ? 1500 : 3000); 
    } else {
        rState();
        if(isAuto) setTimeout(playSpin, isSpeed ? 200 : 800);
    }
}

function closeWin() { document.getElementById('winModal').classList.remove('show'); rState(); if(isAuto) setTimeout(playSpin, 400); }
function rState() { isSpinning = false; document.getElementById('spinBtn').classList.remove('disabled'); }
</script>
</body>
</html>