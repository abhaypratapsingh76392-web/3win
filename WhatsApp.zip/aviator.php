<?php
// session_start() config.php me already hai — duplicate call mat karo
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
error_reporting(0);
date_default_timezone_set('Asia/Kolkata');
require_once 'config.php';

$phone = $_SESSION['user_phone'] ?? $_SESSION['phone'] ?? '';
if ($phone === '') { header('Location: index.php'); exit; }
$_SESSION['user_phone'] = $phone;
$_SESSION['phone'] = $phone;

function ms() { return round(microtime(true) * 1000); }
function jsonOut($d) { 
    if (!headers_sent()) header('Content-Type: application/json'); 
    echo json_encode($d); 
    exit; 
}
function maskPhone($p) { $p = (string)$p; return substr($p, 0, 1) . '***' . substr($p, -1); }

/* ====== ROUND ENGINE (server-time based, live for all users) ====== */
const BET_MS   = 5000;   // betting window
const END_MS   = 3000;   // flew-away display time
const GROWTH   = 0.12;   // multiplier growth per second

function naturalCrash() {
    $r = mt_rand(1, 9999) / 10000;
    if ($r < 0.04) return 1.00;
    return round(min(50, max(1, 0.99 / (1 - $r))), 2);
}

function riggedCrash() {
    // 75% loss (crash below 2x) / 25% win chance
    if (mt_rand(1, 100) <= 75) {
        return round(1.00 + mt_rand(0, 90) / 100, 2); // 1.00x - 1.90x
    }
    return round(2.00 + mt_rand(0, 800) / 100, 2); // 2.00x - 10.00x
}

function crashTimeMs($c) {
    return min(60000, round(log($c) / GROWTH * 1000));
}

function makeBots($crash) {
    $c = 'abcdefghijklmnopqrstuvwxyz';
    $d = '0123456789';
    $amts = [10, 20, 50, 100, 200, 310, 360, 400, 430, 450, 460, 500, 1000];
    $grad = [
        ['#ff9a9e','#fad0c4'],['#a18cd1','#fbc2eb'],['#f6d365','#fda085'],
        ['#84fab0','#8fd3f4'],['#fa709a','#fee140'],['#30cfd0','#330867'],
        ['#667eea','#764ba2'],['#ff0844','#ffb199'],['#00c6fb','#005bea'],
        ['#f83600','#f9d423']
    ];
    $n = 12 + mt_rand(0, 18);
    $bots = [];
    for ($i = 0; $i < $n; $i++) {
        $name = $c[mt_rand(0, 25)] . '***' . (mt_rand(0,1) ? $d[mt_rand(0,9)] : $c[mt_rand(0,25)]);
        $target = mt_rand(1, 100) > 35 ? round(1.05 + mt_rand(5, 400)/100, 2) : 999;
        if ($target >= $crash) $target = 999;
        $bots[] = [
            'name' => $name,
            'g'    => $grad[mt_rand(0, count($grad)-1)],
            'amount' => $amts[mt_rand(0, count($amts)-1)],
            'target' => $target,
            'cashed' => false,
            'cx' => 0
        ];
    }
    usort($bots, function($a, $b) { return $b['amount'] - $a['amount']; });
    return $bots;
}

function ensureRound() {
    $now = ms();
    $cur = firebase_read('aviator/current');

    // ====== FIX: Proper null handling for end_ts ======
    // Create new round ONLY if:
    // 1. No current round exists (first time)
    // 2. Current round has fully ended (end_ts is set AND now > end_ts)
    $needsNewRound = false;
    if (!is_array($cur)) {
        $needsNewRound = true;
    } else {
        $endTs = $cur['end_ts'] ?? null;
        // Only create new round if end_ts exists AND time has passed it
        if ($endTs !== null && $now > $endTs) {
            $needsNewRound = true;
        }
    }

    if ($needsNewRound) {
        $prevId = (int)($cur['id'] ?? 32509842);
        $cur = [
            'id'           => $prevId + 1,
            'bet_start'    => $now,
            'flight_start' => null,
            'crash'        => null,
            'end_ts'       => null,
            'bots'         => null,
            'bets'         => []
        ];
        firebase_write('aviator/current', $cur);
    }

    // Betting phase ended → start flight
    if ($cur['flight_start'] === null && $now >= $cur['bet_start'] + BET_MS) {
        $bets = $cur['bets'] ?? [];
        $realTotal = 0;
        if (is_array($bets)) {
            foreach ($bets as $b) $realTotal += (float)($b['amount'] ?? 0);
        }
        $crash = $realTotal > 0 ? riggedCrash() : naturalCrash();
        $T = crashTimeMs($crash);
        $cur['crash']        = $crash;
        $cur['flight_start'] = $now;
        $cur['end_ts']       = $now + $T + END_MS;
        $cur['bots']         = makeBots($crash);
        firebase_write('aviator/current', $cur);

        // Push to history
        $h = firebase_read('aviator/history');
        $h = is_array($h) ? $h : [];
        array_unshift($h, $crash);
        $h = array_slice($h, 0, 50);
        firebase_write('aviator/history', $h);
    }

    return $cur;
}

/* ====== AJAX API ====== */
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';

    if ($action === 'get_state') {
        $cur = ensureRound();
        $now = ms();
        $phase = 'waiting';
        if ($cur['flight_start'] !== null) {
            $phase = ($now < $cur['end_ts'] - END_MS) ? 'flying' : 'crashed';
        }
        $bets = $cur['bets'] ?? [];
        if (!is_array($bets)) $bets = [];
        $myBet = null;
        foreach ($bets as $id => $b) {
            if (($b['phone'] ?? '') === $phone) {
                $myBet = array_merge($b, ['id' => $id]);
                break;
            }
        }
        $realList = [];
        foreach ($bets as $id => $b) {
            $realList[] = [
                'name'   => maskPhone($b['phone'] ?? ''),
                'amount' => (float)($b['amount'] ?? 0),
                'cashed' => ($b['status'] ?? '') === 'cashed',
                'cx'     => (float)($b['cx'] ?? 0),
                'is_me'  => ($b['phone'] ?? '') === $phone,
                'g'      => ['#37b42a', '#00d2ff']
            ];
        }
        jsonOut([
            'success' => true,
            'server_ts' => $now,
            'round'  => $cur,
            'phase'  => $phase,
            'my_bet' => $myBet,
            'real_bets' => $realList,
            'bots'   => $cur['bots'] ?? []
        ]);
    }

    if ($action === 'place_bet') {
        $amount = (float)($_POST['amount'] ?? 0);
        if ($amount < 10) jsonOut(['success' => false, 'message' => 'Minimum bet ₹10!']);
        $cur = ensureRound();
        $now = ms();
        if ($cur['flight_start'] !== null) jsonOut(['success' => false, 'message' => 'Round started! Wait for next.']);

        $bets = $cur['bets'] ?? [];
        if (is_array($bets)) {
            foreach ($bets as $b) {
                if (($b['phone'] ?? '') === $phone && ($b['status'] ?? '') === 'active') {
                    jsonOut(['success' => false, 'message' => 'Already have active bet']);
                }
            }
        }

        $user = firebase_read("users/" . $phone);
        $bal = (float)($user['balance'] ?? 0);
        if ($amount > $bal) jsonOut(['success' => false, 'message' => 'Insufficient balance!']);

        $betId = 'b_' . uniqid();
        $cur['bets'][$betId] = [
            'phone'  => $phone,
            'amount' => $amount,
            'status' => 'active',
            'cx'     => 0,
            'ts'     => $now
        ];
        firebase_write('aviator/current', $cur);
        firebase_write("users/$phone/balance", $bal - $amount);
        jsonOut(['success' => true, 'bet_id' => $betId, 'balance' => $bal - $amount]);
    }

    if ($action === 'cancel_bet') {
        $cur = ensureRound();
        if ($cur['flight_start'] !== null) jsonOut(['success' => false, 'message' => 'Cannot cancel now']);
        $bets = $cur['bets'] ?? [];
        $found = null; $foundId = null;
        if (is_array($bets)) {
            foreach ($bets as $id => $b) {
                if (($b['phone'] ?? '') === $phone && ($b['status'] ?? '') === 'active') {
                    $found = $b; $foundId = $id; break;
                }
            }
        }
        if (!$found) jsonOut(['success' => false, 'message' => 'No bet to cancel']);
        unset($cur['bets'][$foundId]);
        firebase_write('aviator/current', $cur);
        $user = firebase_read("users/" . $phone);
        $bal = (float)($user['balance'] ?? 0) + (float)$found['amount'];
        firebase_write("users/$phone/balance", $bal);
        jsonOut(['success' => true, 'balance' => $bal]);
    }

    if ($action === 'cash_out') {
        $cur = ensureRound();
        $now = ms();
        if ($cur['flight_start'] === null) jsonOut(['success' => false, 'message' => 'No live round']);
        $elapsed = ($now - $cur['flight_start']) / 1000;
        $m = round(exp(GROWTH * $elapsed), 2);
        if ($m >= $cur['crash']) jsonOut(['success' => false, 'message' => 'Flew away!']);

        $bets = $cur['bets'] ?? [];
        $found = null; $foundId = null;
        if (is_array($bets)) {
            foreach ($bets as $id => $b) {
                if (($b['phone'] ?? '') === $phone && ($b['status'] ?? '') === 'active') {
                    $found = $b; $foundId = $id; break;
                }
            }
        }
        if (!$found) jsonOut(['success' => false, 'message' => 'No active bet']);

        $win = (float)$found['amount'] * $m;
        $cur['bets'][$foundId]['status'] = 'cashed';
        $cur['bets'][$foundId]['cx'] = $m;
        firebase_write('aviator/current', $cur);
        $user = firebase_read("users/" . $phone);
        $newBal = (float)($user['balance'] ?? 0) + $win;
        firebase_write("users/$phone/balance", $newBal);
        jsonOut(['success' => true, 'mult' => $m, 'win' => $win, 'balance' => $newBal]);
    }

    if ($action === 'get_history') {
        $h = firebase_read('aviator/history');
        jsonOut(['success' => true, 'history' => is_array($h) ? $h : []]);
    }

    if ($action === 'get_balance') {
        $u = firebase_read("users/" . $phone);
        jsonOut(['success' => true, 'balance' => (float)($u['balance'] ?? 0)]);
    }

    jsonOut(['success' => false, 'message' => 'Unknown action']);
}

/* ====== INITIAL PAGE LOAD ====== */
$user = firebase_read("users/" . $phone);
$balance = (float)($user['balance'] ?? 0);
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
<title>Aviator</title>
<style>
*{margin:0;padding:0;box-sizing:border-box;-webkit-tap-highlight-color:transparent;user-select:none}
body{font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,sans-serif;background:#0b0c10;color:#fff;max-width:480px;margin:0 auto;min-height:100vh;padding-bottom:42px}
button{font-family:inherit}
.top-bar{display:flex;justify-content:space-between;align-items:center;padding:10px 12px;background:#0e0f14}
.back-btn{font-size:26px;background:none;border:none;color:#fff;cursor:pointer}
.balance-container{display:flex;align-items:center;background:linear-gradient(135deg,#1e3c72,#2a5298);padding:5px 18px 5px 6px;border-radius:22px;gap:8px;border:1px solid #3a62c8}
.coin-icon{width:30px;height:30px;background:radial-gradient(circle at 35% 30%,#ffe08a,#f5a623 60%,#d98200);border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:16px;font-weight:bold;color:#7a4d00;border:2px solid #e8961e;position:relative}
.coin-icon::before{content:'★';position:absolute;top:-7px;left:-5px;font-size:10px;color:#fff;text-shadow:0 0 3px #000}
.balance-amount{font-size:17px;font-weight:600}
.top-icons{display:flex;gap:10px;align-items:center}
.add-btn{width:34px;height:34px;background:#0e0f14;border:2px solid #2a5298;border-radius:10px;color:#4a72c8;font-size:20px;font-weight:bold;cursor:pointer}
.support-icon{width:36px;height:36px;background:radial-gradient(circle at 35% 30%,#7ee4ff,#00a2e8 70%);border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:17px}
.game-header{display:flex;justify-content:space-between;align-items:center;padding:8px 12px;background:#17181d}
.aviator-logo{font-size:27px;font-weight:900;color:#e60f4c;font-style:italic;font-family:'Arial Black',Arial,sans-serif;letter-spacing:-1px;display:flex;align-items:center;gap:10px}
.help-icon{width:26px;height:26px;background:#3a3a40;border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:14px;color:#ccc;cursor:pointer;font-style:normal}
.header-right{display:flex;align-items:center;gap:12px}
.inr-balance{font-size:17px;color:#8a8d95}.inr-balance b{color:#37b42a}
.hamburger{width:46px;height:38px;background:#2a2b31;border-radius:8px;display:flex;flex-direction:column;justify-content:center;gap:5px;align-items:center;cursor:pointer}
.hamburger span{display:block;width:24px;height:3px;background:#9a9da5;border-radius:2px}
.multiplier-history{display:flex;gap:8px;padding:10px 12px;background:#0e0f14;align-items:center;overflow:hidden}
.multiplier-tag{background:#191a1f;padding:8px 14px;border-radius:18px;font-size:15px;font-weight:bold;color:#38b6ff;white-space:nowrap;flex-shrink:0}
.history-controls{margin-left:auto;background:#2a2b31;border-radius:20px;padding:8px 14px;display:flex;gap:12px;cursor:pointer;border:none;flex-shrink:0}
.history-controls svg{width:17px;height:17px;fill:#8a8d95}
.history-controls.active svg{fill:#e60f4c}
.round-info{display:flex;justify-content:space-between;align-items:center;padding:4px 14px 8px;background:#0e0f14;font-size:14px;color:#8a8d95}
.round-id{display:flex;align-items:center;gap:8px}
.round-dropdown{background:#2a2b31;border:none;color:#8a8d95;padding:3px 12px;border-radius:12px;font-size:11px}
.game-canvas-area{position:relative;height:300px;background:#0a0a10;border:1px solid #2a2b31;border-radius:16px;margin:4px 12px;overflow:hidden}
#gameCanvas{width:100%;height:100%;display:block}
.game-overlay{position:absolute;inset:0;display:flex;flex-direction:column;align-items:center;justify-content:center;pointer-events:none}
.flew-away-text{font-size:26px;font-weight:bold;color:#fff;display:none;margin-bottom:4px;letter-spacing:1px}
.multiplier-display{font-size:72px;font-weight:800;color:#fff;display:none;text-shadow:0 0 35px rgba(60,140,255,.8),0 0 70px rgba(60,140,255,.5)}
.multiplier-display.flew{color:#e60f4c;text-shadow:none}
.waiting-screen{position:absolute;inset:0;display:flex;flex-direction:column;align-items:center;justify-content:center}
.ufc-row{display:flex;align-items:center;justify-content:center;gap:14px}
.ufc-text{font-size:46px;font-weight:900;color:#e60f4c;font-style:italic;font-family:'Arial Black',Arial,sans-serif;letter-spacing:-2px}
.divider-line{width:2px;height:52px;background:#6a6d75}
.aviator-plane-icon{display:flex;flex-direction:column;align-items:center}
.logo-plane{width:66px;height:40px;object-fit:contain;filter:sepia(1) saturate(9) hue-rotate(-45deg) brightness(.9) contrast(1.3)}
.aviator-text{font-size:17px;color:#e60f4c;font-style:italic;font-weight:bold;font-family:'Arial Black',Arial,sans-serif}
.official-partners-text{font-size:15px;font-weight:800;letter-spacing:1px;margin-top:6px}
.loading-bar{width:220px;height:5px;background:#2a2b31;margin:12px auto 0;border-radius:3px;overflow:hidden}
.loading-fill{height:100%;width:0%;background:#e60f4c;border-radius:3px;transition:width 0.1s linear}
.spribe-box{background:linear-gradient(135deg,#233a1c,#2c4a22);border:1.5px solid #6db644;border-radius:12px;padding:10px 22px;text-align:center;margin-top:16px}
.spribe-name{font-size:19px;font-weight:800;display:flex;align-items:center;gap:10px;justify-content:center;letter-spacing:1px}
.spribe-dot{width:22px;height:22px;border-radius:50%;background-image:radial-gradient(#fff 1.1px,transparent 1.2px);background-size:4px 4px}
.official-game-badge{background:#12250d;border:1px solid #6db644;color:#8fd460;padding:3px 12px;border-radius:14px;font-size:12px;display:inline-flex;align-items:center;gap:6px;margin-top:6px}
.official-game-badge .chk{width:15px;height:15px;background:#37b42a;border-radius:50%;color:#fff;font-size:10px;display:flex;align-items:center;justify-content:center}
.since-text{font-size:12px;color:#cfd2d8;margin-top:6px}
.round-history{position:absolute;top:0;left:0;right:0;background:#1c1d24;border-radius:0 0 16px 16px;padding:14px;z-index:50;display:none;max-height:100%;overflow-y:auto;box-shadow:0 8px 20px rgba(0,0,0,.6)}
.round-history.open{display:block}
.rh-head{display:flex;justify-content:space-between;align-items:center;margin-bottom:12px}
.rh-title{font-size:18px;font-weight:600;letter-spacing:1px}
.rh-grid{display:grid;grid-template-columns:repeat(5,1fr);gap:8px}
.rh-grid .multiplier-tag{padding:9px 4px;text-align:center;font-size:14px}
.m-blue{color:#38b6ff}.m-purple{color:#b355f7}.m-pink{color:#ff2e97}
.side-tab{position:fixed;right:0;top:290px;width:26px;height:60px;background:#8a8d95;border-radius:10px 0 0 10px;display:flex;align-items:center;justify-content:center;z-index:40}
.side-tab div{width:14px;height:14px;background:#2a5298;border-radius:50%}
.betting-section{padding:8px 12px}
.bet-panel{background:#17181d;border-radius:14px;padding:14px;margin-bottom:12px}
.bet-auto-toggle{display:flex;background:#101115;border-radius:22px;padding:4px;margin:0 auto 14px;width:72%}
.toggle-btn{flex:1;padding:9px;border:none;background:transparent;color:#8a8d95;border-radius:18px;cursor:pointer;font-size:15px}
.toggle-btn.active{background:#2e2f35;color:#fff}
.auto-controls{display:none;flex-direction:column;gap:10px;margin-bottom:12px;background:#101115;border-radius:12px;padding:10px 12px}
.auto-controls.show{display:flex}
.ac-row{display:flex;justify-content:space-between;align-items:center;font-size:13px;color:#cfd2d8}
.ac-stepper{display:flex;align-items:center;gap:8px}
.ac-stepper button{width:24px;height:24px;border-radius:50%;border:1.5px solid #555;background:none;color:#fff;font-size:14px;cursor:pointer}
.ac-stepper .val{font-weight:bold;min-width:52px;text-align:center;color:#38b6ff}
.bet-row{display:flex;gap:12px;align-items:stretch}
.bet-left{flex:1}
.amount-controls{display:flex;align-items:center;background:#000;border-radius:26px;padding:5px;margin-bottom:8px}
.minus-btn,.plus-btn{width:36px;height:36px;border:2px solid #6a6d75;background:transparent;color:#fff;border-radius:50%;font-size:18px;cursor:pointer;display:flex;align-items:center;justify-content:center;flex-shrink:0}
.amount-display{flex:1;text-align:center;font-size:24px;font-weight:800}
.quick-amounts{display:grid;grid-template-columns:repeat(2,1fr);gap:8px}
.quick-amount{background:#202127;border:none;color:#8a8d95;padding:9px;border-radius:10px;cursor:pointer;font-size:15px;font-weight:600}
.quick-amount:active{background:#33343c}
.bet-btn{flex:1.15;background:linear-gradient(180deg,#3fc02c 0%,#2ba318 100%);border:2px solid #b9f5ae;color:#fff;border-radius:18px;cursor:pointer;display:flex;flex-direction:column;align-items:center;justify-content:center;padding:10px;min-height:108px;text-shadow:0 2px 3px rgba(0,0,0,.45);box-shadow:0 0 12px rgba(60,200,40,.35)}
.bet-btn:active{transform:scale(.97)}
.bet-btn .bet-label{font-size:19px;font-weight:600;letter-spacing:1px}
.bet-btn .bet-value{font-size:26px;font-weight:800}
.bet-btn.cashout{background:linear-gradient(180deg,#ff9800,#f57c00);border-color:#ffd59a;box-shadow:0 0 12px rgba(255,152,0,.4)}
.bet-btn.cancel{background:linear-gradient(180deg,#e60f4c,#b00c3a);border-color:#ffb1c6;box-shadow:0 0 12px rgba(230,15,76,.4)}
.bet-btn.disabled{background:#1d4a14;border-color:#3f7a33;color:#9a9da5;box-shadow:none;cursor:not-allowed;text-shadow:none}
.bottom-section{padding:10px 12px;background:#17181d;border-radius:14px 14px 0 0;margin-top:6px}
.tabs{display:flex;background:#101115;border-radius:22px;padding:4px;margin-bottom:12px}
.tab{flex:1;padding:10px;background:transparent;border:none;color:#8a8d95;border-radius:18px;cursor:pointer;font-size:15px}
.tab.active{background:#2e2f35;color:#fff}
.all-bets-header{font-size:18px;font-weight:600;letter-spacing:1px}
.bets-count{color:#cfd2d8;font-size:16px;margin-top:2px}
.bets-table{margin-top:10px;border-top:1px solid #2a2b31}
.bets-table-header{display:grid;grid-template-columns:1.4fr 1fr .5fr 1fr;padding:10px 4px;font-size:14px;color:#8a8d95}
.bets-table-body{max-height:260px;overflow-y:auto}
.bet-row-item{display:grid;grid-template-columns:1.4fr 1fr .5fr 1fr;padding:7px 4px;font-size:14px;background:#1c1d24;border-radius:10px;margin-bottom:6px;align-items:center}
.bet-user{display:flex;align-items:center;gap:10px;overflow:hidden}
.user-avatar{width:34px;height:34px;border-radius:50%;flex-shrink:0}
.bx{color:#38b6ff}.bc{color:#37b42a}
.provably-fair{position:fixed;bottom:0;left:50%;transform:translateX(-50%);width:100%;max-width:480px;background:#000;padding:9px 14px;display:flex;align-items:center;gap:8px;font-size:14px;color:#8a8d95;z-index:60;border-top:1px solid #1c1d24}
.provably-fair b{color:#fff;font-weight:600}
.pf-shield{width:18px;height:18px}
.notification{position:fixed;top:16px;left:50%;transform:translateX(-50%) translateY(-90px);background:#37b42a;color:#fff;padding:12px 22px;border-radius:12px;font-size:14px;font-weight:bold;z-index:1000;transition:transform .3s;text-align:center;max-width:90%}
.notification.show{transform:translateX(-50%) translateY(0)}
.notification.error{background:#e60f4c}
::-webkit-scrollbar{width:4px}::-webkit-scrollbar-thumb{background:#444;border-radius:2px}
</style>
</head>
<body>
<div class="notification" id="notification"></div>
<div class="side-tab"><div></div></div>

<div class="top-bar">
  <button class="back-btn" onclick="location.href='dashboard.php'">‹</button>
  <div class="balance-container">
    <div class="coin-icon">$</div>
    <div class="balance-amount" id="topBalance">₹<?=number_format($balance,2)?></div>
  </div>
  <div class="top-icons">
    <button class="add-btn" onclick="location.href='deposit.php'">+</button>
    <div class="support-icon">😅</div>
  </div>
</div>

<div class="game-header">
  <div class="aviator-logo">Aviator <div class="help-icon" onclick="notify('Bet before takeoff, cash out before fly away!')">?</div></div>
  <div class="header-right">
    <div class="inr-balance"><b id="headerBalance"><?=number_format($balance,0)?></b> INR</div>
    <div class="hamburger"><span></span><span></span><span></span></div>
  </div>
</div>

<div class="multiplier-history" id="multiplierHistory"></div>

<div class="round-info">
  <div class="round-id">Round ID: <span id="roundId">—</span>
    <select class="round-dropdown"><option>▼</option></select>
  </div>
  <div>Ping:<span id="pingDisplay">168</span>ms</div>
</div>

<div class="game-canvas-area">
  <canvas id="gameCanvas"></canvas>
  <div class="game-overlay">
    <div class="flew-away-text" id="flewAwayText">FLEW AWAY!</div>
    <div class="multiplier-display" id="multiplierDisplay">1.00x</div>
  </div>
  <div class="waiting-screen" id="waitingScreen">
    <div class="ufc-row">
      <div class="ufc-text">UFC</div>
      <div class="divider-line"></div>
      <div class="aviator-plane-icon">
        <img class="logo-plane" src="https://i.ibb.co/DTZPFD9/file-00000000cf88820b83d5febafba0300d.png" alt="">
        <div class="aviator-text">Aviator</div>
      </div>
    </div>
    <div class="official-partners-text">OFFICIAL PARTNERS</div>
    <div class="loading-bar"><div class="loading-fill" id="loadingFill"></div></div>
    <div class="spribe-box">
      <div class="spribe-name"><div class="spribe-dot"></div>SPRIBE</div>
      <div class="official-game-badge">Official Game <span class="chk">✓</span></div>
      <div class="since-text">Since 2018</div>
    </div>
  </div>
  <div class="round-history" id="roundHistory">
    <div class="rh-head">
      <div class="rh-title">ROUND HISTORY</div>
      <button class="history-controls active" onclick="toggleHistoryPopup()">
        <svg viewBox="0 0 24 24"><path d="M13 3a9 9 0 0 0-9 9H1l3.8 3.8L8.6 12H6a7 7 0 1 1 7 7v2a9 9 0 0 0 0-18z"/></svg>
        <svg viewBox="0 0 24 24"><path d="M12 21s-8-5.3-8-11a5 5 0 0 1 8-4 5 5 0 0 1 8 4c0 5.7-8 11-8 11z"/></svg>
      </button>
    </div>
    <div class="rh-grid" id="rhGrid"></div>
  </div>
</div>

<div class="betting-section">
  <div class="bet-panel">
    <div class="bet-auto-toggle">
      <button class="toggle-btn active" onclick="setMode(0,'bet',this)">Bet</button>
      <button class="toggle-btn" onclick="setMode(0,'auto',this)">Auto</button>
    </div>
    <div class="auto-controls" id="autoCtl0">
      <div class="ac-row"><span>Auto Cash Out</span>
        <div class="ac-stepper">
          <button onclick="adjAuto(0,-0.1)">−</button>
          <div class="val" id="autoVal0">2.00x</div>
          <button onclick="adjAuto(0,0.1)">+</button>
        </div>
      </div>
    </div>
    <div class="bet-row">
      <div class="bet-left">
        <div class="amount-controls">
          <button class="minus-btn" onclick="changeAmount(0,-10)">−</button>
          <div class="amount-display" id="amount0">10.00</div>
          <button class="plus-btn" onclick="changeAmount(0,10)">+</button>
        </div>
        <div class="quick-amounts">
          <button class="quick-amount" onclick="setAmount(0,10)">10</button>
          <button class="quick-amount" onclick="setAmount(0,100)">100</button>
          <button class="quick-amount" onclick="setAmount(0,500)">500</button>
          <button class="quick-amount" onclick="setAmount(0,1000)">1,000</button>
        </div>
      </div>
      <button class="bet-btn" id="betBtn0" onclick="handleBet(0)">
        <span class="bet-label" id="betLabel0">BET</span>
        <span class="bet-value" id="betValue0">10.00 INR</span>
      </button>
    </div>
  </div>

  <div class="bet-panel">
    <div class="bet-auto-toggle">
      <button class="toggle-btn active" onclick="setMode(1,'bet',this)">Bet</button>
      <button class="toggle-btn" onclick="setMode(1,'auto',this)">Auto</button>
    </div>
    <div class="auto-controls" id="autoCtl1">
      <div class="ac-row"><span>Auto Cash Out</span>
        <div class="ac-stepper">
          <button onclick="adjAuto(1,-0.1)">−</button>
          <div class="val" id="autoVal1">2.00x</div>
          <button onclick="adjAuto(1,0.1)">+</button>
        </div>
      </div>
    </div>
    <div class="bet-row">
      <div class="bet-left">
        <div class="amount-controls">
          <button class="minus-btn" onclick="changeAmount(1,-10)">−</button>
          <div class="amount-display" id="amount1">10.00</div>
          <button class="plus-btn" onclick="changeAmount(1,10)">+</button>
        </div>
        <div class="quick-amounts">
          <button class="quick-amount" onclick="setAmount(1,10)">10</button>
          <button class="quick-amount" onclick="setAmount(1,100)">100</button>
          <button class="quick-amount" onclick="setAmount(1,500)">500</button>
          <button class="quick-amount" onclick="setAmount(1,1000)">1,000</button>
        </div>
      </div>
      <button class="bet-btn" id="betBtn1" onclick="handleBet(1)">
        <span class="bet-label" id="betLabel1">BET</span>
        <span class="bet-value" id="betValue1">10.00 INR</span>
      </button>
    </div>
  </div>
</div>

<div class="bottom-section">
  <div class="tabs">
    <button class="tab active" onclick="switchTab('all',this)">All Bets</button>
    <button class="tab" onclick="switchTab('my',this)">My Bets</button>
    <button class="tab" onclick="switchTab('top',this)">Top</button>
  </div>
  <div class="all-bets-header">ALL BETS</div>
  <div class="bets-count" id="betsCount">0</div>
  <div class="bets-table">
    <div class="bets-table-header"><div>User</div><div>Bet INR</div><div>X</div><div style="text-align:right">Cash out INR</div></div>
    <div class="bets-table-body" id="betsTableBody"></div>
  </div>
</div>

<div class="provably-fair">
  This game is
  <svg class="pf-shield" viewBox="0 0 24 24" fill="none" stroke="#37b42a" stroke-width="2"><path d="M12 2l8 3v6c0 5-3.5 9.3-8 11-4.5-1.7-8-6-8-11V5l8-3z"/><path d="M9 12l2 2 4-4"/></svg>
  <b>Provably Fair</b>
</div>

<script>
const planeImg = new Image();
planeImg.src = 'https://i.ibb.co/DTZPFD9/file-00000000cf88820b83d5febafba0300d.png';
const RED_FILTER = 'sepia(1) saturate(9) hue-rotate(-45deg) brightness(.9) contrast(1.3)';
const GROWTH = 0.12;

const state = {
  balance: <?= $balance ?>,
  serverOffset: 0,
  phase: 'waiting',
  round: null,
  crashPoint: 0,
  flightStartTime: 0,
  multiplier: 1.00,
  history: [],
  bigHistory: [],
  bets: [
    {amount:10, placed:false, betId:null, cashedOut:false, cx:0, mode:'bet', autoActive:false, autoCash:2.00},
    {amount:10, placed:false, betId:null, cashedOut:false, cx:0, mode:'bet', autoActive:false, autoCash:2.00}
  ],
  allBetsCount: 0,
  realBets: [],
  fakeBets: [],
  myBets: [],
  topWins: [],
  currentTab: 'all',
  animFrame: null,
  crashFrame: null,
  lastRoundId: null,
  lastPhase: null,
  myBetId: null
};

let lastP = null, crashStart = 0, lastElapsed = 0;

const canvas = document.getElementById('gameCanvas');
const ctx = canvas.getContext('2d');
let W, H, SX, SY;

function resizeCanvas() {
  const r = canvas.parentElement.getBoundingClientRect();
  canvas.width = r.width * 2;
  canvas.height = r.height * 2;
  ctx.setTransform(2, 0, 0, 2, 0, 0);
  W = r.width; H = r.height; SX = 20; SY = H - 20;
  if (state.phase === 'waiting') drawRays();
}
resizeCanvas();
window.addEventListener('resize', resizeCanvas);

const fmt = n => n.toLocaleString('en-IN', {minimumFractionDigits: 2, maximumFractionDigits: 2});
function nowClient() { return Date.now(); }
function nowServer() { return Date.now() + state.serverOffset; }

function updateBalance() {
  document.getElementById('topBalance').textContent = '₹' + fmt(state.balance);
  document.getElementById('headerBalance').textContent = fmt(state.balance).replace('.00', '');
}

function notify(msg, type = '') {
  const el = document.getElementById('notification');
  el.textContent = msg;
  el.className = 'notification ' + type;
  setTimeout(() => el.classList.add('show'), 10);
  setTimeout(() => el.classList.remove('show'), 2500);
}

const mClass = m => m < 2 ? 'm-blue' : (m < 10 ? 'm-purple' : 'm-pink');

function curvePoint(s) {
  const m = Math.pow(Math.E, GROWTH * s);
  const maxX = W * 0.82;
  const x = Math.min(SX + (maxX - SX) * (1 - Math.exp(-s * 0.45)) + s * 7, maxX);
  let y = SY - (m - 1) * 92;
  y = Math.max(y, 54);
  y += Math.sin(s * 4.2) * 6 * Math.min(1, s / 1.5);
  y = Math.min(y, SY);
  return {x, y, m};
}

async function api(action, extra = {}) {
  const f = new FormData();
  f.append('action', action);
  Object.entries(extra).forEach(([k, v]) => f.append(k, v));
  try {
    const r = await fetch(location.href, {method: 'POST', body: f});
    return await r.json();
  } catch (e) {
    return {success: false, message: 'Network error'};
  }
}

async function loadHistory() {
  const d = await api('get_history');
  if (!d.success) return;
  state.bigHistory = d.history || [];
  state.history = state.bigHistory.slice(0, 6);
  renderHistory();
}

function renderHistory() {
  const c = document.getElementById('multiplierHistory');
  c.innerHTML = '';
  state.history.slice(0, 5).forEach(m => {
    const t = document.createElement('div');
    t.className = 'multiplier-tag ' + mClass(m);
    t.textContent = (+m).toFixed(2) + 'x';
    c.appendChild(t);
  });
  const btn = document.createElement('button');
  btn.className = 'history-controls' + (document.getElementById('roundHistory').classList.contains('open') ? ' active' : '');
  btn.onclick = toggleHistoryPopup;
  btn.innerHTML = '<svg viewBox="0 0 24 24"><path d="M13 3a9 9 0 0 0-9 9H1l3.8 3.8L8.6 12H6a7 7 0 1 1 7 7v2a9 9 0 0 0 0-18z"/></svg><svg viewBox="0 0 24 24"><path d="M12 21s-8-5.3-8-11a5 5 0 0 1 8-4 5 5 0 0 1 8 4c0 5.7-8 11-8 11z"/></svg>';
  c.appendChild(btn);
  const g = document.getElementById('rhGrid');
  g.innerHTML = '';
  state.bigHistory.forEach(m => {
    const t = document.createElement('div');
    t.className = 'multiplier-tag ' + mClass(m);
    t.textContent = (+m).toFixed(2) + 'x';
    g.appendChild(t);
  });
}

function toggleHistoryPopup() {
  document.getElementById('roundHistory').classList.toggle('open');
  renderHistory();
}

function changeAmount(p, d) {
  if (state.bets[p].placed) return;
  state.bets[p].amount = Math.max(10, state.bets[p].amount + d);
  updAmt(p);
}
function setAmount(p, a) {
  if (state.bets[p].placed) return;
  state.bets[p].amount = a;
  updAmt(p);
}
function updAmt(p) {
  document.getElementById('amount' + p).textContent = fmt(state.bets[p].amount);
  if (!state.bets[p].placed) document.getElementById('betValue' + p).textContent = fmt(state.bets[p].amount) + ' INR';
}
function setMode(p, mode, el) {
  el.parentElement.querySelectorAll('.toggle-btn').forEach(b => b.classList.remove('active'));
  el.classList.add('active');
  state.bets[p].mode = mode;
  document.getElementById('autoCtl' + p).classList.toggle('show', mode === 'auto');
  updateBetButton(p);
}
function adjAuto(p, d) {
  state.bets[p].autoCash = Math.max(1.1, Math.round((state.bets[p].autoCash + d) * 100) / 100);
  document.getElementById('autoVal' + p).textContent = state.bets[p].autoCash.toFixed(2) + 'x';
}

function setBtn(p, cls, label, value) {
  document.getElementById('betBtn' + p).className = 'bet-btn' + (cls ? ' ' + cls : '');
  document.getElementById('betLabel' + p).textContent = label;
  document.getElementById('betValue' + p).textContent = value;
}

function updateBetButton(p) {
  const bet = state.bets[p];
  if (bet.cashedOut) {
    setBtn(p, 'disabled', 'CASHED OUT', bet.cx.toFixed(2) + 'x');
  } else if (state.phase === 'waiting' && bet.placed) {
    setBtn(p, 'cancel', 'CANCEL', fmt(bet.amount) + ' INR');
  } else if (state.phase === 'flying' && bet.placed && !bet.cashedOut) {
    setBtn(p, 'cashout', 'CASH OUT', fmt(bet.amount * state.multiplier) + ' INR');
  } else if (state.phase === 'flying' || state.phase === 'crashed') {
    setBtn(p, 'disabled', (bet.mode === 'auto' && bet.autoActive) ? 'AUTO' : 'BET', fmt(bet.amount) + ' INR');
  } else if (bet.mode === 'auto' && bet.autoActive) {
    setBtn(p, 'cancel', 'STOP AUTO', fmt(bet.amount) + ' INR');
  } else {
    setBtn(p, '', (bet.mode === 'auto') ? 'AUTO' : 'BET', fmt(bet.amount) + ' INR');
  }
}

async function handleBet(p) {
  const bet = state.bets[p];
  if (bet.mode === 'auto' && state.phase === 'waiting' && !bet.placed) {
    bet.autoActive = !bet.autoActive;
    updateBetButton(p);
    if (bet.autoActive) { await placeBet(p); }
    return;
  }
  if (bet.mode === 'auto' && bet.autoActive && !bet.placed) {
    bet.autoActive = false;
    updateBetButton(p);
    return;
  }
  if (state.phase === 'waiting') {
    if (!bet.placed) { await placeBet(p); }
    else { await cancelBet(p); }
    return;
  }
  if (state.phase === 'flying' && bet.placed && !bet.cashedOut) {
    await cashOut(p);
  }
}

async function placeBet(p) {
  const bet = state.bets[p];
  if (bet.amount > state.balance) { notify('Insufficient balance!', 'error'); return; }
  if (bet.amount < 10) { notify('Minimum bet ₹10!', 'error'); return; }
  const d = await api('place_bet', {amount: bet.amount});
  if (d.success) {
    bet.placed = true;
    bet.betId = d.bet_id;
    bet.cashedOut = false;
    bet.cx = 0;
    state.balance = d.balance;
    updateBalance();
    updateBetButton(p);
    notify('Bet placed: ' + fmt(bet.amount) + ' INR');
  } else {
    notify(d.message || 'Failed', 'error');
  }
}

async function cancelBet(p) {
  const bet = state.bets[p];
  if (!bet.betId) { bet.placed = false; updateBetButton(p); return; }
  const d = await api('cancel_bet', {bet_id: bet.betId});
  if (d.success) {
    state.balance = d.balance;
    bet.placed = false;
    bet.betId = null;
    updateBalance();
    updateBetButton(p);
    notify('Bet cancelled');
  } else {
    notify(d.message || 'Failed', 'error');
  }
}

async function cashOut(p) {
  const bet = state.bets[p];
  if (!bet.betId) return;
  const d = await api('cash_out', {bet_id: bet.betId});
  if (d.success) {
    bet.cashedOut = true;
    bet.cx = d.mult;
    state.balance = d.balance;
    state.myBets.unshift({amount: bet.amount, x: d.mult, cash: d.win, win: true, round: state.round ? state.round.id : 0});
    state.topWins.push({name: 'You', amount: bet.amount, x: d.mult, cash: d.win});
    updateBalance();
    updateBetButton(p);
    notify('🎉 Cashed out ' + d.mult.toFixed(2) + 'x! +' + fmt(d.win) + ' INR');
    renderTable();
  } else {
    notify(d.message || 'Failed', 'error');
    if (d.message && d.message.includes('Flew')) {
      bet.placed = false;
      bet.betId = null;
      state.myBets.unshift({amount: bet.amount, x: 0, cash: 0, win: false, round: state.round ? state.round.id : 0});
      updateBetButton(p);
      renderTable();
    }
  }
}

function renderTable() {
  const body = document.getElementById('betsTableBody');
  const bots = (state.fakeBets || []).map(b => ({
    name: b.name, g: b.g, amount: b.amount,
    cx: b.cashed ? b.cx : 0, cashed: b.cashed, is_me: false
  }));
  const reals = (state.realBets || []).map(b => ({
    name: b.is_me ? 'You' : b.name,
    g: b.is_me ? ['#37b42a', '#00d2ff'] : b.g,
    amount: b.amount, cx: b.cashed ? b.cx : 0, cashed: b.cashed, is_me: b.is_me
  }));
  let list = [...reals, ...bots];
  list.sort((a, b) => b.amount - a.amount);
  state.allBetsCount = list.length + 600;
  document.getElementById('betsCount').textContent = state.allBetsCount;

  if (state.currentTab === 'all') {
    body.innerHTML = list.map(b => `
      <div class="bet-row-item">
        <div class="bet-user"><div class="user-avatar" style="background:linear-gradient(135deg,${b.g[0]},${b.g[1]})"></div>${b.name}</div>
        <div>${b.amount.toFixed(2)}</div>
        <div class="bx">${b.cashed ? b.cx.toFixed(2) : ''}</div>
        <div class="bc" style="text-align:right">${b.cashed ? (b.amount * b.cx).toFixed(2) : ''}</div>
      </div>`).join('');
  } else if (state.currentTab === 'my') {
    body.innerHTML = state.myBets.length ? state.myBets.map(b => `
      <div class="bet-row-item">
        <div class="bet-user"><div class="user-avatar" style="background:linear-gradient(135deg,#37b42a,#00d2ff)"></div>#${b.round}</div>
        <div>${b.amount.toFixed(2)}</div>
        <div class="bx">${b.win ? b.x.toFixed(2) : '—'}</div>
        <div style="text-align:right;color:${b.win ? '#37b42a' : '#e60f4c'}">${b.win ? b.cash.toFixed(2) : '0.00'}</div>
      </div>`).join('') : '<div style="padding:20px;text-align:center;color:#8a8d95">No bets yet</div>';
  } else {
    const top = [...state.topWins].sort((a, b) => b.cash - a.cash).slice(0, 15);
    body.innerHTML = top.length ? top.map(b => `
      <div class="bet-row-item">
        <div class="bet-user"><div class="user-avatar" style="background:linear-gradient(135deg,#f6d365,#fda085)"></div>${b.name}</div>
        <div>${b.amount.toFixed(2)}</div>
        <div class="bx">${b.x.toFixed(2)}</div>
        <div class="bc" style="text-align:right">${b.cash.toFixed(2)}</div>
      </div>`).join('') : '<div style="padding:20px;text-align:center;color:#8a8d95">No wins yet</div>';
  }
}

function switchTab(t, el) {
  state.currentTab = t;
  document.querySelectorAll('.tab').forEach(x => x.classList.remove('active'));
  el.classList.add('active');
  renderTable();
}

function startWaitingPhase() {
  if (state.animFrame) cancelAnimationFrame(state.animFrame);
  if (state.crashFrame) cancelAnimationFrame(state.crashFrame);
  state.animFrame = null;
  state.crashFrame = null;
  state.phase = 'waiting';
  state.multiplier = 1.00;
  state.bets.forEach((b, i) => {
    b.placed = false;
    b.betId = null;
    b.cashedOut = false;
    b.cx = 0;
  });
  document.getElementById('waitingScreen').style.display = 'flex';
  document.getElementById('multiplierDisplay').style.display = 'none';
  document.getElementById('flewAwayText').style.display = 'none';
  document.getElementById('multiplierDisplay').classList.remove('flew');
  updateBetButton(0); updateBetButton(1);
  drawRays();
  let prog = 0;
  const li = setInterval(() => {
    prog += 2;
    document.getElementById('loadingFill').style.width = prog + '%';
    if (prog >= 100 || state.phase !== 'waiting') {
      clearInterval(li);
    }
  }, 80);
}

function startFlyingPhase(crashPoint, flightStartTimeServer) {
  state.phase = 'flying';
  state.crashPoint = crashPoint;
  state.flightStartTime = flightStartTimeServer - state.serverOffset;
  state.multiplier = 1.00;
  document.getElementById('waitingScreen').style.display = 'none';
  document.getElementById('multiplierDisplay').style.display = 'block';
  updateBetButton(0); updateBetButton(1);
  loop();
}

function loop() {
  if (state.phase !== 'flying') return;
  const elapsed = (nowClient() - state.flightStartTime) / 1000;
  lastElapsed = elapsed;
  state.multiplier = parseFloat(Math.pow(Math.E, GROWTH * elapsed).toFixed(2));
  if (state.multiplier >= state.crashPoint) {
    state.multiplier = state.crashPoint;
    triggerCrash(elapsed);
    return;
  }
  document.getElementById('multiplierDisplay').textContent = state.multiplier.toFixed(2) + 'x';
  state.bets.forEach((b, i) => {
    if (b.placed && !b.cashedOut) {
      if (b.mode === 'auto' && b.autoActive && state.multiplier >= b.autoCash) {
        cashOut(i);
      } else {
        document.getElementById('betValue' + i).textContent = fmt(b.amount * state.multiplier) + ' INR';
      }
    }
  });
  let changed = false;
  (state.fakeBets || []).forEach(b => {
    if (!b.cashed && b.target < state.crashPoint && state.multiplier >= b.target) {
      b.cashed = true;
      b.cx = b.target;
      changed = true;
    }
  });
  if (changed && state.currentTab === 'all') renderTable();
  draw(elapsed);
  state.animFrame = requestAnimationFrame(loop);
}

function triggerCrash(elapsed) {
  state.phase = 'crashed';
  if (state.animFrame) cancelAnimationFrame(state.animFrame);
  lastP = curvePoint(elapsed);
  lastElapsed = elapsed;
  crashStart = nowClient();
  document.getElementById('multiplierDisplay').textContent = state.crashPoint.toFixed(2) + 'x';
  document.getElementById('multiplierDisplay').classList.add('flew');
  document.getElementById('flewAwayText').style.display = 'block';
  state.bets.forEach((b, i) => {
    if (b.placed && !b.cashedOut) {
      state.myBets.unshift({amount: b.amount, x: 0, cash: 0, win: false, round: state.round ? state.round.id : 0});
      b.placed = false;
      b.betId = null;
      notify('Bet lost: ' + fmt(b.amount) + ' INR', 'error');
    }
    updateBetButton(i);
  });
  (state.fakeBets || []).forEach(b => {
    if (b.cashed) {
      state.topWins.push({name: b.name, amount: b.amount, x: b.cx, cash: b.amount * b.cx});
    }
  });
  renderTable();
  flyAwayAnim();
}

function flyAwayAnim() {
  if (state.phase !== 'crashed') { drawRays(); return; }
  const t = (nowClient() - crashStart) / 900;
  if (t >= 1) { drawRays(); state.crashFrame = null; return; }
  drawCrashFrame(t);
  state.crashFrame = requestAnimationFrame(flyAwayAnim);
}

function resetCtx() {
  ctx.setTransform(2, 0, 0, 2, 0, 0);
  ctx.globalAlpha = 1;
  try { ctx.filter = 'none'; } catch (e) {}
  ctx.clearRect(0, 0, W, H);
}

function drawRays() {
  resetCtx();
  ctx.fillStyle = '#0a0a10';
  ctx.fillRect(0, 0, W, H);
  ctx.save();
  ctx.translate(8, H - 4);
  for (let i = 0; i < 26; i++) {
    const a = (-i * 3.6) * Math.PI / 180;
    ctx.fillStyle = 'rgba(255,255,255,0.035)';
    ctx.beginPath();
    ctx.moveTo(0, 0);
    ctx.arc(0, 0, W * 1.7, a - 0.026, a + 0.026);
    ctx.closePath();
    ctx.fill();
  }
  ctx.restore();
}

function buildPts(el) {
  const pts = [];
  for (let s = 0; s <= el; s += 0.04) pts.push(curvePoint(s));
  return pts;
}

function drawCurve(pts, alpha) {
  if (pts.length < 2) return null;
  const last = pts[pts.length - 1];
  ctx.save();
  ctx.globalAlpha = alpha;
  ctx.beginPath();
  ctx.moveTo(SX, SY);
  pts.forEach(p => ctx.lineTo(p.x, p.y));
  ctx.lineTo(last.x, SY);
  ctx.closePath();
  const fg = ctx.createLinearGradient(0, 54, 0, SY);
  fg.addColorStop(0, 'rgba(230,15,76,.45)');
  fg.addColorStop(1, 'rgba(230,15,76,.08)');
  ctx.fillStyle = fg;
  ctx.fill();
  ctx.beginPath();
  ctx.moveTo(SX, SY);
  pts.forEach(p => ctx.lineTo(p.x, p.y));
  ctx.strokeStyle = '#e60f4c';
  ctx.lineWidth = 3;
  ctx.stroke();
  ctx.restore();
  return last;
}

function drawPlane(x, y, rot, alpha) {
  ctx.save();
  ctx.translate(x, y);
  ctx.rotate(rot);
  ctx.globalAlpha = alpha;
  if (planeImg.complete && planeImg.naturalWidth > 0) {
    try { ctx.filter = RED_FILTER; } catch (e) {}
    ctx.drawImage(planeImg, -36, -22, 80, 46);
    try { ctx.filter = 'none'; } catch (e) {}
  } else {
    ctx.fillStyle = '#e60f4c';
    ctx.beginPath();
    ctx.moveTo(-24, 6); ctx.lineTo(18, -9); ctx.lineTo(24, -3);
    ctx.lineTo(12, 3); ctx.lineTo(24, 9); ctx.lineTo(18, 14);
    ctx.closePath();
    ctx.fill();
  }
  ctx.restore();
  ctx.globalAlpha = 1;
  try { ctx.filter = 'none'; } catch (e) {}
}

function draw(el) {
  drawRays();
  const pts = buildPts(el);
  const last = drawCurve(pts, 1);
  if (last) {
    const wig = Math.sin(el * 6) * 0.05;
    drawPlane(last.x + 8, last.y - 6, -0.28 + wig, 1);
  }
}

function drawCrashFrame(t) {
  drawRays();
  const pts = buildPts(lastElapsed);
  drawCurve(pts, 1 - t);
  const x = lastP.x + 8 + t * 260;
  const y = lastP.y - 6 - t * 320;
  drawPlane(x, y, -0.28 - t * 0.35, 1 - t);
}

async function pollServer() {
  const d = await api('get_state');
  if (!d.success) return;
  state.serverOffset = d.server_ts - Date.now();
  state.round = d.round;
  state.fakeBets = d.bots || [];
  state.realBets = d.real_bets || [];
  document.getElementById('roundId').textContent = d.round.id || '—';
  if (d.my_bet) {
    state.myBetId = d.my_bet.id || d.my_bet.phone + '_active';
    state.bets.forEach((b, i) => {
      if (b.betId && !b.cashedOut) {
        if (d.my_bet.status === 'cashed' && b.placed) {
          b.cashedOut = true;
          b.cx = d.my_bet.cx;
          state.balance += (d.my_bet.amount * d.my_bet.cx);
          state.myBets.unshift({amount: b.amount, x: b.cx, cash: b.amount * b.cx, win: true, round: d.round.id});
          state.topWins.push({name: 'You', amount: b.amount, x: b.cx, cash: b.amount * b.cx});
          updateBalance();
          updateBetButton(i);
          renderTable();
        }
      }
    });
  }
  if (d.phase !== state.lastPhase) {
    if (d.phase === 'waiting') {
      startWaitingPhase();
      renderTable();
      loadHistory();
    } else if (d.phase === 'flying') {
      startFlyingPhase(d.round.crash, d.round.flight_start);
      renderTable();
    } else if (d.phase === 'crashed') {
      if (state.lastPhase !== 'crashed') {
        state.crashPoint = d.round.crash;
        state.phase = 'crashed';
        document.getElementById('waitingScreen').style.display = 'none';
        document.getElementById('multiplierDisplay').style.display = 'block';
        document.getElementById('multiplierDisplay').textContent = d.round.crash.toFixed(2) + 'x';
        document.getElementById('multiplierDisplay').classList.add('flew');
        document.getElementById('flewAwayText').style.display = 'block';
        drawRays();
        state.bets.forEach((b, i) => {
          if (b.placed && !b.cashedOut) {
            state.myBets.unshift({amount: b.amount, x: 0, cash: 0, win: false, round: d.round.id});
            b.placed = false;
            b.betId = null;
            updateBetButton(i);
          }
        });
        renderTable();
      }
    }
    state.lastPhase = d.phase;
  }
  updateBetButton(0);
  updateBetButton(1);
  if (state.currentTab === 'all') renderTable();
}

updateBalance();
loadHistory();
renderTable();
startWaitingPhase();
setInterval(pollServer, 1000);
pollServer();
setInterval(async () => {
  const d = await api('get_balance');
  if (d.success) {
    state.balance = d.balance;
    updateBalance();
  }
}, 8000);
setInterval(() => {
  document.getElementById('pingDisplay').textContent = Math.floor(100 + Math.random() * 280);
}, 3000);
document.addEventListener('pointerdown', () => {}, {once: true});
</script>
</body>
</html>