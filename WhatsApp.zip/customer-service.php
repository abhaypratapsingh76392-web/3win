<?php
require_once 'config.php';

if (!isset($_SESSION['phone'])) {
    header('Location: login.php');
    exit;
}

$phone = $_SESSION['phone'];
$lang = $_SESSION['cs_lang'] ?? 'en';

$texts = [
    'en' => [
        'self_service_center' => 'Self Service Center',
        'self_service' => 'Self Service',
        'deposit_not_received' => 'Deposit Not Received',
        'withdrawal_problem' => 'Withdrawal problem',
        'ifsc_modification' => 'IFSC Modification',
        'change_bank_name' => 'Change bank name',
        'change_password' => 'Change ID Login Password',
        'online_chat' => 'Online Customer Service',
        'progress_query' => 'Progress Query',
        'kind_tips' => 'Kind tips',
        'tips_desc' => '1.Please select the relevant query and submit it for review. After successful submission, the customer service specialist will handle it for you immediately.',
    ],
    'hi' => [
        'self_service_center' => 'सेल्फ सर्विस सेंटर',
        'self_service' => 'सेल्फ सर्विस',
        'deposit_not_received' => 'जमा नहीं मिला',
        'withdrawal_problem' => 'निकासी समस्या',
        'ifsc_modification' => 'IFSC संशोधन',
        'change_bank_name' => 'बैंक नाम बदलें',
        'change_password' => 'लॉगिन पासवर्ड बदलें',
        'online_chat' => 'ऑनलाइन ग्राहक सेवा',
        'progress_query' => 'प्रगति क्वेरी',
        'kind_tips' => 'सुझाव',
        'tips_desc' => '1.कृपया संबंधित प्रश्न चुनें और सबमिट करें। सफल सबमिशन के बाद, विशेषज्ञ इसे तुरंत संभालेंगे।',
    ]
];
$T = $texts[$lang];

// ================= PHP BACKEND LOGIC (NO CHANGES) =================
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    header('Content-Type: application/json');
    $action = $_POST['action'];

    if ($action === 'set_lang') {
        $_SESSION['cs_lang'] = $_POST['lang'] ?? 'en';
        echo json_encode(['success' => true]);
        exit;
    }

    if ($action === 'get_deposits') {
        $deps = firebase_read("deposits/" . $phone) ?? [];
        if (!is_array($deps)) $deps = [];
        $list = array_values($deps);
        usort($list, fn($a,$b) => strcmp($b['time']??'',$a['time']??''));
        echo json_encode(['success' => true, 'deposits' => $list]);
        exit;
    }

    if ($action === 'submit_deposit_not_received') {
        $utr = trim($_POST['utr'] ?? '');
        $receiver_upi = trim($_POST['receiver_upi'] ?? '');
        $order_number = trim($_POST['order_number'] ?? '');
        $order_amount = trim($_POST['order_amount'] ?? '');
        $pdf_password = trim($_POST['pdf_password'] ?? '');
        $photo_b64 = $_POST['photo_b64'] ?? '';

        if (!$utr || !$receiver_upi || !$order_number || !$order_amount) {
            echo json_encode(['success' => false, 'message' => 'Please fill all required fields!']);
            exit;
        }

        $reqId = 'REQ' . date('YmdHis') . rand(100,999);
        $data = [
            'request_id' => $reqId,
            'type' => 'Deposit Not Received',
            'phone' => $phone,
            'utr' => $utr,
            'receiver_upi' => $receiver_upi,
            'order_number' => $order_number,
            'order_amount' => $order_amount,
            'pdf_password' => $pdf_password,
            'photo' => $photo_b64,
            'status' => 'Pending',
            'time' => date('Y-m-d H:i:s')
        ];

        $all = firebase_read("support_requests") ?? [];
        if (!is_array($all)) $all = [];
        $all[$reqId] = $data;
        firebase_write("support_requests", $all);

        $userReqs = firebase_read("user_requests/" . $phone) ?? [];
        if (!is_array($userReqs)) $userReqs = [];
        $userReqs[$reqId] = $data;
        firebase_write("user_requests/" . $phone, $userReqs);

        echo json_encode(['success' => true, 'message' => 'Submitted successfully!']);
        exit;
    }

    if ($action === 'submit_withdrawal_problem') {
        $order_id = trim($_POST['order_id'] ?? '');
        $amount = trim($_POST['amount'] ?? '');
        $note = trim($_POST['note'] ?? '');
        if (!$order_id || !$amount) {
            echo json_encode(['success' => false, 'message' => 'Please fill required fields!']);
            exit;
        }
        $reqId = 'REQ' . date('YmdHis') . rand(100,999);
        $data = [
            'request_id' => $reqId, 'type' => 'Withdrawal Problem',
            'phone' => $phone, 'order_id' => $order_id,
            'amount' => $amount, 'note' => $note,
            'status' => 'Pending', 'time' => date('Y-m-d H:i:s')
        ];
        $all = firebase_read("support_requests") ?? [];
        if (!is_array($all)) $all = [];
        $all[$reqId] = $data;
        firebase_write("support_requests", $all);
        $ur = firebase_read("user_requests/".$phone) ?? [];
        if (!is_array($ur)) $ur = [];
        $ur[$reqId] = $data;
        firebase_write("user_requests/".$phone, $ur);
        echo json_encode(['success' => true, 'message' => 'Submitted!']);
        exit;
    }

    if ($action === 'submit_ifsc') {
        $bank_number = trim($_POST['bank_number'] ?? '');
        $ifsc = strtoupper(trim($_POST['ifsc'] ?? ''));
        if (!$bank_number || !$ifsc) {
            echo json_encode(['success' => false, 'message' => 'Please fill all fields!']);
            exit;
        }
        $reqId = 'REQ' . date('YmdHis') . rand(100,999);
        $data = [
            'request_id' => $reqId, 'type' => 'IFSC Modification',
            'phone' => $phone, 'bank_number' => $bank_number,
            'ifsc' => $ifsc, 'status' => 'Pending', 'time' => date('Y-m-d H:i:s')
        ];
        $all = firebase_read("support_requests") ?? [];
        if (!is_array($all)) $all = [];
        $all[$reqId] = $data;
        firebase_write("support_requests", $all);
        $ur = firebase_read("user_requests/".$phone) ?? [];
        if (!is_array($ur)) $ur = [];
        $ur[$reqId] = $data;
        firebase_write("user_requests/".$phone, $ur);
        echo json_encode(['success' => true, 'message' => 'Submitted!']);
        exit;
    }

    if ($action === 'submit_bank_name') {
        $bank_name = trim($_POST['bank_name'] ?? '');
        $card_number = trim($_POST['card_number'] ?? '');
        if (!$bank_name || !$card_number) {
            echo json_encode(['success' => false, 'message' => 'Please fill all fields!']);
            exit;
        }
        $reqId = 'REQ' . date('YmdHis') . rand(100,999);
        $data = [
            'request_id' => $reqId, 'type' => 'Change Bank Name',
            'phone' => $phone, 'bank_name' => $bank_name,
            'card_number' => $card_number, 'status' => 'Pending', 'time' => date('Y-m-d H:i:s')
        ];
        $all = firebase_read("support_requests") ?? [];
        if (!is_array($all)) $all = [];
        $all[$reqId] = $data;
        firebase_write("support_requests", $all);
        $ur = firebase_read("user_requests/".$phone) ?? [];
        if (!is_array($ur)) $ur = [];
        $ur[$reqId] = $data;
        firebase_write("user_requests/".$phone, $ur);
        echo json_encode(['success' => true, 'message' => 'Submitted!']);
        exit;
    }

    if ($action === 'submit_password') {
        $new_pass = trim($_POST['new_password'] ?? '');
        $selfie = $_POST['selfie_b64'] ?? '';
        $receipt = $_POST['receipt_b64'] ?? '';
        $passbook = $_POST['passbook_b64'] ?? '';
        if (!$new_pass || strlen($new_pass) < 6) {
            echo json_encode(['success' => false, 'message' => 'Password min 6 chars!']);
            exit;
        }
        $reqId = 'REQ' . date('YmdHis') . rand(100,999);
        $data = [
            'request_id' => $reqId, 'type' => 'Change Password',
            'phone' => $phone, 'new_password' => $new_pass,
            'selfie' => $selfie, 'receipt' => $receipt, 'passbook' => $passbook,
            'status' => 'Pending', 'time' => date('Y-m-d H:i:s')
        ];
        $all = firebase_read("support_requests") ?? [];
        if (!is_array($all)) $all = [];
        $all[$reqId] = $data;
        firebase_write("support_requests", $all);
        $ur = firebase_read("user_requests/".$phone) ?? [];
        if (!is_array($ur)) $ur = [];
        $ur[$reqId] = $data;
        firebase_write("user_requests/".$phone, $ur);
        echo json_encode(['success' => true, 'message' => 'Submitted!']);
        exit;
    }

    if ($action === 'get_progress') {
        $ur = firebase_read("user_requests/".$phone) ?? [];
        if (!is_array($ur)) $ur = [];
        $list = array_values($ur);
        usort($list, fn($a,$b) => strcmp($b['time']??'',$a['time']??''));
        echo json_encode(['success' => true, 'list' => $list]);
        exit;
    }
}
?>
<!DOCTYPE html>
<html lang="<?php echo $lang;?>">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1.0,maximum-scale=1.0,user-scalable=no">
<title><?php echo $T['self_service_center'];?></title>
<style>
* { margin: 0; padding: 0; box-sizing: border-box; -webkit-tap-highlight-color: transparent; }
body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif; background: #f4f5f8; max-width: 480px; margin: 0 auto; min-height: 100vh; overflow-x: hidden; }

/* HEADER - EXACT UI MATCH */
.hdr { background: #fff; display: flex; align-items: center; justify-content: space-between; padding: 14px 16px; position: sticky; top: 0; z-index: 100; box-shadow: 0 2px 4px rgba(0,0,0,0.05); }
.hdr-home-btn { display: flex; align-items: center; justify-content: center; text-decoration: none; background: none; border: none; cursor: pointer; padding: 5px; }
.hdr-home-btn svg { width: 22px; height: 22px; stroke: #555; fill: none; stroke-width: 2; stroke-linecap: round; stroke-linejoin: round; }
.hdr-title { font-size: 16px; font-weight: 600; color: #111; }
.lang-btn { display: flex; align-items: center; gap: 6px; background: none; border: none; cursor: pointer; font-size: 13px; font-weight: 700; color: #333; }
.flag-wrap { width: 22px; height: 16px; border-radius: 2px; overflow: hidden; border: 1px solid #ddd; flex-shrink: 0; }
.flag-en-bg { width: 100%; height: 100%; background: linear-gradient(to bottom, #012169 0%, #012169 33%, #fff 33%, #fff 66%, #c8102e 66%, #c8102e 100%); }
.flag-in-wrap { width: 100%; height: 100%; display: flex; flex-direction: column; }
.fi-top { height: 33%; background: #FF9933; } .fi-mid { height: 34%; background: #fff; display: flex; align-items: center; justify-content: center; } .fi-wheel { width: 4px; height: 4px; border: 1px solid #000080; border-radius: 50%; } .fi-bot { height: 33%; background: #138808; }

/* BANNER - EXACT UI MATCH */
.banner { width: 100%; height: 160px; background: linear-gradient(100deg, #e4f0ff 0%, #d4ebff 50%, #eef6ff 100%); position: relative; overflow: hidden; display: flex; }
.banner-left { flex: 1.2; padding: 20px 0 0 20px; z-index: 2; }
.banner-heading { font-size: 17px; font-weight: 800; color: #2a5298; line-height: 1.4; text-shadow: 1px 1px 0px rgba(255,255,255,0.8); }
.banner-url-row { margin-top: 10px; }
.banner-url-box { display: inline-flex; align-items: center; gap: 6px; border: 1.5px solid #2a5298; border-radius: 20px; padding: 3px 12px; background: rgba(255,255,255,0.4); }
.banner-url-text { font-size: 11px; color: #2a5298; font-weight: 700; }
.globe-icon { width: 12px; height: 12px; border: 1px solid #2a5298; border-radius: 50%; position: relative; }
.globe-icon::before { content:''; position:absolute; top:50%; left:0; right:0; height:1px; background:#2a5298; }
.globe-icon::after { content:''; position:absolute; top:0; bottom:0; left:50%; width:1px; background:#2a5298; }
.search-icon { width: 10px; height: 10px; border: 1.5px solid #2a5298; border-radius: 50%; position: relative; }
.search-icon::after { content:''; position:absolute; bottom:-3px; right:-3px; width:4px; height:1.5px; background:#2a5298; transform:rotate(45deg); }

.banner-right { flex: 0.8; position: relative; }
.banner-img { position: absolute; bottom: 0; right: 0; height: 100%; object-fit: contain; z-index: 2; }

/* Background Decorations */
.bg-circle-1 { position: absolute; top: 20px; right: 140px; width: 80px; height: 80px; border: 2px solid rgba(42, 82, 152, 0.1); border-radius: 50%; }
.bg-circle-2 { position: absolute; bottom: -20px; left: 150px; width: 120px; height: 120px; border: 2px solid rgba(42, 82, 152, 0.05); border-radius: 50%; }
.bg-plus { position: absolute; bottom: 20px; right: 180px; color: #ffeb3b; font-size: 20px; font-weight: bold; opacity: 0.8; }
.bg-bubble { position: absolute; top: 30px; right: 20px; width: 20px; height: 20px; background: linear-gradient(135deg, #4481eb, #04befe); border-radius: 50%; opacity: 0.8; }

/* Self Service Label */
.ss-label { font-size: 15px; font-weight: 600; color: #333; padding: 16px 16px 10px; background: #fff; }

/* SERVICE LIST - EXACT UI MATCH */
.svc-list { background: #fff; }
.svc-row { display: flex; align-items: center; padding: 14px 16px; border-bottom: 1px solid #f0f0f0; cursor: pointer; transition: background 0.15s; }
.svc-row:active { background: #f8f9fa; }
.svc-row:last-child { border-bottom: none; }
.svc-ico { width: 42px; height: 42px; border-radius: 50%; margin-right: 15px; flex-shrink: 0; display: flex; align-items: center; justify-content: center; box-shadow: 0 2px 5px rgba(0,0,0,0.05); overflow: hidden; }
.svc-ico img { width: 100%; height: 100%; object-fit: cover; }
.svc-txt { flex: 1; font-size: 14px; font-weight: 500; color: #222; }
.svc-chev { width: 8px; height: 8px; border-right: 2px solid #ccc; border-top: 2px solid #ccc; transform: rotate(45deg); flex-shrink: 0; }

/* TIPS */
.tips-wrap { padding: 20px 16px; background: #f4f5f8; }
.tips-title { font-size: 14px; font-weight: 700; color: #333; margin-bottom: 8px; }
.tips-desc { font-size: 12px; color: #777; line-height: 1.6; }

/* PROGRESS BTN */
.prog-btn-wrap { padding: 0 16px 30px; background: #f4f5f8; }
.prog-btn { width: 100%; padding: 15px; background: linear-gradient(90deg, #4481eb 0%, #04befe 100%); color: #fff; border: none; border-radius: 30px; font-size: 16px; font-weight: 600; cursor: pointer; box-shadow: 0 4px 12px rgba(68, 129, 235, 0.3); transition: transform 0.1s; }
.prog-btn:active { transform: scale(0.98); }

/* SUB PAGES */
.sub-pg { display: none; position: fixed; top: 0; left: 50%; transform: translateX(-50%); width: 100%; max-width: 480px; height: 100vh; background: #f4f5f8; z-index: 300; overflow-y: auto; }
.sub-pg.show { display: block; }
.sub-hdr { background: #fff; display: flex; align-items: center; justify-content: space-between; padding: 14px 16px; position: sticky; top: 0; z-index: 10; box-shadow: 0 1px 3px rgba(0,0,0,0.05); }
.sub-back { display: flex; align-items: center; background: none; border: none; cursor: pointer; padding: 5px; }
.back-chev { width: 10px; height: 10px; border-left: 2px solid #333; border-bottom: 2px solid #333; transform: rotate(45deg); }
.sub-title-txt { font-size: 16px; font-weight: 600; color: #222; }
.help-circle { width: 26px; height: 26px; border-radius: 50%; border: 2px solid #4481eb; display: flex; align-items: center; justify-content: center; font-size: 14px; font-weight: 700; color: #4481eb; background: none; cursor: pointer; flex-shrink: 0; }

/* FORM ELEMENTS */
.form-pad { padding: 20px 16px; }
.f-label { font-size: 13px; font-weight: 600; color: #333; margin-bottom: 8px; display: flex; align-items: center; gap: 3px; }
.req { color: #f44336; font-size: 15px; }
.f-input { width: 100%; padding: 14px; border: 1px solid #e0e0e0; border-radius: 10px; font-size: 14px; color: #333; background: #fff; outline: none; margin-bottom: 18px; transition: border 0.2s; }
.f-input:focus { border-color: #4481eb; }
.f-input::placeholder { color: #aaa; }

/* Photo upload box */
.photo-box, .upload-box { width: 120px; height: 120px; border: 1px dashed #ccc; border-radius: 10px; background: #fff; display: flex; flex-direction: column; align-items: center; justify-content: center; cursor: pointer; margin-bottom: 8px; position: relative; overflow: hidden; }
.photo-preview-img { width: 100%; height: 100%; object-fit: cover; display: none; position: absolute; top: 0; left: 0; border-radius: 10px; }
.ph-ico, .folder-ico { width: 32px; height: 32px; margin-bottom: 8px; fill: #ccc; }
.ph-txt, .up-txt { font-size: 12px; color: #999; }
.file-note { font-size: 11px; color: #888; margin-bottom: 18px; line-height: 1.4; }
.guide-title { font-size: 13px; font-weight: 700; color: #f44336; margin-bottom: 6px; }
.guide-txt { font-size: 12px; color: #666; line-height: 1.5; margin-bottom: 15px; }

/* Confirm btn */
.confirm-btn { width: 100%; padding: 15px; background: linear-gradient(90deg, #4481eb 0%, #04befe 100%); color: #fff; border: none; border-radius: 30px; font-size: 16px; font-weight: 600; cursor: pointer; margin-top: 10px; box-shadow: 0 4px 12px rgba(68, 129, 235, 0.3); }

/* DEPOSIT LIST */
.dep-list-wrap { padding: 12px 16px; }
.dep-card { background: #fff; border-radius: 12px; padding: 16px; margin-bottom: 12px; box-shadow: 0 2px 6px rgba(0,0,0,0.04); }
.dep-card-top { display: flex; justify-content: space-between; align-items: center; margin-bottom: 12px; }
.recharge-badge { background: #22b573; color: #fff; font-size: 12px; font-weight: 600; padding: 4px 12px; border-radius: 6px; }
.dep-status-pending { color: #f39c12; font-weight: 600; font-size: 13px; }
.dep-status-complete { color: #22b573; font-weight: 600; font-size: 13px; }
.dep-status-failed { color: #ff4757; font-weight: 600; font-size: 13px; }
.dep-row { display: flex; justify-content: space-between; padding: 6px 0; font-size: 13px; border-bottom: 1px solid #f9f9f9; }
.dep-row:last-child { border-bottom: none; }
.dep-lbl { color: #777; }
.dep-val { color: #333; font-weight: 500; }
.dep-val.orange { color: #f39c12; font-weight: 600; }
.submit-voucher-btn { width: 100%; padding: 12px; background: #fff; color: #4481eb; border: 1px solid #4481eb; border-radius: 20px; font-size: 14px; font-weight: 600; cursor: pointer; margin-top: 12px; }
.no-dep { text-align: center; padding: 40px; color: #999; font-size: 13px; }

/* LOADING & TOAST */
.loading-overlay { display: none; position: fixed; inset: 0; background: rgba(255,255,255,0.9); z-index: 1000; align-items: center; justify-content: center; flex-direction: column; backdrop-filter: blur(3px); }
.loading-overlay.show { display: flex; }
.spin-ring { width: 40px; height: 40px; border: 3px solid #f0f0f0; border-top-color: #4481eb; border-radius: 50%; animation: spinAnim 0.8s linear infinite; margin-bottom: 10px; }
@keyframes spinAnim { to { transform: rotate(360deg); } }
.loading-txt { color: #333; font-size: 14px; font-weight: 600; }

.toast { position: fixed; top: 50%; left: 50%; transform: translate(-50%, -50%) scale(0.9); background: rgba(0,0,0,0.85); color: #fff; padding: 15px 24px; border-radius: 12px; font-size: 14px; text-align: center; z-index: 1500; opacity: 0; pointer-events: none; transition: all 0.3s; }
.toast.show { opacity: 1; transform: translate(-50%, -50%) scale(1); }

/* LANG SHEET */
.sheet-bg { display: none; position: fixed; inset: 0; background: rgba(0,0,0,0.5); z-index: 600; align-items: flex-end; justify-content: center; }
.sheet-bg.show { display: flex; }
.sheet { background: #fff; width: 100%; max-width: 480px; border-radius: 20px 20px 0 0; padding: 15px 0 30px; animation: slideUp 0.3s ease; }
@keyframes slideUp { from { transform: translateY(100%); } to { transform: translateY(0); } }
.lang-opt { display: flex; align-items: center; justify-content: space-between; padding: 16px 20px; cursor: pointer; border-bottom: 1px solid #f0f0f0; font-size: 15px; }
.lang-left { display: flex; align-items: center; gap: 12px; color: #555; }
.lang-opt.active .lang-left { color: #111; font-weight: 600; }
.chk-circle { width: 20px; height: 20px; border-radius: 50%; border: 2px solid #ddd; position: relative; }
.chk-circle.on { background: #4481eb; border-color: #4481eb; }
.chk-circle.on::after { content: ''; position: absolute; top: 4px; left: 6px; width: 5px; height: 9px; border-right: 2px solid #fff; border-bottom: 2px solid #fff; transform: rotate(45deg); }

/* PROGRESS CARDS */
.prog-card { background: #fff; border-radius: 12px; padding: 15px; margin-bottom: 12px; box-shadow: 0 2px 6px rgba(0,0,0,0.04); }
.prog-card-top { display: flex; justify-content: space-between; align-items: center; margin-bottom: 12px; }
.prog-type-badge { background: #e8f0fe; color: #4481eb; font-size: 12px; font-weight: 600; padding: 4px 10px; border-radius: 6px; }
.prog-pend { color: #f39c12; font-weight: 600; font-size: 13px; }
.prog-done { color: #22b573; font-weight: 600; font-size: 13px; }
.prog-fail { color: #ff4757; font-weight: 600; font-size: 13px; }
.prog-row { display: flex; justify-content: space-between; padding: 5px 0; font-size: 13px; border-bottom: 1px solid #f9f9f9; }
.prog-row:last-child { border-bottom: none; }
.pl { color: #777; } .pv { color: #222; font-weight: 500; }

.no-data-wrap { text-align: center; padding: 60px 20px; color: #999; }
.no-data-txt { font-size: 14px; margin-top: 10px; }
.file-inp { display: none; }
</style>
</head>
<body>

<!-- MAIN PAGE -->
<div id="mainPg">

<!-- Header (Exact Match) -->
<div class="hdr">
    <a href="dashboard.php" class="hdr-home-btn">
        <svg viewBox="0 0 24 24"><path d="M3 9.5L12 3l9 6.5V20a1 1 0 01-1 1H5a1 1 0 01-1-1V9.5z"/><path d="M9 21V12h6v9"/></svg>
    </a>
    <span class="hdr-title"><?php echo $T['self_service_center'];?></span>
    <button class="lang-btn" onclick="openLang()">
        <?php if($lang==='en'):?>
        <div class="flag-wrap"><div class="flag-en-bg"></div></div>
        <span>EN</span>
        <?php else:?>
        <div class="flag-wrap"><div class="flag-in-wrap"><div class="fi-top"></div><div class="fi-mid"><div class="fi-wheel"></div></div><div class="fi-bot"></div></div></div>
        <span>HI</span>
        <?php endif;?>
    </button>
</div>

<!-- BANNER (Exact Match Gradient & Layout) -->
<div class="banner">
    <div class="bg-circle-1"></div>
    <div class="bg-circle-2"></div>
    <div class="bg-plus">+</div>
    <div class="bg-bubble"></div>
    
    <div class="banner-left">
        <div class="banner-heading">
            Welcome to Consult the<br>
            GOAGAMES<br>
            Self-Service Center!
        </div>
        <div class="banner-url-row">
            <div class="banner-url-box">
                <div class="globe-icon"></div>
                <span class="banner-url-text">www.goagame.me</span>
                <div class="search-icon"></div>
            </div>
        </div>
    </div>
    <div class="banner-right">
        <!-- Kept user's image url but blended seamlessly -->
        <img src="https://i.ibb.co/tM9xSjB7/Gemini-Generated-Image-3gzqt23gzqt23gzq.png" alt="agent" class="banner-img" style="mix-blend-mode: multiply;">
    </div>
</div>

<!-- Self Service Label -->
<div class="ss-label"><?php echo $T['self_service'];?></div>

<!-- Service List (Exact Match Icons & Clean Lines) -->
<div class="svc-list">
    <div class="svc-row" onclick="openSub('deposit')">
        <div class="svc-ico" style="background:#e3f2fd;"><img src="https://i.ibb.co/VYWBspNr/125640065-235261-GOA-depo-1.jpg" alt=""></div>
        <span class="svc-txt"><?php echo $T['deposit_not_received'];?></span>
        <div class="svc-chev"></div>
    </div>
    <div class="svc-row" onclick="openSub('withdrawal')">
        <div class="svc-ico" style="background:#e3f2fd;"><img src="https://i.ibb.co/RpDrDNtY/125648736-235262-GOA-WD.jpg" alt=""></div>
        <span class="svc-txt"><?php echo $T['withdrawal_problem'];?></span>
        <div class="svc-chev"></div>
    </div>
    <div class="svc-row" onclick="openSub('ifsc')">
        <div class="svc-ico" style="background:#e3f2fd;"><img src="https://i.ibb.co/1J8PrVCz/013639492-611-04.png" alt=""></div>
        <span class="svc-txt"><?php echo $T['ifsc_modification'];?></span>
        <div class="svc-chev"></div>
    </div>
    <div class="svc-row" onclick="openSub('bankname')">
        <div class="svc-ico" style="background:#e3f2fd;"><img src="https://i.ibb.co/8nBsJQgz/122654574-236726-change-bank-name-logo.jpg" alt=""></div>
        <span class="svc-txt"><?php echo $T['change_bank_name'];?></span>
        <div class="svc-chev"></div>
    </div>
    <div class="svc-row" onclick="openSub('password')">
        <div class="svc-ico" style="background:#e3f2fd;"><img src="https://i.ibb.co/8nBsJQgz/122654574-236726-change-bank-name-logo.jpg" alt=""></div>
        <span class="svc-txt"><?php echo $T['change_password'];?></span>
        <div class="svc-chev"></div>
    </div>
    
    <!-- ADDED: ONLINE CUSTOMER SERVICE (LIVE CHAT ANIMATED GIF) -->
    <a href="chat.php" style="text-decoration:none; -webkit-tap-highlight-color: transparent;">
        <div class="svc-row">
            <div class="svc-ico" style="background:#fff;">
                <img src="https://i.ibb.co/v6ggZStq/person-chat-animated-icon.gif" alt="Live Chat" style="width:100%; height:100%; object-fit:contain; border-radius:50%;">
            </div>
            <span class="svc-txt"><?php echo $T['online_chat'];?></span>
            <div class="svc-chev"></div>
        </div>
    </a>
</div>

<!-- Kind Tips -->
<div class="tips-wrap">
    <div class="tips-title"><?php echo $T['kind_tips'];?></div>
    <div class="tips-desc"><?php echo $T['tips_desc'];?></div>
</div>

<!-- Progress Query Button -->
<div class="prog-btn-wrap">
    <button class="prog-btn" onclick="openSub('progress')"><?php echo $T['progress_query'];?></button>
</div>

</div><!-- end mainPg -->


<!-- ===== MODAL/SUB PAGES CODE REMAINS EXACTLY SAME (Just functionality) ===== -->

<!-- ===== DEPOSIT NOT RECEIVED ===== -->
<div class="sub-pg" id="sub-deposit">
    <div class="sub-hdr">
        <button class="sub-back" onclick="closeSub('deposit')"><span class="back-chev"></span></button>
        <span class="sub-title-txt">Deposit Not Received</span>
        <button class="help-circle">?</button>
    </div>

    <!-- Step 1: Select deposit from list -->
    <div id="dep-step1">
        <div style="padding:15px 16px 5px;font-size:13px;color:#666;font-weight:600;">Select your deposit order:</div>
        <div class="dep-list-wrap" id="depListWrap">
            <div class="no-dep">Loading...</div>
        </div>
    </div>

    <!-- Step 2: Fill form -->
    <div id="dep-step2" style="display:none;">
        <div class="form-pad">
            <div class="f-label">UTR number <span class="req">*</span></div>
            <input type="text" class="f-input" id="dep_utr" placeholder="Please enter UTR">

            <div class="f-label">Receiver UPI ID <span class="req">*</span></div>
            <input type="text" class="f-input" id="dep_upi" placeholder="Please enter content">

            <div class="f-label">Order Number <span class="req">*</span></div>
            <input type="text" class="f-input" id="dep_order_num" placeholder="RC2026..." readonly style="background:#f9f9f9; color:#777;">

            <div class="f-label">Order Amount <span class="req">*</span></div>
            <input type="number" class="f-input" id="dep_order_amt" placeholder="100" readonly style="background:#f9f9f9; color:#777;">

            <div class="f-label">Provide PDF Password</div>
            <input type="text" class="f-input" id="dep_pdf_pass" placeholder="Optional">

            <div class="f-label">Deposit proof receipt detail <span class="req">*</span></div>
            <div class="photo-box" onclick="triggerFile('dep_photo_inp')">
                <svg class="ph-ico" viewBox="0 0 24 24"><path d="M21 19V5c0-1.1-.9-2-2-2H5c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2zM8.5 13.5l2.5 3.01L14.5 12l4.5 6H5l3.5-4.5z"/></svg>
                <span class="ph-txt">Upload Photo</span>
                <img class="photo-preview-img" id="dep_photo_prev">
            </div>
            <input type="file" class="file-inp" id="dep_photo_inp" accept="image/*" onchange="prevPhoto(this,'dep_photo_prev')">

            <div class="guide-title">Image Upload Guidelines</div>
            <div class="guide-txt">Please ensure the uploaded image clearly shows the UTR/UPI number.</div>

            <button class="confirm-btn" id="dep_confirm_btn" onclick="submitDepositNotReceived()">Confirm Submit</button>
        </div>
    </div>
</div>

<!-- ===== WITHDRAWAL PROBLEM ===== -->
<div class="sub-pg" id="sub-withdrawal">
    <div class="sub-hdr">
        <button class="sub-back" onclick="closeSub('withdrawal')"><span class="back-chev"></span></button>
        <span class="sub-title-txt">Withdrawal problem</span>
        <button class="help-circle">?</button>
    </div>
    <div class="form-pad">
        <div class="f-label">Order ID <span class="req">*</span></div>
        <input type="text" class="f-input" id="wd_order_id" placeholder="Please enter order ID">
        <div class="f-label">Amount <span class="req">*</span></div>
        <input type="number" class="f-input" id="wd_amount" placeholder="Please enter amount">
        <div class="f-label">Note</div>
        <input type="text" class="f-input" id="wd_note" placeholder="Optional notes">
        <button class="confirm-btn" onclick="submitWithdrawal()">Confirm</button>
    </div>
</div>

<!-- ===== IFSC MODIFICATION ===== -->
<div class="sub-pg" id="sub-ifsc">
    <div class="sub-hdr">
        <button class="sub-back" onclick="closeSub('ifsc')"><span class="back-chev"></span></button>
        <span class="sub-title-txt">IFSC Modification</span>
        <button class="help-circle">?</button>
    </div>
    <div class="form-pad">
        <div class="f-label">Bank number <span class="req">*</span></div>
        <input type="text" class="f-input" id="ifsc_bank_num" placeholder="Please enter Bank Card Number">
        <div class="f-label">Correct IFSC Code <span class="req">*</span></div>
        <input type="text" class="f-input" id="ifsc_code" placeholder="Please enter IFSC" maxlength="11" style="text-transform:uppercase;">
        <button class="confirm-btn" onclick="submitIFSC()">Confirm</button>
    </div>
</div>

<!-- ===== CHANGE BANK NAME ===== -->
<div class="sub-pg" id="sub-bankname">
    <div class="sub-hdr">
        <button class="sub-back" onclick="closeSub('bankname')"><span class="back-chev"></span></button>
        <span class="sub-title-txt">Change bank name</span>
        <button class="help-circle">?</button>
    </div>
    <div class="form-pad">
        <div class="f-label">Correct bank name <span class="req">*</span></div>
        <input type="text" class="f-input" id="bn_name" placeholder="Enter correct bank name">
        <div class="f-label" style="margin-top:10px;">Bank Card Number <span class="req">*</span></div>
        <input type="text" class="f-input" id="bn_card_num" placeholder="Please enter Bank Card Number">
        <button class="confirm-btn" onclick="submitBankName()">Confirm</button>
    </div>
</div>

<!-- ===== CHANGE PASSWORD ===== -->
<div class="sub-pg" id="sub-password">
    <div class="sub-hdr">
        <button class="sub-back" onclick="closeSub('password')"><span class="back-chev"></span></button>
        <span class="sub-title-txt">Change ID Login Password</span>
        <button class="help-circle">?</button>
    </div>
    <div class="form-pad">
        <div class="f-label">New Password <span class="req">*</span></div>
        <input type="text" class="f-input" id="new_pass" placeholder="Enter new password">

        <div class="f-label">Identity Proof Photo <span class="req">*</span></div>
        <div class="photo-box" onclick="triggerFile('selfie_inp')">
            <svg class="ph-ico" viewBox="0 0 24 24"><path d="M21 19V5c0-1.1-.9-2-2-2H5c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2zM8.5 13.5l2.5 3.01L14.5 12l4.5 6H5l3.5-4.5z"/></svg>
            <span class="ph-txt">Upload</span>
            <img class="photo-preview-img" id="selfie_prev">
        </div>
        <input type="file" class="file-inp" id="selfie_inp" accept="image/*" onchange="prevPhoto(this,'selfie_prev')">

        <button class="confirm-btn" style="margin-top:20px;" onclick="submitPassword()">Confirm Change</button>
    </div>
</div>

<!-- ===== PROGRESS QUERY ===== -->
<div class="sub-pg" id="sub-progress">
    <div class="sub-hdr">
        <button class="sub-back" onclick="closeSub('progress')"><span class="back-chev"></span></button>
        <span class="sub-title-txt">Progress Query</span>
        <div style="width:34px;"></div>
    </div>
    <div style="padding:16px;" id="progListWrap">
        <div class="no-data-wrap">
            <svg style="width:60px;height:60px;fill:#ddd;margin-bottom:10px;" viewBox="0 0 24 24"><path d="M19 3H5c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2zm0 16H5V5h14v14zM7 10h2v7H7zm4-3h2v10h-2zm4 6h2v4h-2z"/></svg>
            <div class="no-data-txt">No Data</div>
        </div>
    </div>
</div>

<!-- LANGUAGE SHEET -->
<div class="sheet-bg" id="langSheet">
    <div class="sheet">
        <div class="lang-opt <?php echo $lang==='en'?'active':'';?>" onclick="setLang('en')">
            <div class="lang-left">
                <div class="flag-wrap"><div class="flag-en-bg"></div></div>
                <span>English</span>
            </div>
            <div class="chk-circle <?php echo $lang==='en'?'on':'';?>"></div>
        </div>
        <div class="lang-opt <?php echo $lang==='hi'?'active':'';?>" onclick="setLang('hi')">
            <div class="lang-left">
                <div class="flag-wrap"><div class="flag-in-wrap"><div class="fi-top"></div><div class="fi-mid"><div class="fi-wheel"></div></div><div class="fi-bot"></div></div></div>
                <span>हिंदी</span>
            </div>
            <div class="chk-circle <?php echo $lang==='hi'?'on':'';?>"></div>
        </div>
    </div>
</div>

<!-- LOADING -->
<div class="loading-overlay" id="loadingOv">
    <div class="spin-ring"></div>
    <div class="loading-txt">Loading...</div>
</div>

<!-- TOAST -->
<div class="toast" id="toast"></div>

<script>
// JS Logic (Identical to previous, intact and working)
function openSub(name) {
    if (name === 'deposit') loadDeposits();
    if (name === 'progress') loadProgress();
    document.getElementById('sub-' + name).classList.add('show');
    document.body.style.overflow = 'hidden';
}
function closeSub(name) {
    document.getElementById('sub-' + name).classList.remove('show');
    document.body.style.overflow = '';
    if (name === 'deposit') {
        document.getElementById('dep-step1').style.display = 'block';
        document.getElementById('dep-step2').style.display = 'none';
    }
}

function loadDeposits() {
    const wrap = document.getElementById('depListWrap');
    wrap.innerHTML = '<div style="text-align:center;padding:40px;color:#999;">Loading...</div>';

    const fd = new FormData();
    fd.append('action', 'get_deposits');
    fetch('customer-service.php', {method:'POST', body:fd})
    .then(r => r.json())
    .then(data => {
        if (!data.success || !data.deposits || data.deposits.length === 0) {
            wrap.innerHTML = '<div class="no-dep">No deposit history found</div>';
            return;
        }
        let html = '';
        data.deposits.forEach(dep => {
            const st = dep.status || 'Pending';
            let stClass = 'dep-status-pending';
            if (st === 'Complete' || st === 'Completed') { stClass = 'dep-status-complete'; }
            else if (st === 'Failed') { stClass = 'dep-status-failed'; }

            const oid = dep.order_id || '';
            html += `
            <div class="dep-card">
                <div class="dep-card-top">
                    <span class="recharge-badge">Recharge</span>
                    <span class="${stClass}">${st}</span>
                </div>
                <div class="dep-row"><span class="dep-lbl">Amount</span><span class="dep-val orange">₹${parseFloat(dep.amount||0).toFixed(0)}</span></div>
                <div class="dep-row"><span class="dep-lbl">Order No.</span><span class="dep-val" style="font-size:12px;">${oid}</span></div>
                <div class="dep-row"><span class="dep-lbl">Time</span><span class="dep-val" style="font-size:12px;">${dep.time||''}</span></div>
                <button class="submit-voucher-btn" onclick="fillDepositForm('${oid}','${dep.amount||0}')">Submit Deposit Voucher</button>
            </div>`;
        });
        wrap.innerHTML = html;
    })
    .catch(() => { wrap.innerHTML = '<div class="no-dep">Error loading.</div>'; });
}

function fillDepositForm(orderId, amount) {
    document.getElementById('dep_order_num').value = orderId;
    document.getElementById('dep_order_amt').value = amount;
    document.getElementById('dep_utr').value = '';
    document.getElementById('dep_upi').value = '';
    document.getElementById('dep-step1').style.display = 'none';
    document.getElementById('dep-step2').style.display = 'block';
    document.getElementById('sub-deposit').scrollTop = 0;
}

function submitDepositNotReceived() {
    const utr = document.getElementById('dep_utr').value.trim();
    const upi = document.getElementById('dep_upi').value.trim();
    const ord = document.getElementById('dep_order_num').value.trim();
    const amt = document.getElementById('dep_order_amt').value.trim();
    const photoInp = document.getElementById('dep_photo_inp');

    if (!utr || !upi || !ord || !amt) { showToast('Please fill all required fields!'); return; }

    showLoading();
    const fd = new FormData();
    fd.append('action','submit_deposit_not_received');
    fd.append('utr', utr); fd.append('receiver_upi', upi);
    fd.append('order_number', ord); fd.append('order_amount', amt);
    fd.append('photo_b64', photoInp.getAttribute('data-b64') || '');

    fetch('customer-service.php', {method:'POST', body:fd}).then(r=>r.json()).then(d => {
        hideLoading();
        if (d.success) { showToast('Submitted Successfully!'); setTimeout(() => closeSub('deposit'), 1500); } 
        else showToast(d.message || 'Failed!');
    }).catch(() => { hideLoading(); showToast('Network error!'); });
}

function submitWithdrawal() {
    const oid = document.getElementById('wd_order_id').value.trim();
    const amt = document.getElementById('wd_amount').value.trim();
    if (!oid || !amt) { showToast('Please fill required fields!'); return; }
    const fd = new FormData(); fd.append('action','submit_withdrawal_problem');
    fd.append('order_id',oid); fd.append('amount',amt); fd.append('note',document.getElementById('wd_note').value.trim());
    doPost(fd,'sub-withdrawal');
}

function submitIFSC() {
    const bn = document.getElementById('ifsc_bank_num').value.trim();
    const ic = document.getElementById('ifsc_code').value.trim().toUpperCase();
    if (!bn || !ic) { showToast('Please fill all fields!'); return; }
    const fd = new FormData(); fd.append('action','submit_ifsc');
    fd.append('bank_number',bn); fd.append('ifsc',ic);
    doPost(fd,'sub-ifsc');
}

function submitBankName() {
    const bn = document.getElementById('bn_name').value.trim();
    const cn = document.getElementById('bn_card_num').value.trim();
    if (!bn || !cn) { showToast('Please fill all fields!'); return; }
    const fd = new FormData(); fd.append('action','submit_bank_name');
    fd.append('bank_name',bn); fd.append('card_number',cn);
    doPost(fd,'sub-bankname');
}

function submitPassword() {
    const np = document.getElementById('new_pass').value.trim();
    if (!np || np.length < 6) { showToast('Password min 6 characters!'); return; }
    const selfieInp = document.getElementById('selfie_inp');
    if (!selfieInp.getAttribute('data-b64')) { showToast('Please upload Identity photo!'); return; }
    const fd = new FormData(); fd.append('action','submit_password');
    fd.append('new_password',np); fd.append('selfie_b64', selfieInp.getAttribute('data-b64')||'');
    doPost(fd,'sub-password');
}

function doPost(fd, closeId) {
    showLoading();
    fetch('customer-service.php',{method:'POST',body:fd}).then(r=>r.json()).then(d=>{
        hideLoading();
        if(d.success){showToast('Submitted Successfully!');setTimeout(()=>closeSub(closeId.replace('sub-','')),1500);}
        else showToast(d.message||'Failed!');
    }).catch(()=>{hideLoading();showToast('Network error!');});
}

function loadProgress() {
    const wrap = document.getElementById('progListWrap');
    wrap.innerHTML = '<div style="text-align:center;padding:40px;color:#999;">Loading...</div>';
    const fd = new FormData(); fd.append('action','get_progress');
    fetch('customer-service.php',{method:'POST',body:fd}).then(r=>r.json()).then(data=>{
        if(!data.success||!data.list||data.list.length===0){
            wrap.innerHTML=`<div class="no-data-wrap"><svg style="width:50px;height:50px;fill:#ccc;margin-bottom:10px;" viewBox="0 0 24 24"><path d="M19 3H5c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2zm0 16H5V5h14v14zM7 10h2v7H7zm4-3h2v10h-2zm4 6h2v4h-2z"/></svg><div class="no-data-txt">No Data Found</div></div>`;
            return;
        }
        let html='';
        data.list.forEach(r=>{
            const sc=r.status==='Resolved'?'prog-done':r.status==='Rejected'?'prog-fail':'prog-pend';
            html+=`<div class="prog-card">
                <div class="prog-card-top"><span class="prog-type-badge">${r.type||''}</span><span class="${sc}">${r.status||'Pending'}</span></div>
                <div class="prog-row"><span class="pl">Request ID</span><span class="pv" style="font-size:11px;">${r.request_id||''}</span></div>
                <div class="prog-row"><span class="pl">Time</span><span class="pv">${r.time||''}</span></div>
            </div>`;
        });
        wrap.innerHTML=html;
    }).catch(()=>{wrap.innerHTML='<div style="text-align:center;padding:40px;color:#e53935;">Error!</div>';});
}

function openLang(){document.getElementById('langSheet').classList.add('show');}
function setLang(l){
    const fd=new FormData();fd.append('action','set_lang');fd.append('lang',l);
    fetch('customer-service.php',{method:'POST',body:fd}).then(()=>location.reload());
}
document.getElementById('langSheet').addEventListener('click',function(e){if(e.target===this)this.classList.remove('show');});

function triggerFile(id){document.getElementById(id).click();}
function prevPhoto(input,prevId){
    const f=input.files[0];if(!f)return;
    const r=new FileReader();
    r.onload=function(e){
        const img=new Image();
        img.onload=function(){
            const c=document.createElement('canvas'); let w=img.width,h=img.height,mx=400;
            if(w>h&&w>mx){h=h*mx/w;w=mx;}else if(h>mx){w=w*mx/h;h=mx;}
            c.width=w;c.height=h; c.getContext('2d').drawImage(img,0,0,w,h);
            const b64=c.toDataURL('image/jpeg',0.5); input.setAttribute('data-b64',b64);
            const p=document.getElementById(prevId); p.src=b64; p.style.display='block';
        }; img.src=e.target.result;
    }; r.readAsDataURL(f);
}

function showLoading(){document.getElementById('loadingOv').classList.add('show');}
function hideLoading(){document.getElementById('loadingOv').classList.remove('show');}
function showToast(msg){
    const t=document.getElementById('toast');
    t.textContent=msg; t.classList.add('show');
    setTimeout(()=>t.classList.remove('show'),2500);
}
</script>
</body>
</html>