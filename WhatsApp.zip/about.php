<?php
session_start();
error_reporting(0);
date_default_timezone_set('Asia/Kolkata');
require_once 'config.php';

$phone = $_SESSION['user_phone'] ?? $_SESSION['phone'] ?? '';
if ($phone === '') {
    header('Location: index.php');
    exit;
}
$_SESSION['user_phone'] = $phone;
$_SESSION['phone'] = $phone;

$page = $_GET['page'] ?? 'main';
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
<title>About Us - 3win</title>
<style>
* { margin: 0; padding: 0; box-sizing: border-box; font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif; -webkit-tap-highlight-color: transparent; }
body { background: #f5f6fa; color: #222; min-height: 100vh; display: flex; justify-content: center; }
.app { width: 100%; max-width: 480px; min-height: 100vh; background: #f5f6fa; display: flex; flex-direction: column; position: relative; }

/* SHARED VIEW STYLES */
.view-panel { display: none; flex-direction: column; min-height: 100vh; width: 100%; background: #f5f6fa; }
.view-panel.active { display: flex; }

/* 1. ABOUT US MAIN VIEW */
.header-blue { height: 50px; background: #418dfd; display: flex; align-items: center; justify-content: center; position: sticky; top: 0; z-index: 50; }
.header-blue .back-btn { position: absolute; left: 16px; font-size: 26px; color: #fff; text-decoration: none; cursor: pointer; line-height: 1; display: flex; align-items: center; justify-content: center; }
.header-blue .header-title { font-size: 18px; font-weight: 500; color: #fff; }

.banner-wrap { width: 100%; padding: 0; margin-bottom: 12px; background: #fff; }
.banner-img { width: 100%; height: auto; display: block; object-fit: cover; }

.menu-list { padding: 0 16px; display: flex; flex-direction: column; gap: 10px; }
.menu-item { background: #fff; border-radius: 12px; padding: 16px; display: flex; align-items: center; justify-content: space-between; text-decoration: none; color: inherit; cursor: pointer; box-shadow: 0 2px 6px rgba(0,0,0,0.02); transition: background 0.15s ease; }
.menu-item:active { background: #f9fafd; }

.menu-item-left { display: flex; align-items: center; gap: 14px; }
.item-icon { width: 38px; height: 38px; border-radius: 10px; background: #eaf2fe; display: flex; align-items: center; justify-content: center; flex-shrink: 0; }
.item-icon svg { width: 22px; height: 22px; fill: #418dfd; }
.item-text { font-size: 15.5px; font-weight: 500; color: #1e2229; }
.chevron-icon { width: 18px; height: 18px; stroke: #8a92a6; fill: none; stroke-width: 2.2; stroke-linecap: round; stroke-linejoin: round; }

/* 2. WHITE AGREEMENT SUB-PAGES */
.header-white { height: 50px; background: #fff; display: flex; align-items: center; justify-content: center; position: sticky; top: 0; z-index: 50; border-bottom: 1px solid #edf0f5; }
.header-white .back-btn { position: absolute; left: 16px; font-size: 26px; color: #222; text-decoration: none; cursor: pointer; line-height: 1; display: flex; align-items: center; justify-content: center; }
.header-white .header-title { font-size: 18px; font-weight: 500; color: #222; }

.agreement-body { flex: 1; background: #fff; padding: 20px 18px 40px; font-size: 14.5px; line-height: 1.6; color: #333; }
.agreement-body p { margin-bottom: 16px; }
.agreement-body h3 { font-size: 16px; font-weight: 700; color: #111; margin-bottom: 8px; margin-top: 14px; }
.agreement-body h4 { font-size: 15px; font-weight: 600; color: #111; margin-bottom: 6px; margin-top: 10px; }

.def-item { margin-bottom: 14px; }
.def-item b { color: #111; font-weight: 700; }
.brand-highlight { color: #418dfd; font-weight: 600; }

.dashed-line { border: none; border-top: 1px dashed #7a8291; margin: 18px 0; width: 100%; opacity: 0.6; }
.rule-point { margin-bottom: 14px; line-height: 1.55; }
</style>
</head>
<body>

<div class="app">

    <!-- ======================================================= -->
    <!-- VIEW 1: ABOUT US (MAIN DASHBOARD WITH BANNER)          -->
    <!-- ======================================================= -->
    <div class="view-panel <?= $page === 'main' ? 'active' : '' ?>" id="viewMain">
        <!-- HEADER -->
        <div class="header-blue">
            <a href="account.php" class="back-btn">‹</a>
            <div class="header-title">About us</div>
        </div>

        <!-- TOP BANNER (Aapka Diya Hua Image Link) -->
        <div class="banner-wrap">
            <img 
                src="https://www.goaok.org/assets/png/aboutBg-DRR4Y_nV.png" 
                alt="About Banner" 
                class="banner-img"
                onerror="this.onerror=null; this.src='https://images.unsplash.com/photo-1550745165-9bc0b252726f?auto=format&fit=crop&w=800&q=80';">
        </div>

        <!-- MENU CARDS -->
        <div class="menu-list">
            <!-- Item 1: Confidentiality Agreement -->
            <div class="menu-item" onclick="openPage('confidentiality')">
                <div class="menu-item-left">
                    <div class="item-icon">
                        <!-- Blue Note/Document SVG Icon -->
                        <svg viewBox="0 0 24 24"><path d="M19 3H5c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2zm-5 14H7v-2h7v2zm3-4H7v-2h10v2zm0-4H7V7h10v2z"/></svg>
                    </div>
                    <span class="item-text">Confidentiality Agreement</span>
                </div>
                <svg class="chevron-icon" viewBox="0 0 24 24"><polyline points="9 18 15 12 9 6"></polyline></svg>
            </div>

            <!-- Item 2: Risk Disclosure Agreement -->
            <div class="menu-item" onclick="openPage('risk')">
                <div class="menu-item-left">
                    <div class="item-icon">
                        <!-- Blue Bookmark/Ribbon SVG Icon -->
                        <svg viewBox="0 0 24 24"><path d="M17 3H7c-1.1 0-1.99.9-1.99 2L5 21l7-3 7 3V5c0-1.1-.9-2-2-2z"/></svg>
                    </div>
                    <span class="item-text">Risk Disclosure Agreement</span>
                </div>
                <svg class="chevron-icon" viewBox="0 0 24 24"><polyline points="9 18 15 12 9 6"></polyline></svg>
            </div>
        </div>
    </div>

    <!-- ======================================================= -->
    <!-- VIEW 2: CONFIDENTIALITY AGREEMENT                       -->
    <!-- ======================================================= -->
    <div class="view-panel <?= $page === 'confidentiality' ? 'active' : '' ?>" id="viewConfidentiality">
        <div class="header-white">
            <button type="button" class="back-btn" onclick="openPage('main')">‹</button>
            <div class="header-title">Confidentiality Agreement</div>
        </div>

        <div class="agreement-body">
            <p>This Privacy Policy describes Our policies and procedures on the collection, use and disclosure of Your information when You use the Service and tells You about Your privacy rights and how the law protects You.</p>

            <h3>Interpretation and Definitions</h3>
            <h4>Interpretation</h4>
            <p>The words of which the initial letter is capitalized have meanings defined under the following conditions.</p>
            <p>The following definitions shall have the same meaning regardless of whether they appear in singular or in plural.</p>

            <h3>Definitions</h3>
            <p>For the purposes of this Privacy Policy:</p>

            <div class="def-item">
                <p><b>You</b> means the individual accessing or using the Service, or the company, or other legal entity on behalf of which such individual is accessing or using the Service, as applicable.</p>
            </div>

            <div class="def-item">
                <p><b>Company</b> (referred to as either "the Company", "We", "Us" or "Our" in this Agreement) refers to <span class="brand-highlight">3win</span>.</p>
            </div>

            <div class="def-item">
                <p><b>Affiliate</b> means an entity that controls, is controlled by or is under common control with a party, where "control" means ownership of 50% or more of the shares, equity interest or other securities entitled to vote for election of directors or other managing authority.</p>
            </div>

            <div class="def-item">
                <p><b>Account</b> means a unique account created for You to access our Service or parts of our Service.</p>
            </div>

            <div class="def-item">
                <p><b>Website</b> refers to <span class="brand-highlight">3win</span>, accessible from <span class="brand-highlight">3win</span>.</p>
            </div>

            <div class="def-item">
                <p><b>Service</b> refers to the Website and Applications provided by <span class="brand-highlight">3win</span>.</p>
            </div>

            <div class="def-item">
                <p><b>Country</b> refers to India.</p>
            </div>

            <div class="def-item">
                <p><b>Personal Data</b> is any information that relates to an identified or identifiable individual registered with <span class="brand-highlight">3win</span>.</p>
            </div>
        </div>
    </div>

    <!-- ======================================================= -->
    <!-- VIEW 3: RISK DISCLOSURE AGREEMENT                       -->
    <!-- ======================================================= -->
    <div class="view-panel <?= $page === 'risk' ? 'active' : '' ?>" id="viewRisk">
        <div class="header-white">
            <button type="button" class="back-btn" onclick="openPage('main')">‹</button>
            <div class="header-title">Risk Disclosure Agreement</div>
        </div>

        <div class="agreement-body">
            <h3>User Agreement</h3>
            
            <div class="rule-point">
                1. To avoid betting disputes, members must read the company's rules before entering the app. Once the player "I agree" By entering this company to bet, you will be considered to be in agreement with the company's User Agreement.
            </div>

            <hr class="dashed-line">

            <div class="rule-point">
                2. It is the member's responsibility to ensure the confidentiality of their account and login information. Any online bets placed using your account number and member password will be considered valid. Please change your password from time to time. The company IS not responsible for any compensation for bets made with a stolen account and password.
            </div>

            <hr class="dashed-line">

            <div class="rule-point">
                3. The company reserves the right to change this agreement or the game rules or confidentiality rules from time to time. The modified terms will take effect on the date specified after the change occurs, and the right to make final decisions on all disputes is reserved by the company.
            </div>

            <hr class="dashed-line">

            <div class="rule-point">
                4. Users must be of legal age according to the laws of the country of residence to use our online platform or application. Online bets that have not been submitted will be considered void.
            </div>

            <hr class="dashed-line">

            <div class="rule-point">
                5. When a player is disconnected voluntarily or forcibly from the game before the winning result is announced, it will not affect the game result.
            </div>

            <hr class="dashed-line">

            <div class="rule-point">
                6. In the event of force majeure, system maintenance, or telecommunication operator failures causing data loss or delay, the game results recorded in the backend system of <span class="brand-highlight">3win</span> shall prevail.
            </div>

            <hr class="dashed-line">

            <div class="rule-point">
                7. All participants must play responsibly. The platform provides entertainment services and does not guarantee financial returns.
            </div>
        </div>
    </div>

</div>

<script>
// SPA-Style Clean Tab Switcher (Without flickering or slow page loads)
function openPage(pageName) {
    document.querySelectorAll('.view-panel').forEach(panel => {
        panel.classList.remove('active');
    });

    if (pageName === 'confidentiality') {
        document.getElementById('viewConfidentiality').classList.add('active');
        window.scrollTo(0, 0);
    } else if (pageName === 'risk') {
        document.getElementById('viewRisk').classList.add('active');
        window.scrollTo(0, 0);
    } else {
        document.getElementById('viewMain').classList.add('active');
        window.scrollTo(0, 0);
    }
}
</script>
</body>
</html>