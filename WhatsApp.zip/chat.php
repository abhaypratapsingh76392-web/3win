<?php
// chat.php - 3 WIN Smart Bot + Live Chat (Full Complete File)
require 'config.php';

// ============ HELPERS ============
function generateLongId($length = 32) {
    if (function_exists('random_bytes')) {
        try { return bin2hex(random_bytes($length)); } catch (Exception $e) {}
    }
    if (function_exists('openssl_random_pseudo_bytes')) {
        return bin2hex(openssl_random_pseudo_bytes($length));
    }
    $chars = 'abcdefghijklmnopqrstuvwxyz0123456789';
    $out = '';
    for ($i = 0; $i < $length * 2; $i++) $out .= $chars[mt_rand(0, strlen($chars) - 1)];
    return $out;
}

$phone = $_SESSION['phone'] ?? null;
$isLoggedIn = !empty($phone);

// Chat key setup — PERSISTENT (never auto-delete)
if ($isLoggedIn) {
    $existingChat = firebase_read("chats/user_" . $phone);
    if ($existingChat && isset($existingChat['chat_id'])) {
        $chatId = $existingChat['chat_id'];
    } else {
        $chatId = generateLongId(32) . '_' . time() . '_' . generateLongId(16);
        firebase_write("chats/user_" . $phone, [
            'chat_id' => $chatId,
            'phone' => $phone,
            'created_at' => time(),
            'last_active' => time(),
            'messages' => ['init' => ['id' => 'init', 'text' => '', 'timestamp' => time()]]
        ]);
    }
    $chatKey = "user_" . $phone;
} else {
    if (!isset($_SESSION['temp_chat_key'])) {
        $tempId = generateLongId(32) . '_temp_' . time() . '_' . generateLongId(16);
        $_SESSION['temp_chat_id'] = $tempId;
        $_SESSION['temp_chat_key'] = 'temp_' . generateLongId(8);
        firebase_write("chats/" . $_SESSION['temp_chat_key'], [
            'chat_id' => $tempId,
            'phone' => 'guest',
            'created_at' => time(),
            'last_active' => time(),
            'messages' => ['init' => ['id' => 'init', 'text' => '', 'timestamp' => time()]]
        ]);
    }
    $chatId = $_SESSION['temp_chat_id'];
    $chatKey = $_SESSION['temp_chat_key'];
}

// ============ SMART BOT + ORDER SEARCH ============

function chatNormalizeOrderId($value) {
    $value = trim((string)$value);
    return strtoupper(preg_replace('/[^a-zA-Z0-9]/', '', $value));
}

function chatFieldName($field) {
    return strtolower(preg_replace('/[^a-zA-Z0-9]/', '', (string)$field));
}

function chatOrderValueMatches($value, $wantedOrderId) {
    if (!is_string($value) && !is_numeric($value)) return false;
    $value = chatNormalizeOrderId($value);
    return $value !== '' && $value === $wantedOrderId;
}

function chatGetFirstValue($record, $possibleFields) {
    if (!is_array($record)) return '';
    foreach ($record as $key => $value) {
        $normalizedKey = chatFieldName($key);
        if (in_array($normalizedKey, $possibleFields, true)) {
            if (is_string($value) || is_numeric($value)) return trim((string)$value);
        }
    }
    return '';
}

function chatFindOrderInTree($node, $wantedOrderId, $path = '', $depth = 0, &$visited = 0) {
    if (!is_array($node) || $depth > 12 || $visited > 8000) return null;
    $visited++;

    $idFields = [
        'orderid', 'ordernumber', 'orderno',
        'transactionid', 'transactionno', 'transactionnumber',
        'utr', 'utrnumber',
        'referenceid', 'referenceno',
        'paymentid', 'paymentreference', 'id'
    ];

    foreach ($node as $field => $value) {
        $cleanField = chatFieldName($field);
        if (in_array($cleanField, $idFields, true) && chatOrderValueMatches($value, $wantedOrderId)) {
            return ['record' => $node, 'path' => $path];
        }
    }

    foreach ($node as $key => $child) {
        if (chatNormalizeOrderId($key) === $wantedOrderId) {
            return [
                'record' => is_array($child) ? $child : $node,
                'path' => $path === '' ? (string)$key : $path . '/' . $key
            ];
        }
    }

    foreach ($node as $key => $child) {
        if (!is_array($child)) continue;
        $childPath = $path === '' ? (string)$key : $path . '/' . $key;
        $result = chatFindOrderInTree($child, $wantedOrderId, $childPath, $depth + 1, $visited);
        if ($result !== null) return $result;
    }

    return null;
}

function chatSearchOrder($orderId, $type, $phone) {
    $phone = trim((string)$phone);
    $safePhone = str_replace(['/', '.', '#', '$', '[', ']'], '', $phone);

    $depositPaths = [
        'deposits', 'deposit_history', 'depositHistory',
        'deposit_requests', 'depositRequests',
        'deposit_orders', 'depositOrders',
        'recharges', 'recharge_history', 'rechargeHistory',
        'recharge_requests', 'payment_orders', 'paymentOrders',
        'payments', 'orders/deposits'
    ];

    $withdrawalPaths = [
        'withdrawals', 'withdraw_history', 'withdrawHistory',
        'withdrawal_history', 'withdrawalHistory',
        'withdraw_requests', 'withdrawRequests',
        'withdrawal_requests', 'withdrawalRequests',
        'payouts', 'cashouts', 'orders/withdrawals'
    ];

    $paths = [];

    if ($safePhone !== '' && strtolower($safePhone) !== 'guest') {
        if ($type === 'deposit' || $type === 'general') {
            $paths = array_merge($paths, [
                'deposits/' . $safePhone,
                'deposit_history/' . $safePhone,
                'depositHistory/' . $safePhone,
                'deposit_requests/' . $safePhone,
                'recharges/' . $safePhone,
                'recharge_history/' . $safePhone,
                'payments/' . $safePhone,
                'orders/' . $safePhone . '/deposits',
                'users/' . $safePhone . '/deposits',
                'users/' . $safePhone . '/deposit_history',
                'users/' . $safePhone . '/depositHistory',
                'users/' . $safePhone . '/recharges',
                'users/' . $safePhone . '/transactions'
            ]);
        }
        if ($type === 'withdrawal' || $type === 'general') {
            $paths = array_merge($paths, [
                'withdrawals/' . $safePhone,
                'withdraw_history/' . $safePhone,
                'withdrawHistory/' . $safePhone,
                'withdrawal_history/' . $safePhone,
                'withdrawalHistory/' . $safePhone,
                'withdraw_requests/' . $safePhone,
                'payouts/' . $safePhone,
                'cashouts/' . $safePhone,
                'orders/' . $safePhone . '/withdrawals',
                'users/' . $safePhone . '/withdrawals',
                'users/' . $safePhone . '/withdraw_history',
                'users/' . $safePhone . '/withdrawal_history'
            ]);
        }
    }

    if ($type === 'deposit' || $type === 'general') $paths = array_merge($paths, $depositPaths);
    if ($type === 'withdrawal' || $type === 'general') $paths = array_merge($paths, $withdrawalPaths);

    $checked = [];
    foreach ($paths as $path) {
        if (isset($checked[$path])) continue;
        $checked[$path] = true;
        $data = firebase_read($path);
        if (!$data || !is_array($data)) continue;
        $visited = 0;
        $found = chatFindOrderInTree($data, $orderId, $path, 0, $visited);
        if ($found !== null) {
            $found['firebase_path'] = $path;
            return $found;
        }
    }
    return null;
}

function checkOrder($orderId, $type, $chatKey, $phone) {
    $cleanOrderId = chatNormalizeOrderId($orderId);
    if (strlen($cleanOrderId) < 6) {
        return ['text' => "⚠️ Please enter a valid Order ID.\n\nExample: `RC202609060854007582777N`"];
    }

    $found = chatSearchOrder($cleanOrderId, $type, $phone);

    if ($found !== null) {
        firebase_write('chats/' . $chatKey . '/awaiting', '');
        $record = $found['record'];
        $amount = chatGetFirstValue($record, [
            'amount', 'orderamount', 'money', 'price', 'value',
            'depositamount', 'withdrawamount'
        ]);
        $status = chatGetFirstValue($record, [
            'status', 'state', 'orderstatus', 'paymentstatus'
        ]);
        if ($status === '') $status = 'Processing';

        $orderTypeName = $type === 'withdrawal' ? 'Withdrawal' : 'Deposit';
        $amountLine = '';
        if ($amount !== '') {
            $amountPrefix = strpos($amount, '₹') === false ? '₹' : '';
            $amountLine = "\n💵 Amount: " . $amountPrefix . $amount;
        }

        return [
            'text' =>
                "✅ *" . $orderTypeName . " Found!*\n\n" .
                "🎫 Order ID: `" . $cleanOrderId . "`" .
                $amountLine .
                "\n📊 Current Status: *" . strtoupper($status) . "*\n\n" .
                "⏳ *Please wait up to 24 hours.*\n\n" .
                "Your request is under processing. Thank you for your patience 🙏"
        ];
    }

    firebase_write('chats/' . $chatKey . '/human_requested', true);
    return [
        'text' =>
            "❌ *Order ID Not Found!*\n\n" .
            "🎫 Entered ID: `" . $cleanOrderId . "`\n\n" .
            "Please copy the exact Order Number from your Deposit / Withdrawal History and send it again.\n\n" .
            "A support agent has also been notified. 👨‍💼",
        'notify_admin' => true
    ];
}

function botProcess($userMessage, $chatKey, $phone) {
    $message = trim((string)$userMessage);
    $lowerMessage = strtolower($message);

    $chatData = firebase_read('chats/' . $chatKey);
    $awaiting = '';
    if (is_array($chatData) && isset($chatData['awaiting'])) $awaiting = (string)$chatData['awaiting'];

    if ($awaiting !== '' && preg_match('/^(cancel|close|band|band karo|cancel karo)$/i', $message)) {
        firebase_write('chats/' . $chatKey . '/awaiting', '');
        return ['text' => "✅ Order ID request cancelled.\n\nHow else can I help you?"];
    }

    if ($awaiting === 'deposit_order')    return checkOrder($message, 'deposit', $chatKey, $phone);
    if ($awaiting === 'withdrawal_order') return checkOrder($message, 'withdrawal', $chatKey, $phone);
    if ($awaiting === 'general_order')    return checkOrder($message, 'general', $chatKey, $phone);

    if (preg_match('/deposit|recharge|add money|top.?up|paisa dala|paisa jama|bharo|jama/i', $lowerMessage)) {
        firebase_write('chats/' . $chatKey . '/awaiting', 'deposit_order');
        return [
            'text' =>
                "💳 *Deposit / Recharge Support*\n\n" .
                "Please enter your *Order Number / Transaction ID*.\n\n" .
                "You can find it in your Deposit History.\n\n" .
                "📝 Send your Order ID below:"
        ];
    }

    if (preg_match('/withdraw|withdrawal|paisa nikal|cash.?out|payout|nikalna/i', $lowerMessage)) {
        firebase_write('chats/' . $chatKey . '/awaiting', 'withdrawal_order');
        return [
            'text' =>
                "💰 *Withdrawal Support*\n\n" .
                "Please enter your *Withdrawal Order ID*.\n\n" .
                "You can find it in your Withdrawal History.\n\n" .
                "📝 Send your Order ID below:"
        ];
    }

    if (preg_match('/order|transaction|utr|order id|order number/i', $lowerMessage)) {
        firebase_write('chats/' . $chatKey . '/awaiting', 'general_order');
        return ['text' => "🎫 Please send your *Order ID / Transaction ID* to check the status."];
    }

    if (preg_match('/^(hi|hii|hiii|hello|hey|helo|namaste|namaskar)/i', $lowerMessage)) {
        return [
            'text' =>
                "👋 Hello! Welcome to *3 WIN Support*.\n\n" .
                "I can help with:\n\n" .
                "• 💳 Deposit / Recharge\n" .
                "• 💰 Withdrawal\n" .
                "• 🎮 Game Rules\n" .
                "• 💼 Balance\n\n" .
                "Tell me your issue."
        ];
    }

    if (preg_match('/balance|wallet|paisa kitna|my money|amount/i', $lowerMessage)) {
        if (!empty($phone)) {
            $user = firebase_read('users/' . $phone);
            $balance = is_array($user) && isset($user['balance']) ? $user['balance'] : 0;
            return ['text' => "💼 Your current wallet balance is: *₹" . $balance . "*"];
        }
        return ['text' => "🔐 Please login to check your wallet balance."];
    }

    if (preg_match('/rule|rules|how to play|kaise khel|game/i', $lowerMessage)) {
        return [
            'text' =>
                "🎮 *3 WIN Game Rules*\n\n" .
                "1️⃣ Select your color or number.\n" .
                "2️⃣ Enter your bet amount.\n" .
                "3️⃣ Wait for the round result.\n" .
                "4️⃣ Winning amount is automatically added to wallet.\n\n" .
                "For a specific issue, type *deposit* or *withdrawal*."
        ];
    }

    if (preg_match('/human|agent|admin|support|baat kar|talk/i', $lowerMessage)) {
        firebase_write('chats/' . $chatKey . '/human_requested', true);
        return [
            'text' =>
                "👨‍💼 Your message has been sent to the 3 WIN support team.\n\n" .
                "Please wait. A live agent will reply here soon.",
            'notify_admin' => true
        ];
    }

    firebase_write('chats/' . $chatKey . '/human_requested', true);
    return [
        'text' =>
            "📨 Your message has been received.\n\n" .
            "For faster help, type:\n\n" .
            "• *Deposit* — Deposit issue\n" .
            "• *Withdrawal* — Withdrawal issue\n" .
            "• *Rules* — Game rules\n\n" .
            "A support agent can also reply here soon.",
        'notify_admin' => true
    ];
}

// ============ AJAX HANDLERS ============
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['chat_action'])) {
    header('Content-Type: application/json');

    if ($_POST['chat_action'] === 'send_message') {
        $message = trim($_POST['message'] ?? '');
        $imageData = $_POST['image_data'] ?? '';
        $chatKeyPost = $_POST['chat_key'] ?? '';

        if (empty($message) && empty($imageData)) { echo json_encode(['success' => false]); exit; }

        // Security: only current session's chat allowed
        if (!is_string($chatKeyPost) || $chatKeyPost === '' || $chatKeyPost !== $chatKey) {
            echo json_encode(['success' => false, 'message' => 'Invalid or unauthorized chat session.']);
            exit;
        }

        $msgId = 'msg_' . time() . '_' . mt_rand(1000, 9999);
        $userMsg = [
            'id' => $msgId,
            'sender' => 'user',
            'text' => $message,
            'image' => $imageData,
            'timestamp' => time(),
            'time_formatted' => date('h:i A, d M')
        ];
        firebase_write("chats/" . $chatKeyPost . "/messages/" . $msgId, $userMsg);
        firebase_write("chats/" . $chatKeyPost . "/last_active", time());

        $existingChat = firebase_read("chats/" . $chatKeyPost);
        $adminMsg = $userMsg;
        $adminMsg['from_phone'] = $existingChat['phone'] ?? 'guest';
        $adminMsg['chat_key'] = $chatKeyPost;
        firebase_write("admin_inbox/" . $msgId, $adminMsg);

        $botReply = null;
        if (!empty($message)) {
            $botResponse = botProcess($message, $chatKeyPost, $phone);
            $botMsgId = 'bot_' . (time() + 1) . '_' . mt_rand(1000, 9999);
            $botReply = [
                'id' => $botMsgId,
                'sender' => 'bot',
                'text' => $botResponse['text'],
                'image' => '',
                'timestamp' => time() + 1,
                'time_formatted' => date('h:i A, d M')
            ];
            firebase_write("chats/" . $chatKeyPost . "/messages/" . $botMsgId, $botReply);

            $adminBotMsg = $botReply;
            $adminBotMsg['from_phone'] = 'BOT';
            $adminBotMsg['chat_key'] = $chatKeyPost;
            $adminBotMsg['user_phone'] = $existingChat['phone'] ?? 'guest';
            firebase_write("admin_inbox/" . $botMsgId, $adminBotMsg);
        }

        echo json_encode(['success' => true, 'reply' => $botReply]);
        exit;
    }

    if ($_POST['chat_action'] === 'load_messages') {
        $chatKeyPost = $_POST['chat_key'] ?? '';

        // Security: only current session's chat allowed
        if (!is_string($chatKeyPost) || $chatKeyPost === '' || $chatKeyPost !== $chatKey) {
            echo json_encode(['success' => false, 'message' => 'Invalid or unauthorized chat session.']);
            exit;
        }

        $existingChat = firebase_read("chats/" . $chatKeyPost);
        $messages = $existingChat['messages'] ?? [];
        if (!is_array($messages)) $messages = [];
        if (isset($messages['init'])) unset($messages['init']);

        uasort($messages, function ($a, $b) {
            return ($a['timestamp'] ?? 0) - ($b['timestamp'] ?? 0);
        });

        echo json_encode(['success' => true, 'messages' => array_values($messages)]);
        exit;
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
<title>3 WIN - Support Chat</title>
<style>
@import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap');

* { margin: 0; padding: 0; box-sizing: border-box; -webkit-tap-highlight-color: transparent; }

:root {
    --primary: #6C5CE7;
    --primary-light: #A29BFE;
    --bg-dark: #0F0F1A;
    --bg-card: #1A1A2E;
    --bg-input: #16213E;
    --text-primary: #FFFFFF;
    --text-secondary: #B0B0C8;
    --text-muted: #6C6C8A;
    --success: #00E676;
    --gradient-1: linear-gradient(135deg, #6C5CE7, #A29BFE);
    --gradient-2: linear-gradient(135deg, #00CEC9, #55EFC4);
    --gradient-3: linear-gradient(135deg, #FD79A8, #FDCB6E);
    --gradient-bot: linear-gradient(135deg, #FFA502, #FF6348);
}

html, body { height: 100%; overflow: hidden; }

body {
    font-family: 'Inter', sans-serif;
    background: var(--bg-dark);
    color: var(--text-primary);
    display: flex;
    flex-direction: column;
    position: fixed;
    width: 100%;
    height: 100vh;
    height: 100dvh;
    top: 0; left: 0;
    overflow: hidden;
}

.chat-header {
    background: linear-gradient(135deg, #1A1A2E, #2D2D44);
    border-bottom: 1px solid rgba(108, 92, 231, 0.2);
    flex-shrink: 0;
    z-index: 100;
}

.header-top { display: flex; align-items: center; padding: 12px 16px; gap: 12px; }

.back-btn, .header-menu-btn {
    width: 38px; height: 38px; border-radius: 12px;
    background: rgba(108, 92, 231, 0.15);
    border: 1px solid rgba(108, 92, 231, 0.3);
    display: flex; align-items: center; justify-content: center;
    cursor: pointer; flex-shrink: 0;
}
.back-btn:active, .header-menu-btn:active { transform: scale(0.92); }
.back-btn svg, .header-menu-btn svg { width: 20px; height: 20px; stroke: var(--primary-light); }

.header-info { flex: 1; min-width: 0; }
.header-title { font-size: 17px; font-weight: 700; display: flex; align-items: center; gap: 8px; }
.header-subtitle { font-size: 12px; color: var(--success); display: flex; align-items: center; gap: 5px; margin-top: 2px; }
.online-dot { width: 7px; height: 7px; border-radius: 50%; background: var(--success); animation: pulse-dot 2s infinite; }

@keyframes pulse-dot { 0%,100%{opacity:1;} 50%{opacity:0.4;} }

.assistants-bar { display: flex; gap: 10px; padding: 10px 16px 14px; overflow-x: auto; scrollbar-width: none; }
.assistants-bar::-webkit-scrollbar { display: none; }

.assistant-card {
    display: flex; align-items: center; gap: 10px;
    background: rgba(108,92,231,0.1);
    border: 1px solid rgba(108,92,231,0.25);
    border-radius: 14px; padding: 8px 14px;
    flex-shrink: 0; min-width: 150px; cursor: pointer;
    transition: all 0.3s;
}
.assistant-card.active { background: rgba(108,92,231,0.3); border-color: var(--primary); }
.assistant-card:active { transform: scale(0.96); }

.assistant-avatar { width: 36px; height: 36px; border-radius: 50%; display: flex; align-items: center; justify-content: center; font-size: 18px; position: relative; }
.assistant-avatar.av1 { background: linear-gradient(135deg, #6C5CE7, #A29BFE); }
.assistant-avatar.av2 { background: linear-gradient(135deg, #00CEC9, #55EFC4); }
.assistant-avatar.av3 { background: linear-gradient(135deg, #FD79A8, #FDCB6E); }
.assistant-status-dot { position: absolute; bottom: 0; right: 0; width: 10px; height: 10px; border-radius: 50%; background: var(--success); border: 2px solid var(--bg-card); }
.assistant-name { font-size: 12px; font-weight: 600; white-space: nowrap; }
.assistant-role { font-size: 10px; color: var(--text-muted); white-space: nowrap; }

.chat-id-bar { background: rgba(108, 92, 231, 0.08); padding: 6px 16px; display: flex; align-items: center; gap: 8px; }
.chat-id-label { font-size: 9px; color: var(--text-muted); font-weight: 700; letter-spacing: 0.5px; flex-shrink: 0; }
.chat-id-value { font-size: 9px; color: var(--primary-light); font-family: monospace; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; flex: 1; opacity: 0.7; }
.chat-id-copy { font-size: 14px; cursor: pointer; padding: 2px; flex-shrink: 0; }

.chat-body {
    flex: 1;
    height: 0;
    min-height: 0;
    overflow-y: auto;
    overflow-x: hidden;
    -webkit-overflow-scrolling: touch;
    touch-action: pan-y;
    overscroll-behavior-y: contain;
    padding: 16px;
    display: flex;
    flex-direction: column;
    gap: 12px;
}
.chat-body::-webkit-scrollbar { width: 4px; }
.chat-body::-webkit-scrollbar-thumb { background: rgba(108, 92, 231, 0.4); border-radius: 10px; }

.date-separator { display: flex; align-items: center; gap: 12px; margin: 8px 0; }
.date-separator::before, .date-separator::after { content: ''; flex: 1; height: 1px; background: rgba(108, 92, 231, 0.15); }
.date-separator span { font-size: 11px; color: var(--text-muted); padding: 4px 12px; background: rgba(108, 92, 231, 0.1); border-radius: 20px; }

.message-row { display: flex; gap: 8px; max-width: 85%; animation: msgSlide 0.3s ease; }
.message-row.user { align-self: flex-end; flex-direction: row-reverse; }
.message-row.assistant, .message-row.bot, .message-row.admin { align-self: flex-start; }

@keyframes msgSlide { from{opacity:0;transform:translateY(15px);} to{opacity:1;transform:translateY(0);} }

.msg-avatar { width: 32px; height: 32px; border-radius: 50%; display: flex; align-items: center; justify-content: center; font-size: 15px; flex-shrink: 0; align-self: flex-end; }
.msg-avatar.bot-av { background: var(--gradient-bot); }
.msg-avatar.asst-av { background: var(--gradient-1); }
.msg-avatar.user-av { background: var(--gradient-2); }
.msg-avatar.admin-av { background: linear-gradient(135deg, #FF4757, #FF6B81); }

.msg-bubble { padding: 10px 14px; border-radius: 16px; max-width: 100%; word-wrap: break-word; overflow-wrap: break-word; white-space: pre-wrap; }
.message-row.bot .msg-bubble { background: linear-gradient(135deg, #2D1B00, #3D2500); border: 1px solid rgba(255, 165, 2, 0.3); border-bottom-left-radius: 4px; }
.message-row.assistant .msg-bubble { background: var(--bg-card); border: 1px solid rgba(108, 92, 231, 0.15); border-bottom-left-radius: 4px; }
.message-row.admin .msg-bubble { background: linear-gradient(135deg, #4A1522, #5D1B2A); border: 1px solid rgba(255, 71, 87, 0.4); border-bottom-left-radius: 4px; }
.message-row.user .msg-bubble { background: var(--gradient-1); border-bottom-right-radius: 4px; box-shadow: 0 4px 15px rgba(108, 92, 231, 0.35); }

.msg-sender-label { font-size: 10px; font-weight: 700; margin-bottom: 3px; opacity: 0.9; }
.msg-sender-label.bot { color: #FFA502; }
.msg-sender-label.admin { color: #FF6B81; }

.msg-text { font-size: 14px; line-height: 1.5; word-break: break-word; }
.msg-image { max-width: 220px; max-height: 220px; border-radius: 10px; margin-bottom: 6px; cursor: pointer; object-fit: cover; width: 100%; }
.msg-time { font-size: 10px; opacity: 0.6; margin-top: 4px; text-align: right; }
.message-row.assistant .msg-time, .message-row.bot .msg-time, .message-row.admin .msg-time { text-align: left; }

.typing-indicator { display: none; align-self: flex-start; gap: 8px; align-items: center; }
.typing-indicator.show { display: flex; }
.typing-bubble { background: var(--bg-card); border: 1px solid rgba(255, 165, 2, 0.3); border-radius: 16px; padding: 12px 16px; display: flex; gap: 5px; }
.typing-bubble span { width: 7px; height: 7px; border-radius: 50%; background: #FFA502; animation: typingAnim 1.4s infinite; }
.typing-bubble span:nth-child(2) { animation-delay: 0.2s; }
.typing-bubble span:nth-child(3) { animation-delay: 0.4s; }

@keyframes typingAnim { 0%,60%,100%{transform:translateY(0);opacity:0.4;} 30%{transform:translateY(-6px);opacity:1;} }

.welcome-section { text-align: center; padding: 20px 10px; }
.welcome-icon { width: 70px; height: 70px; border-radius: 50%; background: var(--gradient-1); display: flex; align-items: center; justify-content: center; font-size: 32px; margin: 0 auto 16px; }
.welcome-title { font-size: 18px; font-weight: 700; margin-bottom: 6px; background: var(--gradient-1); -webkit-background-clip: text; -webkit-text-fill-color: transparent; }
.welcome-desc { font-size: 13px; color: var(--text-secondary); line-height: 1.6; max-width: 280px; margin: 0 auto; }

.quick-actions { display: flex; flex-wrap: wrap; gap: 8px; justify-content: center; margin-top: 16px; }
.quick-btn { padding: 8px 16px; border-radius: 20px; background: rgba(108, 92, 231, 0.1); border: 1px solid rgba(108, 92, 231, 0.25); color: var(--primary-light); font-size: 12px; font-weight: 500; cursor: pointer; font-family: 'Inter', sans-serif; }
.quick-btn:active { transform: scale(0.95); }

.chat-input-bar {
    flex-shrink: 0;
    background: linear-gradient(to top, #0F0F1A, rgba(15, 15, 26, 0.98));
    padding: 10px 12px;
    padding-bottom: max(10px, env(safe-area-inset-bottom));
    border-top: 1px solid rgba(108, 92, 231, 0.15);
}

.image-preview-bar { display: none; margin-bottom: 8px; position: relative; width: fit-content; }
.image-preview-bar.show { display: block; }
.image-preview-bar img { width: 70px; height: 70px; border-radius: 12px; object-fit: cover; border: 2px solid var(--primary); }
.image-preview-remove { position: absolute; top: -6px; right: -6px; width: 22px; height: 22px; border-radius: 50%; background: #FF4757; border: none; color: #fff; font-weight: 700; cursor: pointer; }

.input-row { display: flex; align-items: flex-end; gap: 8px; }
.action-btn { width: 42px; height: 42px; border-radius: 14px; border: none; display: flex; align-items: center; justify-content: center; cursor: pointer; flex-shrink: 0; }
.action-btn:active { transform: scale(0.9); }
.attach-btn { background: rgba(108, 92, 231, 0.15); border: 1px solid rgba(108, 92, 231, 0.3); }
.attach-btn svg { width: 20px; height: 20px; stroke: var(--primary-light); }

.input-wrapper { flex: 1; }
.chat-input {
    width: 100%; padding: 11px 15px; border-radius: 16px;
    border: 1px solid rgba(108, 92, 231, 0.25);
    background: var(--bg-input); color: var(--text-primary);
    font-size: 14px; font-family: 'Inter', sans-serif; outline: none; resize: none;
    max-height: 100px; min-height: 42px; line-height: 1.4;
}
.chat-input:focus { border-color: var(--primary); }

.send-btn { background: var(--gradient-1); box-shadow: 0 4px 15px rgba(108, 92, 231, 0.4); }
.send-btn svg { width: 20px; height: 20px; fill: #fff; }

#imageUpload { display: none; }

.image-modal { display: none; position: fixed; inset: 0; background: rgba(0,0,0,0.95); z-index: 9999; align-items: center; justify-content: center; padding: 20px; }
.image-modal.show { display: flex; }
.image-modal img { max-width: 100%; max-height: 80vh; border-radius: 12px; }
.image-modal-close { position: absolute; top: 20px; right: 20px; width: 40px; height: 40px; border-radius: 50%; background: rgba(255,255,255,0.15); border: none; color: #fff; font-size: 20px; cursor: pointer; }

.toast {
    position: fixed; top: 20px; left: 50%;
    transform: translateX(-50%) translateY(-100px);
    background: var(--bg-card); border: 1px solid rgba(108, 92, 231, 0.3);
    padding: 12px 24px; border-radius: 14px; font-size: 13px;
    z-index: 99999; transition: transform 0.4s;
    box-shadow: 0 5px 20px rgba(0,0,0,0.3);
}
.toast.show { transform: translateX(-50%) translateY(0); }

@media (min-width: 500px) {
    body { max-width: 430px; margin: 0 auto; left: 50%; transform: translateX(-50%); border-left: 1px solid rgba(108,92,231,0.1); border-right: 1px solid rgba(108,92,231,0.1); }
}
</style>
</head>
<body>

<div class="chat-header">
    <div class="header-top">
        <div class="back-btn" onclick="history.back()">
            <svg viewBox="0 0 24 24" fill="none" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><polyline points="15 18 9 12 15 6"></polyline></svg>
        </div>
        <div class="header-info">
            <div class="header-title">🏆 3 WIN Support</div>
            <div class="header-subtitle"><span class="online-dot"></span> Bot + 3 Agents Online</div>
        </div>
        <div class="header-menu-btn">
            <svg viewBox="0 0 24 24" fill="none" stroke-width="2" stroke-linecap="round"><circle cx="12" cy="5" r="1"></circle><circle cx="12" cy="12" r="1"></circle><circle cx="12" cy="19" r="1"></circle></svg>
        </div>
    </div>

    <div class="assistants-bar">
        <div class="assistant-card active" onclick="selectAssistant(this, 'Arjun')">
            <div class="assistant-avatar av1">👨‍💼<div class="assistant-status-dot"></div></div>
            <div><div class="assistant-name">Arjun</div><div class="assistant-role">Win Expert</div></div>
        </div>
        <div class="assistant-card" onclick="selectAssistant(this, 'Priya')">
            <div class="assistant-avatar av2">👩‍💻<div class="assistant-status-dot"></div></div>
            <div><div class="assistant-name">Priya</div><div class="assistant-role">Support Lead</div></div>
        </div>
        <div class="assistant-card" onclick="selectAssistant(this, 'Rahul')">
            <div class="assistant-avatar av3">🧑‍🔧<div class="assistant-status-dot"></div></div>
            <div><div class="assistant-name">Rahul</div><div class="assistant-role">VIP Helper</div></div>
        </div>
    </div>

    <div class="chat-id-bar">
        <span class="chat-id-label">Chat ID:</span>
        <span class="chat-id-value"><?php echo htmlspecialchars($chatId); ?></span>
        <span class="chat-id-copy" onclick="copyChatId()">📋</span>
    </div>
</div>

<div class="chat-body" id="chatBody">
    <div class="welcome-section" id="welcomeSection">
        <div class="welcome-icon">💬</div>
        <div class="welcome-title">Welcome to 3 WIN Support!</div>
        <div class="welcome-desc">Ask about deposits, withdrawals, orders, or game rules. Our smart bot + live agents are here 24/7!</div>
        <div class="quick-actions">
            <button class="quick-btn" onclick="sendQuickMsg('Deposit')">💳 Deposit Help</button>
            <button class="quick-btn" onclick="sendQuickMsg('Withdrawal')">💰 Withdrawal</button>
            <button class="quick-btn" onclick="sendQuickMsg('Game rules')">🎮 Game Rules</button>
            <button class="quick-btn" onclick="sendQuickMsg('Balance')">💼 My Balance</button>
        </div>
    </div>
    <div class="typing-indicator" id="typingIndicator">
        <div class="msg-avatar bot-av">🤖</div>
        <div class="typing-bubble"><span></span><span></span><span></span></div>
    </div>
</div>

<div class="image-modal" id="imageModal">
    <button class="image-modal-close" onclick="closeImageModal()">✕</button>
    <img id="imageModalImg" src="" alt="">
</div>

<div class="toast" id="toast"></div>

<div class="chat-input-bar">
    <div class="image-preview-bar" id="imagePreviewBar">
        <img id="imagePreviewImg" src="" alt="">
        <button class="image-preview-remove" onclick="removeImagePreview()">✕</button>
    </div>
    <div class="input-row">
        <button class="action-btn attach-btn" onclick="document.getElementById('imageUpload').click()">
            <svg viewBox="0 0 24 24" fill="none" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="3" width="18" height="18" rx="3"></rect><circle cx="8.5" cy="8.5" r="1.5"></circle><polyline points="21 15 16 10 5 21"></polyline></svg>
        </button>
        <input type="file" id="imageUpload" accept="image/*" onchange="handleImageSelect(event)">
        <div class="input-wrapper">
            <textarea class="chat-input" id="chatInput" placeholder="Type your message..." rows="1" onkeydown="handleEnterKey(event)" oninput="autoResize(this)"></textarea>
        </div>
        <button class="action-btn send-btn" id="sendBtn" onclick="sendMessage()">
            <svg viewBox="0 0 24 24"><path d="M2.01 21L23 12 2.01 3 2 10l15 2-15 2z"/></svg>
        </button>
    </div>
</div>

<script>
const CHAT_KEY = '<?php echo $chatKey; ?>';
const CHAT_ID = '<?php echo $chatId; ?>';
let selectedImage = '';
let messagesLoaded = false;
let lastMessageCount = 0;
let userIsScrolling = false;
let scrollTimeout;

document.addEventListener('DOMContentLoaded', () => {
    loadMessages();
    setInterval(loadMessages, 4000);

    const body = document.getElementById('chatBody');
    body.addEventListener('scroll', () => {
        const nearBottom = body.scrollHeight - body.scrollTop - body.clientHeight < 100;
        userIsScrolling = !nearBottom;
        clearTimeout(scrollTimeout);
        scrollTimeout = setTimeout(() => { if (nearBottom) userIsScrolling = false; }, 1000);
    }, { passive: true });
});

function loadMessages() {
    const formData = new FormData();
    formData.append('chat_action', 'load_messages');
    formData.append('chat_key', CHAT_KEY);

    fetch('chat.php', { method: 'POST', body: formData })
    .then(r => r.json())
    .then(data => {
        if (data.success && data.messages && data.messages.length > 0) {
            document.getElementById('welcomeSection').style.display = 'none';
            const newCount = data.messages.length;
            if (newCount !== lastMessageCount) {
                renderMessages(data.messages);
                lastMessageCount = newCount;
                if (!userIsScrolling) scrollToBottom();
            }
            messagesLoaded = true;
        }
    })
    .catch(() => {});
}

function renderMessages(messages) {
    const body = document.getElementById('chatBody');
    const typing = document.getElementById('typingIndicator');
    body.querySelectorAll('.message-row, .date-separator').forEach(el => el.remove());

    let lastDate = '';
    messages.forEach(msg => {
        const msgDate = new Date((msg.timestamp || 0) * 1000).toDateString();
        if (msgDate !== lastDate) {
            const dateSep = document.createElement('div');
            dateSep.className = 'date-separator';
            const today = new Date().toDateString();
            const label = msgDate === today ? 'Today' : new Date((msg.timestamp || 0) * 1000).toLocaleDateString('en-US', { day: 'numeric', month: 'short', year: 'numeric' });
            dateSep.innerHTML = `<span>${label}</span>`;
            body.insertBefore(dateSep, typing);
            lastDate = msgDate;
        }
        renderSingleMessage(msg, body, typing, false);
    });
}

function renderSingleMessage(msg, body, typing, animate) {
    const row = document.createElement('div');
    let senderClass = msg.sender || 'assistant';
    row.className = 'message-row ' + senderClass;

    let avatarHtml = '';
    let senderLabel = '';
    if (senderClass === 'user') {
        avatarHtml = '<div class="msg-avatar user-av">👤</div>';
    } else if (senderClass === 'bot') {
        avatarHtml = '<div class="msg-avatar bot-av">🤖</div>';
        senderLabel = '<div class="msg-sender-label bot">🤖 3WIN Bot</div>';
    } else if (senderClass === 'admin') {
        avatarHtml = '<div class="msg-avatar admin-av">👨‍💼</div>';
        senderLabel = '<div class="msg-sender-label admin">✅ Support Agent</div>';
    } else {
        avatarHtml = '<div class="msg-avatar asst-av">💼</div>';
    }

    let imageHtml = '';
    if (msg.image && msg.image.length > 20) {
        imageHtml = `<img class="msg-image" src="${msg.image}" onclick="openImageModal('${msg.image}')" alt="">`;
    }
    let textHtml = msg.text ? `<div class="msg-text">${formatText(msg.text)}</div>` : '';
    row.innerHTML = `${avatarHtml}<div class="msg-bubble">${senderLabel}${imageHtml}${textHtml}<div class="msg-time">${msg.time_formatted || ''}</div></div>`;
    if (!animate) row.style.animation = 'none';
    body.insertBefore(row, typing);
}

function formatText(text) {
    text = escapeHtml(text);
    text = text.replace(/\*(.+?)\*/g, '<b>$1</b>');
    text = text.replace(/`(.+?)`/g, '<code style="background:rgba(255,255,255,0.15);padding:2px 6px;border-radius:4px;">$1</code>');
    text = text.replace(/\n/g, '<br>');
    return text;
}

function sendMessage() {
    const input = document.getElementById('chatInput');
    const text = input.value.trim();
    const image = selectedImage;
    if (!text && !image) return;

    document.getElementById('welcomeSection').style.display = 'none';
    addMessageToUI('user', text, image);
    input.value = '';
    input.style.height = '42px';
    removeImagePreview();
    showTyping();
    userIsScrolling = false;
    scrollToBottom();

    const formData = new FormData();
    formData.append('chat_action', 'send_message');
    formData.append('chat_key', CHAT_KEY);
    formData.append('message', text);
    formData.append('image_data', image);

    fetch('chat.php', { method: 'POST', body: formData })
    .then(r => r.json())
    .then(data => {
        setTimeout(() => {
            hideTyping();
            if (data.reply) {
                addMessageToUI(data.reply.sender || 'bot', data.reply.text, '');
                lastMessageCount++;
            }
            lastMessageCount++;
        }, 1200);
    })
    .catch(() => { hideTyping(); showToast('Send failed'); });
}

function addMessageToUI(sender, text, image) {
    const body = document.getElementById('chatBody');
    const typing = document.getElementById('typingIndicator');
    if (!body.querySelector('.date-separator')) {
        const dateSep = document.createElement('div');
        dateSep.className = 'date-separator';
        dateSep.innerHTML = '<span>Today</span>';
        body.insertBefore(dateSep, typing);
    }
    const now = new Date();
    const timeStr = now.toLocaleTimeString('en-US', { hour: 'numeric', minute: '2-digit', hour12: true }) + ', ' + now.toLocaleDateString('en-US', { day: 'numeric', month: 'short' });
    renderSingleMessage({ sender, text, image, time_formatted: timeStr, timestamp: Math.floor(now.getTime()/1000) }, body, typing, true);
    if (!userIsScrolling) scrollToBottom();
}

function sendQuickMsg(text) {
    document.getElementById('chatInput').value = text;
    sendMessage();
}

function handleEnterKey(e) {
    if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); sendMessage(); }
}

function autoResize(el) {
    el.style.height = '42px';
    el.style.height = Math.min(el.scrollHeight, 100) + 'px';
}

function handleImageSelect(e) {
    const file = e.target.files[0];
    if (!file) return;
    if (file.size > 2 * 1024 * 1024) { showToast('Max 2MB'); return; }
    const reader = new FileReader();
    reader.onload = function(ev) {
        selectedImage = ev.target.result;
        document.getElementById('imagePreviewImg').src = selectedImage;
        document.getElementById('imagePreviewBar').classList.add('show');
    };
    reader.readAsDataURL(file);
    e.target.value = '';
}

function removeImagePreview() {
    selectedImage = '';
    document.getElementById('imagePreviewBar').classList.remove('show');
}

function openImageModal(src) {
    document.getElementById('imageModalImg').src = src;
    document.getElementById('imageModal').classList.add('show');
}
function closeImageModal() { document.getElementById('imageModal').classList.remove('show'); }

function showTyping() { document.getElementById('typingIndicator').classList.add('show'); if (!userIsScrolling) scrollToBottom(); }
function hideTyping() { document.getElementById('typingIndicator').classList.remove('show'); }

function scrollToBottom() {
    const body = document.getElementById('chatBody');
    requestAnimationFrame(() => { body.scrollTop = body.scrollHeight; });
}

function selectAssistant(el, name) {
    document.querySelectorAll('.assistant-card').forEach(c => c.classList.remove('active'));
    el.classList.add('active');
    showToast('Connected to ' + name + ' ✨');
}

function copyChatId() {
    if (navigator.clipboard) navigator.clipboard.writeText(CHAT_ID).then(() => showToast('Copied!'));
    else {
        const ta = document.createElement('textarea');
        ta.value = CHAT_ID; document.body.appendChild(ta); ta.select();
        try { document.execCommand('copy'); showToast('Copied!'); } catch(e){}
        document.body.removeChild(ta);
    }
}

function showToast(msg) {
    const t = document.getElementById('toast');
    t.textContent = msg; t.classList.add('show');
    setTimeout(() => t.classList.remove('show'), 2500);
}

function escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}

document.getElementById('imageModal').addEventListener('click', function(e) {
    if (e.target === this) closeImageModal();
});
</script>
</body>
</html>