<?php
if (session_status() === PHP_SESSION_NONE) session_start();
error_reporting(0);
date_default_timezone_set('Asia/Kolkata');
require_once 'config.php';

$phone = $_SESSION['user_phone'] ?? $_SESSION['phone'] ?? '';
if ($phone === '') { header('Location: index.php'); exit; }
$_SESSION['user_phone'] = $phone;
$_SESSION['phone'] = $phone;

function ms() { return round(microtime(true) * 1000); }
function jsonOut($d) { 
    if (!headers_sent()) header('Content-Type: application/json'); 
    echo json_encode($d); exit; 
}

const BET_MS = 5000;
const END_MS = 3000;
const GROWTH = 0.13;

function riggedCrash($totalBet) {
    if ($totalBet <= 0) return round(1.00 + mt_rand(0, 900) / 100, 2);
    if (mt_rand(1, 100) <= 75) {
        return round(1.00 + mt_rand(0, 90) / 100, 2);
    }
    return round(2.00 + mt_rand(0, 800) / 100, 2);
}

function crashTimeMs($c) {
    return min(60000, round(log($c) / GROWTH * 1000));
}

function makeBots($crash) {
    $names = ["galy","kub","gaf","Raj","Priya","Amit","Neha","Vik","Sonu","Karan","Isha","Ravi","Pooja","Rahul"];
    $n = 4 + mt_rand(0, 6);
    $bots = [];
    for ($i = 0; $i < $n; $i++) {
        $amt = round(1 + mt_rand(0, 900) / 100, 2);
        $cashAt = round(1.15 + mt_rand(0, max(10, ($crash - 0.5) * 100)) / 100, 2);
        if ($cashAt >= $crash) $cashAt = 0;
        $bots[] = [
            'name' => $names[mt_rand(0, count($names)-1)],
            'amount' => $amt,
            'cashAt' => $cashAt,
            'cashed' => false
        ];
    }
    return $bots;
}

function ensureRound() {
    $now = ms();
    $cur = firebase_read('gorush/current');
    
    $needsNew = false;
    if (!is_array($cur)) {
        $needsNew = true;
    } else {
        $endTs = $cur['end_ts'] ?? null;
        if ($endTs !== null && $now > $endTs) {
            $needsNew = true;
        }
    }

    if ($needsNew) {
        $prevId = (int)($cur['id'] ?? 100000);
        $cur = [
            'id' => $prevId + 1,
            'bet_start' => $now,
            'flight_start' => null,
            'crash' => null,
            'end_ts' => null,
            'bots' => null,
            'bets' => []
        ];
        firebase_write('gorush/current', $cur);
    }

    if ($cur['flight_start'] === null && $now >= $cur['bet_start'] + BET_MS) {
        $bets = $cur['bets'] ?? [];
        $totalBet = 0;
        if (is_array($bets)) {
            foreach ($bets as $b) $totalBet += (float)($b['amount'] ?? 0);
        }
        $crash = riggedCrash($totalBet);
        $T = crashTimeMs($crash);
        $cur['crash'] = $crash;
        $cur['flight_start'] = $now;
        $cur['end_ts'] = $now + $T + END_MS;
        $cur['bots'] = makeBots($crash);
        firebase_write('gorush/current', $cur);

        $h = firebase_read('gorush/history');
        $h = is_array($h) ? $h : [];
        array_unshift($h, $crash);
        $h = array_slice($h, 0, 24);
        firebase_write('gorush/history', $h);
    }
    return $cur;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    
    if ($action === 'get_state') {
        $cur = ensureRound();
        $now = ms();
        $phase = 'countdown';
        if ($cur['flight_start'] !== null) {
            $phase = ($now < $cur['end_ts'] - END_MS) ? 'flying' : 'crashed';
        }
        $bets = $cur['bets'] ?? [];
        if (!is_array($bets)) $bets = [];
        $myBet = null;
        foreach ($bets as $id => $b) {
            if (($b['phone'] ?? '') === $phone) {
                $myBet = array_merge($b, ['id' => $id]);
                break;
            }
        }
        $realBets = [];
        foreach ($bets as $id => $b) {
            $p = (string)($b['phone'] ?? '');
            $realBets[] = [
                'name' => substr($p, 0, 1) . '***' . substr($p, -1),
                'amount' => (float)($b['amount'] ?? 0),
                'cashed' => ($b['status'] ?? '') === 'cashed',
                'cx' => (float)($b['cx'] ?? 0),
                'is_me' => $p === $phone,
                'panel' => (int)($b['panel'] ?? 0)
            ];
        }
        jsonOut([
            'success' => true,
            'server_ts' => $now,
            'round' => $cur,
            'bet_end' => $cur['bet_start'] + BET_MS,
            'phase' => $phase,
            'my_bet' => $myBet,
            'real_bets' => $realBets,
            'bots' => $cur['bots'] ?? []
        ]);
    }
    
    if ($action === 'place_bet') {
        $amount = (float)($_POST['amount'] ?? 0);
        $panel = (int)($_POST['panel'] ?? 0);
        if ($amount < 1) jsonOut(['success' => false, 'message' => 'Minimum bet ₹1!']);
        $cur = ensureRound();
        if ($cur['flight_start'] !== null) jsonOut(['success' => false, 'message' => 'Round started! Wait for next.']);
        $bets = $cur['bets'] ?? [];
        if (is_array($bets)) {
            foreach ($bets as $b) {
                if (($b['phone'] ?? '') === $phone && ($b['status'] ?? '') === 'active' && ($b['panel'] ?? 0) === $panel) {
                    jsonOut(['success' => false, 'message' => 'Already have active bet on this panel']);
                }
            }
        }
        $user = firebase_read("users/" . $phone);
        $bal = (float)($user['balance'] ?? 0);
        if ($amount > $bal) jsonOut(['success' => false, 'message' => 'Insufficient balance!']);
        $betId = 'b_' . uniqid();
        $cur['bets'][$betId] = [
            'phone' => $phone,
            'panel' => $panel,
            'amount' => $amount,
            'status' => 'active',
            'cx' => 0,
            'ts' => ms()
        ];
        firebase_write('gorush/current', $cur);
        firebase_write("users/$phone/balance", round($bal - $amount, 2));
        jsonOut(['success' => true, 'bet_id' => $betId, 'balance' => round($bal - $amount, 2)]);
    }
    
    if ($action === 'cancel_bet') {
        $panel = (int)($_POST['panel'] ?? 0);
        $cur = ensureRound();
        if ($cur['flight_start'] !== null) jsonOut(['success' => false, 'message' => 'Cannot cancel now']);
        $bets = $cur['bets'] ?? [];
        $found = null; $foundId = null;
        if (is_array($bets)) {
            foreach ($bets as $id => $b) {
                if (($b['phone'] ?? '') === $phone && ($b['status'] ?? '') === 'active' && ($b['panel'] ?? 0) === $panel) {
                    $found = $b; $foundId = $id; break;
                }
            }
        }
        if (!$found) jsonOut(['success' => false, 'message' => 'No bet to cancel']);
        unset($cur['bets'][$foundId]);
        firebase_write('gorush/current', $cur);
        $user = firebase_read("users/" . $phone);
        $bal = (float)($user['balance'] ?? 0) + (float)$found['amount'];
        firebase_write("users/$phone/balance", round($bal, 2));
        jsonOut(['success' => true, 'balance' => round($bal, 2)]);
    }
    
    if ($action === 'cash_out') {
        $panel = (int)($_POST['panel'] ?? 0);
        $cur = ensureRound();
        $now = ms();
        if ($cur['flight_start'] === null) jsonOut(['success' => false, 'message' => 'No live round']);
        $elapsed = ($now - $cur['flight_start']) / 1000;
        $m = round(exp(GROWTH * $elapsed), 2);
        if ($m >= $cur['crash']) jsonOut(['success' => false, 'message' => 'Flew away!']);
        $bets = $cur['bets'] ?? [];
        $found = null; $foundId = null;
        if (is_array($bets)) {
            foreach ($bets as $id => $b) {
                if (($b['phone'] ?? '') === $phone && ($b['status'] ?? '') === 'active' && ($b['panel'] ?? 0) === $panel) {
                    $found = $b; $foundId = $id; break;
                }
            }
        }
        if (!$found) jsonOut(['success' => false, 'message' => 'No active bet']);
        $win = (float)$found['amount'] * $m;
        $cur['bets'][$foundId]['status'] = 'cashed';
        $cur['bets'][$foundId]['cx'] = $m;
        firebase_write('gorush/current', $cur);
        $user = firebase_read("users/" . $phone);
        $newBal = (float)($user['balance'] ?? 0) + $win;
        firebase_write("users/$phone/balance", round($newBal, 2));
        jsonOut(['success' => true, 'mult' => $m, 'win' => round($win, 2), 'balance' => round($newBal, 2)]);
    }
    
    if ($action === 'get_history') {
        $h = firebase_read('gorush/history');
        jsonOut(['success' => true, 'history' => is_array($h) ? $h : []]);
    }
    
    if ($action === 'get_balance') {
        $u = firebase_read("users/" . $phone);
        jsonOut(['success' => true, 'balance' => round((float)($u['balance'] ?? 0), 2)]);
    }
    
    jsonOut(['success' => false, 'message' => 'Unknown action']);
}

$user = firebase_read("users/" . $phone);
$balance = (float)($user['balance'] ?? 0);
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
<title>GoRush Live</title>
<style>
*{margin:0;padding:0;box-sizing:border-box;-webkit-tap-highlight-color:transparent}
body{background:#070b18;color:#fff;font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,Arial,sans-serif;overflow-x:hidden;min-height:100vh;user-select:none}

/* ===== TOP BAR ===== */
.top{height:56px;background:#090d20;display:flex;align-items:center;justify-content:space-between;padding:8px 12px;gap:8px}
.back{width:34px;height:34px;border:0;background:transparent;color:#fff;font-size:30px;line-height:30px;cursor:pointer}
.balance{height:40px;flex:1;max-width:220px;background:linear-gradient(180deg,#1d2c6d,#121a43);border:1px solid #334287;border-radius:22px;display:flex;align-items:center;justify-content:center;gap:8px}
.coin{width:30px;height:30px;border-radius:50%;background:radial-gradient(circle at 35% 25%,#fff3a0,#ffc107 55%,#ff8f00);color:#795000;font-weight:900;display:flex;align-items:center;justify-content:center;box-shadow:0 0 8px rgba(255,193,7,.55)}
.balance span{font-size:17px;font-weight:800}
.top-actions{display:flex;gap:8px;align-items:center}
.round-btn{width:36px;height:36px;border-radius:50%;border:2px solid #334287;background:#121a43;color:#fff;font-size:18px;cursor:pointer}
.avatar{width:38px;height:38px;border-radius:50%;background:radial-gradient(circle at 35% 30%,#7dd3fc,#0ea5e9 55%,#1d4ed8);border:2px solid #bae6fd;display:flex;align-items:center;justify-content:center;font-size:17px}

/* ===== LOGO ROW ===== */
.logo-wrap{height:48px;background:#070b18;display:flex;align-items:center;justify-content:center;position:relative;padding:0 12px}
.logo{font-size:32px;font-weight:1000;font-style:italic;background:linear-gradient(180deg,#ffe76b 0%,#ff8a00 55%,#ff4b00 100%);-webkit-background-clip:text;-webkit-text-fill-color:transparent;filter:drop-shadow(0 2px 6px rgba(255,98,0,.45))}
.logo-rocket{position:absolute;font-size:16px;left:50%;margin-left:26px;top:4px;transform:rotate(-20deg)}
.live-badge{position:absolute;left:12px;top:12px;padding:3px 8px;border-radius:10px;background:#b71c1c;color:#ff8a80;font-size:9px;font-weight:900;animation:pulse 1.5s infinite}
@keyframes pulse{0%,100%{opacity:1}50%{opacity:.55}}
.bal-chip{position:absolute;right:12px;top:8px;background:#0a102c;border:1px solid #3b82f6;border-radius:18px;padding:6px 16px;font-weight:900;font-size:14px;color:#fff;box-shadow:0 0 10px rgba(59,130,246,.35)}

/* ===== HISTORY ===== */
.history-box{background:#0d1430;padding:10px 8px;border-top:1px solid rgba(255,255,255,.03);border-bottom:1px solid rgba(255,255,255,.04);position:relative}
.history{display:grid;grid-template-columns:repeat(8,1fr);gap:7px 4px}
.h{text-align:center;font-size:12.5px;font-weight:900;line-height:16px;text-shadow:0 0 8px currentColor}
.h.low{color:#4db8ff}.h.mid{color:#b06bff}.h.high{color:#ff3d67}
.hist-tools{position:absolute;right:8px;top:-2px;background:#101a3d;border:1px solid #2d4285;border-radius:14px;padding:3px 10px;color:#ff5b5b;font-size:12px;font-weight:900}

/* ===== GAME ===== */
.game{position:relative;height:320px;overflow:hidden;background:radial-gradient(circle at 50% 30%,rgba(64,86,180,.35),transparent 45%),radial-gradient(circle at 80% 80%,rgba(83,65,180,.25),transparent 40%),linear-gradient(180deg,#0a1436 0%,#0d0c31 48%,#081220 100%)}
.game.crashed{background:radial-gradient(circle at 50% 35%,rgba(255,104,0,.35),transparent 36%),linear-gradient(180deg,#2a0804 0%,#16050c 55%,#090611 100%)}
.star{position:absolute;background:#fff;border-radius:50%;animation:twinkle 1.6s infinite alternate}
@keyframes twinkle{from{opacity:.2}to{opacity:1}}
#trail{position:absolute;inset:0;z-index:5;pointer-events:none}
.max{position:absolute;left:10px;top:8px;z-index:6;color:#40b6ff;font-size:11px;font-weight:1000;line-height:12px;opacity:.8}
.mult{position:absolute;top:14px;left:0;right:0;text-align:center;z-index:8;font-size:68px;font-weight:1000;font-style:italic;color:#fff;display:none;text-shadow:0 0 16px rgba(160,120,255,.95),0 0 46px rgba(120,90,255,.5),0 2px 0 #b28bff}
.mult.crash{background:linear-gradient(180deg,#ffe866,#ff7b00 38%,#ff1988 100%);-webkit-background-clip:text;-webkit-text-fill-color:transparent;-webkit-text-stroke:1.5px #fff;text-shadow:none;filter:drop-shadow(0 0 13px rgba(255,31,129,.75))}
.flight-over{position:absolute;top:94px;left:0;right:0;text-align:center;z-index:9;display:none;font-size:22px;font-weight:1000;letter-spacing:2px;color:#ffd54f;text-shadow:0 0 14px rgba(255,213,79,.9)}
.rocket{position:absolute;left:6%;bottom:14%;width:150px;height:150px;display:none;z-index:7;transform:translate(-50%,50%)}
.rocket.fly{transition:left .9s cubic-bezier(.45,0,1,1),bottom .9s cubic-bezier(.45,0,1,1),opacity .9s ease}
.rocket img{width:150px;height:150px;object-fit:contain;transform:rotate(8deg);filter:drop-shadow(0 0 22px rgba(255,132,0,.95))}
.sat{position:absolute;right:12%;top:36%;font-size:46px;z-index:4;display:none;filter:drop-shadow(0 0 12px #40c4ff);animation:floaty 3s ease-in-out infinite alternate}
@keyframes floaty{from{transform:translateY(0)}to{transform:translateY(-10px)}}
.planet{position:absolute;left:50%;bottom:-34px;transform:translateX(-50%);width:130px;height:78px;border-radius:50%;background:radial-gradient(circle at 38% 30%,#584977,#211837 70%);z-index:3;box-shadow:0 -6px 24px rgba(90,70,160,.35)}
.planet:after{content:"";position:absolute;left:-28px;top:42px;width:180px;height:28px;border:3px solid rgba(156,130,220,.34);border-radius:50%}
.left-tabs{position:absolute;left:0;top:110px;display:flex;flex-direction:column;gap:8px;z-index:10}
.tab-jili{border:2px solid #8a6b15;border-left:0;border-radius:0 12px 12px 0;background:linear-gradient(180deg,#2a210a,#120d04);color:#ffd54f;font-weight:1000;padding:10px 7px;writing-mode:vertical-rl;letter-spacing:2px;cursor:pointer}
.tab-gear{width:42px;height:42px;border:2px solid #8a6b15;border-left:0;border-radius:0 12px 12px 0;background:linear-gradient(180deg,#2a210a,#120d04);color:#ffd54f;font-size:19px;cursor:pointer}

/* ===== CASH FEED (max 10) ===== */
.cash-list{position:absolute;right:8px;top:105px;z-index:12;display:flex;flex-direction:column;gap:6px;align-items:flex-end;pointer-events:none}
.cash-item{display:flex;align-items:center;gap:6px;background:rgba(19,31,78,.85);border:1px solid #36519b;border-radius:18px;padding:4px 10px 4px 4px;animation:cashIn .18s ease}
@keyframes cashIn{from{opacity:0;transform:translateX(30px)}to{opacity:1;transform:translateX(0)}}
.cash-coin{width:24px;height:24px;border-radius:50%;background:radial-gradient(circle at 35% 25%,#fff3a0,#ffc107 55%,#ff8f00);color:#795000;font-size:11px;font-weight:1000;display:flex;align-items:center;justify-content:center}
.cash-text{font-size:12px;font-weight:800;color:#d9e2ff}
.cash-win{color:#67ff9a;font-size:11px;font-weight:1000}

/* ===== COUNTDOWN ===== */
.countdown{position:absolute;inset:0;background:rgba(7,11,24,.88);z-index:20;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:14px}
.countdown.hide{display:none}
.loader{width:68px;height:68px;border:3px dashed rgba(79,195,247,.55);border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:28px;animation:spin 2.4s linear infinite}
@keyframes spin{to{transform:rotate(360deg)}}
.cbar{width:260px;height:12px;border:1px solid #2d4285;border-radius:9px;overflow:hidden;background:#101943}
.cfill{height:100%;width:0%;background:linear-gradient(90deg,#00bcd4,#4fc3f7)}
.ctext{color:#58c5ff;font-size:15px;font-weight:800;font-style:italic}
.ctext b{color:#69f0ae;font-size:19px;margin-left:6px}

/* ===== BET AREA ===== */
.bet-area{background:#090d20;padding:12px 10px 6px}
.bet-box{display:grid;grid-template-columns:1fr 78px;gap:9px;margin-bottom:9px}
.main-bet{border:0;border-radius:12px;background:linear-gradient(180deg,#91ee55,#45b92b);padding:12px;min-height:92px;display:flex;flex-direction:column;gap:10px;justify-content:center;box-shadow:0 4px 14px rgba(0,0,0,.4),inset 0 2px 0 rgba(255,255,255,.35);cursor:pointer;transition:transform .1s,filter .15s}
.main-bet:active{transform:scale(.97);filter:brightness(1.1)}
.main-bet .label{text-align:center;font-size:24px;font-weight:1000;color:#0d5b15;text-shadow:0 1px 0 rgba(255,255,255,.3)}
.main-bet .amount{background:rgba(0,50,0,.28);border-radius:8px;padding:9px;text-align:center;font-size:22px;font-weight:1000;color:#fff}
.main-bet.state-queued{background:linear-gradient(180deg,#42a5f5,#1565c0)}
.main-bet.state-queued .label{color:#fff}
.main-bet.state-active{background:linear-gradient(180deg,#ffc12e,#f57c00);box-shadow:0 0 18px rgba(255,152,0,.5)}
.main-bet.state-active .label{color:#603000}
.main-bet.state-active .amount{background:rgba(255,255,255,.16);color:#fff7c2}
.main-bet.state-cashed{background:linear-gradient(180deg,#66bb6a,#2e7d32)}
.main-bet.state-cashed .label,.main-bet.state-cashed .amount{color:#fff}
.main-bet.state-lost{background:linear-gradient(180deg,#ef5350,#b71c1c)}
.main-bet.state-lost .label,.main-bet.state-lost .amount{color:#fff}
.bet-side{border:0;border-radius:12px;background:linear-gradient(180deg,#2c4c9c,#1d3468);color:#9fc4ff;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:4px;font-size:14px;font-weight:1000;cursor:pointer;box-shadow:0 4px 12px rgba(0,0,0,.4)}
.bet-side:active{transform:scale(.95)}
.bet-side svg{width:26px;height:26px;fill:#9fc4ff}
.auto-row{display:flex;align-items:center;gap:8px;margin-bottom:14px}
.auto-row label{color:#9fc4ff;font-size:14px;font-weight:900;white-space:nowrap}
.auto-val{flex:1;height:44px;border-radius:8px;border:1px solid #2d4285;background:#142151;color:#83b7ff;display:flex;align-items:center;justify-content:center;font-size:18px;font-weight:1000;cursor:pointer}
.small-btn{width:44px;height:44px;border-radius:8px;border:1px solid #2d4285;background:#142151;color:#83b7ff;font-size:18px;cursor:pointer}
.repeat{width:74px;height:44px;border-radius:8px;border:1px solid #2d4285;background:#24418f;color:#83b7ff;font-size:20px;cursor:pointer}
.footer{background:#090d20;display:flex;justify-content:flex-end;align-items:center;gap:6px;color:#c5d3ff;font-size:12px;padding:6px 12px 10px}

/* ===== MODALS / TOAST ===== */
.modal{position:fixed;inset:0;background:rgba(0,0,0,.75);z-index:99;display:none;align-items:center;justify-content:center;padding:20px}
.modal.show{display:flex}
.modal-box{width:100%;max-width:310px;background:#141d4d;border:2px solid #2d4285;border-radius:14px;padding:20px}
.modal-title{text-align:center;color:#83b7ff;font-size:18px;font-weight:1000;margin-bottom:14px}
.modal-input{width:100%;height:48px;background:#090d20;border:1px solid #2d4285;border-radius:9px;color:#fff;text-align:center;font-size:22px;font-weight:1000;outline:none;margin-bottom:12px}
.modal-btns{display:flex;gap:8px}
.modal-btns button{flex:1;height:42px;border:0;border-radius:8px;color:#fff;font-weight:1000;font-size:15px;cursor:pointer}
.cancel{background:#e53935}.ok{background:#43a047}
.toast{position:fixed;top:70px;left:50%;transform:translateX(-50%);background:rgba(0,0,0,.92);border:1px solid #2d4285;border-radius:9px;padding:10px 18px;color:#fff;z-index:200;display:none;font-size:13px;font-weight:800;white-space:nowrap}
.toast.show{display:block}
@media(max-width:380px){
  .game{height:290px}
  .mult{font-size:56px}
  .rocket,.rocket img{width:120px;height:120px}
}
</style>
</head>
<body>

<div class="top">
  <button class="back" onclick="location.href='dashboard.php'">‹</button>
  <div class="balance"><div class="coin">$</div><span id="balanceTop">₹<?=number_format($balance,2)?></span></div>
  <div class="top-actions">
    <button class="round-btn" onclick="location.href='deposit.php'">+</button>
    <div class="avatar">🙂</div>
  </div>
</div>

<div class="logo-wrap">
  <div class="live-badge">LIVE</div>
  <div class="logo">GoRush</div>
  <div class="logo-rocket">🚀</div>
  <div class="bal-chip" id="balChip">₹<?=number_format($balance,2)?></div>
</div>

<div class="history-box">
  <div class="history" id="history"></div>
  <div class="hist-tools">🕐 ▼</div>
</div>

<div class="game" id="game">
  <div class="max">500x<br>MAX</div>
  <canvas id="trail"></canvas>
  <div class="mult" id="mult">1.00x</div>
  <div class="flight-over" id="flightOver">FLIGHT IS OVER</div>
  <div class="sat" id="sat">🛰️</div>
  <div class="rocket" id="rocket"><img src="https://i.ibb.co/zT7NXZgf/file-00000000b6b481f5b10209abb9b239c9.png" alt="rocket"></div>
  <div class="planet"></div>
  <div class="left-tabs">
    <button class="tab-jili" onclick="showToast('JILI Games')">JILI</button>
    <button class="tab-gear" onclick="showToast('Settings')">⚙️</button>
    <button class="tab-gear" onclick="location.href='dashboard.php'">🏠</button>
  </div>
  <div class="cash-list" id="cashList"></div>
  <div class="countdown" id="countdown">
    <div class="loader">🚀</div>
    <div class="cbar"><div class="cfill" id="cfill"></div></div>
    <div class="ctext">Waiting for next round...<b id="sec">5s</b></div>
  </div>
</div>

<div class="bet-area">
  <div class="bet-box">
    <button class="main-bet" id="btn0" onclick="mainBet(0)">
      <div class="label" id="label0">Start ↻</div>
      <div class="amount" id="amount0">₹1.00</div>
    </button>
    <button class="bet-side" onclick="openBetModal(0)"><svg viewBox="0 0 24 24"><path d="M12 3l7 3v2H5V6l7-3zm-7 7h14v2H5v-2zm0 4h14v2H5v-2zm0 4h14v2H5v-2z"/></svg><span>Bet</span></button>
  </div>
  <div class="auto-row">
    <label>Auto Cash Out</label>
    <div class="auto-val" id="auto0" onclick="openAutoModal(0)">3.00X</div>
    <button class="small-btn" onclick="openAutoModal(0)"></button>
    <button class="repeat" onclick="repeatBet(0)">🔄</button>
  </div>
  <div class="bet-box">
    <button class="main-bet" id="btn1" onclick="mainBet(1)">
      <div class="label" id="label1">Start ↻</div>
      <div class="amount" id="amount1">₹1.00</div>
    </button>
    <button class="bet-side" onclick="openBetModal(1)"><svg viewBox="0 0 24 24"><path d="M12 3l7 3v2H5V6l7-3zm-7 7h14v2H5v-2zm0 4h14v2H5v-2zm0 4h14v2H5v-2z"/></svg><span>Bet</span></button>
  </div>
  <div class="auto-row">
    <label>Auto Cash Out</label>
    <div class="auto-val" id="auto1" onclick="openAutoModal(1)">3.00X</div>
    <button class="small-btn" onclick="openAutoModal(1)">⚙</button>
    <button class="repeat" onclick="repeatBet(1)">🔄</button>
  </div>
</div>

<div class="footer"><span id="roundId">—</span> <span style="color:#4caf50">⌁</span> <span id="pingDisplay">120</span>ms</div>

<div class="modal" id="betModal">
  <div class="modal-box">
    <div class="modal-title">💰 Set Bet Amount</div>
    <input type="number" class="modal-input" id="betInput" value="1" min="1" step="1">
    <div class="modal-btns"><button class="cancel" onclick="closeModals()">Cancel</button><button class="ok" onclick="saveBet()">Confirm</button></div>
  </div>
</div>
<div class="modal" id="autoModal">
  <div class="modal-box">
    <div class="modal-title">⚙️ Auto Cash Out</div>
    <input type="number" class="modal-input" id="autoInput" value="3.00" min="1.01" step="0.01">
    <div class="modal-btns"><button class="cancel" onclick="closeModals()">Cancel</button><button class="ok" onclick="saveAuto()">Save</button></div>
  </div>
</div>
<div class="toast" id="toast"></div>

<script>
const GROWTH = 0.13;
const BET_MS = 5000;
const state = {
  balance: <?= $balance ?>,
  serverOffset: 0,
  phase: 'countdown',
  round: null,
  crashPoint: 1,
  flightStartTime: 0,
  betEndClient: 0,
  current: 1,
  bots: [],
  realBets: [],
  knownCashed: {},
  lastPhase: null,
  panels: [
    {amount: 1, auto: 3, state: 'idle', cashed: false},
    {amount: 1, auto: 3, state: 'idle', cashed: false}
  ]
};
const cashFeed = [];

function $(id){ return document.getElementById(id); }
function showToast(m){ const t=$('toast'); t.textContent=m; t.classList.add('show'); clearTimeout(t._h); t._h=setTimeout(()=>t.classList.remove('show'),1600); }
function updateBalanceUI(){ $('balanceTop').textContent='₹'+state.balance.toFixed(2); $('balChip').textContent='₹'+state.balance.toFixed(2); }

async function api(action, extra={}){
  const f=new FormData(); f.append('action',action);
  Object.entries(extra).forEach(([k,v])=>f.append(k,v));
  try{ const r=await fetch(location.href,{method:'POST',body:f}); return await r.json(); }
  catch(e){ return {success:false,message:'Network error'}; }
}

/* ===== STARS ===== */
function makeStars(){
  const g=$('game');
  for(let i=0;i<60;i++){
    const s=document.createElement('div'); s.className='star';
    const sz=Math.random()*2+1;
    s.style.cssText='width:'+sz+'px;height:'+sz+'px;left:'+(Math.random()*100)+'%;top:'+(Math.random()*100)+'%;animation-delay:'+(Math.random()*2)+'s';
    g.appendChild(s);
  }
}

/* ===== TRAIL CANVAS ===== */
const tcv=$('trail'); const tctx=tcv.getContext('2d');
function sizeTrail(){ const g=$('game'); tcv.width=g.clientWidth; tcv.height=g.clientHeight; }
window.addEventListener('resize', sizeTrail);
function quadPoint(a,c,b,t){ const u=1-t; return u*u*a + 2*u*t*c + t*t*b; }
function drawTrail(pr){
  const W=tcv.width,H=tcv.height;
  tctx.clearRect(0,0,W,H);
  if(pr<=0.01) return;
  const sx=W*0.06, sy=H*0.86;
  const x=W*(0.06+pr*0.62), y=H*(0.86-pr*0.62);
  const cx1=W*0.28, cy1=H*0.82;
  const grad=tctx.createLinearGradient(sx,sy,x,y);
  grad.addColorStop(0,'rgba(255,23,68,0)');
  grad.addColorStop(0.4,'rgba(255,64,0,.5)');
  grad.addColorStop(1,'rgba(255,193,77,.95)');
  tctx.strokeStyle=grad; tctx.lineWidth=11; tctx.lineCap='round';
  tctx.shadowColor='rgba(255,109,0,.8)'; tctx.shadowBlur=16;
  tctx.beginPath(); tctx.moveTo(sx,sy); tctx.quadraticCurveTo(cx1,cy1,x,y); tctx.stroke();
  tctx.shadowBlur=0;
  for(let i=0;i<12;i++){
    const t=Math.random()*Math.max(pr,0.1);
    const px=quadPoint(sx,cx1,x,t)+(Math.random()*16-8);
    const py=quadPoint(sy,cy1,y,t)+(Math.random()*16-8);
    tctx.fillStyle='rgba(255,'+(140+Math.floor(Math.random()*100))+',60,'+(0.2+Math.random()*0.5)+')';
    tctx.beginPath(); tctx.arc(px,py,Math.random()*2.5+0.6,0,7); tctx.fill();
  }
}

/* ===== CASH FEED (max 10, old removed) ===== */
function pushCash(item){
  cashFeed.unshift(item);
  if(cashFeed.length>10) cashFeed.pop();
  renderCashFeed();
}
function renderCashFeed(){
  $('cashList').innerHTML = cashFeed.map(c=>
    '<div class="cash-item"><div class="cash-coin">$</div><div><div class="cash-text">'+c.name+'</div><div class="cash-win">₹'+c.win.toFixed(2)+' @ '+c.mult.toFixed(2)+'x</div></div></div>'
  ).join('');
}
function clearCashFeed(){ cashFeed.length=0; renderCashFeed(); }

/* ===== PANELS ===== */
function renderPanel(i){
  const p=state.panels[i], btn=$('btn'+i), label=$('label'+i), amount=$('amount'+i);
  btn.className='main-bet';
  if(p.state==='idle'){ label.textContent='Start ↻'; amount.textContent='₹'+p.amount.toFixed(2); }
  else if(p.state==='queued'){ btn.classList.add('state-queued'); label.textContent='Cancel ⏳'; amount.textContent='₹'+p.amount.toFixed(2); }
  else if(p.state==='active'){ btn.classList.add('state-active'); label.textContent='Cash out 💰'; }
  else if(p.state==='cashed'){ btn.classList.add('state-cashed'); label.textContent='Cashed ✅'; }
  else if(p.state==='lost'){ btn.classList.add('state-lost'); label.textContent='Lost ❌'; amount.textContent='₹0.00'; }
}
function renderAll(){ renderPanel(0); renderPanel(1); }

async function mainBet(i){
  const p=state.panels[i];
  if(state.phase==='countdown'){
    if(p.state==='idle'){
      const d=await api('place_bet',{amount:p.amount,panel:i});
      if(d.success){ state.balance=d.balance; updateBalanceUI(); p.state='queued'; showToast('✅ Bet placed ₹'+p.amount.toFixed(2)); }
      else showToast(d.message||'Failed');
    } else if(p.state==='queued'){
      const d=await api('cancel_bet',{panel:i});
      if(d.success){ state.balance=d.balance; updateBalanceUI(); p.state='idle'; showToast('Bet cancelled'); }
      else showToast(d.message||'Failed');
    }
    renderPanel(i); return;
  }
  if(state.phase==='flying'){
    if(p.state==='active'){ await cashoutUser(i); }
    else showToast('⏳ Wait for next round');
    return;
  }
  showToast('⏳ Wait for next round');
}
async function repeatBet(i){
  if(state.phase!=='countdown'){ showToast('⏳ Wait for next round'); return; }
  if(state.panels[i].state==='idle') mainBet(i);
}

let modalIndex=0;
function openBetModal(i){ modalIndex=i; $('betInput').value=state.panels[i].amount; $('betModal').classList.add('show'); }
function openAutoModal(i){ modalIndex=i; $('autoInput').value=state.panels[i].auto.toFixed(2); $('autoModal').classList.add('show'); }
function closeModals(){ $('betModal').classList.remove('show'); $('autoModal').classList.remove('show'); }
function saveBet(){
  const v=parseFloat($('betInput').value);
  if(v>=1 && v<=state.balance){ state.panels[modalIndex].amount=v; renderPanel(modalIndex); showToast('✅ Bet ₹'+v.toFixed(2)); }
  else showToast('❌ Invalid amount');
  closeModals();
}
function saveAuto(){
  const v=parseFloat($('autoInput').value);
  if(v>=1.01){ state.panels[modalIndex].auto=v; $('auto'+modalIndex).textContent=v.toFixed(2)+'X'; showToast('✅ Auto '+v.toFixed(2)+'x'); }
  else showToast('Minimum 1.01x');
  closeModals();
}

async function cashoutUser(i){
  const p=state.panels[i];
  if(p.state!=='active'||p.cashed) return;
  const d=await api('cash_out',{panel:i});
  if(d.success){
    p.cashed=true; p.state='cashed';
    state.balance=d.balance; updateBalanceUI();
    $('amount'+i).textContent='₹'+d.win.toFixed(2);
    renderPanel(i);
    pushCash({name:'You',win:d.win,mult:d.mult});
  } else {
    showToast(d.message||'Failed');
    if(d.message && d.message.includes('Flew')){ p.state='lost'; renderPanel(i); }
  }
}

/* ===== PHASES ===== */
function startCountdownLocal(){
  state.phase='countdown';
  state.current=1;
  state.betEndClient=(state.round ? state.round.bet_start : Date.now()+state.serverOffset) + BET_MS - state.serverOffset;
  $('game').classList.remove('crashed');
  $('countdown').classList.remove('hide');
  $('mult').style.display='none';
  $('mult').classList.remove('crash');
  $('flightOver').style.display='none';
  $('sat').style.display='none';
  const r=$('rocket');
  r.classList.remove('fly');
  r.style.display='none';
  r.style.left='6%'; r.style.bottom='14%';
  sizeTrail(); tctx.clearRect(0,0,tcv.width,tcv.height);
  clearCashFeed();
  state.knownCashed={};
  state.panels.forEach((p,i)=>{
    if(p.state==='cashed'||p.state==='lost'){ p.state='idle'; p.cashed=false; }
    renderPanel(i);
  });
}
function startFlightLocal(crashPoint, flightStartServer){
  state.phase='flying';
  state.crashPoint=crashPoint;
  state.flightStartTime=flightStartServer - state.serverOffset;
  state.current=1;
  $('countdown').classList.add('hide');
  $('mult').style.display='block';
  $('mult').textContent='1.00x';
  $('sat').style.display='block';
  const r=$('rocket');
  r.classList.remove('fly');
  r.style.display='block';
  r.style.left='6%'; r.style.bottom='14%';
  sizeTrail();
  state.panels.forEach((p,i)=>{
    if(p.state==='queued'){ p.state='active'; p.cashed=false; }
    renderPanel(i);
  });
}
function crashNowLocal(crash){
  if(state.phase==='crashed') return;
  state.phase='crashed';
  $('game').classList.add('crashed');
  $('mult').textContent=crash.toFixed(2)+'x';
  $('mult').classList.add('crash');
  $('flightOver').style.display='block';
  $('sat').style.display='none';
  const r=$('rocket');
  r.classList.add('fly');
  r.style.left='130%'; r.style.bottom='170%';
  setTimeout(()=>{ tctx.clearRect(0,0,tcv.width,tcv.height); },900);
  state.panels.forEach((p,i)=>{
    if(p.state==='active' && !p.cashed){ p.state='lost'; renderPanel(i); }
  });
  loadHistory();
}

/* ===== MASTER LOOP (rocket + countdown sync) ===== */
function tick(){
  if(state.phase==='flying'){
    const elapsed=(Date.now()-state.flightStartTime)/1000;
    const m=Math.min(state.crashPoint, Math.exp(GROWTH*elapsed));
    state.current=m;
    $('mult').textContent=m.toFixed(2)+'x';
    const pr=Math.min((m-1)/(Math.max(state.crashPoint,2)-1),1);
    const r=$('rocket');
    r.style.left=(6+pr*62)+'%';
    r.style.bottom=(14+pr*62)+'%';
    drawTrail(pr);
    state.panels.forEach((p,i)=>{
      if(p.state==='active' && !p.cashed){
        $('amount'+i).textContent='₹'+(p.amount*m).toFixed(2);
        if(m>=p.auto) cashoutUser(i);
      }
    });
    (state.bots||[]).forEach(b=>{
      if(!b.cashed && b.cashAt>0 && m>=b.cashAt && m<state.crashPoint){
        b.cashed=true;
        pushCash({name:'***'+b.name, win:b.amount*b.cashAt, mult:b.cashAt});
      }
    });
    if(m>=state.crashPoint){ crashNowLocal(state.crashPoint); }
  } else if(state.phase==='countdown' && state.betEndClient){
    const remain=Math.max(0,(state.betEndClient-Date.now())/1000);
    $('sec').textContent=Math.ceil(remain)+'s';
    $('cfill').style.width=(((BET_MS/1000)-remain)/(BET_MS/1000)*100)+'%';
  }
  requestAnimationFrame(tick);
}

/* ===== SERVER POLL ===== */
async function pollServer(){
  const d=await api('get_state');
  if(!d.success) return;
  state.serverOffset=d.server_ts-Date.now();
  state.round=d.round;
  state.bots=d.bots||[];
  state.realBets=d.real_bets||[];
  $('roundId').textContent=d.round.id||'—';

  (state.realBets||[]).forEach(b=>{
    const key=b.name+'|'+b.amount;
    if(b.cashed && !state.knownCashed[key] && !b.is_me){
      state.knownCashed[key]=true;
      pushCash({name:b.name, win:b.amount*b.cx, mult:b.cx});
    }
  });

  if(d.my_bet && d.my_bet.status==='cashed'){
    const panel=d.my_bet.panel??0;
    if(state.panels[panel].state==='active' && !state.panels[panel].cashed){
      state.panels[panel].cashed=true;
      state.panels[panel].state='cashed';
      state.balance+=d.my_bet.amount*d.my_bet.cx;
      $('amount'+panel).textContent='₹'+(d.my_bet.amount*d.my_bet.cx).toFixed(2);
      updateBalanceUI(); renderPanel(panel);
    }
  }

  if(d.phase!==state.lastPhase){
    if(d.phase==='countdown') startCountdownLocal();
    else if(d.phase==='flying') startFlightLocal(d.round.crash, d.round.flight_start);
    else if(d.phase==='crashed' && state.lastPhase!=='crashed') crashNowLocal(d.round.crash);
    state.lastPhase=d.phase;
  }
}

/* ===== HISTORY ===== */
async function loadHistory(){
  const d=await api('get_history');
  if(!d.success) return;
  const b=$('history'); b.innerHTML='';
  (d.history||[]).slice(0,24).forEach(v=>{
    const div=document.createElement('div');
    div.className='h '+(v<2?'low':v<10?'mid':'high');
    div.textContent=(+v).toFixed(2)+'x';
    b.appendChild(div);
  });
}

/* ===== INIT ===== */
makeStars();
sizeTrail();
loadHistory();
updateBalanceUI();
renderAll();
pollServer();
setInterval(pollServer,1000);
requestAnimationFrame(tick);
setInterval(async()=>{
  const d=await api('get_balance');
  if(d.success){ state.balance=d.balance; updateBalanceUI(); }
},8000);
setInterval(()=>{ $('pingDisplay').textContent=Math.floor(100+Math.random()*150); },3000);
</script>
</body>
</html>