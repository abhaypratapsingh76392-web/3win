<?php
require_once 'config.php';

// ═══ CRON KEEPER KEY (FIX) ═══
// Agar koi online na ho tab bhi game chalti rahe, iske liye free cron (cron-job.org)
// se har 1 minute me ye URL kholo:  k3.php?cron=12345
// (12345 ki jagah apni secret key rakho — neeche CRON_KEY me bhi same rakho)
define('CRON_KEY','12345');
$cronCall = (isset($_GET['cron']) && $_GET['cron']===CRON_KEY);

if (!$cronCall && !isset($_SESSION['phone'])) {
    header('Location: index.php');
    exit;
}

$phone = $cronCall ? '' : $_SESSION['phone'];
$userData = $cronCall ? [] : firebase_read("users/" . $phone);
$balance = $userData['balance'] ?? 0;

// ═══ HELPERS ═══
function fb_patch($path, $data) {
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, FIREBASE_URL.'/'.$path.'.json');
    curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "PATCH");
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_TIMEOUT, 10);
    $r = curl_exec($ch); curl_close($ch);
    return json_decode($r, true);
}
function fb_post($path, $data) {
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, FIREBASE_URL.'/'.$path.'.json');
    curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_TIMEOUT, 10);
    $r = curl_exec($ch); curl_close($ch);
    return json_decode($r, true);
}

// ═══ MULTIPLIERS ═══
function getMult() {
    return [
        'total' => [
            3=>207.36,4=>69.12,5=>34.56,6=>20.74,
            7=>13.83,8=>9.88,9=>8.3,10=>7.68,
            11=>7.68,12=>8.3,13=>9.88,14=>13.83,
            15=>20.74,16=>34.56,17=>69.12,18=>207.36
        ],
        'small'=>2,'big'=>2,'even'=>2,'odd'=>2,
        '2same'=>5,'3same'=>207.36,'3same_any'=>24,'different'=>1.5
    ];
}

// ═══ PERIOD SYSTEM (FIXED) ═══
// FIX: Period ID ab period ke START time ke date se banta hai (pehle hamesha $now ke
// date se banta tha). Isse aadhi-raat (12 baje) ke aas-paas PID mismatch nahi hoga.
// Game server-time se chalti hai — koi khele ya na khele, period sab users ke liye same hai.
function getPeriod($mode) {
    $iv = ['1min'=>60,'3min'=>180,'5min'=>300,'10min'=>600];
    $cd = ['1min'=>'1','3min'=>'3','5min'=>'5','10min'=>'10'];
    $interval = $iv[$mode] ?? 60;
    $now = time();
    $pNum = floor($now / $interval);
    $tr   = $interval - ($now % $interval);
    // Period ID same for all users at same time
    $pStart = $pNum * $interval; // FIX: is period ke start ka time
    $pid  = date('Ymd',$pStart) . $cd[$mode] . str_pad($pNum, 8, '0', STR_PAD_LEFT);
    return [
        'period'    => $pid,
        'time_remaining' => $tr,
        'interval'  => $interval,
        'pNum'      => $pNum
    ];
}

function getPrevPeriod($mode, $back=1) {
    $iv = ['1min'=>60,'3min'=>180,'5min'=>300,'10min'=>600];
    $cd = ['1min'=>'1','3min'=>'3','5min'=>'5','10min'=>'10'];
    $interval = $iv[$mode] ?? 60;
    $now = time();
    $pNum = floor($now / $interval) - $back;
    // FIX: us period ke apne start-time ka date use karo (aaj ka date nahi)
    $pStart = $pNum * $interval;
    $pid  = date('Ymd',$pStart) . $cd[$mode] . str_pad($pNum, 8, '0', STR_PAD_LEFT);
    return $pid;
}

// ═══ SMART RESULT - MIN PAYOUT (DETERMINISTIC FIX) ═══
// FIX: Pehle array_rand() se random pick hota tha — agar 2 users ek hi second me
// result banate to alag-alag result ban sakta tha. Ab pick period-ID ke hash se hoti hai,
// isliye chahe koi bhi user result banaye, result HAMESHA same rahega. Sabke me same-to-same!
function smartResult($pid, $mode) {
    $mult = getMult();
    $bets = firebase_read("k3_bets/{$mode}/{$pid}") ?? [];

    $pool=0;
    $sumB=array_fill(3,16,0.0);
    $smB=0;$bgB=0;$evB=0;$odB=0;
    $s2=array_fill(1,6,0.0);$s3=array_fill(1,6,0.0);
    $s3A=0;$dfB=0;

    foreach($bets as $bid=>$bet){
        if(!is_array($bet)) continue;
        $a=floatval($bet['total_bet']??0);
        $t=$bet['bet_type']??'';
        $v=$bet['bet_value']??0;
        $pool+=$a;
        switch($t){
            case 'total': $n=intval($v); if(isset($sumB[$n])) $sumB[$n]+=$a; break;
            case 'small': $smB+=$a; break;
            case 'big':   $bgB+=$a; break;
            case 'even':  $evB+=$a; break;
            case 'odd':   $odB+=$a; break;
            case '2same': $n=intval($v); if(isset($s2[$n])) $s2[$n]+=$a; break;
            case '3same': $n=intval($v); if(isset($s3[$n])) $s3[$n]+=$a; break;
            case '3same_any': $s3A+=$a; break;
            case 'different': $dfB+=$a; break;
        }
    }

    // Try all 216 combinations
    $cands = [];
    for($d1=1;$d1<=6;$d1++) for($d2=1;$d2<=6;$d2++) for($d3=1;$d3<=6;$d3++){
        $sum=$d1+$d2+$d3;
        $arr=[$d1,$d2,$d3]; sort($arr);
        $allS=($arr[0]===$arr[1]&&$arr[1]===$arr[2]);
        $allD=($arr[0]!==$arr[1]&&$arr[1]!==$arr[2]&&$arr[0]!==$arr[2]);
        $twoS=(!$allS&&($arr[0]===$arr[1]||$arr[1]===$arr[2]));
        $pv=$twoS?(($arr[0]===$arr[1])?$arr[0]:$arr[2]):0;
        $pay=0;
        if(isset($sumB[$sum])) $pay+=$sumB[$sum]*($mult['total'][$sum]??1);
        if($sum<=10) $pay+=$smB*2;
        if($sum>=11) $pay+=$bgB*2;
        if($sum%2===0) $pay+=$evB*2;
        if($sum%2!==0) $pay+=$odB*2;
        if($twoS&&$pv>0) $pay+=($s2[$pv]??0)*5;
        if($allS){$pay+=($s3[$arr[0]]??0)*207.36;$pay+=$s3A*24;}
        if($allD) $pay+=$dfB*1.5;
        $cands[]=[$d1,$d2,$d3,$sum,$pay];
    }

    // Sort by payout (ascending = min payout = max profit)
    usort($cands, fn($a,$b)=>$a[4]<=>$b[4]);
    // FIX: deterministic pick — period ID + mode ke hash se (sabke liye same result)
    $seed = abs(crc32($mode . '|' . $pid));
    $zeros = array_values(array_filter($cands, fn($c)=>$c[4]==0));
    if(!empty($zeros)){
        $pick = $zeros[$seed % count($zeros)];
    } else {
        $slice = array_slice($cands,0,min(5,count($cands)));
        $pick  = $slice[$seed % count($slice)];
    }

    return ['d1'=>$pick[0],'d2'=>$pick[1],'d3'=>$pick[2],'sum'=>$pick[3]];
}

// ═══ PROCESS PERIOD ═══
// This runs for any period - generates result if not exists
function processPeriod($pid, $mode) {
    // Already done?
    $ex = firebase_read("k3_results/{$mode}/{$pid}");
    if($ex && !empty($ex['processed'])) return $ex;

    $res = smartResult($pid, $mode);
    $d1=$res['d1'];$d2=$res['d2'];$d3=$res['d3'];$sum=$res['sum'];
    $arr=[$d1,$d2,$d3]; sort($arr);
    $allS=($arr[0]===$arr[1]&&$arr[1]===$arr[2]);
    $allD=($arr[0]!==$arr[1]&&$arr[1]!==$arr[2]&&$arr[0]!==$arr[2]);
    $twoS=(!$allS&&($arr[0]===$arr[1]||$arr[1]===$arr[2]));
    $pv=$twoS?(($arr[0]===$arr[1])?$arr[0]:$arr[2]):0;

    $rData=[
        'period'=>$pid,'mode'=>$mode,
        'dice1'=>$d1,'dice2'=>$d2,'dice3'=>$d3,'sum'=>$sum,
        'big_small'=>$sum>=11?'Big':'Small',
        'odd_even'=>$sum%2!==0?'Odd':'Even',
        'processed'=>true,'timestamp'=>time()
    ];
    fb_patch("k3_results/{$mode}/{$pid}", $rData);

    // Pay winners
    $mult = getMult();
    $bets = firebase_read("k3_bets/{$mode}/{$pid}") ?? [];
    foreach($bets as $bid=>$bet){
        if(!is_array($bet)||($bet['status']??'')==='done') continue;
        $t=$bet['bet_type']??'';$v=$bet['bet_value']??'';
        $total=floatval($bet['total_bet']??0);$bp=$bet['phone']??'';
        $won=false;$wm=0;
        switch($t){
            case 'total': if(intval($v)===$sum){$won=true;$wm=$mult['total'][$sum]??1;} break;
            case 'small': if($sum<=10){$won=true;$wm=2;} break;
            case 'big':   if($sum>=11){$won=true;$wm=2;} break;
            case 'even':  if($sum%2===0){$won=true;$wm=2;} break;
            case 'odd':   if($sum%2!==0){$won=true;$wm=2;} break;
            case '2same': if($twoS&&intval($v)===$pv){$won=true;$wm=5;} break;
            case '3same': if($allS&&intval($v)===$arr[0]){$won=true;$wm=207.36;} break;
            case '3same_any': if($allS){$won=true;$wm=24;} break;
            case 'different': if($allD){$won=true;$wm=1.5;} break;
        }
        $wa=$won?round($total*$wm,2):0;
        fb_patch("k3_bets/{$mode}/{$pid}/{$bid}",['status'=>'done','won'=>$won,'win_amount'=>$wa]);
        if($won&&$bp&&$wa>0){
            $ud=firebase_read("users/{$bp}");
            $nb=floatval($ud['balance']??0)+$wa;
            fb_patch("users/{$bp}",['balance'=>round($nb,2)]);
        }
        if($bp){
            fb_post("user_history/{$bp}",[
                'period'=>$pid,'mode'=>$mode,'bet_type'=>$t,'bet_value'=>$v,
                'total_bet'=>$total,'won'=>$won,'win_amount'=>$wa,
                'result_sum'=>$sum,'result_bs'=>$sum>=11?'Big':'Small',
                'result_oe'=>$sum%2!==0?'Odd':'Even',
                'dice'=>[$d1,$d2,$d3],'timestamp'=>time()
            ]);
        }
    }
    return $rData;
}

// ═══ FILL MISSING HISTORY (FIXED) ═══
// Game band ho ya koi online na ho — jab bhi koi aayega (ya cron chalega),
// chhoote hue periods ke results auto ban jayenge, taaki history me gap na dikhe
// aur history wahi se continue lage jahan game chal rahi hai.
// Ek call me max 40 periods process hote hain (server timeout se bachne ke liye);
// gap bada hua to agli calls me aage ka fill ho jayega (progressive catch-up).
function fillMissingHistory($mode, $count=100) {
    @set_time_limit(60);
    $iv=['1min'=>60,'3min'=>180,'5min'=>300,'10min'=>600];
    $cd=['1min'=>'1','3min'=>'3','5min'=>'5','10min'=>'10'];
    $interval=$iv[$mode]??60;
    $now=time();
    $currPNum=floor($now/$interval);

    // Ek hi read me existing results le lo (baar-baar Firebase hit nahi)
    $all = firebase_read("k3_results/{$mode}") ?? [];
    if(!is_array($all)) $all=[];

    $done=0;
    for($i=1; $i<=$count; $i++){
        if($done>=40) break; // per-call cap
        $pNum=$currPNum-$i;
        $pStart=$pNum*$interval; // FIX: us period ke apne date se PID
        $pid=date('Ymd',$pStart).($cd[$mode]).str_pad($pNum,8,'0',STR_PAD_LEFT);
        if(isset($all[$pid]) && !empty($all[$pid]['processed'])) continue;
        processPeriod($pid,$mode);
        $done++;
    }
}

// ═══ ENSURE RECENT (NEW - halka keeper) ═══
// Haal ke kuch periods turant ensure karo (poora history padhe bina).
// Page load / live-polling / cron me isi ka use hota hai taaki live result sabke liye same rahe.
function ensureRecent($mode, $n=5) {
    for($b=1;$b<=$n;$b++){
        $pid=getPrevPeriod($mode,$b);
        $ex=firebase_read("k3_results/{$mode}/{$pid}");
        if(!$ex||empty($ex['processed'])) processPeriod($pid,$mode);
    }
}

// ═══ CRON RUN (FIX - bina login ke) ═══
// cron-job.org se har 1 min me k3.php?cron=CRON_KEY kholo —
// tab game ZERO visitor par bhi chalti rahegi aur history banti rahegi.
if($cronCall){
    @set_time_limit(60);
    header('Content-Type: application/json');
    foreach(['1min','3min','5min','10min'] as $m){ ensureRecent($m,3); }
    echo json_encode(['success'=>true,'time'=>time()]);
    exit;
}

// ═══ AJAX ═══
if($_SERVER['REQUEST_METHOD']==='POST' && isset($_POST['action'])){
    header('Content-Type: application/json');
    $action=$_POST['action'];
    $mode=$_POST['mode']??'1min';

    // GET BALANCE
    if($action==='get_balance'){
        $ud=firebase_read("users/{$phone}");
        echo json_encode(['success'=>true,'balance'=>floatval($ud['balance']??0)]);
        exit;
    }

    // GET PERIOD INFO
    if($action==='get_period'){
        $info=getPeriod($mode);
        // Also ensure previous period is processed
        $prevPid = getPrevPeriod($mode,1);
        $ex=firebase_read("k3_results/{$mode}/{$prevPid}");
        if(!$ex||empty($ex['processed'])){
            processPeriod($prevPid,$mode);
        }
        echo json_encode(['success'=>true]+$info);
        exit;
    }

    // PLACE BET
    if($action==='place_bet'){
        $bType=trim($_POST['bet_type']??'');
        $bVal=trim($_POST['bet_value']??'');
        $bAmt=floatval($_POST['bet_amount']??0);
        $qty=max(1,intval($_POST['quantity']??1));
        $mul=floatval($_POST['multiplier']??1);
        $tot=round($bAmt*$qty*$mul,2);
        if($tot<=0){echo json_encode(['success'=>false,'message'=>'Invalid amount']);exit;}
        $info=getPeriod($mode);
        if($info['time_remaining']<=5){
            echo json_encode(['success'=>false,'message'=>'Betting closed! Wait for next round.']);
            exit;
        }
        $ud=firebase_read("users/{$phone}");
        $bal=floatval($ud['balance']??0);
        if($bal<$tot){echo json_encode(['success'=>false,'message'=>'Insufficient balance!']);exit;}
        fb_patch("users/{$phone}",['balance'=>round($bal-$tot,2)]);
        fb_post("k3_bets/{$mode}/{$info['period']}",[
            'phone'=>$phone,'period'=>$info['period'],'mode'=>$mode,
            'bet_type'=>$bType,'bet_value'=>$bVal,
            'bet_amount'=>$bAmt,'quantity'=>$qty,'multiplier'=>$mul,
            'total_bet'=>$tot,'status'=>'pending','timestamp'=>time()
        ]);
        echo json_encode(['success'=>true,'new_balance'=>round($bal-$tot,2)]);
        exit;
    }

    // CHECK + PROCESS RESULT (called when timer hits 0)
    if($action==='check_result'){
        $pid=$_POST['period_id']??'';
        if(!$pid){echo json_encode(['success'=>false]);exit;}
        $result=processPeriod($pid,$mode);
        $bets=firebase_read("k3_bets/{$mode}/{$pid}")??[];
        $myBets=[];$myWon=false;$myWin=0;$myLost=0;
        foreach($bets as $bid=>$bet){
            if(!is_array($bet)||($bet['phone']??'')!==$phone) continue;
            $myBets[]=$bet;
            if($bet['won']??false){$myWon=true;$myWin+=floatval($bet['win_amount']??0);}
            else $myLost+=floatval($bet['total_bet']??0);
        }
        $ud=firebase_read("users/{$phone}");
        echo json_encode([
            'success'=>true,'result'=>$result,
            'my_bets'=>$myBets,'my_won'=>$myWon,
            'my_win'=>round($myWin,2),'my_lost'=>round($myLost,2),
            'has_bets'=>count($myBets)>0,
            'new_balance'=>floatval($ud['balance']??0)
        ]);
        exit;
    }

    // GET GAME HISTORY (real results from Firebase)
    if($action==='get_history'){
        $page=max(1,intval($_POST['page']??1));
        $all=firebase_read("k3_results/{$mode}")??[];
        if(!is_array($all)) $all=[];
        if(empty($all)){
            // Auto fill history if empty
            fillMissingHistory($mode,100);
            $all=firebase_read("k3_results/{$mode}")??[];
            if(!is_array($all)) $all=[];
        } else {
            // FIX: gap-fill taaki beech ke chhoote periods bhi ban jayein (history continuous lage)
            fillMissingHistory($mode,100);
            $all=firebase_read("k3_results/{$mode}")??[];
            if(!is_array($all)) $all=[];
        }
        // FIX: Sort newest first BY PERIOD KEY (pehle arsort values par tha — order gadbad hota tha)
        krsort($all);
        $vals=array_values($all);
        $tp=max(1,ceil(count($vals)/10));
        $slice=array_slice($vals,($page-1)*10,10);
        echo json_encode([
            'success'=>true,'history'=>$slice,
            'total_pages'=>$tp,'page'=>$page,'total'=>count($vals)
        ]);
        exit;
    }

    // GET MY HISTORY
    if($action==='get_my_history'){
        $page=max(1,intval($_POST['page']??1));
        $all=firebase_read("user_history/{$phone}")??[];
        $f=[];
        foreach($all as $k=>$v){
            if(is_array($v)&&($v['mode']??'')===$mode) $f[]=$v;
        }
        usort($f,fn($a,$b)=>($b['timestamp']??0)-($a['timestamp']??0));
        $tp=max(1,ceil(count($f)/10));
        $slice=array_slice($f,($page-1)*10,10);
        echo json_encode(['success'=>true,'history'=>$slice,'total_pages'=>$tp,'page'=>$page]);
        exit;
    }

    // CHART
    if($action==='get_chart'){
        $all=firebase_read("k3_results/{$mode}")??[];
        if(!is_array($all)) $all=[];
        // FIX: key se sort (newest first)
        krsort($all);
        $vals=array_slice(array_values($all),0,30);
        $out=[];
        foreach($vals as $r){
            $out[]=[
                'period'=>substr($r['period']??'',-6),
                'sum'=>$r['sum']??0,
                'bs'=>$r['big_small']??'',
                'oe'=>$r['odd_even']??''
            ];
        }
        echo json_encode(['success'=>true,'chart'=>$out]);
        exit;
    }

    // FILL HISTORY (called on first load to ensure history exists)
    if($action==='fill_history'){
        $m=$_POST['mode']??'1min';
        fillMissingHistory($m,100);
        echo json_encode(['success'=>true]);
        exit;
    }

    // FILL ALL MODES (NEW FIX - page load par chaaro time-models ke recent results ensure karo)
    if($action==='fill_all'){
        foreach(['1min','3min','5min','10min'] as $m){ ensureRecent($m,5); }
        echo json_encode(['success'=>true]);
        exit;
    }

    // GET LATEST RESULT (for live polling)
    if($action==='get_latest_result'){
        $prevPid=getPrevPeriod($mode,1);
        $result=firebase_read("k3_results/{$mode}/{$prevPid}");
        if(!$result||empty($result['processed'])){
            $result=processPeriod($prevPid,$mode);
        }
        // Get current period info too
        $info=getPeriod($mode);
        echo json_encode([
            'success'=>true,
            'result'=>$result,
            'current_period'=>$info['period'],
            'time_remaining'=>$info['time_remaining']
        ]);
        exit;
    }
}

$initP=getPeriod('1min');
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1.0,maximum-scale=1.0,user-scalable=no">
<title>K3 Dice</title>
<style>
*{margin:0;padding:0;box-sizing:border-box;-webkit-tap-highlight-color:transparent}
body{font-family:-apple-system,'Segoe UI',sans-serif;background:#f2f3f7;max-width:480px;margin:0 auto;min-height:100vh;overflow-x:hidden;padding-bottom:40px}

/* HEADER */
.hdr{background:linear-gradient(135deg,#4d9ef7,#2979d8);height:54px;display:flex;align-items:center;justify-content:space-between;padding:0 16px;position:sticky;top:0;z-index:300;box-shadow:0 2px 12px rgba(0,0,0,.18)}
.hdr a{color:#fff;font-size:28px;text-decoration:none;line-height:1}
.hdr .logo{color:#fff;font-size:18px;font-weight:800;font-style:italic}
.hdr .icons{display:flex;gap:14px}
.hdr .icons span{font-size:22px;cursor:pointer}

/* WALLET */
.wallet{background:#fff;margin:12px;border-radius:18px;padding:20px 18px;box-shadow:0 2px 14px rgba(0,0,0,.07)}
.w-top{display:flex;align-items:center;justify-content:center;gap:6px}
.w-sym{font-size:22px;font-weight:700;color:#111;flex-shrink:0}
.w-num{font-size:26px;font-weight:900;color:#111;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;max-width:200px}
.ref-btn{font-size:20px;cursor:pointer;color:#999;transition:transform .5s;flex-shrink:0}
.ref-btn.spin{animation:sp .5s linear}
@keyframes sp{to{transform:rotate(360deg)}}
.w-lbl{text-align:center;color:#999;font-size:14px;margin-top:5px;display:flex;align-items:center;justify-content:center;gap:5px}
.w-btns{display:flex;gap:12px;margin-top:14px}
.btn-wd{flex:1;background:linear-gradient(135deg,#ff7070,#e53935);color:#fff;border:none;border-radius:30px;padding:13px;font-size:16px;font-weight:700;cursor:pointer}
.btn-dp{flex:1;background:linear-gradient(135deg,#56e07e,#25a244);color:#fff;border:none;border-radius:30px;padding:13px;font-size:16px;font-weight:700;cursor:pointer}

/* NOTICE */
.notice{background:#fff;margin:0 12px 12px;border-radius:14px;padding:10px 14px;display:flex;align-items:center;gap:8px;box-shadow:0 1px 8px rgba(0,0,0,.05)}
.ntxt{flex:1;font-size:13px;color:#555;overflow:hidden;white-space:nowrap;text-overflow:ellipsis;transition:opacity .3s}
.ndet{background:#eef5ff;color:#2979d8;border:1.5px solid #2979d8;border-radius:20px;padding:5px 13px;font-size:12px;white-space:nowrap;cursor:pointer;flex-shrink:0;font-weight:600}

/* MODE TABS */
.mode-card{background:#fff;margin:0 12px 12px;border-radius:16px;padding:12px;box-shadow:0 1px 8px rgba(0,0,0,.05)}
.mode-row{display:flex;justify-content:space-around}
.m-tab{display:flex;flex-direction:column;align-items:center;gap:5px;cursor:pointer;flex:1}
.m-circle{width:48px;height:48px;border-radius:50%;background:#e8e8e8;display:flex;align-items:center;justify-content:center;font-size:20px;transition:all .2s}
.m-tab.active .m-circle{background:linear-gradient(135deg,#00d4ea,#0097a7);box-shadow:0 4px 14px rgba(0,188,212,.4)}
.m-lbl{font-size:11px;color:#999;text-align:center;font-weight:600;line-height:1.3}
.m-tab.active .m-lbl{color:#00bcd4}

/* PERIOD CARD - FIXED */
.period-card{background:#fff;margin:0 12px 12px;border-radius:16px;padding:12px 14px;box-shadow:0 1px 8px rgba(0,0,0,.05)}
.pc-row{display:flex;align-items:flex-start;justify-content:space-between;gap:6px}
.pc-left{flex:1;min-width:0;overflow:hidden}
.pc-lbl{font-size:11px;color:#aaa;font-weight:500;margin-bottom:3px}
.pc-id{font-size:12px;font-weight:800;color:#111;font-family:'Courier New',monospace;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;max-width:100%}
.how-btn{display:inline-flex;align-items:center;gap:5px;border:1.5px solid #2979d8;border-radius:20px;padding:5px 12px;font-size:12px;color:#2979d8;cursor:pointer;font-weight:600;background:#fff;margin-top:8px;white-space:nowrap}
.pc-right{flex-shrink:0}
.tr-lbl{font-size:11px;color:#aaa;font-weight:500;margin-bottom:3px;text-align:right}
.timer-row{display:flex;align-items:center;gap:2px}
.tb{width:30px;height:38px;background:#2979d8;color:#fff;font-size:20px;font-weight:900;border-radius:6px;display:flex;align-items:center;justify-content:center;font-family:'Courier New',monospace}
.tc{font-size:22px;font-weight:900;color:#2979d8;margin:0 1px}

/* DICE */
.dice-wrap{background:linear-gradient(160deg,#1d6b30,#0f4020);margin:0 12px 12px;border-radius:20px;padding:20px 14px;display:flex;align-items:center;justify-content:center;gap:12px;min-height:126px;position:relative;box-shadow:0 6px 24px rgba(0,0,0,.22)}
.d-arr{position:absolute;top:50%;transform:translateY(-50%);color:rgba(255,255,255,.4);font-size:26px;cursor:pointer;user-select:none;padding:8px}
.d-arr.l{left:0}.d-arr.r{right:0}
.d-slot{background:#1e1e1e;border-radius:14px;width:82px;height:82px;display:flex;align-items:center;justify-content:center;box-shadow:inset 0 4px 10px rgba(0,0,0,.6)}
.d-slot.roll{animation:dr .12s ease infinite alternate}
@keyframes dr{from{transform:rotate(-10deg) scale(.93)}to{transform:rotate(10deg) scale(1.07)}}
.dsvg{width:62px;height:62px}

/* BET TABS */
.btab-row{margin:0 12px;background:#e4e4e4;border-radius:14px;padding:4px;display:flex;gap:2px}
.btab{flex:1;padding:9px 2px;text-align:center;font-size:12px;font-weight:700;color:#888;cursor:pointer;border-radius:10px;transition:all .2s;white-space:nowrap}
.btab.active{background:#2979d8;color:#fff}

/* NUM GRID */
.num-grid{display:grid;grid-template-columns:repeat(4,1fr);gap:12px 8px;padding:14px 12px;background:#fff;margin:8px 12px 0;border-radius:18px;box-shadow:0 2px 12px rgba(0,0,0,.06)}
.ni{display:flex;flex-direction:column;align-items:center;gap:6px;cursor:pointer}
.nb{width:58px;height:58px;border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:21px;font-weight:900;color:#fff;transition:transform .15s;background:radial-gradient(circle at 36% 33%,#f87070,#c0392b 72%);box-shadow:0 4px 14px rgba(192,57,43,.32),inset 0 -3px 6px rgba(0,0,0,.2)}
.nb.g{background:radial-gradient(circle at 36% 33%,#6ee8b4,#1abc9c 72%);box-shadow:0 4px 14px rgba(26,188,156,.32),inset 0 -3px 6px rgba(0,0,0,.2)}
.nb:active{transform:scale(1.1)}
.n-odds{font-size:11px;color:#777;font-weight:700}

/* ACTION BTNS */
.act-row{display:grid;grid-template-columns:repeat(4,1fr);gap:6px;padding:10px 12px;background:#fff;margin:6px 12px;border-radius:18px;box-shadow:0 2px 12px rgba(0,0,0,.06)}
.ab{border:none;border-radius:12px;padding:14px 4px;font-size:14px;font-weight:800;cursor:pointer;display:flex;flex-direction:column;align-items:center;gap:3px;color:#fff;transition:transform .15s}
.ab span{font-size:11px;font-weight:600;opacity:.88}
.ab:active{transform:scale(.95)}
.ab-sm{background:linear-gradient(135deg,#5ba3f5,#2979d8)}
.ab-bg{background:linear-gradient(135deg,#f5a84b,#d68010)}
.ab-ev{background:linear-gradient(135deg,#52d68a,#1e9e52)}
.ab-od{background:linear-gradient(135deg,#f1706a,#c0392b)}

/* SAME */
.same-grid{display:grid;grid-template-columns:repeat(3,1fr);gap:12px 8px;padding:14px 12px;background:#fff;margin:8px 12px 0;border-radius:18px;box-shadow:0 2px 12px rgba(0,0,0,.06)}
.diff-card{background:#fff;margin:8px 12px 0;border-radius:18px;padding:20px;text-align:center;box-shadow:0 2px 12px rgba(0,0,0,.06)}
.diff-card p{color:#999;font-size:13px;margin-top:10px}

/* HISTORY TABS */
.htab-row{display:flex;margin:12px 12px 0;background:#fff;border-radius:14px 14px 0 0;overflow:hidden;box-shadow:0 2px 12px rgba(0,0,0,.06)}
.htab{flex:1;padding:13px 4px;text-align:center;font-size:13px;font-weight:700;color:#bbb;cursor:pointer;border-bottom:3px solid transparent;transition:all .2s;white-space:nowrap}
.htab.active{color:#2979d8;border-bottom-color:#2979d8;background:#f0f6ff}

/* LIVE DOT */
.ldot{display:inline-block;width:7px;height:7px;background:#ff3d3d;border-radius:50%;margin-left:4px;animation:ldp 1s infinite}
@keyframes ldp{0%,100%{opacity:1;transform:scale(1)}50%{opacity:.4;transform:scale(.8)}}

/* HISTORY TABLE */
.hsec{background:#fff;margin:0 12px;border-radius:0 0 16px 16px;overflow:hidden;box-shadow:0 2px 12px rgba(0,0,0,.06);margin-bottom:12px}
.htbl{width:100%;border-collapse:collapse}
.htbl thead{background:linear-gradient(135deg,#2979d8,#1a56b0)}
.htbl thead th{color:#fff;padding:11px 6px;font-size:13px;font-weight:700;text-align:center}
.htbl tbody tr{border-bottom:1px solid #f5f5f5;transition:background .3s}
.htbl tbody tr:hover{background:#fafcff}
.htbl tbody td{padding:10px 6px;font-size:11px;color:#333;text-align:center;vertical-align:middle}
.pcell{font-size:10px!important;color:#aaa!important;font-family:'Courier New',monospace}
.tag{display:inline-block;border-radius:5px;padding:2px 6px;font-size:11px;font-weight:700;color:#fff;margin:1px}
.tsm{background:#2979d8}.tbg{background:#e67e22}.tev{background:#27ae60}.tod{background:#e74c3c}
.twin{background:#27ae60}.tloss{background:#e74c3c}
.md{display:inline-flex;align-items:center;justify-content:center;width:22px;height:22px;background:#c0392b;border-radius:4px;margin:1px;font-size:12px}
.new-row td{animation:newR .8s ease}
@keyframes newR{from{background:#fffde7}to{background:transparent}}

/* PAGINATION */
.pag{display:flex;align-items:center;justify-content:center;gap:12px;padding:12px;border-top:1px solid #f5f5f5}
.pgbtn{width:36px;height:36px;border-radius:50%;border:1.5px solid #ddd;background:#fff;font-size:18px;cursor:pointer;display:flex;align-items:center;justify-content:center;transition:all .2s;color:#444}
.pgbtn:hover,.pgbtn:active{background:#2979d8;color:#fff;border-color:#2979d8}
.pginfo{font-size:13px;color:#666;font-weight:700}

/* CHART */
.chart-body{padding:14px}
.crow{display:flex;align-items:center;gap:6px;padding:6px 0;border-bottom:1px solid #f8f8f8}
.cper{color:#bbb;font-family:'Courier New',monospace;min-width:50px;font-size:10px}
.csum{font-weight:900;min-width:22px;text-align:center;color:#222;font-size:13px}
.cbar-w{flex:1;height:12px;background:#f0f0f0;border-radius:6px;overflow:hidden}
.cbar{height:100%;border-radius:6px}
.cb-sm{background:#2979d8}.cb-bg{background:#e67e22}
.ctag{display:flex;gap:2px;flex-shrink:0}

/* BET MODAL */
.ov{display:none;position:fixed;inset:0;background:rgba(0,0,0,.55);z-index:500;align-items:flex-end;justify-content:center;max-width:480px;margin:0 auto}
.ov.show{display:flex}
.bm{background:#fff;border-radius:22px 22px 0 0;width:100%;padding:18px 16px 24px;animation:sUp .3s cubic-bezier(.34,1.56,.64,1)}
@keyframes sUp{from{transform:translateY(100%)}to{transform:translateY(0)}}
.bm-handle{width:36px;height:4px;background:#e0e0e0;border-radius:2px;margin:0 auto 14px}
.bm-hdr{display:flex;align-items:center;gap:12px;margin-bottom:16px}
.bm-badge{min-width:42px;height:42px;border-radius:50%;background:radial-gradient(circle at 36% 33%,#6ee8b4,#1abc9c 72%);color:#fff;font-size:14px;font-weight:900;display:flex;align-items:center;justify-content:center;padding:0 6px}
.bm-title{font-size:15px;font-weight:800}
.bm-sub{font-size:13px;color:#999;margin-top:2px}
.bm-row{display:flex;align-items:center;justify-content:space-between;margin-bottom:14px}
.bm-lbl{font-size:14px;font-weight:700;color:#333}
.amts{display:flex;gap:6px}
.abtn{background:#f3f3f3;border:2px solid transparent;border-radius:9px;padding:8px 12px;font-size:14px;font-weight:700;cursor:pointer;color:#333;transition:all .15s}
.abtn.sel{background:#2979d8;color:#fff;border-color:#2979d8}
.qc{display:flex;align-items:center;gap:10px}
.qbtn{width:36px;height:36px;background:#2979d8;color:#fff;border:none;border-radius:9px;font-size:22px;font-weight:700;cursor:pointer;display:flex;align-items:center;justify-content:center}
.qval{font-size:20px;font-weight:900;min-width:26px;text-align:center}
.mbts{display:flex;gap:5px;flex-wrap:wrap}
.mbtn{background:#f3f3f3;border:2px solid transparent;border-radius:8px;padding:7px 10px;font-size:13px;font-weight:700;cursor:pointer;color:#333;transition:all .15s}
.mbtn.sel{background:#2979d8;color:#fff;border-color:#2979d8}
.agrow{display:flex;align-items:center;gap:10px;padding:10px 0;border-top:1px solid #f5f5f5}
.agrow input{width:20px;height:20px;accent-color:#2979d8;cursor:pointer}
.agrow label{font-size:13px;color:#555}
.agrow a{color:#e53935;text-decoration:none;font-weight:700}
.bm-foot{display:flex;border-top:1px solid #f5f5f5;padding-top:12px}
.bcn{flex:1;background:#f5f5f5;border:none;padding:14px;font-size:16px;font-weight:700;color:#888;cursor:pointer;border-radius:12px 0 0 12px}
.bco{flex:2;background:linear-gradient(135deg,#5ba3f5,#2979d8);border:none;padding:14px;font-size:14px;font-weight:700;color:#fff;cursor:pointer;border-radius:0 12px 12px 0}

/* RESULT MODAL */
.rov{display:none;position:fixed;inset:0;background:rgba(0,0,0,.65);z-index:1000;align-items:center;justify-content:center}
.rov.show{display:flex}
.rm{background:#fff;border-radius:26px;padding:26px 20px;text-align:center;width:88%;max-width:340px;animation:pIn .45s cubic-bezier(.175,.885,.32,1.275)}
@keyframes pIn{from{transform:scale(.3) rotate(-12deg);opacity:0}to{transform:scale(1) rotate(0);opacity:1}}
.r-emo{font-size:60px;margin-bottom:6px;line-height:1}
.r-title{font-size:24px;font-weight:900;margin-bottom:5px}
.r-title.win{color:#1e9e52}.r-title.loss{color:#c0392b}
.r-dice{display:flex;justify-content:center;gap:10px;margin:10px 0}
.rdice{width:48px;height:48px;background:#c0392b;border-radius:11px;display:flex;align-items:center;justify-content:center;font-size:22px;color:#fff}
.r-sum{font-size:14px;color:#666;margin:4px 0;font-weight:600}
.r-tags{margin:6px 0}
.r-mybets{background:#f8f9ff;border-radius:10px;padding:8px 12px;margin:8px 0;text-align:left;max-height:80px;overflow-y:auto}
.r-mybets p{font-size:12px;color:#555;margin-bottom:2px}
.r-amt{font-size:24px;font-weight:900;margin:10px 0 14px}
.r-amt.w{color:#1e9e52}.r-amt.l{color:#c0392b}
.rok{background:linear-gradient(135deg,#5ba3f5,#2979d8);color:#fff;border:none;border-radius:28px;padding:13px 44px;font-size:16px;font-weight:800;cursor:pointer}

/* HOW MODAL */
.hov{display:none;position:fixed;inset:0;background:rgba(0,0,0,.6);z-index:2000;align-items:center;justify-content:center}
.hov.show{display:flex}
.hm{background:#fff;border-radius:22px;padding:20px;width:92%;max-width:360px;max-height:85vh;overflow-y:auto}
.hm h3{font-size:16px;font-weight:900;margin-bottom:10px;color:#111}
.hmtbl{width:100%;border-collapse:collapse;font-size:12px}
.hmtbl th,.hmtbl td{padding:7px 4px;border:1px solid #e8e8e8;text-align:center}
.hmtbl th{background:#2979d8;color:#fff;font-weight:700}
.hmtbl tr:nth-child(even) td{background:#f8f9ff}
.hcls{display:block;width:100%;margin-top:12px;background:#2979d8;color:#fff;border:none;border-radius:12px;padding:12px;font-size:15px;font-weight:700;cursor:pointer}

/* TOAST */
.toast{position:fixed;top:62px;left:50%;transform:translateX(-50%);background:rgba(0,0,0,.84);color:#fff;padding:10px 20px;border-radius:26px;font-size:14px;z-index:9999;opacity:0;transition:opacity .3s;max-width:300px;text-align:center;pointer-events:none;white-space:nowrap}
.toast.show{opacity:1}
.ldg{text-align:center;padding:22px;color:#bbb;font-size:14px}
</style>
</head>
<body>

<!-- HEADER -->
<div class="hdr">
  <a href="index.php">&#8249;</a>
  <div class="logo">✈ K3 Dice</div>
  <div class="icons"><span>🎧</span><span>🎵</span></div>
</div>

<!-- WALLET -->
<div class="wallet">
  <div class="w-top">
    <span class="w-sym">₹</span>
    <span class="w-num" id="wBal"><?php echo number_format($balance,2);?></span>
    <span class="ref-btn" id="refIco" onclick="refreshBal()">↻</span>
  </div>
  <div class="w-lbl">💰 Wallet balance</div>
  <div class="w-btns">
    <button class="btn-wd" onclick="location.href='withdraw.php'">Withdraw</button>
    <button class="btn-dp" onclick="location.href='deposit.php'">Deposit</button>
  </div>
</div>

<!-- NOTICE -->
<div class="notice">
  <span style="font-size:18px">📢</span>
  <div class="ntxt" id="ntxt">Welcome to K3 Dice! Predict 3 dice result and win big!</div>
  <div class="ndet">💧 Detail</div>
</div>

<!-- MODE TABS -->
<div class="mode-card">
  <div class="mode-row">
    <div class="m-tab active" onclick="switchMode('1min',this)">
      <div class="m-circle">⏱</div>
      <div class="m-lbl">K3 1 Min</div>
    </div>
    <div class="m-tab" onclick="switchMode('3min',this)">
      <div class="m-circle">⏱</div>
      <div class="m-lbl">K3 3 Min</div>
    </div>
    <div class="m-tab" onclick="switchMode('5min',this)">
      <div class="m-circle">⏱</div>
      <div class="m-lbl">K3 5 Min</div>
    </div>
    <div class="m-tab" onclick="switchMode('10min',this)">
      <div class="m-circle">⏱</div>
      <div class="m-lbl">K3 10 Min</div>
    </div>
  </div>
</div>

<!-- PERIOD CARD -->
<div class="period-card">
  <div class="pc-row">
    <div class="pc-left">
      <div class="pc-lbl">Period</div>
      <div class="pc-id" id="periodId"><?php echo $initP['period'];?></div>
      <button class="how-btn" onclick="showHow()">📋 How to play</button>
    </div>
    <div class="pc-right">
      <div class="tr-lbl">Time remaining</div>
      <div class="timer-row">
        <div class="tb" id="t0">0</div>
        <div class="tb" id="t1">0</div>
        <div class="tc">:</div>
        <div class="tb" id="t2">0</div>
        <div class="tb" id="t3">0</div>
      </div>
    </div>
  </div>
</div>

<!-- DICE -->
<div class="dice-wrap">
  <span class="d-arr l">&#8249;</span>
  <div class="d-slot" id="ds1"><?php echo dsvg(1);?></div>
  <div class="d-slot" id="ds2"><?php echo dsvg(4);?></div>
  <div class="d-slot" id="ds3"><?php echo dsvg(1);?></div>
  <span class="d-arr r">&#8250;</span>
</div>

<!-- BET TABS -->
<div class="btab-row">
  <div class="btab active" onclick="switchBTab('total',this)">Total</div>
  <div class="btab" onclick="switchBTab('2same',this)">2 same</div>
  <div class="btab" onclick="switchBTab('3same',this)">3 same</div>
  <div class="btab" onclick="switchBTab('different',this)">Different</div>
</div>

<!-- TOTAL TAB -->
<div id="tab_total">
  <div class="num-grid">
    <?php
    $ms=[3=>207.36,4=>69.12,5=>34.56,6=>20.74,7=>13.83,8=>9.88,9=>8.3,10=>7.68,
         11=>7.68,12=>8.3,13=>9.88,14=>13.83,15=>20.74,16=>34.56,17=>69.12,18=>207.36];
    $gr=[4,6,8,10,12,14,16,18];
    foreach($ms as $n=>$m):$c=in_array($n,$gr)?'nb g':'nb';?>
    <div class="ni" onclick="openModal('total','<?php echo $n?>',<?php echo $m?>)">
      <div class="<?php echo $c?>"><?php echo $n?></div>
      <div class="n-odds"><?php echo $m?>X</div>
    </div>
    <?php endforeach;?>
  </div>
  <div class="act-row">
    <button class="ab ab-sm" onclick="openModal('small','Small',2)">Small<span>2X</span></button>
    <button class="ab ab-bg" onclick="openModal('big','Big',2)">Big<span>2X</span></button>
    <button class="ab ab-ev" onclick="openModal('even','Even',2)">Even<span>2X</span></button>
    <button class="ab ab-od" onclick="openModal('odd','Odd',2)">Odd<span>2X</span></button>
  </div>
</div>

<!-- 2SAME TAB -->
<div id="tab_2same" style="display:none">
  <div class="same-grid">
    <?php for($i=1;$i<=6;$i++):?>
    <div class="ni" onclick="openModal('2same','<?php echo $i?>',5)">
      <div class="nb"><?php echo $i.$i?></div>
      <div class="n-odds">5X</div>
    </div>
    <?php endfor;?>
  </div>
</div>

<!-- 3SAME TAB -->
<div id="tab_3same" style="display:none">
  <div class="same-grid">
    <div class="ni" onclick="openModal('3same_any','Any Triple',24)">
      <div class="nb g" style="font-size:11px;width:58px;height:58px">Any<br>Triple</div>
      <div class="n-odds">24X</div>
    </div>
    <?php for($i=1;$i<=6;$i++):?>
    <div class="ni" onclick="openModal('3same','<?php echo $i?>',207.36)">
      <div class="nb"><?php echo $i.$i.$i?></div>
      <div class="n-odds">207X</div>
    </div>
    <?php endfor;?>
  </div>
</div>

<!-- DIFFERENT TAB -->
<div id="tab_different" style="display:none">
  <div class="diff-card">
    <div class="ni" style="cursor:pointer;display:inline-flex;flex-direction:column;align-items:center;gap:7px"
         onclick="openModal('different','All Different',1.5)">
      <div class="nb g" style="width:72px;height:72px;font-size:14px;font-weight:800">1·2·3</div>
      <div class="n-odds" style="font-size:13px">1.5X</div>
    </div>
    <p>All 3 dice show different numbers</p>
  </div>
</div>

<!-- HISTORY TABS -->
<div class="htab-row">
  <div class="htab active" onclick="switchHTab('game',this)">
    Game history<span class="ldot"></span>
  </div>
  <div class="htab" onclick="switchHTab('chart',this)">Chart</div>
  <div class="htab" onclick="switchHTab('my',this)">My history</div>
</div>

<!-- GAME HISTORY -->
<div id="sec_game" class="hsec">
  <table class="htbl">
    <thead>
      <tr>
        <th>Period</th>
        <th>Sum</th>
        <th>Result</th>
      </tr>
    </thead>
    <tbody id="ghBody">
      <tr><td colspan="3" class="ldg">Loading...</td></tr>
    </tbody>
  </table>
  <div class="pag">
    <button class="pgbtn" onclick="ghPrev()">&#8249;</button>
    <span class="pginfo" id="ghPg">1/1</span>
    <button class="pgbtn" onclick="ghNext()">&#8250;</button>
  </div>
</div>

<!-- CHART -->
<div id="sec_chart" class="hsec" style="display:none">
  <div class="chart-body" id="chartBody"><div class="ldg">Loading...</div></div>
</div>

<!-- MY HISTORY -->
<div id="sec_my" class="hsec" style="display:none">
  <table class="htbl">
    <thead>
      <tr><th>Period</th><th>Bet</th><th>Amount</th><th>Result</th></tr>
    </thead>
    <tbody id="mhBody">
      <tr><td colspan="4" class="ldg">Loading...</td></tr>
    </tbody>
  </table>
  <div class="pag">
    <button class="pgbtn" onclick="mhPrev()">&#8249;</button>
    <span class="pginfo" id="mhPg">1/1</span>
    <button class="pgbtn" onclick="mhNext()">&#8250;</button>
  </div>
</div>

<!-- BET MODAL -->
<div class="ov" id="betOv">
  <div class="bm">
    <div class="bm-handle"></div>
    <div class="bm-hdr">
      <div class="bm-badge" id="bmBadge">4</div>
      <div>
        <div class="bm-title" id="bmMode">K3 1 Min</div>
        <div class="bm-sub">Selected: <b id="bmSel">4</b></div>
      </div>
    </div>
    <div class="bm-row">
      <div class="bm-lbl">Balance</div>
      <div class="amts">
        <button class="abtn sel" onclick="selAmt(1,this)">1</button>
        <button class="abtn" onclick="selAmt(10,this)">10</button>
        <button class="abtn" onclick="selAmt(100,this)">100</button>
        <button class="abtn" onclick="selAmt(1000,this)">1K</button>
      </div>
    </div>
    <div class="bm-row">
      <div class="bm-lbl">Quantity</div>
      <div class="qc">
        <button class="qbtn" onclick="chgQty(-1)">−</button>
        <div class="qval" id="qdisp">1</div>
        <button class="qbtn" onclick="chgQty(1)">+</button>
      </div>
    </div>
    <div class="bm-row" style="align-items:flex-start">
      <div></div>
      <div class="mbts">
        <button class="mbtn sel" onclick="selMult(1,this)">X1</button>
        <button class="mbtn" onclick="selMult(5,this)">X5</button>
        <button class="mbtn" onclick="selMult(10,this)">X10</button>
        <button class="mbtn" onclick="selMult(20,this)">X20</button>
        <button class="mbtn" onclick="selMult(50,this)">X50</button>
        <button class="mbtn" onclick="selMult(100,this)">X100</button>
      </div>
    </div>
    <div class="agrow">
      <input type="checkbox" id="agck" checked>
      <label for="agck">I agree <a href="#">《Pre-sale rules》</a></label>
    </div>
    <div class="bm-foot">
      <button class="bcn" onclick="closeMod()">Cancel</button>
      <button class="bco" id="confBtn" onclick="placeBet()">
        Total amount ₹<span id="totAmt">1.00</span>
      </button>
    </div>
  </div>
</div>

<!-- RESULT MODAL -->
<div class="rov" id="resOv">
  <div class="rm">
    <div class="r-emo" id="rEmo">🎉</div>
    <div class="r-title" id="rTitle">You Won!</div>
    <div class="r-dice" id="rDice"></div>
    <div class="r-sum" id="rSum"></div>
    <div class="r-tags" id="rTags"></div>
    <div class="r-mybets" id="rMyBets"></div>
    <div class="r-amt" id="rAmt"></div>
    <button class="rok" onclick="closeRes()">Collect</button>
  </div>
</div>

<!-- HOW MODAL -->
<div class="hov" id="howOv">
  <div class="hm">
    <h3>📋 How to Play K3</h3>
    <p style="font-size:13px;color:#666;line-height:1.7;margin-bottom:10px">
      3 dice rolled each round. Predict result to win!<br>
      <b>Small</b>=Sum 3–10 | <b>Big</b>=Sum 11–18
    </p>
    <table class="hmtbl">
      <tr><th>Bet</th><th>Condition</th><th>Multiplier</th></tr>
      <tr><td>Small/Big</td><td>Sum range</td><td>2X</td></tr>
      <tr><td>Even/Odd</td><td>Sum parity</td><td>2X</td></tr>
      <tr><td>3 & 18</td><td>Exact sum</td><td>207.36X</td></tr>
      <tr><td>4 & 17</td><td>Exact sum</td><td>69.12X</td></tr>
      <tr><td>5 & 16</td><td>Exact sum</td><td>34.56X</td></tr>
      <tr><td>6 & 15</td><td>Exact sum</td><td>20.74X</td></tr>
      <tr><td>7 & 14</td><td>Exact sum</td><td>13.83X</td></tr>
      <tr><td>8 & 13</td><td>Exact sum</td><td>9.88X</td></tr>
      <tr><td>9 & 12</td><td>Exact sum</td><td>8.3X</td></tr>
      <tr><td>10 & 11</td><td>Exact sum</td><td>7.68X</td></tr>
      <tr><td>2 Same</td><td>Two dice match</td><td>5X</td></tr>
      <tr><td>Any Triple</td><td>All three match</td><td>24X</td></tr>
      <tr><td>Exact Triple</td><td>Specific triple</td><td>207.36X</td></tr>
      <tr><td>All Different</td><td>All 3 different</td><td>1.5X</td></tr>
    </table>
    <button class="hcls" onclick="closeHow()">Close</button>
  </div>
</div>

<div class="toast" id="toast"></div>

<?php
function dsvg($n){
    $d=[1=>[[50,50]],2=>[[30,30],[70,70]],3=>[[30,30],[50,50],[70,70]],
        4=>[[30,30],[70,30],[30,70],[70,70]],5=>[[30,30],[70,30],[50,50],[30,70],[70,70]],
        6=>[[30,22],[70,22],[30,50],[70,50],[30,78],[70,78]]];
    $pts=$d[$n]??$d[1];
    $s='<svg class="dsvg" viewBox="0 0 100 100" xmlns="http://www.w3.org/2000/svg">';
    $s.='<rect width="100" height="100" rx="16" fill="#c0392b"/>';
    $s.='<rect x="4" y="4" width="92" height="92" rx="13" fill="#cc3333"/>';
    foreach($pts as $i=>$p){$c=$i===0?'#f5c518':'#fff';$s.="<circle cx='{$p[0]}' cy='{$p[1]}' r='9' fill='$c'/>";}
    return $s.'</svg>';
}
?>

<script>
// ═══ STATE ═══
let MODE='1min', TINT=null, LINT=null;
let lastPeriod='', lastPeriodNum=0, waitRes=false, pendPeriod='';
let cType='',cVal='',cOdds=1;
let sAmt=1,qty=1,mult=1;
let ghPage=1,ghTotal=1,mhPage=1,mhTotal=1;
let lastGHCount=0, lastResultPid='';
const DE={1:'⚀',2:'⚁',3:'⚂',4:'⚃',5:'⚄',6:'⚅'};
const ML={'1min':'K3 1 Min','3min':'K3 3 Min','5min':'K3 5 Min','10min':'K3 10 Min'};
// FIX: har mode ka apna round-time (pehle sab me 60 sec tha — isliye 3/5/10 min ka timer galat chalta tha)
const MODE_INT={'1min':60,'3min':180,'5min':300,'10min':600};

// ═══ INIT ═══
document.addEventListener('DOMContentLoaded',()=>{
    syncPeriod();
    fillAll(); // FIX: chaaro time-models ke recent results ensure karo (sab models me history banegi)
    startTimer();
    // Load history from firebase (real history)
    loadGH(1);
    // Live polling every 5 seconds
    LINT = setInterval(liveCheck, 5000);
    // Balance refresh
    setInterval(refreshBalSilent, 25000);
    initNotice();
    // FIX: game band karke (tab/app) wapas aane par turant sync — history wahi se continue lagegi
    document.addEventListener('visibilitychange',()=>{
        if(!document.hidden){ syncPeriod(); liveCheck(); loadGH(1); }
    });
});

// FIX (NEW): page load par chaaro modes ke haal ke results ensure karo
function fillAll(){
    fetch('',{
        method:'POST',
        headers:{'Content-Type':'application/x-www-form-urlencoded'},
        body:'action=fill_all'
    })
    .then(r=>r.json())
    .then(d=>{ loadGH(1); })
    .catch(()=>{});
}

// ═══ NOTICE ═══
function initNotice(){
    const msgs=[
        'Welcome to K3 Dice! Predict 3 dice and win big!',
        'Small = Sum 3-10 | Big = Sum 11-18',
        'Number 3 & 18 give 207.36X multiplier!',
        'Betting closes 5 seconds before round ends.',
        'All results are shared in real-time! 🎲'
    ];
    let i=0;
    setInterval(()=>{
        const el=document.getElementById('ntxt');
        el.style.opacity='0';
        setTimeout(()=>{i=(i+1)%msgs.length;el.textContent=msgs[i];el.style.opacity='1';},300);
    },3500);
}

// ═══ SERVER SYNC (FIX - timer hamesha server-time se) ═══
function syncPeriod(){
    fetch('',{
        method:'POST',
        headers:{'Content-Type':'application/x-www-form-urlencoded'},
        body:`action=get_period&mode=${MODE}`
    })
    .then(r=>r.json())
    .then(d=>{
        if(!d.success) return;
        localTR=parseInt(d.time_remaining);
        setTimer(localTR);
        document.getElementById('periodId').textContent=d.period;
        lastPeriod=d.period;
    }).catch(()=>{});
}

// ═══ LIVE CHECK ═══
// Poll server every 5s - get latest result
// This ensures ALL users see same history in real-time
function liveCheck(){
    fetch('',{
        method:'POST',
        headers:{'Content-Type':'application/x-www-form-urlencoded'},
        body:`action=get_latest_result&mode=${MODE}`
    })
    .then(r=>r.json())
    .then(d=>{
        if(!d.success) return;
        const res=d.result;
        const pid=res?.period||'';

        // New result appeared (period changed)
        if(pid && pid!==lastResultPid && lastResultPid!==''){
            lastResultPid=pid;
            // Show latest dice on screen
            if(res.dice1) setDice(res.dice1,res.dice2,res.dice3);
            // Refresh history (real data)
            loadGH(1);
            // Check if MY bets won
            checkMyBets(pid);
        } else if(!lastResultPid && pid){
            lastResultPid=pid;
            if(res.dice1) setDice(res.dice1,res.dice2,res.dice3);
        }

        // FIX: server timer ko local countdown me bhi likho (timer jump nahi karega, sabke me same)
        if(d.time_remaining){
            localTR=parseInt(d.time_remaining);
            setTimer(localTR);
        }
        if(d.current_period){
            document.getElementById('periodId').textContent=d.current_period;
        }
    })
    .catch(()=>{});
}

// Check MY bets for a completed period
function checkMyBets(pid){
    fetch('',{
        method:'POST',
        headers:{'Content-Type':'application/x-www-form-urlencoded'},
        body:`action=check_result&period_id=${pid}&mode=${MODE}`
    })
    .then(r=>r.json())
    .then(d=>{
        if(!d.success) return;
        // Update balance
        document.getElementById('wBal').textContent=parseFloat(d.new_balance).toFixed(2);
        // Show result popup only if user had bets
        if(d.has_bets && d.result){
            rollDice(()=>{
                setDice(d.result.dice1,d.result.dice2,d.result.dice3);
                showResult(d,d.result);
            });
        }
        // Refresh my history
        const secM=document.getElementById('sec_my');
        if(secM.style.display!=='none') loadMH(1);
    })
    .catch(()=>{});
}

// ═══ MODE SWITCH ═══
function switchMode(m,el){
    MODE=m;
    localTR=MODE_INT[m]||60; // FIX: naye mode ka sahi timer turant
    document.querySelectorAll('.m-tab').forEach(t=>t.classList.remove('active'));
    el.classList.add('active');
    document.getElementById('bmMode').textContent=ML[m];
    lastResultPid='';
    syncPeriod(); // FIX: mode badalte hi server se sahi period+timer lao
    // Reload everything for new mode
    loadGH(1);
    const secC=document.getElementById('sec_chart');
    const secM=document.getElementById('sec_my');
    if(secC.style.display!=='none') loadChart();
    if(secM.style.display!=='none') loadMH(1);
}

// ═══ TIMER ═══
function startTimer(){
    tickTimer();
    TINT=setInterval(tickTimer,1000);
}

// Local countdown (accurate, no server load every second)
let localTR=60, tickCount=0;
function tickTimer(){
    tickCount++;
    localTR--;
    // FIX: period badalte hi turant naya period + result lao, aur mode ke hisaab se reset karo
    if(localTR<=0){
        localTR=MODE_INT[MODE]||60;
        syncPeriod();
        liveCheck();
    }
    setTimer(localTR);

    // Every 10 seconds, sync with server
    if(tickCount%10===0){
        syncPeriod();
    }

    // Lock bet button last 5 seconds
    const cb=document.getElementById('confBtn');
    if(localTR<=5){
        cb.style.background='linear-gradient(135deg,#aaa,#888)';
        cb.innerHTML='Round ending...';
    } else {
        if(cb.style.background.includes('aaa')){
            cb.style.background='';
            cb.innerHTML=`Total amount ₹<span id="totAmt">${(sAmt*qty*mult).toFixed(2)}</span>`;
        }
    }
}

function setTimer(t){
    t=Math.max(0,parseInt(t));
    const m=Math.floor(t/60), s=t%60;
    document.getElementById('t0').textContent=Math.floor(m/10);
    document.getElementById('t1').textContent=m%10;
    document.getElementById('t2').textContent=Math.floor(s/10);
    document.getElementById('t3').textContent=s%10;
}

// ═══ DICE ═══
function rollDice(cb){
    const slots=['ds1','ds2','ds3'];
    slots.forEach(s=>document.getElementById(s).classList.add('roll'));
    let c=0;
    const iv=setInterval(()=>{
        slots.forEach(s=>document.getElementById(s).innerHTML=dsvgJS(Math.ceil(Math.random()*6)));
        if(++c>12){
            clearInterval(iv);
            slots.forEach(s=>document.getElementById(s).classList.remove('roll'));
            if(cb) cb();
        }
    },100);
}
function setDice(d1,d2,d3){
    document.getElementById('ds1').innerHTML=dsvgJS(d1);
    document.getElementById('ds2').innerHTML=dsvgJS(d2);
    document.getElementById('ds3').innerHTML=dsvgJS(d3);
}

// ═══ BET MODAL ═══
function openModal(type,val,odds){
    cType=type;cVal=val;cOdds=odds;sAmt=1;qty=1;mult=1;
    document.getElementById('bmBadge').textContent=val;
    document.getElementById('bmSel').textContent=val;
    document.querySelectorAll('.abtn').forEach(b=>b.classList.remove('sel'));
    document.querySelector('.abtn').classList.add('sel');
    document.querySelectorAll('.mbtn').forEach(b=>b.classList.remove('sel'));
    document.querySelector('.mbtn').classList.add('sel');
    document.getElementById('qdisp').textContent=1;
    document.getElementById('agck').checked=true;
    updTot();
    document.getElementById('betOv').classList.add('show');
}
function closeMod(){document.getElementById('betOv').classList.remove('show');}
function selAmt(v,el){sAmt=v;document.querySelectorAll('.abtn').forEach(b=>b.classList.remove('sel'));el.classList.add('sel');updTot();}
function chgQty(d){qty=Math.max(1,qty+d);document.getElementById('qdisp').textContent=qty;updTot();}
function selMult(m,el){mult=m;document.querySelectorAll('.mbtn').forEach(b=>b.classList.remove('sel'));el.classList.add('sel');updTot();}
function updTot(){
    const el=document.getElementById('totAmt');
    if(el) el.textContent=(sAmt*qty*mult).toFixed(2);
}

// ═══ PLACE BET ═══
function placeBet(){
    if(!document.getElementById('agck').checked){showToast('Please agree to rules!');return;}
    const total=parseFloat((sAmt*qty*mult).toFixed(2));
    const bal=parseFloat(document.getElementById('wBal').textContent.replace(/,/g,''));
    if(bal<total){showToast('❌ Insufficient balance!');return;}
    const cb=document.getElementById('confBtn');
    cb.innerHTML='Placing...';cb.disabled=true;
    fetch('',{
        method:'POST',
        headers:{'Content-Type':'application/x-www-form-urlencoded'},
        body:`action=place_bet&mode=${MODE}&bet_type=${cType}&bet_value=${encodeURIComponent(cVal)}&bet_amount=${sAmt}&quantity=${qty}&multiplier=${mult}`
    })
    .then(r=>r.json())
    .then(d=>{
        cb.innerHTML=`Total amount ₹<span id="totAmt">${total.toFixed(2)}</span>`;
        cb.disabled=false;
        closeMod();
        if(d.success){
            document.getElementById('wBal').textContent=parseFloat(d.new_balance).toFixed(2);
            showToast(`✅ Bet ₹${total} on ${cVal}!`);
        } else showToast('❌ '+(d.message||'Failed!'));
    })
    .catch(()=>{
        cb.innerHTML=`Total amount ₹<span id="totAmt">${total.toFixed(2)}</span>`;
        cb.disabled=false;
        showToast('Network error!');
    });
}

// ═══ SHOW RESULT POPUP ═══
function showResult(data,res){
    const won=data.my_won;
    document.getElementById('rEmo').textContent=won?'🎉':'😔';
    const rt=document.getElementById('rTitle');
    rt.textContent=won?'You Won!':'Better Luck!';
    rt.className='r-title '+(won?'win':'loss');
    document.getElementById('rDice').innerHTML=
        [res.dice1,res.dice2,res.dice3].map(d=>`<div class="rdice">${DE[d]||d}</div>`).join('');
    document.getElementById('rSum').textContent=`Sum: ${res.sum}`;
    document.getElementById('rTags').innerHTML=
        `<span class="tag ${res.big_small==='Big'?'tbg':'tsm'}">${res.big_small}</span>`+
        `<span class="tag ${res.odd_even==='Odd'?'tod':'tev'}">${res.odd_even}</span>`;
    let bh='';
    (data.my_bets||[]).forEach(b=>{
        const w=b.won;
        bh+=`<p>${b.bet_value} | ₹${parseFloat(b.total_bet||0).toFixed(2)} → `+
            `<b style="color:${w?'#27ae60':'#e74c3c'}">${w?'+₹'+parseFloat(b.win_amount||0).toFixed(2):'Loss'}</b></p>`;
    });
    document.getElementById('rMyBets').innerHTML=bh;
    const ra=document.getElementById('rAmt');
    if(won){ra.textContent=`+₹${parseFloat(data.my_win||0).toFixed(2)}`;ra.className='r-amt w';}
    else{ra.textContent=`-₹${parseFloat(data.my_lost||0).toFixed(2)}`;ra.className='r-amt l';}
    document.getElementById('resOv').classList.add('show');
}
function closeRes(){
    document.getElementById('resOv').classList.remove('show');
    loadGH(1);
    const secM=document.getElementById('sec_my');
    if(secM.style.display!=='none') loadMH(1);
}

// ═══ GAME HISTORY (Real Firebase data) ═══
function loadGH(page){
    ghPage=page;
    fetch('',{
        method:'POST',
        headers:{'Content-Type':'application/x-www-form-urlencoded'},
        body:`action=get_history&mode=${MODE}&page=${page}`
    })
    .then(r=>r.json())
    .then(d=>{
        if(!d.success) return;
        ghTotal=d.total_pages||1;
        document.getElementById('ghPg').textContent=`${ghPage}/${ghTotal}`;
        renderGH(d.history||[]);
    });
}
function renderGH(h){
    let html='';
    if(!h.length){html='<tr><td colspan="3" class="ldg">No history yet</td></tr>';}
    else h.forEach(r=>{
        const d1=DE[r.dice1]||'?',d2=DE[r.dice2]||'?',d3=DE[r.dice3]||'?';
        const bst=r.big_small==='Big'?'tbg':'tsm';
        const oet=r.odd_even==='Odd'?'tod':'tev';
        // Show last 10 chars of period ID
        const shortP=(r.period||'-').slice(-10);
        html+=`<tr>
            <td class="pcell">${shortP}</td>
            <td>${r.sum||'-'}<br>
                <span class="tag ${bst}">${r.big_small||''}</span>
                <span class="tag ${oet}">${r.odd_even||''}</span>
            </td>
            <td>
                <div style="display:flex;justify-content:center;gap:2px">
                    <div class="md">${d1}</div>
                    <div class="md">${d2}</div>
                    <div class="md">${d3}</div>
                </div>
            </td>
        </tr>`;
    });
    document.getElementById('ghBody').innerHTML=html;
}
function ghPrev(){if(ghPage>1)loadGH(ghPage-1);}
function ghNext(){if(ghPage<ghTotal)loadGH(ghPage+1);}

// ═══ MY HISTORY ═══
function loadMH(page){
    mhPage=page;
    document.getElementById('mhBody').innerHTML='<tr><td colspan="4" class="ldg">Loading...</td></tr>';
    fetch('',{
        method:'POST',
        headers:{'Content-Type':'application/x-www-form-urlencoded'},
        body:`action=get_my_history&mode=${MODE}&page=${page}`
    })
    .then(r=>r.json())
    .then(d=>{
        mhTotal=d.total_pages||1;
        document.getElementById('mhPg').textContent=`${mhPage}/${mhTotal}`;
        const h=d.history||[];
        let html='';
        if(!h.length){html='<tr><td colspan="4" class="ldg">No bets yet</td></tr>';}
        else h.forEach(b=>{
            const w=b.won;
            const shortP=(b.period||'-').slice(-8);
            html+=`<tr>
                <td class="pcell">${shortP}</td>
                <td><b>${b.bet_value||'-'}</b><br><small style="color:#ccc">${b.bet_type||''}</small></td>
                <td>₹${parseFloat(b.total_bet||0).toFixed(2)}</td>
                <td>${w?`<span class="tag twin">+₹${parseFloat(b.win_amount||0).toFixed(2)}</span>`:'<span class="tag tloss">Loss</span>'}</td>
            </tr>`;
        });
        document.getElementById('mhBody').innerHTML=html;
    });
}
function mhPrev(){if(mhPage>1)loadMH(mhPage-1);}
function mhNext(){if(mhPage<mhTotal)loadMH(mhPage+1);}

// ═══ CHART ═══
function loadChart(){
    document.getElementById('chartBody').innerHTML='<div class="ldg">Loading...</div>';
    fetch('',{
        method:'POST',
        headers:{'Content-Type':'application/x-www-form-urlencoded'},
        body:`action=get_chart&mode=${MODE}`
    })
    .then(r=>r.json())
    .then(d=>{
        const c=d.chart||[];
        if(!c.length){document.getElementById('chartBody').innerHTML='<div class="ldg">No data yet</div>';return;}
        let html='';
        c.forEach(r=>{
            const isBig=r.bs==='Big';
            const pct=Math.round((r.sum/18)*100);
            html+=`<div class="crow">
                <div class="cper">${r.period}</div>
                <div class="csum">${r.sum}</div>
                <div class="cbar-w"><div class="cbar ${isBig?'cb-bg':'cb-sm'}" style="width:${pct}%"></div></div>
                <div class="ctag">
                    <span class="tag ${isBig?'tbg':'tsm'}">${r.bs}</span>
                    <span class="tag ${r.oe==='Odd'?'tod':'tev'}">${r.oe}</span>
                </div>
            </div>`;
        });
        document.getElementById('chartBody').innerHTML=html;
    });
}

// ═══ TAB SWITCHES ═══
function switchBTab(tab,el){
    document.querySelectorAll('.btab').forEach(t=>t.classList.remove('active'));
    el.classList.add('active');
    ['total','2same','3same','different'].forEach(t=>
        document.getElementById('tab_'+t).style.display='none'
    );
    document.getElementById('tab_'+tab).style.display='block';
}
function switchHTab(tab,el){
    document.querySelectorAll('.htab').forEach(t=>t.classList.remove('active'));
    el.classList.add('active');
    ['game','chart','my'].forEach(s=>
        document.getElementById('sec_'+s).style.display='none'
    );
    document.getElementById('sec_'+tab).style.display='block';
    if(tab==='game') loadGH(1);
    if(tab==='chart') loadChart();
    if(tab==='my') loadMH(1);
}

// ═══ BALANCE ═══
function refreshBal(){
    const ico=document.getElementById('refIco');
    ico.classList.add('spin');
    fetch('',{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},body:'action=get_balance'})
    .then(r=>r.json())
    .then(d=>{
        if(d.success) document.getElementById('wBal').textContent=parseFloat(d.balance).toFixed(2);
        setTimeout(()=>ico.classList.remove('spin'),500);
    }).catch(()=>ico.classList.remove('spin'));
}
function refreshBalSilent(){
    fetch('',{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},body:'action=get_balance'})
    .then(r=>r.json())
    .then(d=>{if(d.success) document.getElementById('wBal').textContent=parseFloat(d.balance).toFixed(2);});
}

// ═══ HOW/TOAST ═══
function showHow(){document.getElementById('howOv').classList.add('show');}
function closeHow(){document.getElementById('howOv').classList.remove('show');}
function showToast(m){
    const t=document.getElementById('toast');
    t.textContent=m;t.classList.add('show');
    setTimeout(()=>t.classList.remove('show'),3000);
}

// ═══ DICE SVG JS ═══
function dsvgJS(n){
    const cfg={
        1:[[50,50]],2:[[30,30],[70,70]],3:[[30,30],[50,50],[70,70]],
        4:[[30,30],[70,30],[30,70],[70,70]],5:[[30,30],[70,30],[50,50],[30,70],[70,70]],
        6:[[30,22],[70,22],[30,50],[70,50],[30,78],[70,78]]
    };
    const pts=cfg[n]||cfg[1];
    let s=`<svg class="dsvg" viewBox="0 0 100 100" xmlns="http://www.w3.org/2000/svg">
        <rect width="100" height="100" rx="16" fill="#c0392b"/>
        <rect x="4" y="4" width="92" height="92" rx="13" fill="#cc3333"/>`;
    pts.forEach((p,i)=>{
        const c=i===0?'#f5c518':'#fff';
        s+=`<circle cx="${p[0]}" cy="${p[1]}" r="9" fill="${c}"/>`;
    });
    return s+'</svg>';
}

// Close overlays on outside click
['betOv','resOv','howOv'].forEach(id=>{
    document.getElementById(id).addEventListener('click',function(e){
        if(e.target===this){
            if(id==='resOv') closeRes();
            else if(id==='howOv') closeHow();
            else closeMod();
        }
    });
});
</script>
</body>
</html>
