<?php
error_reporting(0);
date_default_timezone_set('Asia/Kolkata');
$savedAction = $_POST['action'] ?? null;
unset($_POST['action']);
require_once 'config.php';
if ($savedAction !== null) $_POST['action'] = $savedAction;

if ($_SERVER['REQUEST_METHOD'] !== 'POST' && (isset($_SESSION['user_phone']) || isset($_SESSION['phone']))) {
    header('Location: dashboard.php');
    exit;
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    header('Content-Type: application/json');
    $response = ['success' => false, 'message' => '', 'type' => ''];
    $action = $_POST['action'] ?? '';
    $phone = preg_replace('/[^0-9]/', '', $_POST['phone'] ?? '');
    $password = $_POST['password'] ?? '';

    if ($action === 'register') {
        $cpassword = $_POST['cpassword'] ?? '';
        $invite = htmlspecialchars($_POST['invite'] ?? '');
        if (empty($phone) || empty($password) || empty($cpassword)) {
            $response['message'] = "Phone and Password are required!";
        } elseif (strlen($phone) < 10) {
            $response['message'] = "Enter a valid mobile number!";
        } elseif ($password !== $cpassword) {
            $response['message'] = "Passwords do not match!";
        } elseif (!isset($_POST['privacy'])) {
            $response['message'] = "Privacy Agreement must be accepted!";
        } else {
            $existingUser = firebase_read("users/" . $phone);
            if ($existingUser) {
                $response['message'] = "Number already registered. Please Login.";
            } else {
                $userData = [
                    'phone' => $phone,
                    'password' => $password,
                    'inviteCode' => $invite,
                    'balance' => 0,
                    'createdAt' => date('Y-m-d H:i:s')
                ];
                firebase_write("users/" . $phone, $userData);
                
                // --- PROMOTION REFERRAL LINKING START ---
                if (!empty($invite)) {
                    $ownerPhone = firebase_read("inviteCodes/" . rawurlencode($invite));
                    if ($ownerPhone) {
                        $refData = [
                            'phone' => $phone,
                            'deposit' => 0,
                            'registeredAt' => date('Y-m-d H:i:s')
                        ];
                        firebase_write("referrals/" . $ownerPhone . "/" . $phone, $refData);
                    }
                }
                // --- PROMOTION REFERRAL LINKING END ---

                $_SESSION['user_phone'] = $phone;
                $_SESSION['phone'] = $phone;
                $response['success'] = true;
                $response['type'] = 'register';
                $response['message'] = "Account successfully created! Welcome to 3win.";
            }
        }
    }
    elseif ($action === 'login') {
        if (empty($phone) || empty($password)) {
            $response['message'] = "Enter both Phone and Password!";
        } else {
            $userData = firebase_read("users/" . $phone);
            if ($userData && isset($userData['password']) && $userData['password'] === $password) {
                $_SESSION['user_phone'] = $phone;
                $_SESSION['phone'] = $phone;
                $response['success'] = true;
                $response['type'] = 'login';
                $response['message'] = "Login Successful!";
            } else {
                $response['message'] = "Incorrect Number or Password!";
            }
        }
    }
    echo json_encode($response);
    exit;
}
$url_invite = htmlspecialchars($_GET['invite'] ?? '');
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
<title>3win - Register / Login</title>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
<link href="https://fonts.googleapis.com/icon?family=Material+Icons+Round" rel="stylesheet">
<style>
* { margin: 0; padding: 0; box-sizing: border-box; font-family: 'Inter', sans-serif; -webkit-tap-highlight-color: transparent; }
body { background-color: #f4f6f9; color: #333; min-height: 100vh; display: flex; flex-direction: column; overflow-x: hidden; scroll-behavior: smooth; }
#splashScreen { position: fixed; top: 0; left: 0; width: 100vw; height: 100vh; z-index: 999999; background-color: #fff; display: flex; justify-content: center; align-items: center; transition: opacity 0.5s ease-out; }
#splashScreen img { width: 100%; height: 100%; object-fit: cover; }
.header { background: linear-gradient(135deg, #4481eb 0%, #04befe 100%); padding: 20px 16px 60px 16px; color: white; position: relative; }
.top-bar { display: flex; justify-content: space-between; align-items: center; margin-bottom: 25px; }
.brand-name { font-size: 20px; font-weight: 800; display: flex; align-items: center; gap: 6px; letter-spacing: 1px; }
.header h1 { font-size: 26px; font-weight: 700; margin-bottom: 8px; }
.header p { font-size: 13px; opacity: 0.9; }
.form-container { background: white; flex: 1; border-radius: 24px 24px 0 0; margin-top: -30px; padding: 24px 20px; box-shadow: 0 -4px 15px rgba(0,0,0,0.05); position: relative; z-index: 10; }
.input-group { margin-bottom: 22px; }
.label-row { display: flex; align-items: center; gap: 10px; margin-bottom: 10px; }
.icon-box { background: #4481eb; color: white; width: 24px; height: 24px; border-radius: 6px; display: flex; align-items: center; justify-content: center; }
.icon-box .material-icons-round { font-size: 16px; }
.label-text { font-size: 14px; font-weight: 600; color: #444; }
.input-row { display: flex; align-items: center; background: #f8f9fa; border-radius: 12px; padding: 4px 14px; border: 1px solid #e0e0e0; transition: all 0.3s ease; }
.input-row:focus-within { border-color: #4481eb; background: #fff; box-shadow: 0 0 0 3px rgba(68, 129, 235, 0.1); }
.input-row.locked { background: #e9ecef; border-color: #ddd; opacity: 0.8; }
.country-code { display: flex; align-items: center; gap: 4px; padding-right: 12px; border-right: 1px solid #ddd; font-size: 14px; font-weight: 500; }
.input-field { flex: 1; border: none; background: transparent; padding: 12px 10px; font-size: 14px; outline: none; color: #333; }
.eye-btn { color: #999; background: none; border: none; cursor: pointer; padding: 4px; }
.eye-btn:hover { color: #4481eb; }
.btn-main { width: 100%; background: linear-gradient(90deg, #4481eb 0%, #04befe 100%); color: white; border: none; padding: 16px; border-radius: 30px; font-size: 16px; font-weight: 700; cursor: pointer; box-shadow: 0 4px 15px rgba(68, 129, 235, 0.3); margin-bottom: 16px; transition: transform 0.1s; }
.btn-main:active { transform: scale(0.98); }
.btn-outline { width: 100%; background: white; color: #4481eb; border: 1px solid #4481eb; padding: 16px; border-radius: 30px; font-size: 16px; font-weight: 700; cursor: pointer; text-align: center; }
.privacy-row { display: flex; align-items: center; gap: 8px; margin-bottom: 24px; cursor: pointer; }
.custom-radio { width: 18px; height: 18px; border: 2px solid #ddd; border-radius: 50%; position: relative; }
input[type="checkbox"] { display: none; }
input[type="checkbox"]:checked + .custom-radio { border-color: #4481eb; }
input[type="checkbox"]:checked + .custom-radio::after { content: ''; position: absolute; top: 50%; left: 50%; transform: translate(-50%, -50%); width: 10px; height: 10px; background: #4481eb; border-radius: 50%; }
.privacy-text { font-size: 13px; color: #666; } .privacy-text span { color: #4481eb; font-weight: 600; }
.alert-box { display: none; background: #f44336; color: white; padding: 14px 20px; border-radius: 12px; position: fixed; top: 20px; left: 50%; transform: translateX(-50%); z-index: 10000; font-size: 14px; font-weight: 600; box-shadow: 0 10px 25px rgba(0,0,0,0.2); width: 90%; max-width: 400px; text-align: center; }
@keyframes slideDown { 0% { top: -50px; opacity: 0; } 100% { top: 20px; opacity: 1; } }
.loader-overlay { display: none; position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(255,255,255,0.95); z-index: 9999; align-items: center; justify-content: center; backdrop-filter: blur(5px); }
.loader-overlay.active { display: flex; animation: fadeIn 0.3s ease; }
.loader-container { position: relative; width: 70px; height: 70px; display: flex; justify-content: center; align-items: center; }
.circular-spinner { position: absolute; top: 0; left: 0; width: 100%; height: 100%; border: 4px solid #f0f0f0; border-top: 4px solid #4481eb; border-right: 4px solid #04befe; border-radius: 50%; animation: spin 0.8s linear infinite; z-index: 1; }
.custom-loader-img { width: 35px; height: auto; z-index: 2; animation: pulse 1.5s infinite ease-in-out; }
@keyframes spin { 0% { transform: rotate(0deg); } 100% { transform: rotate(360deg); } }
@keyframes pulse { 0% { transform: scale(0.95); opacity: 0.8; } 50% { transform: scale(1.1); opacity: 1; } 100% { transform: scale(0.95); opacity: 0.8; } }
@keyframes fadeIn { from { opacity: 0; } to { opacity: 1; } }
</style>
</head>
<body>

<div id="splashScreen">
    <img src="https://i.ibb.co/DPDw1dNd/file-00000000569881fab1367e739d11bdcf.png" alt="Welcome">
</div>

<div class="loader-overlay" id="loadingUI">
    <div class="loader-container">
        <div class="circular-spinner"></div>
        <img src="https://i.ibb.co/vC5cQwWy/file-00000000ac6c8206970524e22b8f79f5.png" alt="Loading..." class="custom-loader-img">
    </div>
</div>

<div class="alert-box" id="customAlert"></div>
<div class="header">
<div class="top-bar">
<div class="brand-name"><span class="material-icons-round">sports_esports</span> 3win</div>
</div>
<h1 id="headerTitle">Register</h1>
<p id="headerSub">Play and win big with us!</p>
</div>
<div class="form-container">
<form id="registerForm" style="display: block;" onsubmit="submitFormAjax(event, 'registerForm')">
<input type="hidden" name="action" value="register">
<div class="input-group">
<div class="label-row"><div class="icon-box"><span class="material-icons-round">smartphone</span></div><span class="label-text">Phone number</span></div>
<div class="input-row">
<div class="country-code">+91</div>
<input type="number" name="phone" class="input-field" placeholder="Please enter the phone number" required>
</div>
</div>
<div class="input-group">
<div class="label-row"><div class="icon-box"><span class="material-icons-round">lock</span></div><span class="label-text">Set password</span></div>
<div class="input-row">
<input type="password" name="password" id="regPass" class="input-field" placeholder="Set password" required>
<button type="button" class="eye-btn" onclick="toggleVis('regPass', 'eyeReg1')"><span class="material-icons-round" id="eyeReg1">visibility_off</span></button>
</div>
</div>
<div class="input-group">
<div class="label-row"><div class="icon-box"><span class="material-icons-round">lock</span></div><span class="label-text">Confirm password</span></div>
<div class="input-row">
<input type="password" name="cpassword" id="regCPass" class="input-field" placeholder="Confirm password" required>
<button type="button" class="eye-btn" onclick="toggleVis('regCPass', 'eyeReg2')"><span class="material-icons-round" id="eyeReg2">visibility_off</span></button>
</div>
</div>
<div class="input-group">
<div class="label-row"><div class="icon-box"><span class="material-icons-round">receipt</span></div><span class="label-text">Invite code (Optional)</span></div>
<div class="input-row <?php echo !empty($url_invite) ? 'locked' : ''; ?>">
<input type="text" name="invite" class="input-field" placeholder="Enter Invite Code" value="<?php echo $url_invite; ?>" <?php echo !empty($url_invite) ? 'readonly' : ''; ?>>
<?php if(!empty($url_invite)): ?><span class="material-icons-round" style="color: #4481eb; font-size: 18px; margin-right: 10px;">lock</span><?php endif; ?>
</div>
</div>
<label class="privacy-row">
<input type="checkbox" name="privacy" required>
<div class="custom-radio"></div>
<div class="privacy-text">I have read and agree <span>【Privacy Agreement】</span></div>
</label>
<button type="submit" class="btn-main">Register</button>
<div class="btn-outline" onclick="switchForm('login')">I have an account Login</div>
</form>

<form id="loginForm" style="display: none;" onsubmit="submitFormAjax(event, 'loginForm')">
<input type="hidden" name="action" value="login">
<div class="input-group">
<div class="label-row"><div class="icon-box"><span class="material-icons-round">smartphone</span></div><span class="label-text">Phone number</span></div>
<div class="input-row">
<div class="country-code">+91</div>
<input type="number" name="phone" id="loginPhoneInput" class="input-field" placeholder="Please enter the phone number" required>
</div>
</div>
<div class="input-group">
<div class="label-row"><div class="icon-box"><span class="material-icons-round">lock</span></div><span class="label-text">Password</span></div>
<div class="input-row">
<input type="password" name="password" id="logPass" class="input-field" placeholder="Enter password" required>
<button type="button" class="eye-btn" onclick="toggleVis('logPass', 'eyeLog')"><span class="material-icons-round" id="eyeLog">visibility_off</span></button>
</div>
</div>
<br>
<button type="submit" class="btn-main">Log in</button>
<div class="btn-outline" onclick="switchForm('register')">Create an account</div>
</form>
</div>
<script>
window.addEventListener("load", function() { setTimeout(function() { const splash = document.getElementById("splashScreen"); if (splash) { splash.style.opacity = "0"; setTimeout(function() { splash.style.display = "none"; }, 500); } }, 3000); });
function toggleVis(inputId, iconId) { const input = document.getElementById(inputId); const icon = document.getElementById(iconId); if (input.type === "password") { input.type = "text"; icon.innerText = "visibility"; icon.style.color = "#4481eb"; } else { input.type = "password"; icon.innerText = "visibility_off"; icon.style.color = "#999"; } }
function switchForm(type) { const regForm = document.getElementById('registerForm'); const logForm = document.getElementById('loginForm'); const title = document.getElementById('headerTitle'); if (type === 'login') { regForm.style.display = 'none'; logForm.style.display = 'block'; title.innerText = 'Login'; } else { logForm.style.display = 'none'; regForm.style.display = 'block'; title.innerText = 'Register'; } }
function submitFormAjax(event, formId) { event.preventDefault(); document.getElementById('loadingUI').classList.add('active'); const form = document.getElementById(formId); const formData = new FormData(form); fetch(window.location.href, { method: 'POST', body: formData }).then(async response => { const contentType = response.headers.get("content-type"); if (contentType && contentType.indexOf("application/json") !== -1) { return response.json(); } else { throw new Error("Server Error"); } }).then(data => { setTimeout(() => { document.getElementById('loadingUI').classList.remove('active'); if (data.success) { showCustomAlert(data.message, true); setTimeout(() => { window.location.href = 'dashboard.php'; }, 900); } else { showCustomAlert(data.message, false); } }, 500); }).catch(error => { setTimeout(() => { document.getElementById('loadingUI').classList.remove('active'); showCustomAlert("Network Error! Please check your connection.", false); }, 500); }); }
function showCustomAlert(msg, isSuccess = false) { const alertBox = document.getElementById('customAlert'); alertBox.innerText = msg; if (isSuccess) { alertBox.style.background = 'linear-gradient(90deg, #15b055, #1fb85c)'; } else { alertBox.style.background = 'linear-gradient(90deg, #f44336, #e53935)'; } alertBox.style.display = 'block'; alertBox.style.animation = 'none'; setTimeout(() => { alertBox.style.animation = 'slideDown 0.4s cubic-bezier(0.175, 0.885, 0.32, 1.275) forwards'; }, 10); setTimeout(() => { alertBox.style.display = 'none'; }, 4000); }
</script>
</body>
</html>