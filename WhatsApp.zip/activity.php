<?php
// config.php ko call kar rahe hain (Tumhara code bina change kiye)
require_once 'config.php'; 

// Default bonus 0 set kar rahe hain
$real_balance = "0.00";

// Agar user login hai, toh Firebase se asli balance nikalenge
if (isset($_SESSION['phone'])) {
    $user_phone = $_SESSION['phone'];
    $userData = firebase_read("users/" . $user_phone);
    
    // Agar balance database mein hai toh usko update karenge
    if ($userData && isset($userData['balance'])) {
        $real_balance = number_format((float)$userData['balance'], 2, '.', '');
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title>3 win - Activity</title>
    <!-- High quality UI font -->
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Inter', sans-serif;
            -webkit-tap-highlight-color: transparent;
        }

        body {
            background-color: #f4f6fa;
            max-width: 450px;
            margin: 0 auto;
            position: relative;
            min-height: 100vh;
            padding-bottom: 85px; /* Increased for bottom nav */
            overflow-x: hidden;
        }

        a { text-decoration: none; }

        /* --- HEADER SECTION --- */
        .header {
            background: linear-gradient(180deg, #4295ff 0%, #68b1ff 100%);
            padding: 25px 20px 30px 20px;
            color: white;
            border-bottom-left-radius: 28px;
            border-bottom-right-radius: 28px;
            text-align: center;
        }

        .logo {
            font-size: 22px;
            font-weight: 800;
            font-style: italic;
            display: flex;
            justify-content: center;
            align-items: center;
            gap: 8px;
            margin-bottom: 25px;
            letter-spacing: 0.5px;
        }

        .bonus-section {
            display: flex;
            align-items: center;
            justify-content: center;
            margin-bottom: 20px;
        }

        .bonus-item {
            flex: 1;
        }

        .bonus-item p {
            font-size: 13px;
            margin-bottom: 4px;
            font-weight: 500;
            color: rgba(255, 255, 255, 0.9);
        }

        .bonus-item h2 {
            font-size: 24px;
            font-weight: 700;
        }

        .divider {
            width: 1px;
            height: 35px;
            background-color: rgba(255, 255, 255, 0.3);
            margin: 0 10px;
        }

        .bonus-btn {
            background-color: white;
            color: #4295ff;
            border: none;
            padding: 10px 32px;
            border-radius: 25px;
            font-size: 15px;
            font-weight: 600;
            cursor: pointer;
            display: inline-block;
        }

        /* --- ICONS SECTION --- */
        .icon-menu {
            padding: 20px 15px 5px 15px;
            display: flex;
            justify-content: flex-start;
        }

        .menu-item {
            display: flex;
            flex-direction: column;
            align-items: center;
            width: 80px;
            position: relative;
        }

        .icon-box {
            width: 55px;
            height: 55px;
            background: linear-gradient(135deg, #ff9f8c 0%, #ffd0bc 100%);
            border-radius: 18px;
            display: flex;
            justify-content: center;
            align-items: center;
            margin-bottom: 8px;
            position: relative;
        }

        .icon-box i {
            font-size: 30px;
            color: white;
            opacity: 0.9;
        }

        .red-dot {
            position: absolute;
            top: -2px;
            right: -2px;
            width: 12px;
            height: 12px;
            background-color: #ff3b30;
            border-radius: 50%;
            border: 2px solid white;
        }

        .menu-item span {
            font-size: 13px;
            color: #7d8495;
            font-weight: 500;
        }

        /* --- CARDS SECTION --- */
        .cards-area {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 12px;
            padding: 15px;
        }

        .card {
            background: white;
            border-radius: 12px;
            overflow: hidden;
            box-shadow: 0 4px 15px rgba(0,0,0,0.04);
            display: flex;
            flex-direction: column;
            height: 100%;
        }

        .card img {
            width: 100%;
            height: 95px;
            object-fit: cover;
            border-top-left-radius: 12px;
            border-top-right-radius: 12px;
        }

        .card-content {
            padding: 12px;
        }

        .card-content h3 {
            font-size: 15px;
            color: #1c1c1c;
            margin-bottom: 5px;
            font-weight: 700;
        }

        .card-content p {
            font-size: 12px;
            color: #8a92a3;
            line-height: 1.4;
            font-weight: 500;
        }

        /* --- SCROLLABLE BANNERS SECTION --- */
        .slider-section {
            padding: 5px 15px 20px 15px;
        }

        .slider-wrapper {
            display: flex;
            overflow-x: auto;
            scroll-snap-type: x mandatory;
            gap: 10px;
            border-radius: 14px;
            scrollbar-width: none; 
        }

        .slider-wrapper::-webkit-scrollbar {
            display: none; 
        }

        .slide {
            min-width: 100%;
            scroll-snap-align: center;
        }

        .slide img {
            width: 100%;
            display: block;
            border-radius: 14px;
            height: 140px;
            object-fit: cover;
            box-shadow: 0 4px 12px rgba(0,0,0,0.08);
        }

        /* --- FLOATING CUSTOMER SERVICE ICON (FIXED TO SCREEN) --- */
        .floating-chat {
            position: fixed; /* Ye screen par fix rahega */
            right: 15px;
            bottom: 110px; /* Bottom nav ke thoda upar */
            width: 50px;
            height: 50px;
            z-index: 999; /* Sabse aage dikhega */
            cursor: pointer;
            border-radius: 50%;
            box-shadow: 0 4px 15px rgba(0,0,0,0.25);
            background: white; 
            overflow: hidden;
            display: flex;
            justify-content: center;
            align-items: center;
            transition: transform 0.2s ease;
        }

        .floating-chat:active {
            transform: scale(0.95);
        }
        
        .floating-chat img {
            width: 100%;
            height: 100%;
            object-fit: cover; 
        }

        /* --- BOTTOM NAVIGATION (REDESIGNED LIKE SCREENSHOT) --- */
        .bottom-nav {
            position: fixed;
            bottom: 0;
            left: 50%;
            transform: translateX(-50%);
            width: 100%;
            max-width: 450px;
            background: white;
            display: flex;
            justify-content: space-between;
            align-items: flex-end;
            padding: 10px 10px 12px 10px;
            box-shadow: 0 -2px 15px rgba(0,0,0,0.08);
            z-index: 1000;
        }

        .nav-item {
            color: #9ba3b5; /* Unactive color */
            display: flex;
            flex-direction: column;
            align-items: center;
            font-size: 11px;
            font-weight: 600;
            width: 20%;
            position: relative;
        }

        .nav-item i {
            font-size: 24px;
            margin-bottom: 5px;
        }

        .nav-item.active {
            color: #4295ff; /* Active blue color */
        }
        
        .nav-dot {
            position: absolute;
            top: -2px;
            right: 18px;
            width: 9px;
            height: 9px;
            background-color: #ff3b30;
            border-radius: 50%;
            border: 1.5px solid white;
        }

        /* --- PERFECT GAUGE BUTTON (Get ₹500) --- */
        .nav-center {
            display: flex;
            flex-direction: column;
            align-items: center;
            width: 20%;
            position: relative;
            margin-top: -30px; /* Bahaar nikalne ke liye */
        }

        .gauge-wrapper {
            width: 70px;
            height: 70px;
            background: white;
            border-radius: 50%;
            display: flex;
            justify-content: center;
            align-items: center;
            box-shadow: 0 -4px 10px rgba(0,0,0,0.06);
            margin-bottom: 4px;
            padding: 5px;
        }

        .gauge-meter {
            width: 100%;
            height: 100%;
            background: radial-gradient(circle at bottom, #ff9800 0%, #ff3d00 100%);
            border-radius: 50%;
            position: relative;
            display: flex;
            justify-content: center;
            align-items: flex-end; /* Niche set karne ke liye */
            border: 2px solid #ffdecc;
            overflow: hidden;
            box-shadow: inset 0 2px 5px rgba(0,0,0,0.2);
        }
        
        /* Ticks/Lines inside meter */
        .gauge-meter::before {
            content: '';
            position: absolute;
            width: 90%;
            height: 90%;
            top: 5%;
            left: 5%;
            border-radius: 50%;
            background: repeating-conic-gradient(
                from -90deg, 
                transparent 0deg, 
                transparent 15deg, 
                rgba(255,255,255,0.4) 15deg, 
                rgba(255,255,255,0.4) 18deg
            );
            -webkit-mask-image: linear-gradient(to bottom, black 55%, transparent 55%);
        }

        /* Chhota blue GO button */
        .gauge-go {
            width: 26px;
            height: 26px;
            background: white;
            border-radius: 50%;
            display: flex;
            justify-content: center;
            align-items: center;
            z-index: 2;
            color: #4295ff;
            font-size: 10px;
            font-weight: 800;
            box-shadow: 0 2px 6px rgba(0,0,0,0.3);
            margin-bottom: 4px; /* Meter ke andar sabse niche */
        }

        .nav-center span {
            font-size: 13px;
            font-weight: 700;
            color: #4295ff;
            white-space: nowrap;
        }
    </style>
</head>
<body>

    <!-- HEADER AREA -->
    <div class="header">
        <div class="logo">
            <i class="fa-solid fa-gem"></i> 3 win
        </div>
        
        <div class="bonus-section">
            <div class="bonus-item">
                <p>Today's bonus</p>
                <h2>₹0.00</h2>
            </div>
            <div class="divider"></div>
            <div class="bonus-item">
                <p>Total bonus</p>
                <!-- REAL FIREBASE BALANCE -->
                <h2>₹<?php echo $real_balance; ?></h2>
            </div>
        </div>

        <div class="bonus-btn">Bonus details</div>
    </div>

    <!-- ICON MENU -->
    <div class="icon-menu">
        <a href="spin.php" class="menu-item">
            <div class="icon-box">
                <i class="fa-solid fa-dharmachakra"></i>
                <div class="red-dot"></div>
            </div>
            <span>Invite Wheel</span>
        </a>
    </div>

    <!-- CARDS -->
    <div class="cards-area">
        <a href="gift.php" class="card">
            <img src="https://i.ibb.co/wFNHqSpq/sign-In-Banner-D5-E7-GDCc.png" alt="Gifts">
            <div class="card-content">
                <h3>Gifts</h3>
                <p>Enter the redemption code to receive gift rewards</p>
            </div>
        </a>

        <a href="attendance-bonus.php" class="card">
            <img src="https://i.ibb.co/CKHSC0wp/gift-Redeem-Bne-G-FUT.png" alt="Attendance">
            <div class="card-content">
                <h3>Attendance bonus</h3>
                <p>The more consecutive days you sign in, the higher the reward will be.</p>
            </div>
        </a>
    </div>

    <!-- BANNERS SLIDER (SCROLLABLE BY FINGER) -->
    <div class="slider-section">
        <div class="slider-wrapper">
            <div class="slide"><img src="https://i.ibb.co/xSFyW335/Banner-20260105132932b796.jpg" alt="Banner 1"></div>
            <div class="slide"><img src="https://i.ibb.co/WWtGK2DL/Banner-20260105142654poy4.png" alt="Banner 2"></div>
            <div class="slide"><img src="https://i.ibb.co/spDx3mLD/trashed-1791111713-Banner-20260105180824tvv4.png" alt="Banner 3"></div>
            <div class="slide"><img src="https://i.ibb.co/274NDY3F/trashed-1791111696-Banner-20260105180751t1nw.png" alt="Banner 4"></div>
        </div>
    </div>

    <!-- FLOATING CUSTOMER SERVICE ICON (AB SCREEN PAR FIX RAHEGA) -->
    <a href="customer-service.php" class="floating-chat">
        <img src="https://i.ibb.co/YYwGN9L/icon-sevice-BIWTN-c-L-1.png" alt="Customer Service">
    </a>

    <!-- BOTTOM NAVIGATION (EXACT SCREENSHOT DESIGN) -->
    <div class="bottom-nav">
        <!-- Home -->
        <a href="dashboard.php" class="nav-item">
            <i class="fa-solid fa-house"></i>
            <span>Home</span>
        </a>
        
        <!-- Activity (Active with Red Dot) -->
        <a href="activity.php" class="nav-item active">
            <i class="fa-solid fa-bag-shopping"></i>
            <span>Activity</span>
            <div class="nav-dot"></div>
        </a>
        
        <!-- CENTER GAUGE BUTTON (PERFECT SPEEDOMETER DESIGN) -->
        <a href="spin.php" class="nav-center">
            <div class="gauge-wrapper">
                <div class="gauge-meter">
                    <!-- The tiny GO button inside the meter at the bottom -->
                    <div class="gauge-go">GO</div>
                </div>
            </div>
            <span>Get ₹500</span>
        </a>

        <!-- Promotion -->
        <a href="promotion.php" class="nav-item">
            <i class="fa-solid fa-wallet"></i>
            <span>Promotion</span>
        </a>
        
        <!-- Account -->
        <a href="account.php" class="nav-item">
            <i class="fa-regular fa-user"></i>
            <span>Account</span>
        </a>
    </div>

</body>
</html>
