<?php
require_once 'config.php'; 
$real_balance = "0.00";
if (isset($_SESSION['phone'])) {
    $user_phone = $_SESSION['phone'];
    $userData = firebase_read("users/" . $user_phone);
    if ($userData && isset($userData['balance'])) {
        $real_balance = number_format((float)$userData['balance'], 2, '.', '');
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
<title>3 win - Activity</title>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
<link href="https://fonts.googleapis.com/icon?family=Material+Icons+Round" rel="stylesheet">
<style>
* { margin: 0; padding: 0; box-sizing: border-box; font-family: 'Inter', sans-serif; -webkit-tap-highlight-color: transparent; }
body { background-color: #f4f6fa; max-width: 480px; margin: 0 auto; position: relative; min-height: 100vh; padding-bottom: 85px; overflow-x: hidden; }
a { text-decoration: none; }

.header { background: linear-gradient(180deg, #4295ff 0%, #68b1ff 100%); padding: 25px 20px 30px 20px; color: white; border-bottom-left-radius: 28px; border-bottom-right-radius: 28px; text-align: center; }
.logo { font-size: 22px; font-weight: 800; font-style: italic; display: flex; justify-content: center; align-items: center; gap: 8px; margin-bottom: 25px; letter-spacing: 0.5px; }
.bonus-section { display: flex; align-items: center; justify-content: center; margin-bottom: 20px; }
.bonus-item { flex: 1; }
.bonus-item p { font-size: 13px; margin-bottom: 4px; font-weight: 500; color: rgba(255, 255, 255, 0.9); }
.bonus-item h2 { font-size: 24px; font-weight: 700; }
.divider { width: 1px; height: 35px; background-color: rgba(255, 255, 255, 0.3); margin: 0 10px; }
.bonus-btn { background-color: white; color: #4295ff; border: none; padding: 10px 32px; border-radius: 25px; font-size: 15px; font-weight: 600; cursor: pointer; display: inline-block; }

.icon-menu { padding: 20px 15px 5px 15px; display: flex; justify-content: flex-start; }
.menu-item-icon { display: flex; flex-direction: column; align-items: center; width: 80px; position: relative; }
.icon-box { width: 55px; height: 55px; background: linear-gradient(135deg, #ff9f8c 0%, #ffd0bc 100%); border-radius: 18px; display: flex; justify-content: center; align-items: center; margin-bottom: 8px; position: relative; }
.icon-box i { font-size: 30px; color: white; opacity: 0.9; }
.red-dot { position: absolute; top: -2px; right: -2px; width: 12px; height: 12px; background-color: #ff3b30; border-radius: 50%; border: 2px solid white; }
.menu-item-icon span { font-size: 13px; color: #7d8495; font-weight: 500; }

.cards-area { display: grid; grid-template-columns: 1fr 1fr; gap: 12px; padding: 15px; }
.card { background: white; border-radius: 12px; overflow: hidden; box-shadow: 0 4px 15px rgba(0,0,0,0.04); display: flex; flex-direction: column; height: 100%; }
.card img { width: 100%; height: 95px; object-fit: cover; border-top-left-radius: 12px; border-top-right-radius: 12px; }
.card-content { padding: 12px; }
.card-content h3 { font-size: 15px; color: #1c1c1c; margin-bottom: 5px; font-weight: 700; }
.card-content p { font-size: 12px; color: #8a92a3; line-height: 1.4; font-weight: 500; }

.slider-section { padding: 5px 15px 20px 15px; }
.slider-wrapper { display: flex; overflow-x: auto; scroll-snap-type: x mandatory; gap: 10px; border-radius: 14px; scrollbar-width: none; }
.slider-wrapper::-webkit-scrollbar { display: none; }
.slide { min-width: 100%; scroll-snap-align: center; }
.slide img { width: 100%; display: block; border-radius: 14px; height: 140px; object-fit: cover; box-shadow: 0 4px 12px rgba(0,0,0,0.08); }

.floating-chat { position: fixed; right: 15px; bottom: 110px; width: 50px; height: 50px; z-index: 999; cursor: pointer; border-radius: 50%; box-shadow: 0 4px 15px rgba(0,0,0,0.25); background: white; overflow: hidden; display: flex; justify-content: center; align-items: center; transition: transform 0.2s ease; }
.floating-chat:active { transform: scale(0.95); }
.floating-chat img { width: 100%; height: 100%; object-fit: cover; }

/* UNIVERSAL BOTTOM NAV */
.bottom-nav { position: fixed; bottom: 0; width: 100%; max-width: 480px; left: 50%; transform: translateX(-50%); background: white; display: flex; justify-content: space-around; align-items: flex-end; padding: 10px 0 12px; box-shadow: 0 -4px 20px rgba(0,0,0,0.06); z-index: 1000; border-radius: 20px 20px 0 0; }
.nav-item { display: flex; flex-direction: column; align-items: center; color: #999; text-decoration: none; font-size: 11px; font-weight: 700; gap: 4px; flex: 1; }
.nav-item .material-icons-round { font-size: 26px; }
.nav-item.active { color: #4781ff; }
.nav-center { flex: 1; display: flex; flex-direction: column; align-items: center; text-decoration: none; color: #4781ff; font-size: 12px; font-weight: 800; position: relative; margin-top: -30px; gap: 2px; }
.nav-center-bg { background: white; width: 68px; height: 68px; border-radius: 50%; display: flex; align-items: center; justify-content: center; box-shadow: 0 -4px 10px rgba(0,0,0,0.05); }
.nav-center-img { width: 58px; height: 58px; border-radius: 50%; object-fit: cover; box-shadow: 0 4px 10px rgba(255, 136, 0, 0.4); }
</style>
</head>
<body>

    <div class="header">
        <div class="logo"><i class="fa-solid fa-gem"></i> 3 win</div>
        <div class="bonus-section">
            <div class="bonus-item"><p>Today's bonus</p><h2>₹0.00</h2></div>
            <div class="divider"></div>
            <div class="bonus-item"><p>Total bonus</p><h2>₹<?php echo $real_balance; ?></h2></div>
        </div>
        <div class="bonus-btn">Bonus details</div>
    </div>

    <div class="icon-menu">
        <a href="spin.php" class="menu-item-icon">
            <div class="icon-box"><i class="fa-solid fa-dharmachakra"></i><div class="red-dot"></div></div>
            <span>Invite Wheel</span>
        </a>
    </div>

    <div class="cards-area">
        <a href="gift.php" class="card">
            <img src="https://i.ibb.co/wFNHqSpq/sign-In-Banner-D5-E7-GDCc.png">
            <div class="card-content"><h3>Gifts</h3><p>Enter the redemption code to receive gift rewards</p></div>
        </a>
        <a href="attendance-bonus.php" class="card">
            <img src="https://i.ibb.co/CKHSC0wp/gift-Redeem-Bne-G-FUT.png">
            <div class="card-content"><h3>Attendance bonus</h3><p>The more consecutive days you sign in, the higher the reward.</p></div>
        </a>
    </div>

    <div class="slider-section">
        <div class="slider-wrapper">
            <div class="slide"><img src="https://i.ibb.co/xSFyW335/Banner-20260105132932b796.jpg"></div>
            <div class="slide"><img src="https://i.ibb.co/WWtGK2DL/Banner-20260105142654poy4.png"></div>
            <div class="slide"><img src="https://i.ibb.co/spDx3mLD/trashed-1791111713-Banner-20260105180824tvv4.png"></div>
            <div class="slide"><img src="https://i.ibb.co/274NDY3F/trashed-1791111696-Banner-20260105180751t1nw.png"></div>
        </div>
    </div>

    <a href="customer-service.php" class="floating-chat"><img src="https://i.ibb.co/YYwGN9L/icon-sevice-BIWTN-c-L-1.png"></a>

    <!-- FIXED BOTTOM NAVIGATION -->
    <div class="bottom-nav">
        <a href="dashboard.php" class="nav-item <?php echo (basename($_SERVER['PHP_SELF']) == 'dashboard.php') ? 'active' : ''; ?>">
            <span class="material-icons-round">home</span>Home
        </a>
        <a href="activity.php" class="nav-item <?php echo (basename($_SERVER['PHP_SELF']) == 'activity.php') ? 'active' : ''; ?>">
            <span class="material-icons-round">local_activity</span>Activity
        </a>
        <a href="spin.php" class="nav-center">
            <div class="nav-center-bg"><img src="https://i.ibb.co/KxgzgMNB/images.png" class="nav-center-img"></div>
            <span>Get ₹500</span>
        </a>
        <a href="promotion.php" class="nav-item <?php echo (basename($_SERVER['PHP_SELF']) == 'promotion.php') ? 'active' : ''; ?>">
            <span class="material-icons-round">card_giftcard</span>Promotion
        </a>
        <a href="account.php" class="nav-item <?php echo (basename($_SERVER['PHP_SELF']) == 'account.php') ? 'active' : ''; ?>">
            <span class="material-icons-round">person</span>Account
        </a>
    </div>

</body>
</html>