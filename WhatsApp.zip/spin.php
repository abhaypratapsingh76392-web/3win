<?php
require_once __DIR__ . '/config.php';

if (!isset($_SESSION['phone'])) {
    die('<meta name="viewport" content="width=device-width,initial-scale=1"><center style="margin-top:80px;font-family:sans-serif">Pehle login karo</center>');
}

$phone    = $_SESSION['phone'];
$memberId = 'Member' . strtoupper(substr(md5($phone . '3win'), 0, 8));
$INVITE   = 'https://3win.gamer.gd/promotion.php?view=invite';
$TARGET   = 500.00;
$HOURS    = 120;

function wkey($p){ return "users/{$p}/wheel"; }
function hkey($p){ return "users/{$p}/wheel_history"; }
function wdef(){
    return ['balance'=>0,'spins'=>0,'box_open'=>false,'timer'=>time()+120*3600];
}

if ($_SERVER['REQUEST_METHOD']==='POST' && isset($_POST['action'])) {
    header('Content-Type: application/json');
    $act = $_POST['action'];
    $wd  = firebase_read(wkey($phone));
    if (!is_array($wd)) $wd = wdef();

    if ($act === 'status') {
        $hist = firebase_read(hkey($phone));
        echo json_encode(['ok'=>1,'d'=>$wd,'id'=>$memberId,'h'=>is_array($hist)?array_values($hist):[]]);
        exit;
    }

    if ($act === 'open_box') {
        if (!empty($wd['box_open'])) { echo json_encode(['ok'=>0,'msg'=>'already']); exit; }
        $win = round(mt_rand(48000,48500)/100, 2);
        $fake = [
            $win,
            round(mt_rand(30000,40000)/100,2),
            round(mt_rand(47000,48500)/100,2),
            round(mt_rand(49000,49990)/100,2),
        ];
        shuffle($fake);
        $wd['balance']  = $win;
        $wd['spins']    = 1;
        $wd['box_open'] = true;
        $wd['timer']    = time() + $HOURS*3600;
        firebase_write(wkey($phone), $wd);
        $hist = [['a'=>$win,'t'=>date('Y-m-d H:i:s')]];
        firebase_write(hkey($phone), $hist);
        echo json_encode(['ok'=>1,'win'=>$win,'fake'=>$fake,'spins'=>1,'timer'=>$wd['timer'],'h'=>$hist,'id'=>$memberId]);
        exit;
    }

    if ($act === 'spin') {
        if ((int)$wd['spins'] <= 0) { echo json_encode(['ok'=>0,'msg'=>'nospin']); exit; }
        $bal = (float)$wd['balance'];
        if ($bal >= 499) {
            $reward = 0.00;
            $seg = 0; // visual: 0.5-10 slice, amount 0
        } else {
            $reward = round(mt_rand(50, 1000)/100, 2); // 0.50–10
            if ($bal + $reward > 499.99) $reward = round(499.99 - $bal, 2);
            $seg = 0; // ₹0.5-10 (top)
        }
        $wd['spins']   = (int)$wd['spins'] - 1;
        $wd['balance'] = round($bal + $reward, 2);
        firebase_write(wkey($phone), $wd);
        $hist = firebase_read(hkey($phone));
        $hist = is_array($hist) ? array_values($hist) : [];
        if ($reward > 0) {
            array_unshift($hist, ['a'=>$reward,'t'=>date('Y-m-d H:i:s')]);
            $hist = array_slice($hist, 0, 20);
            firebase_write(hkey($phone), $hist);
        }
        echo json_encode(['ok'=>1,'reward'=>$reward,'bal'=>$wd['balance'],'spins'=>$wd['spins'],'seg'=>$seg,'h'=>$hist]);
        exit;
    }

    if ($act === 'add_spin_deposit') {
        $inv = preg_replace('/\D/','', $_POST['inviter_phone'] ?? '');
        if ($inv) {
            $iw = firebase_read(wkey($inv));
            if (is_array($iw)) { $iw['spins'] = (int)$iw['spins'] + 1; firebase_write(wkey($inv), $iw); }
        }
        echo json_encode(['ok'=>1]); exit;
    }
    echo json_encode(['ok'=>0]); exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no">
<meta name="theme-color" content="#3B82F6">
<title>Invite Wheel</title>
<style>
*{margin:0;padding:0;box-sizing:border-box;font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,sans-serif;-webkit-tap-highlight-color:transparent;user-select:none}
html,body{height:100%;background:#000}
.app{max-width:430px;margin:0 auto;min-height:100%;position:relative;overflow-x:hidden}

/* HEADER */
.hd{height:48px;background:linear-gradient(#4ea0f5,#3b82f6);display:flex;align-items:center;justify-content:space-between;padding:0 10px 0 6px;position:sticky;top:0;z-index:40}
.hd h1{color:#fff;font-size:17px;font-weight:700;position:absolute;left:50%;transform:translateX(-50%)}
.ib{background:0;border:0;width:36px;height:36px;display:grid;place-items:center;color:#fff}

/* WHEEL PAGE */
#pw{display:none;background:linear-gradient(180deg,#ff7a45 0%,#ff5a38 28%,#ee3a3a 62%,#d4263a 100%);padding-bottom:28px;min-height:100%}
.sky{position:relative;overflow:hidden}
.sky:before{content:"";position:absolute;left:-20%;right:-20%;bottom:38%;height:180px;background:radial-gradient(ellipse at 50% 100%,rgba(255,180,90,.35),transparent 70%);pointer-events:none}
.amt{text-align:center;padding:12px 0 6px;position:relative;z-index:2}
.amt .lab{color:#fff;font-size:13px;font-weight:500}
.amt .n{font-size:42px;font-weight:800;line-height:1.15;background:linear-gradient(#fff36a,#ffd000);-webkit-background-clip:text;background-clip:text;color:transparent;filter:drop-shadow(0 2px 0 rgba(180,40,0,.45))}
.co{margin-top:8px;border:0;color:#fff;font-weight:800;font-size:16px;letter-spacing:.4px;padding:10px 42px;border-radius:24px;background:linear-gradient(#ffc44a,#ff8c12);box-shadow:0 5px 0 #c85a00,0 8px 16px rgba(120,20,0,.35)}
.co:active{transform:translateY(2px);box-shadow:0 3px 0 #c85a00}

/* WHEEL */
.wa{position:relative;width:340px;height:390px;margin:8px auto 0}
.coin{position:absolute;width:52px;height:52px;border-radius:50%;background:radial-gradient(circle at 32% 28%,#ffe9a0,#f5c431 55%,#d48a08);box-shadow:inset 0 0 0 5px rgba(255,255,255,.25),0 4px 8px rgba(0,0,0,.25);z-index:3}
.cl{left:4px;bottom:70px;transform:rotate(-18deg)}
.cr{right:2px;top:86px;transform:rotate(22deg)}
.cb1{left:18px;bottom:18px;width:48px;height:48px;opacity:.95}
.cb2{right:22px;bottom:22px;width:44px;height:44px}

svg.wh{width:318px;height:318px;display:block;margin:0 auto;position:relative;z-index:4;filter:drop-shadow(0 10px 16px rgba(80,0,0,.35))}
#rot{transform-origin:160px 160px;transition:none}
#rot.go{transition:transform 4.2s cubic-bezier(.12,.75,.08,1)}

.stand{position:absolute;left:50%;bottom:8px;transform:translateX(-50%);width:210px;z-index:1}
.st-t{height:58px;background:linear-gradient(#e44,#b51c1c);border-radius:8px 8px 4px 4px;box-shadow:inset 0 -12px 16px rgba(0,0,0,.25)}
.st-b{height:22px;margin:0 -18px;background:linear-gradient(#c62828,#8e1212);border-radius:4px 4px 10px 10px}

.hub{position:absolute;left:50%;top:159px;transform:translate(-50%,-50%);width:92px;height:92px;border-radius:50%;background:#fff;border:5px solid #e63b3b;z-index:8;display:flex;flex-direction:column;align-items:center;justify-content:center;color:#e63b3b;box-shadow:0 0 0 3px #ffe9b8,0 6px 14px rgba(0,0,0,.28);cursor:pointer}
.hub b{font-size:28px;line-height:1;font-weight:900}
.hub s{font-size:9px;text-decoration:none;font-weight:800;margin-top:2px;letter-spacing:.2px}
.burst{position:absolute;left:50%;top:159px;transform:translate(-50%,-50%);pointer-events:none;z-index:9;font-size:22px;opacity:0}
.burst.on{animation:burst .9s ease-out}
@keyframes burst{0%{opacity:1;transform:translate(-50%,-50%) scale(.4)}100%{opacity:0;transform:translate(-50%,-50%) scale(1.6)}}

.bot{padding:4px 18px 0;position:relative;z-index:5}
.inv{width:100%;border:0;color:#fff;font-weight:800;font-size:15px;padding:14px 12px;border-radius:28px;background:linear-gradient(#ffd24a,#ff9a18);box-shadow:0 5px 0 #c87000,0 8px 14px rgba(80,0,0,.28);letter-spacing:.3px}
.inv:active{transform:translateY(2px)}
.left{text-align:center;color:#fff;font-size:13px;margin:10px 0 18px;font-weight:500}
.cs{position:absolute;right:8px;bottom:78px;width:58px;height:58px;background:url('https://www.goaok.org/assets/png/icon_sevice-BIWTN_cL.png') center/contain no-repeat;z-index:12}

.rec h3{color:#fff;font-size:20px;font-weight:800;margin:6px 0 8px}
.ri{display:flex;align-items:center;gap:10px;padding:10px 0;border-bottom:1px solid rgba(255,255,255,.12)}
.av{width:42px;height:42px;border-radius:50%;background:#ffe8c8;overflow:hidden;flex-shrink:0}
.av img{width:100%;height:100%}
.rn{flex:1;color:#fff;font-size:14px;font-weight:600}
.ra{text-align:right}
.ra b{display:block;color:#ffd24a;font-size:15px}
.ra i{font-style:normal;color:rgba(255,255,255,.75);font-size:11px}

/* BOX PAGE */
#pb{min-height:100%;background:#000;display:flex;flex-direction:column}
.bb{padding:14px 12px}
.tt{text-align:center;margin-top:8vh;font-size:26px;font-weight:800;background:linear-gradient(#fff1a8,#f0b429);-webkit-background-clip:text;background-clip:text;color:transparent}
.g{display:grid;grid-template-columns:1fr 1fr;gap:36px 22px;padding:48px 36px 0}
.sl{display:flex;flex-direction:column;align-items:center;position:relative}
.bx{width:112px;height:112px;cursor:pointer}
.bx img{width:100%;height:100%;object-fit:contain}
.sl.win .bx{filter:drop-shadow(0 0 18px #ffb84a)}
.pill{margin-top:10px;min-width:108px;text-align:center;background:#5a0c0c;border:1.5px solid #e8a43a;color:#ffd24a;border-radius:20px;padding:5px 10px;font-weight:700;font-size:14px;opacity:0}
.pill.on{opacity:1}
.ch{text-align:center;color:#eee;margin-top:40px;font-size:16px}

#ld{position:fixed;inset:0;display:none;place-items:center;background:rgba(0,0,0,.45);z-index:80}
#ld.on{display:grid}
.ldb{width:140px;height:140px;background:rgba(40,28,12,.92);border-radius:12px;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:12px;color:#fff;font-size:14px}
.sp{width:32px;height:32px;border:3px solid rgba(255,255,255,.25);border-top-color:#fff;border-radius:50%;animation:rt 1s linear infinite}
@keyframes rt{to{transform:rotate(360deg)}}

.mo{position:fixed;inset:0;display:none;place-items:center;background:rgba(0,0,0,.45);z-index:90}
.mo.on{display:grid}
.mc{background:#fff;width:78%;max-width:300px;border-radius:16px;padding:22px 18px;text-align:center}
.mc h2{color:#e63b3b;font-size:18px}
.mc p{margin:8px 0 14px;color:#333;font-size:14px;line-height:1.45}
.mc button{border:0;background:linear-gradient(#ffb02e,#ff8a00);color:#fff;font-weight:800;padding:9px 28px;border-radius:20px}
</style>
</head>
<body>
<div class="app">

<div id="pb">
  <div class="bb"><button class="ib" onclick="history.back()"><svg width="22" height="22" fill="none" stroke="#fff" stroke-width="2.4"><path d="M14 5 7 12l7 7"/></svg></button></div>
  <div class="tt">༄ Cash everyday ༅</div>
  <div class="g" id="g"></div>
  <div class="ch">Choose your reward</div>
</div>

<div id="pw">
  <div class="hd">
    <button class="ib" onclick="history.back()"><svg width="22" height="22" fill="none" stroke="#fff" stroke-width="2.4"><path d="M14 5 7 12l7 7"/></svg></button>
    <h1>Invite Wheel</h1>
    <div style="display:flex">
      <button class="ib" onclick="pop('Rules','Invite friends. Jab woh <b>deposit</b> karein tab +1 FREE spin. Sirf login = spin nahi. ₹500 par CASH OUT.')"><svg width="22" height="22" fill="none" stroke="#fff" stroke-width="2"><circle cx="11" cy="11" r="9"/><path d="M9 8.2a2.2 2.2 0 1 1 2.6 2.1c-.7.3-1.1.8-1.1 1.6"/><circle cx="11" cy="16" r=".8" fill="#fff" stroke="none"/></svg></button>
      <button class="ib" onclick="document.getElementById('rec').scrollIntoView({behavior:'smooth'})"><svg width="22" height="22" fill="none" stroke="#fff" stroke-width="2"><rect x="5" y="3" width="12" height="16" rx="1.5"/><path d="M8 8h6M8 11h6"/><circle cx="14" cy="15.5" r="2"/></svg></button>
    </div>
  </div>

  <div class="sky">
    <div class="amt">
      <div class="lab">my amount(<span id="tm">119:59:59</span>)</div>
      <div class="n" id="am">₹0.00</div>
      <button class="co" onclick="cash()">CASH OUT</button>
    </div>

    <div class="wa">
      <i class="coin cl"></i><i class="coin cr"></i>
      <i class="coin cb1"></i><i class="coin cb2"></i>

      <svg class="wh" viewBox="0 0 320 320">
        <defs>
          <linearGradient id="gold" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#ffe9a8"/><stop offset="1" stop-color="#e8b24a"/></linearGradient>
          <linearGradient id="rim" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#ff6a4a"/><stop offset="1" stop-color="#e23a32"/></linearGradient>
        </defs>
        <circle cx="160" cy="160" r="158" fill="url(#gold)"/>
        <circle cx="160" cy="160" r="148" fill="url(#rim)"/>
        <g id="rot">
          <!-- 8 slices: cream / pale yellow, start -22.5 so a slice is centered at top -->
          <path d="M160,160 L160,18 A142,142 0 0,1 260.4,59.6 Z" fill="#fff8ee"/>
          <path d="M160,160 L260.4,59.6 A142,142 0 0,1 302,160 Z" fill="#ffe7a8"/>
          <path d="M160,160 L302,160 A142,142 0 0,1 260.4,260.4 Z" fill="#fff8ee"/>
          <path d="M160,160 L260.4,260.4 A142,142 0 0,1 160,302 Z" fill="#ffe7a8"/>
          <path d="M160,160 L160,302 A142,142 0 0,1 59.6,260.4 Z" fill="#fff8ee"/>
          <path d="M160,160 L59.6,260.4 A142,142 0 0,1 18,160 Z" fill="#ffe7a8"/>
          <path d="M160,160 L18,160 A142,142 0 0,1 59.6,59.6 Z" fill="#fff8ee"/>
          <path d="M160,160 L59.6,59.6 A142,142 0 0,1 160,18 Z" fill="#ffe7a8"/>
          <!-- labels (rotated with wheel). Index 0 = top ₹0.5-10 -->
          <g font-size="13" font-weight="800" fill="#e23a32" text-anchor="middle">
            <text x="160" y="48">₹0.5-10</text>
            <text transform="rotate(45 160 160)" x="160" y="48">₹19</text>
            <text transform="rotate(90 160 160)" x="160" y="48">₹29</text>
            <text transform="rotate(135 160 160)" x="160" y="48">₹500</text>
            <text transform="rotate(180 160 160)" x="160" y="48">₹299</text>
            <text transform="rotate(225 160 160)" x="160" y="48">₹59</text>
            <text transform="rotate(270 160 160)" x="160" y="48">₹99</text>
            <text transform="rotate(315 160 160)" x="160" y="48">₹199</text>
          </g>
          <g font-size="20" text-anchor="middle">
            <text x="160" y="78">🪙</text>
            <text transform="rotate(45 160 160)" x="160" y="78">🪙</text>
            <text transform="rotate(90 160 160)" x="160" y="78">🪙</text>
            <text transform="rotate(135 160 160)" x="160" y="78">💵</text>
            <text transform="rotate(180 160 160)" x="160" y="78">💵</text>
            <text transform="rotate(225 160 160)" x="160" y="78">🪙</text>
            <text transform="rotate(270 160 160)" x="160" y="78">🪙</text>
            <text transform="rotate(315 160 160)" x="160" y="78">💵</text>
          </g>
        </g>
        <!-- bulbs on rim -->
        <g id="bulbs"></g>
        <!-- gold pointer arch -->
        <path d="M118,28 Q160,-6 202,28 L188,42 Q160,18 132,42 Z" fill="url(#gold)" stroke="#d4a03a" stroke-width="2"/>
        <polygon points="160,36 148,58 172,58" fill="#fff"/>
      </svg>

      <div class="hub" onclick="spin()"><b id="xn">X0</b><s>FREE SPIN</s></div>
      <div class="burst" id="burst">✨🪙💵🪙</div>
      <div class="stand"><div class="st-t"></div><div class="st-b"></div></div>
    </div>
  </div>

  <div class="bot">
    <button class="inv" onclick="location.href=<?= json_encode($INVITE) ?>">INVITE FRIENDS TO GET SPIN</button>
    <div class="left" id="lf">Only ₹500.00 left to get prize ₹500.00</div>
    <div class="cs" onclick="pop('Support','Customer service')"></div>
    <div class="rec" id="rec"><h3>Record</h3><div id="rl"></div></div>
  </div>
</div>
</div>

<div id="ld"><div class="ldb"><div class="sp"></div>loading...</div></div>
<div class="mo" id="mo"><div class="mc"><h2 id="mt"></h2><p id="mm"></p><button onclick="document.getElementById('mo').classList.remove('on')">OK</button></div></div>

<script>
const ID = <?= json_encode($memberId) ?>;
const TARGET = <?= $TARGET ?>;
let bal=0,spins=0,end=0,rot=0,busy=false,tid=null;

const bulbs = document.getElementById('bulbs');
for(let i=0;i<24;i++){
  const a = (i/24)*Math.PI*2 - Math.PI/2;
  const x = 160 + Math.cos(a)*148, y = 160 + Math.sin(a)*148;
  const c = document.createElementNS('http://www.w3.org/2000/svg','circle');
  c.setAttribute('cx',x); c.setAttribute('cy',y); c.setAttribute('r','4.2');
  c.setAttribute('fill','#fff');
  bulbs.appendChild(c);
}

const g = document.getElementById('g');
for(let i=0;i<4;i++){
  g.innerHTML += `<div class="sl"><div class="bx" onclick="openBox(${i})"><img src="https://i.ibb.co/Ng4R6ntK/download-1.png"></div><div class="pill" id="p${i}">₹0.00</div></div>`;
}

function money(n){return '₹'+Number(n).toFixed(2)}
function ld(v){document.getElementById('ld').classList.toggle('on',v)}
function pop(t,m){document.getElementById('mt').innerHTML=t;document.getElementById('mm').innerHTML=m;document.getElementById('mo').classList.add('on')}
async function api(a,extra={}){
  const fd=new FormData(); fd.append('action',a);
  for(const k in extra) fd.append(k,extra[k]);
  return (await fetch(location.pathname,{method:'POST',body:fd})).json();
}
function tick(){
  const s=Math.max(0,end-Math.floor(Date.now()/1000));
  const h=String(Math.floor(s/3600)).padStart(2,'0');
  const m=String(Math.floor(s%3600/60)).padStart(2,'0');
  const ss=String(s%60).padStart(2,'0');
  document.getElementById('tm').textContent=h+':'+m+':'+ss;
}
function ui(){
  document.getElementById('am').textContent=money(bal);
  document.getElementById('xn').textContent='X'+spins;
  const left=Math.max(0,TARGET-bal);
  document.getElementById('lf').textContent=`Only ${money(left)} left to get prize ${money(TARGET)}`;
}
function recs(h){
  const w=document.getElementById('rl'); w.innerHTML='';
  (h||[]).forEach(r=>{
    w.innerHTML += `<div class="ri"><div class="av"><img src="https://api.dicebear.com/9.x/avataaars/svg?seed=${ID}"></div>
      <div class="rn">${ID}</div>
      <div class="ra"><b>${money(r.a)}</b><i>${r.t}</i></div></div>`;
  });
}
function goWheel(){
  document.getElementById('pb').style.display='none';
  document.getElementById('pw').style.display='block';
  ui();
}

async function boot(){
  ld(true);
  const r=await api('status');
  setTimeout(()=>{
    ld(false);
    if(r.ok){
      bal=+r.d.balance||0; spins=+r.d.spins||0; end=+r.d.timer||0;
      recs(r.h); tick(); clearInterval(tid); tid=setInterval(tick,1000);
      if(r.d.box_open) goWheel();
    }
  },900);
}

async function openBox(i){
  if(busy) return; busy=true; ld(true);
  const r=await api('open_box');
  setTimeout(()=>{
    ld(false);
    if(!r.ok){ goWheel(); busy=false; return; }
    document.querySelectorAll('.pill').forEach((p,idx)=>{ p.textContent=money(r.fake[idx]); p.classList.add('on'); });
    document.querySelectorAll('.sl')[i].classList.add('win');
    bal=r.win; spins=r.spins; end=r.timer; recs(r.h);
    setTimeout(()=>{ goWheel(); tick(); clearInterval(tid); tid=setInterval(tick,1000); busy=false; },1400);
  },1100);
}

async function spin(){
  if(busy) return;
  if(spins<=0){ location.href=<?= json_encode($INVITE) ?>; return; }
  busy=true;
  const r=await api('spin');
  if(!r.ok){ busy=false; location.href=<?= json_encode($INVITE) ?>; return; }
  document.getElementById('xn').textContent='...';
  const land = -r.seg*45;
  const extra = 360*6;
  const cur = rot % 360;
  let d = (land - cur + 360)%360;
  rot += extra + d;
  const el=document.getElementById('rot');
  el.classList.add('go');
  el.style.transform=`rotate(${rot}deg)`;
  document.getElementById('burst').classList.add('on');
  setTimeout(()=>{
    document.getElementById('burst').classList.remove('on');
    bal=r.bal; spins=r.spins; recs(r.h); ui();
    if(r.reward>0) pop('Congratulations!', 'You got <b>'+money(r.reward)+'</b>');
    else pop('Oops','₹0.00 — dost ko invite karke <b>deposit</b> karwao.');
    busy=false;
  },4300);
}

function cash(){
  if(bal>=TARGET) pop('CASH OUT','₹500 ready!');
  else pop('CASH OUT','Reach '+money(TARGET)+'. Left '+money(Math.max(0,TARGET-bal)));
}

boot();
</script>
</body>
</html>