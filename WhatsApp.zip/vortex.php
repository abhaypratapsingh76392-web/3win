<?php
require_once 'config.php';
$PHONE = isset($_SESSION['phone']) ? $_SESSION['phone'] : '';
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
<title>Vortex - Official Game</title>
<style>
@import url('https://fonts.googleapis.com/css2?family=Montserrat:ital,wght@0,600;0,700;0,800;0,900;1,800;1,900&display=swap');
*{margin:0;padding:0;box-sizing:border-box;font-family:'Montserrat',sans-serif;-webkit-tap-highlight-color:none;user-select:none}
html,body{height:100%}
body{background:#0b0d12;color:#fff;overflow:hidden;touch-action:manipulation}
#app{max-width:440px;height:100vh;margin:0 auto;display:flex;flex-direction:column;position:relative;background:
 radial-gradient(1200px 600px at 80% 10%, #171a22 0%, transparent 60%),
 radial-gradient(900px 500px at 10% 90%, #14161e 0%, transparent 60%),
 linear-gradient(180deg,#171921 0%,#101218 40%,#0b0d12 100%)}

/* ---------- HEADER ---------- */
.hdr{display:flex;align-items:center;justify-content:space-between;padding:12px 14px;gap:10px}
.hbtn{background:none;border:none;color:#cfd6e4;cursor:pointer;opacity:.85;transition:.15s;display:flex;align-items:center;justify-content:center;width:38px;height:38px;border-radius:50%;position:relative;overflow:hidden}
.hbtn:active{transform:scale(.88);opacity:1}
.hbtn svg{width:22px;height:22px}
.back{font-size:30px;font-weight:700;color:#fff}
.bal-pill{display:flex;align-items:center;gap:10px;background:linear-gradient(90deg,#173a63,#0e2a4d 60%,#0b2140);border:1px solid #2a5a8f;border-radius:26px;padding:6px 8px;box-shadow:0 4px 14px rgba(0,0,0,.5), inset 0 1px 0 rgba(255,255,255,.08);flex:1;max-width:230px;justify-content:space-between}
.bal-left{display:flex;align-items:center;gap:8px}
.coin-ic{width:30px;height:30px;border-radius:50%;background:radial-gradient(circle at 35% 30%,#ffe08a,#fbbf24 45%,#d97706 100%);display:flex;align-items:center;justify-content:center;font-weight:900;color:#8a4b00;font-size:16px;box-shadow:0 2px 8px rgba(251,191,36,.45)}
.bal-pill b{font-size:16px;font-weight:800;letter-spacing:.3px}
.addp{width:30px;height:30px;border-radius:50%;border:1px solid #7db4ff;background:linear-gradient(180deg,#4d94ff,#1f66e0);color:#fff;font-size:18px;font-weight:800;cursor:pointer;position:relative;overflow:hidden;transition:.15s;box-shadow:0 2px 10px rgba(59,130,246,.5)}
.addp:active{transform:scale(.88)}
.avatar{width:38px;height:38px;border-radius:50%;background:radial-gradient(circle at 35% 30%,#7dd3fc,#0ea5e9 55%,#1d4ed8 100%);border:2px solid #bae6fd;display:flex;align-items:center;justify-content:center;cursor:pointer;transition:.15s;box-shadow:0 0 14px rgba(56,189,248,.4)}
.avatar:active{transform:scale(.9)}
.avatar svg{width:22px;height:22px}
.subhdr{display:flex;align-items:center;justify-content:space-between;padding:0 18px 6px;color:#8b93a7;font-size:13px;font-weight:700}
.wallet{display:flex;align-items:center;gap:7px}
.wallet svg{width:18px;height:15px;opacity:.85}
.subicons{display:flex;gap:6px}

/* ---------- LOGO ---------- */
.logo{position:relative;text-align:center;padding:2px 0 0;height:78px}
.logo svg.swoosh{position:absolute;left:50%;top:2px;transform:translateX(-50%);width:210px;height:80px}
.logo h1{position:relative;font-style:italic;font-weight:900;font-size:34px;letter-spacing:2px;line-height:68px;
 background:linear-gradient(180deg,#ffffff 0%,#d9dde6 35%,#8f96a8 50%,#f5f7ff 55%,#aeb4c6 100%);
 -webkit-background-clip:text;background-clip:text;-webkit-text-fill-color:transparent;
 filter:drop-shadow(0 3px 2px rgba(0,0,0,.6))}
.logo small{position:relative;display:block;font-size:10px;font-weight:800;font-style:italic;letter-spacing:3px;color:#e8ebf5;margin-top:-12px;text-shadow:0 2px 2px rgba(0,0,0,.7)}

/* ---------- WHEEL ---------- */
.wheel-zone{flex:1;display:flex;align-items:center;justify-content:center;position:relative;min-height:0}
.wheel-wrap{position:relative;width:min(94vw,400px,44vh);aspect-ratio:1/1}
.wheel-wrap svg.board{position:absolute;inset:0;width:100%;height:100%}
text.mult{font-family:'Montserrat',sans-serif;font-weight:800;font-style:italic;fill:#525b70;transition:fill .25s}
text.mult.lit-fire{fill:#ff4757}
text.mult.lit-earth{fill:#35e65a}
text.mult.lit-water{fill:#3aa0ff}
circle.arc{fill:none;stroke-linecap:round;opacity:0;transition:opacity .3s}
circle.arc.on{opacity:1}
.arc-fire{stroke:#ff4757;filter:drop-shadow(0 0 8px rgba(255,71,87,.7))}
.arc-earth{stroke:#35e65a;filter:drop-shadow(0 0 8px rgba(53,230,90,.7))}
.arc-water{stroke:#3aa0ff;filter:drop-shadow(0 0 8px rgba(58,160,255,.7))}
circle.knob{fill:#0c0f16;stroke:#000;stroke-width:2;opacity:0;transition:opacity .3s}
circle.knob.on{opacity:1}
circle.knob-ring{fill:none;stroke-width:3;opacity:0;transition:opacity .3s}
circle.knob-ring.on{opacity:1}
.kr-fire{stroke:#ff4757}.kr-earth{stroke:#35e65a}.kr-water{stroke:#3aa0ff}

.badge{position:absolute;left:50%;transform:translate(-50%,-50%);border-radius:50%;display:flex;align-items:center;justify-content:center;z-index:6;box-shadow:0 4px 12px rgba(0,0,0,.6), inset 0 -3px 6px rgba(0,0,0,.35);border:2px solid rgba(255,255,255,.15)}
.badge svg{width:74%;height:74%;filter:drop-shadow(0 1px 2px rgba(0,0,0,.5))}
.badge.fire{top:6%;width:12.5%;height:12.5%;background:radial-gradient(circle at 35% 30%,#5b2106,#3a1503 70%);box-shadow:0 0 18px rgba(249,115,22,.55)}
.badge.earth{top:15.5%;width:11.5%;height:11.5%;background:radial-gradient(circle at 35% 30%,#052e16,#03200f 70%);box-shadow:0 0 18px rgba(34,197,94,.55)}
.badge.water{top:24.5%;width:10.5%;height:10.5%;background:radial-gradient(circle at 35% 30%,#082449,#051a33 70%);box-shadow:0 0 18px rgba(59,130,246,.55)}
.badge.flash{animation:bflash .8s ease}
@keyframes bflash{0%{transform:translate(-50%,-50%) scale(1)}30%{transform:translate(-50%,-50%) scale(1.35)}100%{transform:translate(-50%,-50%) scale(1)}}

.reel-win{position:absolute;left:31%;top:31%;width:38%;height:38%;border-radius:50%;overflow:hidden;z-index:4;
 background:radial-gradient(circle at 50% 40%, #1a202b 0%, #0d1017 75%);
 box-shadow:inset 0 6px 18px rgba(0,0,0,.85), inset 0 -6px 18px rgba(0,0,0,.85);
 -webkit-mask-image:linear-gradient(180deg,transparent 0%,#000 18%,#000 82%,transparent 100%);
 mask-image:linear-gradient(180deg,transparent 0%,#000 18%,#000 82%,transparent 100%)}
.reel-strip{position:absolute;left:0;top:0;width:100%;will-change:transform}
.reel-strip.blur{filter:blur(5px) saturate(1.35) brightness(1.1)}
.reel-item{display:flex;align-items:center;justify-content:center}
.reel-item svg{width:72%;height:72%;filter:drop-shadow(0 4px 10px rgba(0,0,0,.55))}
.center-result{position:absolute;left:31%;top:31%;width:38%;height:38%;border-radius:50%;display:flex;align-items:center;justify-content:center;z-index:5;opacity:0;pointer-events:none;filter:drop-shadow(0 0 22px rgba(255,255,255,.25))}
.center-result svg{width:66%;height:66%}
.center-result.pop{animation:cpop 1s cubic-bezier(.2,1.4,.4,1) forwards}
@keyframes cpop{0%{opacity:0;transform:scale(.3)}25%{opacity:1;transform:scale(1.15)}45%{transform:scale(1)}80%{opacity:1}100%{opacity:0;transform:scale(1)}}

.winbox{position:absolute;left:50%;top:50%;transform:translate(-50%,-50%) scale(.6);width:74%;padding:26px 10px;border-radius:22px;text-align:center;z-index:9;opacity:0;pointer-events:none;
 background:rgba(13,16,24,.88);border:1px solid rgba(255,255,255,.12);backdrop-filter:blur(6px);box-shadow:0 20px 60px rgba(0,0,0,.7);transition:all .35s cubic-bezier(.2,1.3,.4,1)}
.winbox.show{opacity:1;transform:translate(-50%,-50%) scale(1)}
.winbox .wx{font-size:42px;font-weight:900;font-style:italic;letter-spacing:1px;color:#fff;text-shadow:0 0 24px rgba(255,255,255,.55)}
.winbox .wl{width:26px;height:3px;background:#fff;margin:10px auto;opacity:.7;border-radius:2px}
.winbox .wa{font-size:22px;font-weight:800;color:#e6eaf4}
.winbox.bad .wx{color:#ff5d6e;text-shadow:0 0 24px rgba(255,71,87,.6)}

/* ---------- CONTROLS ---------- */
.controls{padding:8px 18px 6px;background:linear-gradient(180deg,rgba(10,12,17,.2),rgba(8,10,14,.9))}
.bet-label{text-align:center;color:#98a9c3;font-size:12px;font-weight:700;margin-bottom:6px}
.bet-row{display:flex;align-items:center;justify-content:center;gap:12px}
.rbtn{width:48px;height:48px;border-radius:50%;border:2px solid #2b3345;background:radial-gradient(circle at 35% 30%,#2a3140,#171c26 70%);color:#dfe5f2;font-size:18px;font-weight:800;cursor:pointer;box-shadow:0 5px 14px rgba(0,0,0,.5), inset 0 2px 4px rgba(255,255,255,.08);transition:.15s;position:relative;overflow:hidden}
.rbtn:active{transform:scale(.9);filter:brightness(1.4)}
.rbtn.turbo-on{border-color:#a855f7;color:#d8b4fe;box-shadow:0 0 16px rgba(168,85,247,.5)}
.bet-box{min-width:110px;text-align:center;font-weight:800;font-size:17px;line-height:1.2;background:linear-gradient(180deg,#1b2130,#12161f);border:2px solid #2b3345;border-radius:14px;padding:8px 10px}
.bet-box small{display:block;font-size:10px;color:#8b93a7;font-weight:700}
.action-row{display:flex;align-items:center;justify-content:center;gap:22px;margin-top:10px;position:relative}
.side-btn{width:82px;height:82px;border-radius:50%;border:none;background:radial-gradient(circle at 35% 30%,#2a3140,#161b25 75%);color:#77809a;font-size:12px;font-weight:900;letter-spacing:1px;cursor:pointer;box-shadow:0 6px 16px rgba(0,0,0,.55), inset 0 2px 5px rgba(255,255,255,.06);transition:.2s;line-height:1.25;position:relative;overflow:hidden}
.side-btn:active{transform:scale(.92);filter:brightness(1.4)}
.side-btn small{font-size:11px;font-weight:800;display:block}
#cashBtn.ready{background:radial-gradient(circle at 35% 30%,#ffe08a,#fbbf24 45%,#d97706 100%);color:#5b3200;box-shadow:0 0 26px rgba(251,191,36,.65);animation:cpulse 1.4s infinite}
@keyframes cpulse{0%,100%{box-shadow:0 0 18px rgba(251,191,36,.45)}50%{box-shadow:0 0 34px rgba(251,191,36,.85)}}
.spin-wrap{width:118px;height:118px;position:relative;cursor:pointer;filter:drop-shadow(0 0 24px rgba(168,85,247,.55));transition:transform .12s;border-radius:50%;overflow:hidden}
.spin-wrap:active{transform:scale(.92)}
.spin-wrap svg{width:100%;height:100%}
.spin-wrap .rotor{transform-origin:60px 60px;animation:rot 9s linear infinite}
@keyframes rot{to{transform:rotate(360deg)}}
.spin-wrap.disabled{opacity:.45}
.foot-info{display:flex;justify-content:space-between;padding:10px 22px 2px}
.foot-info>div{text-align:center;padding:4px 12px;border-radius:12px;border:1px solid transparent;transition:.25s}
.foot-info span{color:#77809a;font-size:12px;font-weight:800}
.foot-info strong{display:block;font-size:15px;font-weight:800;color:#eef1f8;margin-top:2px}
#partBtn{cursor:pointer}
#partBtn.ready{border-color:rgba(53,230,90,.55);box-shadow:0 0 16px rgba(53,230,90,.35);background:rgba(53,230,90,.08)}
#partBtn.ready strong{color:#8dffb0}
#partBtn:active{transform:scale(.94)}
.bottom-bar{display:flex;justify-content:space-between;padding:6px 16px 8px;color:#5b6478;font-size:11px;font-weight:700}

span.rip{position:absolute;border-radius:50%;background:rgba(255,255,255,.35);transform:scale(0);animation:rip .5s ease-out forwards;pointer-events:none}
@keyframes rip{to{transform:scale(3);opacity:0}}

#toast{position:fixed;left:50%;top:18%;transform:translate(-50%,-50%) scale(.8);background:rgba(15,18,26,.95);border:1px solid rgba(255,255,255,.15);padding:12px 22px;border-radius:30px;font-weight:800;font-size:14px;z-index:999;opacity:0;pointer-events:none;transition:.25s;box-shadow:0 10px 30px rgba(0,0,0,.6)}
#toast.show{opacity:1;transform:translate(-50%,-50%) scale(1)}
#toast.red{border-color:#ff4757;color:#ff8a95}
#toast.green{border-color:#35e65a;color:#8dffb0}

/* ---------- AUTH SCREEN ---------- */
#authScreen{position:fixed;inset:0;background:linear-gradient(180deg,#12141c,#0b0d12);z-index:1000;display:flex;align-items:center;justify-content:center;padding:20px}
#authScreen.hide{display:none}
.auth-card{width:100%;max-width:360px;background:linear-gradient(180deg,#1a1e29,#12151e);border:1px solid #2b3345;border-radius:24px;padding:28px 22px;box-shadow:0 30px 80px rgba(0,0,0,.7)}
.auth-card h2{text-align:center;font-style:italic;font-weight:900;font-size:30px;letter-spacing:2px;background:linear-gradient(180deg,#fff,#a855f7);-webkit-background-clip:text;background-clip:text;-webkit-text-fill-color:transparent;margin-bottom:4px}
.auth-card p{text-align:center;color:#77809a;font-size:11px;font-weight:700;letter-spacing:3px;margin-bottom:20px}
.auth-card label{display:block;color:#98a9c3;font-size:11px;font-weight:800;margin:12px 0 5px}
.auth-card input{width:100%;background:#0e1219;border:2px solid #2b3345;border-radius:12px;padding:12px 14px;color:#fff;font-weight:700;font-size:14px;outline:none;transition:.2s}
.auth-card input:focus{border-color:#a855f7;box-shadow:0 0 12px rgba(168,85,247,.3)}
.auth-btns{display:flex;gap:10px;margin-top:20px}
.auth-btns button{flex:1;border:none;border-radius:14px;padding:14px 0;font-weight:900;font-size:14px;cursor:pointer;letter-spacing:1px;transition:.15s;position:relative;overflow:hidden}
.auth-btns button:active{transform:scale(.95)}
#loginBtn{background:linear-gradient(135deg,#a855f7,#6d28d9);color:#fff;box-shadow:0 6px 20px rgba(168,85,247,.4)}
#regBtn{background:linear-gradient(135deg,#2a3140,#171c26);color:#cfd6e4;border:2px solid #2b3345}
#inviteRow{display:none}
#inviteRow.show{display:block}
</style>
</head>
<body>

<svg width="0" height="0" style="position:absolute">
<defs>
<linearGradient id="gF" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#ffd166"/><stop offset=".45" stop-color="#f97316"/><stop offset="1" stop-color="#dc2626"/></linearGradient>
<linearGradient id="gF2" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#fff7cc"/><stop offset="1" stop-color="#fbbf24"/></linearGradient>
<linearGradient id="gE" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#bef264"/><stop offset="1" stop-color="#16a34a"/></linearGradient>
<radialGradient id="gE2" cx="40%" cy="35%" r="80%"><stop offset="0" stop-color="#4ade80"/><stop offset="1" stop-color="#15803d"/></radialGradient>
<radialGradient id="gW" cx="38%" cy="32%" r="85%"><stop offset="0" stop-color="#7cc0ff"/><stop offset="1" stop-color="#1d4ed8"/></radialGradient>
<linearGradient id="gS" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#f8fafc"/><stop offset="1" stop-color="#94a3b8"/></linearGradient>
</defs>
</svg>

<!-- LOGIN / REGISTER (uses config.php) -->
<div id="authScreen" class="<?php echo $PHONE?'hide':''; ?>">
  <div class="auth-card">
    <h2>VORTEX</h2>
    <p>OFFICIAL GAME</p>
    <label>Phone Number</label>
    <input type="tel" id="aPhone" placeholder="9876543210" maxlength="11">
    <label>Password</label>
    <input type="password" id="aPass" placeholder="••••••">
    <div id="inviteRow">
      <label>Invite Code (optional)</label>
      <input type="text" id="aInvite" placeholder="Invite code">
    </div>
    <div class="auth-btns">
      <button id="loginBtn" onclick="doAuth('login')">LOGIN</button>
      <button id="regBtn" onclick="doAuth('register')">REGISTER</button>
    </div>
  </div>
</div>

<div id="app">
  <div class="hdr">
    <button class="hbtn back" onclick="toast('Back')">‹</button>
    <div class="bal-pill">
      <div class="bal-left"><span class="coin-ic">$</span><b>₹<span id="hdrBal">0</span></b></div>
      <button class="addp" onclick="openDeposit()">+</button>
    </div>
    <div class="avatar" onclick="toast('Player: <?php echo htmlspecialchars($PHONE); ?>')">
      <svg viewBox="0 0 24 24" fill="#0b2140"><circle cx="12" cy="9" r="4.4"/><path d="M4 20c1.4-4 5-6 8-6s6.6 2 8 6z"/></svg>
    </div>
  </div>
  <div class="subhdr">
    <span class="wallet">
      <svg viewBox="0 0 22 18" fill="none"><rect x="1" y="1" width="20" height="16" rx="3" stroke="#8b93a7" stroke-width="2"/><rect x="1" y="4" width="20" height="3" fill="#8b93a7"/></svg>
      <b id="wallet">0</b>&nbsp;INR
    </span>
    <div class="subicons">
      <button class="hbtn" onclick="showHelp()"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><circle cx="12" cy="12" r="10"/><path d="M9.4 9.2a2.6 2.6 0 1 1 3.6 2.4c-.8.4-1 1-1 1.8"/><circle cx="12" cy="16.8" r=".6" fill="currentColor"/></svg></button>
      <button class="hbtn" id="muteBtn" onclick="toggleSound()"></button>
      <button class="hbtn" onclick="toast('Settings')"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M4 7h9M19 7h1M4 17h3M13 17h7"/><circle cx="16" cy="7" r="2.6"/><circle cx="10" cy="17" r="2.6"/></svg></button>
    </div>
  </div>

  <div class="logo">
    <svg class="swoosh" viewBox="0 0 230 92">
      <defs><linearGradient id="pg" x1="0" y1="0" x2="1" y2="1">
        <stop offset="0" stop-color="#7c3aed"/><stop offset=".5" stop-color="#a855f7"/><stop offset="1" stop-color="#5b21b6"/>
      </linearGradient></defs>
      <path d="M18 62 C 40 18, 150 4, 208 26 C 160 16, 70 22, 40 52 C 30 62, 24 66, 18 62 Z" fill="url(#pg)"/>
      <path d="M212 34 C 190 78, 80 92, 24 68 C 72 80, 160 72, 190 44 C 200 34, 206 30, 212 34 Z" fill="url(#pg)" opacity=".85"/>
    </svg>
    <h1>VORTEX</h1>
    <small>OFFICIAL GAME</small>
  </div>

  <div class="wheel-zone">
    <div class="wheel-wrap" id="wheelWrap">
      <svg class="board" id="board" viewBox="0 0 400 400"></svg>
      <div class="badge fire" id="badge-fire"></div>
      <div class="badge earth" id="badge-earth"></div>
      <div class="badge water" id="badge-water"></div>
      <div class="reel-win"><div class="reel-strip" id="reelStrip"></div></div>
      <div class="center-result" id="centerResult"></div>
      <div class="winbox" id="winBox">
        <div class="wx" id="winX">0X</div>
        <div class="wl"></div>
        <div class="wa" id="winA">0 ₹</div>
      </div>
    </div>
  </div>

  <div class="controls">
    <div class="bet-label">Bet Amount ⓘ</div>
    <div class="bet-row">
      <button class="rbtn" onclick="halveBet()" title="Half">🪙</button>
      <button class="rbtn" onclick="changeBet(-5)">−</button>
      <div class="bet-box"><span id="betTxt">0</span><small>INR BET</small></div>
      <button class="rbtn" onclick="changeBet(5)">+</button>
      <button class="rbtn" id="turboBtn" onclick="toggleTurbo()" title="Turbo">⚡</button>
    </div>
    <div class="action-row">
      <button class="side-btn" id="cashBtn" onclick="cashOut()">CASH<br>OUT</button>
      <div class="spin-wrap" id="spinBtn" onclick="spin()">
        <svg viewBox="0 0 120 120">
          <defs>
            <radialGradient id="sg" cx="40%" cy="35%" r="80%">
              <stop offset="0" stop-color="#c084fc"/><stop offset=".45" stop-color="#9333ea"/><stop offset="1" stop-color="#6d28d9"/>
            </radialGradient>
            <path id="tp" d="M60,60 m-45,0 a45,45 0 1,1 90,0 a45,45 0 1,1 -90,0"/>
          </defs>
          <circle cx="60" cy="60" r="58" fill="url(#sg)" stroke="#e9d5ff" stroke-width="3"/>
          <g class="rotor">
            <text fill="#fff" font-size="12.5" font-weight="800" letter-spacing="2.5">
              <textPath href="#tp">HOLD TO SPIN • HOLD TO SPIN •</textPath>
            </text>
          </g>
          <text x="60" y="73" text-anchor="middle" font-size="34" fill="#fff">🌀</text>
        </svg>
      </div>
      <button class="side-btn" id="autoBtn" onclick="toggleAuto()">1<small>↻</small></button>
    </div>
    <div class="foot-info">
      <div><span>Payout</span><strong id="payoutTxt">0.00 INR</strong></div>
      <div id="partBtn" onclick="partPayout()"><span>Part PayOut</span><strong id="partTxt">-</strong></div>
    </div>
    <div class="bottom-bar"><span>TopBet Games • Vortex</span><span id="clock"></span></div>
  </div>
</div>
<div id="toast"></div>

<script>
/* ================= FIREBASE + SESSION ================= */
const USER_PHONE = <?php echo json_encode($PHONE); ?>;
const FB_URL = 'https://lottery-8f331-default-rtdb.firebaseio.com';

function fbReadBalance(){
  if(!USER_PHONE)return Promise.resolve(0);
  return fetch(FB_URL+'/users/'+encodeURIComponent(USER_PHONE)+'.json')
    .then(r=>r.json())
    .then(d=>(d&&typeof d.balance==='number')?d.balance:0)
    .catch(()=>0);
}
function fbSaveBalance(v){
  if(!USER_PHONE)return;
  fetch(FB_URL+'/users/'+encodeURIComponent(USER_PHONE)+'.json',{
    method:'PATCH',headers:{'Content-Type':'application/json'},
    body:JSON.stringify({balance:Math.round(v*100)/100})
  }).catch(()=>{});
}

/* ================= AUTH (config.php actions) ================= */
function doAuth(action){
  const ph=document.getElementById('aPhone').value.trim();
  const pw=document.getElementById('aPass').value;
  if(!ph||!pw){toast('Number aur password bharo!','red');return;}
  const fd=new FormData();
  fd.append('action',action);fd.append('phone',ph);fd.append('password',pw);
  if(action==='register')fd.append('invite',document.getElementById('aInvite').value.trim());
  fetch('config.php',{method:'POST',body:fd})
    .then(r=>r.json())
    .then(j=>{toast(j.message,j.success?'green':'red');
      if(j.success)setTimeout(()=>location.reload(),800);})
    .catch(()=>toast('Server error!','red'));
}
document.getElementById('regBtn').addEventListener('click',()=>{});
document.getElementById('aPass').addEventListener('focus',()=>document.getElementById('inviteRow').classList.add('show'));

/* ================= ICONS ================= */
function starPts(cx,cy,spikes,outer,inner){const p=[];for(let i=0;i<spikes*2;i++){const r=i%2===0?outer:inner;const a=(Math.PI*i)/spikes-Math.PI/2;p.push((cx+r*Math.cos(a)).toFixed(1)+','+(cy+r*Math.sin(a)).toFixed(1));}return p.join(' ');}
const ICONS={
 fire:`<svg viewBox="0 0 64 64"><path fill="url(#gF)" d="M32 3c2 9 10 13 13 20 3 8 1 17-6 22-7 6-18 6-25 0-7-5-9-14-6-22 2-6 8-10 9-16 3 3 4 6 4 9 5-4 9-8 11-13z"/><path fill="url(#gF2)" d="M32 27c4 5 8 8 8 13a8 8 0 0 1-16 0c0-5 4-8 8-13z"/></svg>`,
 earth:`<svg viewBox="0 0 64 64"><polygon points="${starPts(32,32,12,30,19)}" fill="url(#gE)"/><circle cx="32" cy="32" r="11" fill="url(#gE2)"/></svg>`,
 water:`<svg viewBox="0 0 64 64"><circle cx="32" cy="32" r="29" fill="url(#gW)"/><path fill="#eaf6ff" d="M12 38c6-12 22-16 32-10-4 0-8 2-10 6 6-2 12 0 16 4-4 8-12 12-20 12-8 0-14-5-18-12z"/><circle cx="41" cy="25" r="4" fill="#eaf6ff"/></svg>`,
 wind:`<svg viewBox="0 0 64 64" fill="none" stroke="#c7d0e0" stroke-width="5" stroke-linecap="round"><path d="M12 22h24a8 8 0 1 0-8-10"/><path d="M10 34h36a9 9 0 1 1-9 11"/><path d="M16 46h14a6 6 0 1 1-6 7"/></svg>`,
 skull:`<svg viewBox="0 0 64 64"><path fill="url(#gS)" d="M32 6a21 21 0 0 0-21 21c0 8 4 15 11 18v9h7v-6h3v6h3v-6h7v-9c7-3 11-10 11-18A21 21 0 0 0 32 6z"/><circle cx="24" cy="28" r="5.5" fill="#0b0d12"/><circle cx="40" cy="28" r="5.5" fill="#0b0d12"/><path d="M32 34l4 7h-8z" fill="#0b0d12"/></svg>`
};
const SPK_ON=`<svg viewBox="0 0 24 24" fill="currentColor"><path d="M4 9v6h4l6 5V4L8 9H4z"/><path d="M16.5 8a5.5 5.5 0 0 1 0 8" stroke="currentColor" fill="none" stroke-width="2" stroke-linecap="round"/></svg>`;
const SPK_OFF=`<svg viewBox="0 0 24 24" fill="currentColor"><path d="M4 9v6h4l6 5V4L8 9H4z"/><path d="M16 9l6 6M22 9l-6 6" stroke="currentColor" fill="none" stroke-width="2" stroke-linecap="round"/></svg>`;

/* ================= RINGS ================= */
const RINGS=[
 {id:'fire', r:176, track:30, cls:'fire', segs:[{v:3.9},{v:12.5},{v:28},{v:52},{v:85},{v:133},{v:200},{v:100,l:'BONUS'}]},
 {id:'earth',r:138, track:28, cls:'earth',segs:[{v:2.5},{v:7.7},{v:16},{v:27.5},{v:10},{v:44},{v:20.5,p:1},{v:100,l:'BONUS'}]},
 {id:'water',r:102, track:26, cls:'water',segs:[{v:1.55},{v:4.85},{v:10},{v:7,p:1}]}
];
const S={bal:0,bet:50,busy:false,turbo:false,auto:false,sound:true,banked:0,cashing:false,
 rings:{fire:{f:0,lp:0,a:0},earth:{f:0,lp:0,a:0},water:{f:0,lp:0,a:0}}};
let AC=null;
const $=id=>document.getElementById(id);
const fmt=n=>{n=Math.round(n*100)/100;return n%1===0?n.toFixed(0):n.toString();};

/* ================= AUDIO ================= */
function ac(){if(!AC)AC=new (window.AudioContext||window.webkitAudioContext)();if(AC.state==='suspended')AC.resume();return AC;}
function tone(f,d,type,v,slide){if(!S.sound)return;try{const c=ac(),o=c.createOscillator(),g=c.createGain(),t=c.currentTime;
 o.type=type||'sine';o.frequency.setValueAtTime(f,t);if(slide)o.frequency.exponentialRampToValueAtTime(slide,t+d);
 g.gain.setValueAtTime(v||.25,t);g.gain.exponentialRampToValueAtTime(.001,t+d);o.connect(g);g.connect(c.destination);o.start(t);o.stop(t+d);}catch(e){}}
function sSpin(){tone(220,.5,'sine',.18,700);}
function sTick(){tone(1400,.03,'square',.05);}
function sLand(){tone(180,.18,'sine',.35,90);}
function sArc(){tone(500,.35,'sine',.22,1200);}
function sWin(){[523,659,783,1046].forEach((f,i)=>setTimeout(()=>tone(f,.35,'sine',.3),i*110));}
function sCash(){[784,988,1319,1568].forEach((f,i)=>setTimeout(()=>tone(f,.3,'triangle',.3),i*90));}
function sSkull(){[300,200,120,70].forEach((f,i)=>setTimeout(()=>tone(f,.4,'sawtooth',.3),i*140));}
function sWind(){tone(600,.5,'sine',.15,200);}

/* ================= BOARD ================= */
function polar(r,a){const rad=(a-90)*Math.PI/180;return[200+r*Math.cos(rad),200+r*Math.sin(rad)];}
function buildBoard(){
 const svg=$('board');let h='';
 h+='<defs><radialGradient id="wg" cx="50%" cy="42%" r="65%"><stop offset="0" stop-color="#232936"/><stop offset=".8" stop-color="#161a23"/><stop offset="1" stop-color="#10131b"/></radialGradient></defs>';
 h+='<circle cx="200" cy="200" r="199" fill="#12151d"/>';
 h+='<circle cx="200" cy="200" r="196" fill="url(#wg)" stroke="#2a3140" stroke-width="3"/>';
 RINGS.forEach(rg=>{
   h+=`<circle cx="200" cy="200" r="${rg.r}" fill="none" stroke="#1c212c" stroke-width="${rg.track}"/>`;
   h+=`<circle cx="200" cy="200" r="${rg.r}" fill="none" stroke="#0d1017" stroke-width="${rg.track-6}" opacity=".55"/>`;
   const seg=360/rg.segs.length;
   rg.segs.forEach((s2,i)=>{
     const ba=i*seg,[x1,y1]=polar(rg.r-11,ba),[x2,y2]=polar(rg.r+11,ba);
     h+=`<line x1="${x1}" y1="${y1}" x2="${x2}" y2="${y2}" stroke="#39435a" stroke-width="3" opacity=".8"/>`;
     const ma=ba+seg/2,[tx,ty]=polar(rg.r,ma);
     const label=s2.l||((s2.p?'+':'')+fmt(s2.v)+'X');
     h+=`<text class="mult" id="lb-${rg.id}-${i}" x="${tx}" y="${ty}" font-size="${rg.id==='water'?13:14}" text-anchor="middle" dominant-baseline="middle" transform="rotate(${ma} ${tx} ${ty})">${label}</text>`;
   });
 });
 h+='<circle cx="200" cy="200" r="80" fill="#0e1119" stroke="#2a3140" stroke-width="5"/>';
 RINGS.forEach(rg=>{
   const C=2*Math.PI*rg.r;
   h+=`<circle class="arc arc-${rg.cls}" id="arc-${rg.id}" cx="200" cy="200" r="${rg.r}" stroke-width="15" stroke-dasharray="0 ${C}" transform="rotate(-90 200 200)" data-c="${C}"/>`;
   h+=`<circle class="knob-ring kr-${rg.cls}" id="kr-${rg.id}" cx="200" cy="${200-rg.r}" r="13"/>`;
   h+=`<circle class="knob" id="kn-${rg.id}" cx="200" cy="${200-rg.r}" r="10"/>`;
 });
 svg.innerHTML=h;
}
function renderRing(rg){
 const st=S.rings[rg.id],C=+($('arc-'+rg.id).dataset.c),seg=360/rg.segs.length;
 const len=C*(st.a/360);
 const arc=$('arc-'+rg.id);
 arc.setAttribute('stroke-dasharray',`${len} ${C-len}`);
 arc.classList.toggle('on',st.a>0.5);
 const [kx,ky]=polar(rg.r,st.a);
 const kn=$('kn-'+rg.id),kr=$('kr-'+rg.id);
 kn.setAttribute('cx',kx);kn.setAttribute('cy',ky);kn.classList.toggle('on',st.a>0.5);
 kr.setAttribute('cx',kx);kr.setAttribute('cy',ky);kr.classList.toggle('on',st.a>0.5);
 const covered=Math.floor((st.a+0.01)/seg);
 rg.segs.forEach((s2,i)=>{
   const el=$('lb-'+rg.id+'-'+i);
   el.classList.remove('lit-fire','lit-earth','lit-water');
   if(i<covered)el.classList.add('lit-'+rg.cls);
 });
}
function animateRing(rg,to,dur,cb){
 const st=S.rings[rg.id],from=st.a,t0=performance.now();
 function step(t){let p=Math.min(1,(t-t0)/dur);p=1-Math.pow(1-p,3);
   st.a=from+(to-from)*p;renderRing(rg);
   if(p<1)requestAnimationFrame(step);else{st.a=to;renderRing(rg);cb&&cb();}}
 requestAnimationFrame(step);
}

/* ================= MATH ================= */
const ringVal=id=>{const rg=RINGS.find(r=>r.id===id),f=S.rings[id].f;return f>0?rg.segs[f-1].v:0;};
const totalMult=()=>ringVal('fire')+ringVal('earth')+ringVal('water');
const payout=()=>S.bet*totalMult();
const cashable=()=>Math.max(0,payout()-S.banked);
function partVal(){let t=0;RINGS.forEach(rg=>{const st=S.rings[rg.id];
 if(st.f>st.lp&&st.f>=1){t+=rg.segs[st.f-1].v-(st.f>=2?rg.segs[st.f-2].v:0);}});return S.bet*t;}

/* ================= UI ================= */
function updateUI(){
 $('hdrBal').textContent=fmt(S.bal);
 $('wallet').textContent=fmt(S.bal);
 $('betTxt').textContent=fmt(S.bet);
 const p=payout(),pv=partVal(),ca=cashable();
 $('payoutTxt').textContent=p.toFixed(2)+' INR';
 $('partTxt').textContent=pv>0?pv.toFixed(2)+' INR':'-';
 $('partBtn').classList.toggle('ready',pv>0);
 const cb=$('cashBtn');
 if(p>0&&ca>0){cb.classList.add('ready');cb.innerHTML=`CASH OUT<small>₹${fmt(ca)}</small>`;}
 else if(p>0){cb.classList.add('ready');cb.innerHTML='CASH<br>OUT';}
 else{cb.classList.remove('ready');cb.innerHTML='CASH<br>OUT';}
 $('spinBtn').classList.toggle('disabled',S.busy||S.bal<S.bet);
}
function toast(msg,cls){const t=$('toast');t.textContent=msg;t.className='show '+(cls||'');
 clearTimeout(t._h);t._h=setTimeout(()=>t.className='',1800);}
function openDeposit(){window.location.href='deposit.php';}

/* ================= REEL (exact landing) ================= */
let reelRAF=null;
function runReel(out,done){
 cancelAnimationFrame(reelRAF);
 const win=document.querySelector('.reel-win');
 const strip=$('reelStrip');
 const H=win.clientHeight;
 const itemH=Math.round(H*0.42);
 const keys=['fire','earth','water','wind','fire','water','earth','skull','fire','wind','water','earth'];
 const seq=[];for(let i=0;i<24;i++)seq.push(keys[Math.floor(Math.random()*keys.length)]);
 seq.push(out.k);seq.push('wind');
 strip.innerHTML=seq.map(k=>`<div class="reel-item" style="height:${itemH}px">${ICONS[k]}</div>`).join('');
 strip.classList.add('blur');
 strip.style.transform='translateY(0)';
 const idx=seq.length-2;
 const target=idx*itemH+itemH/2-H/2;
 const dur=S.turbo?800:1900,t0=performance.now();
 let lastTick=0;
 function step(t){const p=Math.min(1,(t-t0)/dur);
   const e=1-Math.pow(1-p,3);
   strip.style.transform=`translateY(${-(e*target)}px)`;
   if(p<0.75&&t-lastTick>80){sTick();lastTick=t;}
   if(p<1){reelRAF=requestAnimationFrame(step);}
   else{strip.classList.remove('blur');sLand();
     const cr=$('centerResult');cr.innerHTML=ICONS[out.k];
     cr.classList.remove('pop');void cr.offsetWidth;cr.classList.add('pop');
     done();}}
 reelRAF=requestAnimationFrame(step);
}

/* ================= OUTCOMES: WIN 17% / LOSS 83% ================= */
function pickOutcome(){
 const winChance=0.17;
 if(Math.random()<winChance){
   const e=['fire','earth','water'][Math.floor(Math.random()*3)];
   return {t:e,k:e};
 }
 const p=payout();
 let pressure=Math.min(0.45,(p/(S.bet*8))*0.35);
 if(S.bal>2000)pressure+=0.10;
 const skullChance=0.30+pressure;
 return Math.random()<skullChance?{t:'skull',k:'skull'}:{t:'wind',k:'wind'};
}

/* ================= SPIN ================= */
function spin(){
 if(S.busy)return;
 if(!USER_PHONE){toast('Pehle login karo!','red');return;}
 if(S.bal<S.bet){toast('Balance kam hai! Deposit karo.','red');return;}
 ac();S.busy=true;
 S.bal-=S.bet;fbSaveBalance(S.bal);
 updateUI();sSpin();
 const out=pickOutcome();
 runReel(out,()=>{setTimeout(()=>{applyOutcome(out);},350);});
}
function applyOutcome(out){
 const adv=S.turbo?350:750;
 if(out.t==='fire'||out.t==='earth'||out.t==='water'){
   const rg=RINGS.find(r=>r.id===out.t),st=S.rings[out.t];
   if(st.f<rg.segs.length){st.f++;}
   const b=$('badge-'+out.t);b.classList.remove('flash');void b.offsetWidth;b.classList.add('flash');
   sArc();
   animateRing(rg,st.f*(360/rg.segs.length),adv,()=>finish());
 }else if(out.t==='skull'){
   sSkull();toast('💀 SKULL! Progress wiped','red');
   let pending=3;
   RINGS.forEach(rg=>{S.rings[rg.id].f=0;S.rings[rg.id].lp=0;
     animateRing(rg,0,adv,()=>{if(--pending===0)finish();});});
   S.banked=0;
   showWinBox('0X','LOST',true);
 }else{
   sWind();toast('💨 Wind — No win');
   finish();
 }
}
function finish(){S.busy=false;updateUI();
 if(S.auto){if(S.bal<S.bet){S.auto=false;resetAutoBtn();toast('Auto stopped — low balance','red');}
 else setTimeout(()=>{if(S.auto)spin();},500);}}

/* ================= CASH / PART (single-add, Firebase sync) ================= */
function showWinBox(x,a,bad){const wb=$('winBox');$('winX').textContent=x;$('winA').textContent=a;
 wb.classList.toggle('bad',!!bad);wb.classList.add('show');
 clearTimeout(wb._h);wb._h=setTimeout(()=>wb.classList.remove('show'),2200);}
function cashOut(){
 if(S.busy||S.cashing)return;
 const p=payout();if(p<=0)return;
 const pay=cashable();
 S.cashing=true;
 if(pay>0){S.bal+=pay;fbSaveBalance(S.bal);}
 sCash();
 showWinBox(fmt(totalMult())+'X','+₹'+fmt(pay),false);
 RINGS.forEach(rg=>{S.rings[rg.id].f=0;S.rings[rg.id].lp=0;animateRing(rg,0,600);});
 S.banked=0;
 toast('₹'+fmt(pay)+' balance me add!','green');
 updateUI();
 setTimeout(()=>{S.cashing=false;},800);
}
function partPayout(){
 const pv=partVal();if(pv<=0||S.busy)return;
 S.bal+=pv;S.banked+=pv;fbSaveBalance(S.bal);
 RINGS.forEach(rg=>S.rings[rg.id].lp=S.rings[rg.id].f);
 sWin();toast('Part Payout +₹'+fmt(pv),'green');updateUI();
}

/* ================= CONTROLS ================= */
function changeBet(d){if(S.busy)return;
 if(totalMult()>0){toast('Cash out first!','red');return;}
 S.bet=Math.max(5,Math.min(10000,S.bet+d));updateUI();}
function halveBet(){if(S.busy)return;if(totalMult()>0){toast('Cash out first!','red');return;}
 S.bet=Math.max(5,Math.floor(S.bet/2));updateUI();}
function toggleTurbo(){S.turbo=!S.turbo;$('turboBtn').classList.toggle('turbo-on',S.turbo);toast('Turbo '+(S.turbo?'ON ⚡':'OFF'));}
function resetAutoBtn(){$('autoBtn').style.borderColor='';$('autoBtn').style.color='';}
function toggleAuto(){S.auto=!S.auto;
 $('autoBtn').style.borderColor=S.auto?'#a855f7':'';
 $('autoBtn').style.color=S.auto?'#d8b4fe':'';
 toast('Auto '+(S.auto?'ON':'OFF'));
 if(S.auto)spin();}
function toggleSound(){S.sound=!S.sound;$('muteBtn').innerHTML=S.sound?SPK_ON:SPK_OFF;if(S.sound)tone(880,.15,'sine',.2);}
function showHelp(){toast('🔥🍀🌊 = rings grow • 💨 = nothing • 💀 = wipe');}

/* ================= RIPPLE ================= */
document.addEventListener('pointerdown',e=>{
 const b=e.target.closest('.rbtn,.side-btn,.hbtn,.addp,.auth-btns button');
 if(!b)return;
 const r=document.createElement('span');r.className='rip';
 const rect=b.getBoundingClientRect(),sz=Math.max(rect.width,rect.height);
 r.style.width=r.style.height=sz+'px';
 r.style.left=(e.clientX-rect.left-sz/2)+'px';
 r.style.top=(e.clientY-rect.top-sz/2)+'px';
 b.appendChild(r);setTimeout(()=>r.remove(),500);
});

/* ================= CLOCK ================= */
setInterval(()=>{const d=new Date();
 const mo=['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'][d.getMonth()];
 const hh=String(d.getHours()).padStart(2,'0'),mm=String(d.getMinutes()).padStart(2,'0'),ss=String(d.getSeconds()).padStart(2,'0');
 $('clock').textContent=`${String(d.getDate()).padStart(2,'0')} ${mo}, ${d.getFullYear()} | ${hh}:${mm}:${ss}`;},1000);

/* ================= INIT ================= */
$('badge-fire').innerHTML=ICONS.fire;
$('badge-earth').innerHTML=ICONS.earth;
$('badge-water').innerHTML=ICONS.water;
$('muteBtn').innerHTML=SPK_ON;
buildBoard();RINGS.forEach(renderRing);
if(USER_PHONE){
  fbReadBalance().then(b=>{S.bal=b;updateUI();});
}else{
  updateUI();
}
updateUI();
</script>
</body>
</html>