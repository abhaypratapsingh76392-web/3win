<?php
if (session_status() === PHP_SESSION_NONE) session_start();
error_reporting(0);
date_default_timezone_set('Asia/Kolkata');
require_once 'config.php';

define('ADMIN_USER', 'admin');
define('ADMIN_PASS', 'abhay12345');

// Handle login
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['login'])) {
    $user = trim($_POST['username'] ?? '');
    $pass = $_POST['password'] ?? '';
    
    if ($user === ADMIN_USER && $pass === ADMIN_PASS) {
        $_SESSION['admin_logged'] = true;
        $_SESSION['admin_user'] = 'main_admin';
        $_SESSION['admin_perms'] = ['all' => true];
        $_SESSION['admin_created_by'] = 'system';
        header('Location: admin.php');
        exit;
    }
    
    // Check sub-admin
    $admins = firebase_read('admins');
    if (is_array($admins)) {
        foreach ($admins as $aid => $admin) {
            if (($admin['username'] ?? '') === $user && ($admin['password'] ?? '') === $pass) {
                $_SESSION['admin_logged'] = true;
                $_SESSION['admin_user'] = $user;
                $_SESSION['admin_perms'] = $admin['permissions'] ?? [];
                $_SESSION['admin_created_by'] = $admin['created_by'] ?? '';
                header('Location: admin.php');
                exit;
            }
        }
    }
    $login_error = "Invalid username or password!";
}

// Logout
if (isset($_GET['logout'])) {
    session_destroy();
    header('Location: admin.php');
    exit;
}

// Check login
if (!isset($_SESSION['admin_logged'])) {
    ?>
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Admin Login - 3win</title>
        <style>
            * { margin: 0; padding: 0; box-sizing: border-box; font-family: 'Segoe UI', sans-serif; }
            body { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); min-height: 100vh; display: flex; align-items: center; justify-content: center; }
            .login-box { background: white; padding: 40px; border-radius: 20px; box-shadow: 0 20px 60px rgba(0,0,0,0.3); width: 90%; max-width: 400px; }
            .login-box h1 { text-align: center; color: #667eea; margin-bottom: 10px; font-size: 28px; }
            .login-box p { text-align: center; color: #666; margin-bottom: 30px; font-size: 14px; }
            .input-group { margin-bottom: 20px; }
            .input-group label { display: block; margin-bottom: 8px; color: #333; font-weight: 600; font-size: 14px; }
            .input-group input { width: 100%; padding: 12px; border: 2px solid #e0e0e0; border-radius: 10px; font-size: 14px; transition: 0.3s; }
            .input-group input:focus { outline: none; border-color: #667eea; }
            .btn { width: 100%; padding: 14px; background: linear-gradient(135deg, #667eea, #764ba2); color: white; border: none; border-radius: 10px; font-size: 16px; font-weight: 700; cursor: pointer; transition: 0.3s; }
            .error { background: #fee; color: #c33; padding: 12px; border-radius: 8px; margin-bottom: 20px; text-align: center; font-size: 14px; }
        </style>
    </head>
    <body>
        <div class="login-box">
            <h1>🔐 Admin Login</h1>
            <p>3win Control Panel</p>
            <?php if (isset($login_error)): ?><div class="error"><?= $login_error ?></div><?php endif; ?>
            <form method="POST">
                <div class="input-group"><label>Username</label><input type="text" name="username" required autofocus></div>
                <div class="input-group"><label>Password</label><input type="password" name="password" required></div>
                <button type="submit" name="login" class="btn">Login</button>
            </form>
        </div>
    </body>
    </html>
    <?php
    exit;
}

// Generate Random Alphanumeric Code for Gifts
function generateGiftCode($length = 25) {
    $characters = '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ';
    $randomString = '';
    for ($i = 0; $i < $length; $i++) { $randomString .= $characters[rand(0, strlen($characters) - 1)]; }
    return $randomString;
}

// Get permissions
$perms = $_SESSION['admin_perms'] ?? [];
$is_main = ($_SESSION['admin_user'] ?? '') === 'main_admin';
$can_all = $is_main || ($perms['all'] ?? false);
$can_withdrawal = $can_all || ($perms['can_withdrawal'] ?? false);
$can_deposit = $can_all || ($perms['can_deposit'] ?? false);
$can_users = $can_all || ($perms['can_users'] ?? false);
$can_upi = $can_all || ($perms['can_upi'] ?? false);
$can_admins = $can_all || ($perms['can_admins'] ?? false);
$can_support = $can_all || ($perms['can_support'] ?? false);
$can_notif = $can_all || ($perms['can_notif'] ?? false);
$can_chat = $can_all || ($perms['can_chat'] ?? false);
$can_feedback = $can_all || ($perms['can_feedback'] ?? false);

// Handle actions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';

    // ===============================================
    // NEW ACTION: SEND NOTIFICATION / SMS TO USER
    // ===============================================
    if ($action === 'send_notification' && $can_notif) {
        $target = trim($_POST['target'] ?? '');
        $title = trim($_POST['title'] ?? 'Notice from 3win');
        $msg = trim($_POST['message'] ?? '');

        if ($msg !== '') {
            $nowTime = date('Y-m-d H:i:s');
            $msgId = 'custom_' . time() . '_' . rand(100, 999);

            if ($target === 'all') {
                // Send to all users via global announcement
                $newAnnounce = ['id' => $msgId, 'title' => $title, 'date' => $nowTime, 'message' => $msg];
                firebase_write("system_announcements/$msgId", $newAnnounce);
            } else {
                // Send to specific user
                $targetPhone = preg_replace('/[^0-9]/', '', $target);
                if (!empty($targetPhone)) {
                    $userMsg = ['id' => $msgId, 'title' => $title, 'type' => 'admin_direct', 'date' => $nowTime, 'message' => $msg];
                    firebase_write("users/$targetPhone/notifications/$msgId", $userMsg);
                }
            }
        }
    }

    // ===============================================
    // NEW ACTION: ADMIN REPLY IN CHAT
    // ===============================================
    if ($action === 'reply_chat' && $can_chat) {
        $chatKey = $_POST['chat_key'] ?? '';
        $message = trim($_POST['message'] ?? '');
        
        if ($chatKey !== '' && $message !== '') {
            $msgId = 'msg_' . time() . '_' . mt_rand(1000, 9999);
            $adminMsg = [
                'id' => $msgId,
                'sender' => 'admin',
                'text' => $message,
                'timestamp' => time(),
                'time_formatted' => date('h:i A, d M')
            ];
            firebase_write("chats/$chatKey/messages/$msgId", $adminMsg);
            firebase_write("chats/$chatKey/awaiting", ''); // Cancel any bot await state
            firebase_write("chats/$chatKey/last_active", time());
        }
    }

    // AJAX Action for Password Reset
    if ($action === 'reset_password' && $can_users) {
        $phone = $_POST['phone'] ?? '';
        $newPass = (string)rand(10000000, 99999999);
        firebase_write("users/$phone/password", $newPass);
        header('Content-Type: application/json');
        echo json_encode(['success' => true, 'new_password' => $newPass]);
        exit;
    }
    
    // SAFE UPDATE WITHDRAWAL
    if ($action === 'update_withdrawal' && $can_withdrawal) {
        $id = $_POST['id'] ?? '';
        $status = $_POST['status'] ?? '';
        $phone = $_POST['phone'] ?? '';
        $amount = (float)($_POST['amount'] ?? 0);
        
        $wData = firebase_read("withdrawals/$phone") ?: [];
        if (isset($wData[$id])) {
            $wData[$id]['status'] = ucfirst($status);
            $wData[$id]['processed_at'] = date('Y-m-d H:i:s');
            firebase_write("withdrawals/$phone", $wData);
            
            if ($status === 'rejected') {
                $user = firebase_read("users/$phone");
                if ($user) {
                    $bal = (float)($user['balance'] ?? 0);
                    firebase_write("users/$phone/balance", round($bal + $amount, 2)); // Refund
                }
            }
        }
    }
    
    // SAFE UPDATE DEPOSIT
    if ($action === 'update_deposit' && $can_deposit) {
        $id = $_POST['id'] ?? '';
        $status = $_POST['status'] ?? '';
        $phone = $_POST['phone'] ?? '';
        $amount = (float)($_POST['amount'] ?? 0);
        
        $dData = firebase_read("deposits/$phone") ?: [];
        if (isset($dData[$id])) {
            $dData[$id]['status'] = ucfirst($status);
            $dData[$id]['processed_at'] = date('Y-m-d H:i:s');
            firebase_write("deposits/$phone", $dData);
            
            if ($status === 'approved' || $status === 'completed') {
                $user = firebase_read("users/$phone");
                if ($user) {
                    $bal = (float)($user['balance'] ?? 0);
                    firebase_write("users/$phone/balance", round($bal + $amount, 2));
                }
            }
        }
    }

    // UPDATE SUPPORT REQUESTS
    if ($action === 'update_support' && $can_support) {
        $id = $_POST['id'] ?? '';
        $phone = $_POST['phone'] ?? '';
        $status = ucfirst($_POST['status'] ?? ''); 

        $sData = firebase_read("support_requests") ?: [];
        if(isset($sData[$id])) {
            $sData[$id]['status'] = $status;
            firebase_write("support_requests/$id", $sData[$id]);
        }
        $usData = firebase_read("user_requests/$phone") ?: [];
        if(isset($usData[$id])) {
            $usData[$id]['status'] = $status;
            firebase_write("user_requests/$phone/$id", $usData[$id]);
        }
    }

    // RESTORE ANY REJECTED ITEM
    if ($action === 'restore_item') {
        $type = $_POST['restore_type'];
        $id = $_POST['id'];
        $phone = $_POST['phone'];
        $amount = (float)($_POST['amount'] ?? 0);

        if ($type === 'deposit' && $can_deposit) {
            $dData = firebase_read("deposits/$phone") ?: [];
            if(isset($dData[$id])) {
                $dData[$id]['status'] = 'Pending';
                firebase_write("deposits/$phone", $dData);
            }
        } elseif ($type === 'withdrawal' && $can_withdrawal) {
            $wData = firebase_read("withdrawals/$phone") ?: [];
            if(isset($wData[$id])) {
                $wData[$id]['status'] = 'Pending';
                firebase_write("withdrawals/$phone", $wData);
                $user = firebase_read("users/$phone");
                if ($user) {
                    firebase_write("users/$phone/balance", round($user['balance'] - $amount, 2));
                }
            }
        } elseif ($type === 'support' && $can_support) {
            $sData = firebase_read("support_requests") ?: [];
            if(isset($sData[$id])) {
                $sData[$id]['status'] = 'Pending';
                firebase_write("support_requests/$id", $sData[$id]);
            }
            $usData = firebase_read("user_requests/$phone") ?: [];
            if(isset($usData[$id])) {
                $usData[$id]['status'] = 'Pending';
                firebase_write("user_requests/$phone/$id", $usData[$id]);
            }
        }
    }
    
    // Update User Full Info
    if ($action === 'update_user_full_info' && $can_users) {
        $phone = $_POST['phone'] ?? '';
        $balance = (float)($_POST['balance'] ?? 0);
        $exp = (float)($_POST['exp'] ?? 0);
        
        $bank_name = $_POST['bank_name'] ?? '';
        $account_number = $_POST['account_number'] ?? '';
        $ifsc_code = $_POST['ifsc_code'] ?? '';
        $account_holder = $_POST['account_holder'] ?? '';
        
        $upi_id = $_POST['upi_id'] ?? '';
        $upi_name = $_POST['upi_name'] ?? '';
        
        $user = firebase_read("users/$phone");
        if (is_array($user)) {
            $user['balance'] = $balance;
            $user['exp'] = $exp;
            
            if(!empty($account_number)) {
                $user['bank_info'] = ['bank_name' => $bank_name, 'account_number' => $account_number, 'ifsc_code' => $ifsc_code, 'account_name' => $account_holder];
            }
            if(!empty($upi_id)) {
                $user['upi_info'] = ['upi_id' => $upi_id, 'upi_name' => $upi_name];
            }
            firebase_write("users/$phone", $user);
        }
    }
    
    if ($action === 'delete_user' && $can_users) { firebase_delete("users/" . $_POST['phone']); }
    
    if ($action === 'add_upi' && $can_upi) {
        firebase_write("admin_settings", [
            'upi_qr_id' => $_POST['upi_qr_id'] ?? '',
            'paytm_upi_id' => $_POST['paytm_upi_id'] ?? '',
            'upi_direct_id' => $_POST['upi_direct_id'] ?? ''
        ]);
    }
    
    if ($action === 'create_gift' && $can_all) {
        firebase_write("gift_codes/" . generateGiftCode(), ['amount' => (float)$_POST['gift_amount'], 'max_uses' => (int)$_POST['gift_uses'], 'created_at' => date('Y-m-d H:i:s'), 'used_by' => []]);
    }
    if ($action === 'delete_gift' && $can_all) { firebase_delete("gift_codes/" . $_POST['code']); }

    if ($action === 'add_admin' && $can_admins) {
        $username = $_POST['username'] ?? '';
        $perms_new = [
            'can_withdrawal' => isset($_POST['perm_withdrawal']) ? 1 : 0,
            'can_deposit' => isset($_POST['perm_deposit']) ? 1 : 0,
            'can_users' => isset($_POST['perm_users']) ? 1 : 0,
            'can_upi' => isset($_POST['perm_upi']) ? 1 : 0,
            'can_admins' => isset($_POST['perm_admins']) ? 1 : 0,
            'can_support' => isset($_POST['perm_support']) ? 1 : 0,
            'can_notif' => isset($_POST['perm_notif']) ? 1 : 0,
            'can_chat' => isset($_POST['perm_chat']) ? 1 : 0,
            'can_feedback' => isset($_POST['perm_feedback']) ? 1 : 0,
        ];
        if (isset($_POST['perm_all'])) $perms_new['all'] = 1;
        $perms_new['created_by'] = $_SESSION['admin_user'];
        $perms_new['created_at'] = date('Y-m-d H:i:s');
        firebase_write("admins/$username", array_merge(['username' => $username, 'password' => $_POST['password']], $perms_new));
    }
    
    if ($action === 'delete_admin' && $can_admins && $_POST['username'] !== 'main_admin') {
        firebase_delete("admins/" . $_POST['username']);
    }
    
    header('Location: admin.php?page=' . ($_GET['page'] ?? 'home'));
    exit;
}

$page = $_GET['page'] ?? 'home';

// Fetch all necessary data safely
$users = firebase_read('users') ?: [];
$admin_settings = firebase_read('admin_settings') ?: ['upi_qr_id'=>'', 'paytm_upi_id'=>'', 'upi_direct_id'=>''];
$gift_codes = firebase_read('gift_codes') ?: [];
$admins = firebase_read('admins') ?: [];
$raw_support = firebase_read('support_requests') ?: [];

// New fetches for the 3 new tabs
$feedbacks = firebase_read('feedbacks') ?: [];
$chats = firebase_read('chats') ?: [];

$withdrawals = [];
$raw_withdrawals = firebase_read('withdrawals') ?: [];
foreach($raw_withdrawals as $ph => $orders) {
    if(is_array($orders)) { foreach($orders as $oid => $o) { $o['phone'] = $o['phone'] ?? $ph; $o['order_id'] = $o['order_id'] ?? $oid; $withdrawals[$oid] = $o; } }
}

$deposits = [];
$raw_deposits = firebase_read('deposits') ?: [];
foreach($raw_deposits as $ph => $orders) {
    if(is_array($orders)) { foreach($orders as $oid => $o) { $o['phone'] = $o['phone'] ?? $ph; $o['order_id'] = $o['order_id'] ?? $oid; $deposits[$oid] = $o; } }
}

// Stats & Sorting Data Lists
$total_users = count($users);
$total_deposits = 0; $total_withdrawals = 0; $pending_withdrawals = 0; $pending_deposits = 0;

$deposits_active = []; $deposits_rejected = [];
usort($deposits, function($a, $b){ return strcmp($b['time']??'', $a['time']??''); });
foreach ($deposits as $d) {
    $st = strtolower($d['status'] ?? '');
    if ($st === 'rejected') { $deposits_rejected[] = $d; continue; }
    $deposits_active[] = $d;
    if ($st === 'approved' || $st === 'completed') $total_deposits += (float)($d['amount'] ?? 0);
    if ($st === 'pending') $pending_deposits++;
}

$withdrawals_active = []; $withdrawals_rejected = [];
usort($withdrawals, function($a, $b){ return strcmp($b['time']??'', $a['time']??''); });
foreach ($withdrawals as $w) {
    $st = strtolower($w['status'] ?? '');
    if ($st === 'rejected') { $withdrawals_rejected[] = $w; continue; }
    $withdrawals_active[] = $w;
    if ($st === 'approved' || $st === 'completed') $total_withdrawals += (float)($w['amount'] ?? 0);
    if ($st === 'pending') $pending_withdrawals++;
}

$support_active = []; $support_rejected = [];
usort($raw_support, function($a, $b){ return strcmp($b['time']??'', $a['time']??''); });
foreach ($raw_support as $s) {
    $st = strtolower($s['status'] ?? '');
    if ($st === 'rejected') { $support_rejected[] = $s; continue; }
    $support_active[] = $s;
}

// Sort chats by last_active
usort($chats, function($a, $b) {
    return ($b['last_active'] ?? 0) <=> ($a['last_active'] ?? 0);
});

// Sort feedbacks by created_at
usort($feedbacks, function($a, $b) {
    return strcmp($b['created_at'] ?? '', $a['created_at'] ?? '');
});

?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Admin Panel - 3win</title>
<style>
* { margin: 0; padding: 0; box-sizing: border-box; font-family: 'Segoe UI', sans-serif; }
body { background: #f0f2f5; }
.admin-container { display: flex; min-height: 100vh; }
.sidebar { width: 260px; background: linear-gradient(180deg, #1e3c72 0%, #2a5298 100%); color: white; position: fixed; height: 100vh; overflow-y: auto; }
.sidebar-header { padding: 20px; text-align: center; border-bottom: 1px solid rgba(255,255,255,0.1); }
.sidebar-menu { padding: 20px 0; }
.menu-item { display: flex; align-items: center; padding: 15px 25px; color: rgba(255,255,255,0.8); text-decoration: none; transition: 0.3s; }
.menu-item:hover, .menu-item.active { background: rgba(255,255,255,0.1); color: white; }
.menu-item .icon { margin-right: 15px; font-size: 20px; }
.menu-item .badge { margin-left: auto; background: #ff4757; padding: 3px 8px; border-radius: 10px; font-size: 11px; }
.main-content { flex: 1; margin-left: 260px; padding: 30px; }
.page-header { margin-bottom: 30px; }
.page-header h1 { font-size: 28px; color: #1e3c72; }
.stats-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(240px, 1fr)); gap: 20px; margin-bottom: 30px; }
.stat-card { background: white; padding: 25px; border-radius: 15px; box-shadow: 0 4px 15px rgba(0,0,0,0.08); }
.stat-card .label { color: #666; font-size: 13px; margin-bottom: 10px; }
.stat-card .value { font-size: 32px; font-weight: 800; color: #1e3c72; }
.content-card { background: white; border-radius: 15px; padding: 25px; box-shadow: 0 4px 15px rgba(0,0,0,0.08); margin-bottom: 20px; overflow-x:auto;}
.table { width: 100%; border-collapse: collapse; min-width: 800px;}
.table th { background: #f8f9fa; padding: 12px; text-align: left; font-size: 13px; color: #666; font-weight: 600; }
.table td { padding: 12px; border-bottom: 1px solid #f0f0f0; font-size: 14px; }
.btn { padding: 8px 16px; border: none; border-radius: 6px; cursor: pointer; font-size: 13px; font-weight: 600; transition: 0.3s; color:white;}
.btn-primary { background: #667eea; } .btn-success { background: #22b573; } .btn-danger { background: #ff4757; } .btn-info { background: #17a2b8; } .btn-warning {background: #f39c12;}
.form-group { margin-bottom: 20px; }
.form-group label { display: block; margin-bottom: 8px; color: #333; font-weight: 600; font-size: 14px; }
.form-group input, .form-group select, .form-group textarea { width: 100%; padding: 12px; border: 2px solid #e0e0e0; border-radius: 8px; font-size: 14px; }
.search-input { width: 100%; max-width: 500px; padding: 12px; border-radius: 8px; border: 2px solid #e0e0e0; font-size: 15px; margin-bottom: 20px; }
.status { padding: 5px 12px; border-radius: 12px; font-size: 12px; font-weight: 600; text-transform: capitalize;}
.status-pending { background: #fff3cd; color: #856404; } .status-approved, .status-completed, .status-resolved { background: #d4edda; color: #155724; } .status-rejected { background: #f8d7da; color: #721c24; }
.modal { display: none; position: fixed; z-index: 1000; left: 0; top: 0; width: 100%; height: 100%; background-color: rgba(0,0,0,0.6); align-items: center; justify-content: center;}
.modal.show { display: flex; }
.modal-content { background-color: #fff; padding: 30px; border-radius: 15px; width: 90%; max-width: 550px; max-height: 90vh; overflow-y: auto;}
.close { color: #aaa; float: right; font-size: 28px; font-weight: bold; cursor: pointer; }
.box-info { background: #f9f9f9; padding: 10px; border: 1px solid #ddd; border-radius: 5px; font-size: 13px; margin-top:5px; line-height:1.6;}
.action-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 10px; margin-bottom: 20px; }
.action-btn { padding: 10px; background: #ecf0f1; border: 1px solid #bdc3c7; border-radius: 5px; cursor: pointer; font-weight: bold; color: #2c3e50; }
.action-btn:hover, .action-btn.active { background: #3498db; color: white; border-color: #2980b9; }
.edit-section { display: none; background: #f9f9f9; padding: 15px; border: 1px solid #ddd; border-radius: 5px; }
.checkbox-group { display: flex; flex-wrap: wrap; gap: 15px; margin: 15px 0; }

/* Chat Bubbles for Modal */
.chat-window { background: #f5f6fa; border-radius: 8px; padding: 15px; height: 350px; overflow-y: auto; display: flex; flex-direction: column; gap: 10px; border: 1px solid #ddd; margin-bottom: 15px;}
.msg-row { display: flex; max-width: 85%; }
.msg-row.user { align-self: flex-start; }
.msg-row.bot, .msg-row.admin { align-self: flex-end; flex-direction: row-reverse; }
.msg-bubble { padding: 10px 14px; border-radius: 15px; font-size: 14px; }
.msg-row.user .msg-bubble { background: #e0e0e0; color: #333; border-bottom-left-radius: 2px;}
.msg-row.bot .msg-bubble { background: #3498db; color: #fff; border-bottom-right-radius: 2px;}
.msg-row.admin .msg-bubble { background: #2ecc71; color: #fff; border-bottom-right-radius: 2px;}
.msg-sender { font-size: 11px; font-weight: bold; margin-bottom: 3px; opacity: 0.8; }
.msg-time { font-size: 10px; margin-top: 5px; opacity: 0.7; text-align: right;}
</style>
</head>
<body>
<div class="admin-container">
    <div class="sidebar">
        <div class="sidebar-header"><h2>🎮 3win Admin</h2></div>
        <div class="sidebar-menu">
            <a class="menu-item <?= $page === 'home' ? 'active' : '' ?>" href="?page=home"><span class="icon">🏠</span> Dashboard</a>
            
            <?php if ($can_notif): ?>
            <a class="menu-item <?= $page === 'notifications' ? 'active' : '' ?>" href="?page=notifications"><span class="icon">📢</span> Send Notification</a>
            <?php endif; ?>

            <?php if ($can_chat): ?>
            <a class="menu-item <?= $page === 'chats' ? 'active' : '' ?>" href="?page=chats"><span class="icon">💬</span> Live Chat Support</a>
            <?php endif; ?>

            <?php if ($can_feedback): ?>
            <a class="menu-item <?= $page === 'feedbacks' ? 'active' : '' ?>" href="?page=feedbacks"><span class="icon">📝</span> User Feedbacks</a>
            <?php endif; ?>

            <?php if ($can_withdrawal): ?>
            <a class="menu-item <?= $page === 'withdrawals' ? 'active' : '' ?>" href="?page=withdrawals"><span class="icon">💸</span> Withdrawals <?php if ($pending_withdrawals > 0): ?><span class="badge"><?= $pending_withdrawals ?></span><?php endif; ?></a>
            <?php endif; ?>
            
            <?php if ($can_deposit): ?>
            <a class="menu-item <?= $page === 'deposits' ? 'active' : '' ?>" href="?page=deposits"><span class="icon">💰</span> Deposits <?php if ($pending_deposits > 0): ?><span class="badge"><?= $pending_deposits ?></span><?php endif; ?></a>
            <?php endif; ?>

            <?php if ($can_support): ?>
            <a class="menu-item <?= $page === 'support' ? 'active' : '' ?>" href="?page=support"><span class="icon">🎧</span> Deposit Tkt</a>
            <?php endif; ?>

            <a class="menu-item <?= $page === 'rejected' ? 'active' : '' ?>" href="?page=rejected"><span class="icon">🗑️</span> Rejected Archive</a>

            <?php if ($can_users): ?>
            <a class="menu-item <?= $page === 'users' ? 'active' : '' ?>" href="?page=users"><span class="icon">👥</span> Users</a>
            <?php endif; ?>

            <?php if ($can_upi): ?>
            <a class="menu-item <?= $page === 'upi' ? 'active' : '' ?>" href="?page=upi"><span class="icon">💳</span> Payment Settings</a>
            <?php endif; ?>

            <?php if ($can_all): ?>
            <a class="menu-item <?= $page === 'gifts' ? 'active' : '' ?>" href="?page=gifts"><span class="icon">🎁</span> Gift Codes</a>
            <?php endif; ?>

            <?php if ($can_admins): ?>
            <a class="menu-item <?= $page === 'admins' ? 'active' : '' ?>" href="?page=admins"><span class="icon">🔐</span> Admins</a>
            <?php endif; ?>

            <a class="menu-item" href="?logout=1"><span class="icon">🚪</span> Logout</a>
        </div>
    </div>

    <div class="main-content">
        <?php if ($page === 'home'): ?>
        <div class="page-header"><h1>Dashboard</h1></div>
        <div class="stats-grid">
            <div class="stat-card"><div class="label">Total Users</div><div class="value"><?= $total_users ?></div></div>
            <div class="stat-card"><div class="label">Total Deposits (Success)</div><div class="value" style="color:green;">₹<?= number_format($total_deposits, 2) ?></div></div>
            <div class="stat-card"><div class="label">Total Withdrawals (Success)</div><div class="value" style="color:red;">₹<?= number_format($total_withdrawals, 2) ?></div></div>
            <div class="stat-card"><div class="label">Pending Action Req</div><div class="value" style="color:orange;"><?= $pending_withdrawals + $pending_deposits ?></div></div>
        </div>

        <?php elseif ($page === 'notifications' && $can_notif): ?>
        <div class="page-header"><h1>📢 Send Notification / SMS</h1></div>
        <div class="content-card" style="max-width: 600px;">
            <form method="POST">
                <input type="hidden" name="action" value="send_notification">
                <div class="form-group">
                    <label>Target User (Phone Number or 'all' for everyone)</label>
                    <select name="target" id="targetSelect" onchange="togglePhoneInput()">
                        <option value="all">Broadcast to All Users</option>
                        <option value="specific">Specific User</option>
                    </select>
                </div>
                <div class="form-group" id="phoneInputGrp" style="display:none;">
                    <label>Enter User Phone Number</label>
                    <input type="text" name="target" id="specificPhone" placeholder="E.g., 9876543210" disabled>
                </div>
                <div class="form-group">
                    <label>Notification Title</label>
                    <input type="text" name="title" placeholder="E.g., Special Bonus!" required>
                </div>
                <div class="form-group">
                    <label>Message Content</label>
                    <textarea name="message" rows="5" placeholder="Type your message here..." required></textarea>
                </div>
                <button type="submit" class="btn btn-primary">Send Notification</button>
            </form>
        </div>
        <script>
            function togglePhoneInput() {
                const sel = document.getElementById('targetSelect');
                const grp = document.getElementById('phoneInputGrp');
                const inp = document.getElementById('specificPhone');
                if (sel.value === 'specific') {
                    grp.style.display = 'block';
                    inp.disabled = false;
                    sel.name = ''; // Remove name from select so input takes over
                } else {
                    grp.style.display = 'none';
                    inp.disabled = true;
                    sel.name = 'target';
                }
            }
        </script>

        <?php elseif ($page === 'chats' && $can_chat): ?>
        <div class="page-header"><h1>💬 Live Chat Support</h1></div>
        <div class="content-card">
            <table class="table">
                <tr><th>User Phone / ID</th><th>Last Active</th><th>Last Message</th><th>Action</th></tr>
                <?php foreach ($chats as $chatKey => $c): 
                    $msgs = $c['messages'] ?? [];
                    if (!is_array($msgs)) $msgs = [];
                    // Extract last message text
                    $lastMsgText = 'No messages';
                    if (!empty($msgs)) {
                        $lastMsg = end($msgs);
                        $lastMsgText = $lastMsg['text'] ?? '';
                        // Limit to first 6-8 words or letters roughly
                        $lastMsgText = mb_strimwidth($lastMsgText, 0, 30, '...'); 
                    }
                    $lastActive = $c['last_active'] ?? 0;
                    $phoneStr = $c['phone'] ?? 'Guest';
                ?>
                <tr>
                    <td><b><?= htmlspecialchars($phoneStr) ?></b><br><small style="color:#888;"><?= htmlspecialchars($c['chat_id'] ?? '') ?></small></td>
                    <td><?= $lastActive > 0 ? date('d M, h:i A', $lastActive) : 'Unknown' ?></td>
                    <td><i><?= htmlspecialchars($lastMsgText) ?></i></td>
                    <td>
                        <textarea id="chatjson_<?= $chatKey ?>" style="display:none;"><?= json_encode($c) ?></textarea>
                        <button class="btn btn-info" onclick="openChatModal('<?= $chatKey ?>')">View & Reply</button>
                    </td>
                </tr>
                <?php endforeach; ?>
            </table>
        </div>

        <?php elseif ($page === 'feedbacks' && $can_feedback): ?>
        <div class="page-header"><h1>📝 User Feedbacks</h1></div>
        <div class="content-card">
            <table class="table">
                <tr><th>Phone Number</th><th>Date</th><th>Feedback Description</th><th>Status</th></tr>
                <?php foreach ($feedbacks as $f): ?>
                <tr>
                    <td><b><?= htmlspecialchars($f['phone'] ?? '') ?></b></td>
                    <td><?= htmlspecialchars($f['created_at'] ?? '') ?></td>
                    <td><?= nl2br(htmlspecialchars($f['message'] ?? '')) ?></td>
                    <td><span class="status status-<?= strtolower($f['status'] ?? 'pending') ?>"><?= $f['status'] ?? 'Pending' ?></span></td>
                </tr>
                <?php endforeach; ?>
            </table>
        </div>

        <?php elseif ($page === 'withdrawals' && $can_withdrawal): ?>
        <div class="page-header"><h1>Active Withdrawal Requests</h1></div>
        <div class="content-card">
            <table class="table">
                <tr><th>User</th><th>Amount</th><th>Details</th><th>Status</th><th>Date</th><th>Action</th></tr>
                <?php foreach ($withdrawals_active as $w): 
                    $wPh = $w['phone'];
                    $bInfo = $users[$wPh]['bank_info'] ?? null;
                    $uInfo = $users[$wPh]['upi_info'] ?? null;
                    $type = $w['type'] ?? 'BANK CARD';
                ?>
                <tr>
                    <td><?= htmlspecialchars($wPh) ?></td>
                    <td><strong style="color:red;">₹<?= number_format($w['amount'] ?? 0, 2) ?></strong></td>
                    <td>
                        <div class="box-info">
                            <b>Method:</b> <?= $type ?><br>
                            <?php if(strpos($type, 'UPI') !== false && $uInfo): ?>
                                <b>UPI:</b> <?= htmlspecialchars($uInfo['upi_id'] ?? '') ?> (<?= htmlspecialchars($uInfo['upi_name'] ?? '') ?>)
                            <?php elseif($bInfo): ?>
                                <b>A/C No:</b> <b style="color:blue;"><?= htmlspecialchars($bInfo['account_number'] ?? '') ?></b><br>
                                <b>IFSC:</b> <?= htmlspecialchars($bInfo['ifsc_code'] ?? '') ?> (<?= htmlspecialchars($bInfo['bank_name'] ?? '') ?>)
                            <?php endif; ?>
                        </div>
                    </td>
                    <td><span class="status status-<?= strtolower($w['status'] ?? 'pending') ?>"><?= $w['status'] ?? 'Pending' ?></span></td>
                    <td><?= $w['time'] ?? '' ?></td>
                    <td>
                        <?php if (strtolower($w['status'] ?? '') === 'pending'): ?>
                        <form method="POST" style="display:inline">
                            <input type="hidden" name="action" value="update_withdrawal">
                            <input type="hidden" name="id" value="<?= $w['order_id'] ?>">
                            <input type="hidden" name="phone" value="<?= $wPh ?>">
                            <input type="hidden" name="amount" value="<?= $w['amount'] ?>">
                            <button type="submit" name="status" value="completed" class="btn btn-success">Approve</button>
                            <button type="submit" name="status" value="rejected" class="btn btn-danger">Reject</button>
                        </form>
                        <?php else: ?> Resolved <?php endif; ?>
                    </td>
                </tr>
                <?php endforeach; ?>
            </table>
        </div>

        <?php elseif ($page === 'deposits' && $can_deposit): ?>
        <div class="page-header"><h1>Active Deposit Requests</h1></div>
        <div class="content-card">
            <table class="table">
                <tr><th>User</th><th>Amount</th><th>Method & UTR</th><th>Status</th><th>Date</th><th>Action</th></tr>
                <?php foreach ($deposits_active as $d): ?>
                <tr>
                    <td><?= htmlspecialchars($d['phone'] ?? '') ?></td>
                    <td><strong style="color:green;">₹<?= number_format($d['amount'] ?? 0, 2) ?></strong></td>
                    <td>
                        <b>Method:</b> <?= $d['type'] ?? 'Unknown' ?><br>
                        <b>UTR:</b> <span style="color:red; font-weight:bold;"><?= $d['utr'] ? $d['utr'] : 'Not Submitted' ?></span>
                    </td>
                    <td><span class="status status-<?= strtolower($d['status'] ?? 'pending') ?>"><?= $d['status'] ?? 'Pending' ?></span></td>
                    <td><?= $d['time'] ?? '' ?></td>
                    <td>
                        <?php if (in_array(strtolower($d['status'] ?? ''), ['pending', 'processing'])): ?>
                        <form method="POST" style="display:inline">
                            <input type="hidden" name="action" value="update_deposit">
                            <input type="hidden" name="id" value="<?= $d['order_id'] ?>">
                            <input type="hidden" name="phone" value="<?= $d['phone'] ?>">
                            <input type="hidden" name="amount" value="<?= $d['amount'] ?>">
                            <button type="submit" name="status" value="completed" class="btn btn-success">Approve</button>
                            <button type="submit" name="status" value="rejected" class="btn btn-danger">Reject</button>
                        </form>
                        <?php else: ?> Resolved <?php endif; ?>
                    </td>
                </tr>
                <?php endforeach; ?>
            </table>
        </div>

        <?php elseif ($page === 'support' && $can_support): ?>
        <div class="page-header"><h1>Customer Support Tickets</h1></div>
        <div class="content-card">
            <table class="table">
                <tr><th>Req ID</th><th>User Phone</th><th>Ticket Type</th><th>Date</th><th>Status</th><th>Actions</th></tr>
                <?php foreach ($support_active as $s): ?>
                <tr>
                    <td><b><?= htmlspecialchars($s['request_id'] ?? '') ?></b></td>
                    <td><?= htmlspecialchars($s['phone'] ?? '') ?></td>
                    <td><?= htmlspecialchars($s['type'] ?? '') ?></td>
                    <td><?= htmlspecialchars($s['time'] ?? '') ?></td>
                    <td><span class="status status-<?= strtolower($s['status'] ?? 'pending') ?>"><?= $s['status'] ?? 'Pending' ?></span></td>
                    <td>
                        <textarea id="sjson_<?= $s['request_id'] ?>" style="display:none;"><?= json_encode($s) ?></textarea>
                        <button class="btn btn-info" onclick="viewSupport('<?= $s['request_id'] ?>')">View Full Details</button>
                        
                        <?php if(strtolower($s['status'] ?? '') === 'pending'): ?>
                        <form method="POST" style="display:inline; margin-left:10px;">
                            <input type="hidden" name="action" value="update_support">
                            <input type="hidden" name="id" value="<?= $s['request_id'] ?>">
                            <input type="hidden" name="phone" value="<?= $s['phone'] ?>">
                            <button type="submit" name="status" value="Resolved" class="btn btn-success">Resolve</button>
                            <button type="submit" name="status" value="Rejected" class="btn btn-danger">Reject</button>
                        </form>
                        <?php endif; ?>
                    </td>
                </tr>
                <?php endforeach; ?>
            </table>
        </div>

        <?php elseif ($page === 'rejected'): ?>
        <div class="page-header"><h1>🗑️ Rejected Archive / Trash</h1></div>
        <p style="margin-bottom:20px; color:#666;">Yahan sirf wo requests hain jinhe Reject kiya gaya tha. Search se filter karo aur wapis Pending me bhejne ke liye Restore button dabao.</p>
        
        <input type="text" id="rejectSearch" class="search-input" onkeyup="searchRejected()" placeholder="🔍 Search Phone No., Order ID, ya Type...">

        <div class="content-card">
            <table class="table">
                <tr><th>Category</th><th>ID (Req/Order)</th><th>User Phone</th><th>Info</th><th>Date</th><th>Action</th></tr>
                
                <?php if ($can_deposit): foreach ($deposits_rejected as $d): ?>
                <tr class="reject-row">
                    <td><span class="status status-rejected">DEPOSIT</span></td>
                    <td><?= htmlspecialchars($d['order_id'] ?? '') ?></td>
                    <td><?= htmlspecialchars($d['phone'] ?? '') ?></td>
                    <td>Amt: <b>₹<?= $d['amount'] ?></b> | UTR: <?= $d['utr'] ?></td>
                    <td><?= $d['time'] ?? '' ?></td>
                    <td>
                        <form method="POST"><input type="hidden" name="action" value="restore_item"><input type="hidden" name="restore_type" value="deposit"><input type="hidden" name="id" value="<?= $d['order_id'] ?>"><input type="hidden" name="phone" value="<?= $d['phone'] ?>"><input type="hidden" name="amount" value="<?= $d['amount'] ?>"><button type="submit" class="btn btn-warning" onclick="return confirm('Restore this to Deposits Tab?')">Restore to Pending</button></form>
                    </td>
                </tr>
                <?php endforeach; endif; ?>

                <?php if ($can_withdrawal): foreach ($withdrawals_rejected as $w): ?>
                <tr class="reject-row">
                    <td><span class="status status-rejected">WITHDRAWAL</span></td>
                    <td><?= htmlspecialchars($w['order_id'] ?? '') ?></td>
                    <td><?= htmlspecialchars($w['phone'] ?? '') ?></td>
                    <td>Amt: <b>₹<?= $w['amount'] ?></b></td>
                    <td><?= $w['time'] ?? '' ?></td>
                    <td>
                        <form method="POST"><input type="hidden" name="action" value="restore_item"><input type="hidden" name="restore_type" value="withdrawal"><input type="hidden" name="id" value="<?= $w['order_id'] ?>"><input type="hidden" name="phone" value="<?= $w['phone'] ?>"><input type="hidden" name="amount" value="<?= $w['amount'] ?>"><button type="submit" class="btn btn-warning" onclick="return confirm('WARNING: Restoring will deduct ₹<?= $w['amount'] ?> from user balance. Continue?')">Restore to Pending</button></form>
                    </td>
                </tr>
                <?php endforeach; endif; ?>

                <?php if ($can_support): foreach ($support_rejected as $s): ?>
                <tr class="reject-row">
                    <td><span class="status status-rejected">SUPPORT TICKET</span></td>
                    <td><?= htmlspecialchars($s['request_id'] ?? '') ?></td>
                    <td><?= htmlspecialchars($s['phone'] ?? '') ?></td>
                    <td>Type: <b><?= htmlspecialchars($s['type'] ?? '') ?></b></td>
                    <td><?= $s['time'] ?? '' ?></td>
                    <td>
                        <form method="POST" style="display:inline;"><input type="hidden" name="action" value="restore_item"><input type="hidden" name="restore_type" value="support"><input type="hidden" name="id" value="<?= $s['request_id'] ?>"><input type="hidden" name="phone" value="<?= $s['phone'] ?>"><button type="submit" class="btn btn-warning" onclick="return confirm('Restore this support ticket?')">Restore to Pending</button></form>
                        <textarea id="sjson_<?= $s['request_id'] ?>" style="display:none;"><?= json_encode($s) ?></textarea>
                        <button class="btn btn-info" onclick="viewSupport('<?= $s['request_id'] ?>')">Details</button>
                    </td>
                </tr>
                <?php endforeach; endif; ?>
            </table>
        </div>

        <?php elseif ($page === 'users' && $can_users): ?>
        <div class="page-header"><h1>User Management</h1></div>
        <div class="content-card">
            <table class="table">
                <tr><th>Phone</th><th>Balance</th><th>VIP EXP</th><th>Created</th><th>Action</th></tr>
                <?php foreach ($users as $phone => $u): ?>
                <tr>
                    <td><?= htmlspecialchars($phone) ?></td>
                    <td><strong style="color:green;">₹<?= number_format($u['balance'] ?? 0, 2) ?></strong></td>
                    <td><?= $u['exp'] ?? 0 ?> EXP</td>
                    <td><?= $u['createdAt'] ?? 'N/A' ?></td>
                    <td><button class="btn btn-info" onclick='openUserModal(<?= json_encode(array_merge($u, ["_phone"=>$phone])) ?>)'>Control User</button></td>
                </tr>
                <?php endforeach; ?>
            </table>
        </div>

        <?php elseif ($page === 'upi' && $can_upi): ?>
        <div class="page-header"><h1>Payment Settings</h1></div>
        <div class="content-card" style="max-width: 600px;">
            <form method="POST">
                <input type="hidden" name="action" value="add_upi">
                <div class="form-group"><label>ArUpi Pay (UPI_QR)</label><input type="text" name="upi_qr_id" value="<?= htmlspecialchars($admin_settings['upi_qr_id'] ?? '') ?>"></div>
                <div class="form-group"><label>Paytm X QR (PAYTM_QR)</label><input type="text" name="paytm_upi_id" value="<?= htmlspecialchars($admin_settings['paytm_upi_id'] ?? '') ?>"></div>
                <div class="form-group"><label>Normal UPI (UPI)</label><input type="text" name="upi_direct_id" value="<?= htmlspecialchars($admin_settings['upi_direct_id'] ?? '') ?>"></div>
                <button type="submit" class="btn btn-primary">Save Settings</button>
            </form>
        </div>

        <?php elseif ($page === 'gifts' && $can_all): ?>
        <div class="page-header"><h1>Gift Codes</h1></div>
        <div class="content-card" style="max-width: 600px; margin-bottom:20px;">
            <form method="POST" style="display:flex; gap:10px; align-items:flex-end;">
                <input type="hidden" name="action" value="create_gift">
                <div class="form-group" style="margin:0;"><label>Amount (₹)</label><input type="number" name="gift_amount" required></div>
                <div class="form-group" style="margin:0;"><label>Max Claims</label><input type="number" name="gift_uses" value="1" required></div>
                <button type="submit" class="btn btn-success" style="height:42px;">Generate Code</button>
            </form>
        </div>
        <div class="content-card">
            <table class="table">
                <tr><th>Code</th><th>Amount</th><th>Uses</th><th>Date</th><th>Action</th></tr>
                <?php foreach ($gift_codes as $code => $d): $uc = isset($d['used_by']) ? count($d['used_by']) : 0; ?>
                <tr>
                    <td><b id="c_<?= $code ?>"><?= $code ?></b> <button class="btn btn-primary" style="padding:4px 8px; font-size:10px;" onclick="copy('c_<?= $code ?>')">Copy</button></td>
                    <td>₹<?= $d['amount'] ?></td><td><?= $uc ?> / <?= $d['max_uses'] ?></td><td><?= $d['created_at'] ?></td>
                    <td><form method="POST"><input type="hidden" name="action" value="delete_gift"><input type="hidden" name="code" value="<?= $code ?>"><button type="submit" class="btn btn-danger">Delete</button></form></td>
                </tr>
                <?php endforeach; ?>
            </table>
        </div>

        <?php elseif ($page === 'admins' && $can_admins): ?>
        <div class="page-header"><h1>Admin Management</h1></div>
        <div class="content-card" style="max-width: 600px;">
            <h3>Add Sub-Admin</h3>
            <form method="POST">
                <input type="hidden" name="action" value="add_admin">
                <div class="form-group"><label>Username</label><input type="text" name="username" required></div>
                <div class="form-group"><label>Password</label><input type="password" name="password" required></div>
                <div class="form-group">
                    <label>Permissions</label>
                    <div class="checkbox-group">
                        <label><input type="checkbox" name="perm_all"> Full Access</label>
                        <label><input type="checkbox" name="perm_withdrawal"> Withdrawals</label>
                        <label><input type="checkbox" name="perm_deposit"> Deposits</label>
                        <label><input type="checkbox" name="perm_support"> Deposit Tkt Support</label>
                        <label><input type="checkbox" name="perm_notif"> Notifications / SMS</label>
                        <label><input type="checkbox" name="perm_chat"> Live Chat</label>
                        <label><input type="checkbox" name="perm_feedback"> Feedbacks</label>
                        <label><input type="checkbox" name="perm_users"> Users Edit</label>
                        <label><input type="checkbox" name="perm_upi"> Payment Gateway</label>
                    </div>
                </div>
                <button type="submit" class="btn btn-primary">Create Admin</button>
            </form>
        </div>
        <div class="content-card">
            <table class="table">
                <tr><th>Username</th><th>Permissions</th><th>Action</th></tr>
                <?php foreach ($admins as $uname => $a): ?>
                <tr>
                    <td><b><?= $uname ?></b></td>
                    <td><?= ($a['all'] ?? false) ? 'ALL' : 'Custom Config' ?></td>
                    <td><form method="POST"><input type="hidden" name="action" value="delete_admin"><input type="hidden" name="username" value="<?= $uname ?>"><button type="submit" class="btn btn-danger">Delete</button></form></td>
                </tr>
                <?php endforeach; ?>
            </table>
        </div>
        <?php endif; ?>
    </div>
</div>

<!-- CHAT MODAL -->
<div id="chatModal" class="modal">
    <div class="modal-content" style="max-width:600px;">
        <span class="close" onclick="document.getElementById('chatModal').classList.remove('show')">&times;</span>
        <h2 style="margin-bottom: 20px; color:#1e3c72;">Chat Viewer</h2>
        
        <div id="chatWindow" class="chat-window">
            <!-- Chat messages injected via JS -->
        </div>

        <form method="POST" style="margin-top: 15px; display:flex; gap:10px;">
            <input type="hidden" name="action" value="reply_chat">
            <input type="hidden" name="chat_key" id="replyChatKey">
            <input type="text" name="message" placeholder="Type reply as Admin..." required style="flex:1; padding:10px; border-radius:8px; border:1px solid #ccc;">
            <button type="submit" class="btn btn-success">Send Reply</button>
        </form>
    </div>
</div>

<!-- SUPPORT DETAILS MODAL -->
<div id="suppModal" class="modal">
    <div class="modal-content">
        <span class="close" onclick="document.getElementById('suppModal').classList.remove('show')">&times;</span>
        <h2 style="margin-bottom: 20px; color:#1e3c72;">Support Request Details</h2>
        <div id="suppModalBody" style="line-height:1.8;"></div>
    </div>
</div>

<!-- EDIT USER MODAL -->
<div id="editUserModal" class="modal">
    <div class="modal-content">
        <span class="close" onclick="document.getElementById('editUserModal').classList.remove('show')">&times;</span>
        <h2 style="margin-bottom: 20px;">Control User: <span id="um_phone" style="color:#1e3c72;"></span></h2>
        <div class="action-grid">
            <button class="action-btn" onclick="showSection('sec_bal', this)">💰 Edit Balance</button>
            <button class="action-btn" onclick="showSection('sec_bank', this)">🏦 Bank Card</button>
            <button class="action-btn" onclick="showSection('sec_upi', this)">📱 UPI ID</button>
            <button class="action-btn" onclick="showSection('sec_vip', this)">⭐ Edit VIP (EXP)</button>
            <button class="action-btn" onclick="doResetPassword()" style="grid-column: span 2; background:#ff4757; color:white; border:none;">🔐 Generate New Password</button>
        </div>
        <form method="POST" id="fullInfoForm">
            <input type="hidden" name="action" value="update_user_full_info"><input type="hidden" name="phone" id="edit_phone">
            <div id="sec_bal" class="edit-section"><div class="form-group"><input type="number" name="balance" id="edit_balance" step="0.01"></div></div>
            <div id="sec_bank" class="edit-section">
                <div class="form-group"><label>Bank Name</label><input type="text" name="bank_name" id="bank_name"></div>
                <div class="form-group"><label>A/C Number</label><input type="text" name="account_number" id="account_number"></div>
                <div class="form-group"><label>IFSC Code</label><input type="text" name="ifsc_code" id="ifsc_code"></div>
                <div class="form-group"><label>Holder Name</label><input type="text" name="account_holder" id="account_holder"></div>
            </div>
            <div id="sec_upi" class="edit-section">
                <div class="form-group"><label>UPI ID</label><input type="text" name="upi_id" id="upi_id"></div>
                <div class="form-group"><label>UPI Name</label><input type="text" name="upi_name" id="upi_name"></div>
            </div>
            <div id="sec_vip" class="edit-section"><div class="form-group"><input type="number" name="exp" id="edit_exp" step="0.01"></div></div>
            <button type="submit" class="btn btn-success" style="width:100%; height:45px; margin-top:20px; font-size:16px;">Save Changes</button>
        </form>
    </div>
</div>

<script>
// Search Rejected Data
function searchRejected() {
    let filter = document.getElementById("rejectSearch").value.toLowerCase();
    let rows = document.querySelectorAll(".reject-row");
    rows.forEach(row => {
        let text = row.innerText.toLowerCase();
        row.style.display = text.includes(filter) ? "" : "none";
    });
}

// Support Modal
function viewSupport(reqId) {
    let jsonString = document.getElementById("sjson_" + reqId).value;
    let data = JSON.parse(jsonString);
    let html = '';
    const ignored = ['request_id', 'status', 'time'];
    const photos = ['photo', 'selfie', 'receipt', 'passbook'];
    for (let key in data) {
        if (!ignored.includes(key) && data[key]) {
            let label = key.replace(/_/g, ' ').toUpperCase();
            if (photos.includes(key)) {
                html += `<div class="box-info"><b>${label}</b><br><img src="${data[key]}" style="width:100%; max-width:400px; border-radius:10px; margin-top:10px; border:2px solid #ccc;"></div>`;
            } else {
                html += `<div class="box-info"><b>${label}:</b> ${data[key]}</div>`;
            }
        }
    }
    document.getElementById('suppModalBody').innerHTML = html;
    document.getElementById('suppModal').classList.add('show');
}

// Chat Modal rendering
function openChatModal(chatKey) {
    document.getElementById('replyChatKey').value = chatKey;
    let jsonString = document.getElementById("chatjson_" + chatKey).value;
    let chatData = JSON.parse(jsonString);
    let msgs = chatData.messages || {};
    
    // sort messages by timestamp
    let msgArray = Object.values(msgs).filter(m => m.id !== 'init');
    msgArray.sort((a,b) => (a.timestamp || 0) - (b.timestamp || 0));

    let html = '';
    if(msgArray.length === 0) {
        html = '<div style="text-align:center; color:#999; margin-top:20px;">No messages in this chat yet.</div>';
    } else {
        msgArray.forEach(m => {
            let senderType = m.sender || 'assistant';
            let senderName = senderType === 'user' ? 'User' : (senderType === 'bot' ? 'Bot' : 'Admin');
            
            // image rendering if exists
            let imgHtml = '';
            if (m.image && m.image.length > 20) {
                imgHtml = `<br><img src="${m.image}" style="max-width:200px; border-radius:8px; margin-top:5px;">`;
            }
            
            html += `
            <div class="msg-row ${senderType}">
                <div class="msg-bubble">
                    <div class="msg-sender">${senderName}</div>
                    <div>${m.text ? m.text : ''}${imgHtml}</div>
                    <div class="msg-time">${m.time_formatted || ''}</div>
                </div>
            </div>`;
        });
    }

    let win = document.getElementById('chatWindow');
    win.innerHTML = html;
    document.getElementById('chatModal').classList.add('show');
    
    // Scroll to bottom
    setTimeout(() => { win.scrollTop = win.scrollHeight; }, 100);
}

// User Modal
let currentUserPhone = '';
function openUserModal(user) {
    currentUserPhone = user._phone;
    document.getElementById('um_phone').innerText = user._phone;
    document.getElementById('edit_phone').value = user._phone;
    document.getElementById('edit_balance').value = user.balance || 0;
    document.getElementById('edit_exp').value = user.exp || 0;
    
    let b = user.bank_info || {};
    document.getElementById('bank_name').value = b.bank_name || '';
    document.getElementById('account_number').value = b.account_number || '';
    document.getElementById('ifsc_code').value = b.ifsc_code || '';
    document.getElementById('account_holder').value = b.account_name || '';

    let u = user.upi_info || {};
    document.getElementById('upi_id').value = u.upi_id || '';
    document.getElementById('upi_name').value = u.upi_name || '';

    document.querySelectorAll('.edit-section').forEach(s => s.style.display = 'none');
    document.querySelectorAll('.action-btn').forEach(b => b.classList.remove('active'));
    document.getElementById('editUserModal').classList.add('show');
}

function showSection(id, btn) {
    document.querySelectorAll('.edit-section').forEach(s => s.style.display = 'none');
    document.querySelectorAll('.action-btn').forEach(b => b.classList.remove('active'));
    document.getElementById(id).style.display = 'block';
    btn.classList.add('active');
}

function doResetPassword() {
    if(!confirm("Are you sure you want to generate a new password?")) return;
    let fd = new FormData();
    fd.append('action', 'reset_password'); fd.append('phone', currentUserPhone);
    fetch('admin.php', { method: 'POST', body: fd }).then(r => r.json()).then(d => {
        if(d.success) alert("✅ New Password for " + currentUserPhone + " is: " + d.new_password); 
    });
}

function copy(id) {
    var txt = document.getElementById(id).innerText;
    var e = document.createElement("textarea"); document.body.appendChild(e); e.value = txt; e.select(); document.execCommand("copy"); document.body.removeChild(e);
    alert("Code Copied!");
}
</script>
</body>
</html>