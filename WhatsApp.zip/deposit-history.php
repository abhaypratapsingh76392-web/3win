<?php
require_once 'config.php';
if (!isset($_SESSION['phone'])) { header('Location: login.php'); exit; }
$phone = $_SESSION['phone'];

$deposits = firebase_read("deposits/" . $phone) ?? [];
if (!is_array($deposits)) $deposits = [];
usort($deposits, function($a, $b) { return strcmp($b['time'] ?? '', $a['time'] ?? ''); });
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
<title>Deposit History</title>
<style>
* { margin:0; padding:0; box-sizing:border-box; -webkit-tap-highlight-color:transparent; }
body { font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',sans-serif; background:#f0f2f5; max-width:480px; margin:0 auto; padding-bottom:30px; }
.header { background:#fff; display:flex; align-items:center; justify-content:space-between; padding:14px 16px; position:sticky; top:0; z-index:100; box-shadow:0 1px 4px rgba(0,0,0,0.08); }
.header-back { font-size:22px; color:#333; text-decoration:none; }
.header-title { font-size:17px; font-weight:600; color:#222; }
.header-space { width:32px; }

/* Filter Tabs */
.filter-tabs { display:flex; overflow-x:auto; padding:12px 12px 0; gap:8px; scrollbar-width:none; }
.filter-tabs::-webkit-scrollbar { display:none; }
.filter-tab { display:flex; align-items:center; gap:6px; padding:8px 14px; border-radius:20px; background:#fff; border:1.5px solid #e0e8f5; font-size:13px; font-weight:600; color:#666; cursor:pointer; white-space:nowrap; flex-shrink:0; }
.filter-tab img { width:20px; height:20px; border-radius:4px; object-fit:cover; }
.filter-tab.active { background:#4a90e2; border-color:#4a90e2; color:#fff; }
.filter-tab.all-tab { font-size:18px; }

/* Status + Date Filter */
.filter-row { display:flex; gap:8px; padding:10px 12px; }
.filter-select-box { flex:1; display:flex; align-items:center; justify-content:space-between; background:#fff; border-radius:8px; padding:10px 12px; font-size:13px; color:#333; cursor:pointer; box-shadow:0 1px 4px rgba(0,0,0,0.06); }
.filter-select-box .arrow { color:#aaa; }

/* History Cards */
.history-section { padding:0 12px; }
.history-card { background:#fff; border-radius:14px; padding:14px 16px; margin-bottom:10px; box-shadow:0 1px 4px rgba(0,0,0,0.06); }
.history-top { display:flex; justify-content:space-between; align-items:center; margin-bottom:10px; }
.deposit-badge { background:#22b573; color:#fff; font-size:13px; font-weight:700; padding:5px 14px; border-radius:8px; }
.status-complete { color:#22b573; font-weight:700; font-size:14px; }
.status-pending { color:#f5a623; font-weight:700; font-size:14px; }
.status-processing { color:#4a90e2; font-weight:700; font-size:14px; }
.status-failed { color:#e85d5d; font-weight:700; font-size:14px; }
.history-row { display:flex; justify-content:space-between; padding:5px 0; border-bottom:1px solid #f5f5f5; font-size:13px; }
.history-row:last-child { border-bottom:none; }
.history-row .lbl { color:#888; }
.history-row .val { color:#333; font-weight:500; }
.history-row .orange { color:#e85d04; font-weight:600; }
.submit-utr-btn { width:100%; background:linear-gradient(135deg,#4a90e2,#357abd); color:#fff; border:none; border-radius:10px; padding:12px; font-size:14px; font-weight:600; cursor:pointer; margin-top:10px; }
.order-copy { display:flex; align-items:center; gap:4px; cursor:pointer; color:#555; font-size:11px; }
.no-history { text-align:center; padding:60px 20px; color:#bbb; font-size:14px; }
.no-history-icon { font-size:50px; margin-bottom:12px; }

/* Status Filter Sheet */
.sheet-overlay { display:none; position:fixed; top:0;left:0;right:0;bottom:0; background:rgba(0,0,0,0.5); z-index:400; align-items:flex-end; justify-content:center; }
.sheet-overlay.show { display:flex; }
.sheet-box { background:#fff; width:100%; max-width:480px; border-radius:20px 20px 0 0; padding:10px 0 30px; animation:slideUp 0.3s ease; }
@keyframes slideUp { from{transform:translateY(100%)} to{transform:translateY(0)} }
.sheet-header { display:flex; justify-content:space-between; padding:14px 20px; font-size:15px; font-weight:600; border-bottom:1px solid #f0f0f0; }
.sheet-confirm { color:#4a90e2; cursor:pointer; }
.sheet-cancel { color:#999; cursor:pointer; }
.sheet-option { padding:18px 20px; font-size:16px; color:#aaa; text-align:center; cursor:pointer; }
.sheet-option.selected { color:#222; font-weight:700; }
.sheet-option:hover { background:#f5f5f5; }

/* Calendar Sheet */
.cal-sheet-overlay { display:none; position:fixed; top:0;left:0;right:0;bottom:0; background:rgba(0,0,0,0.5); z-index:400; align-items:flex-end; justify-content:center; }
.cal-sheet-overlay.show { display:flex; }
.cal-box { background:#fff; width:100%; max-width:480px; border-radius:20px 20px 0 0; padding:0 16px 20px; max-height:90vh; overflow-y:auto; animation:slideUp 0.3s ease; }
.cal-header { display:flex; justify-content:space-between; align-items:center; padding:16px 0 12px; border-bottom:1px solid #f0f0f0; }
.cal-close { font-size:22px; color:#999; cursor:pointer; }
.cal-title { font-size:18px; font-weight:700; color:#222; }
.cal-grid-header { display:grid; grid-template-columns:repeat(7,1fr); gap:0; text-align:center; padding:12px 0 8px; }
.cal-grid-header span { font-size:12px; color:#aaa; }
.cal-month-title { font-size:16px; font-weight:700; text-align:center; padding:14px 0 8px; color:#222; }
.cal-grid { display:grid; grid-template-columns:repeat(7,1fr); gap:4px; margin-bottom:12px; }
.cal-day { text-align:center; padding:10px 4px; font-size:14px; color:#333; cursor:pointer; border-radius:8px; }
.cal-day.empty { cursor:default; }
.cal-day.selected-start { background:#4a90e2; color:#fff; border-radius:8px; }
.cal-day.selected-end { background:#4a90e2; color:#fff; border-radius:8px; }
.cal-day.in-range { background:#e8f0fd; color:#4a90e2; }
.cal-confirm-btn { width:100%; padding:14px; background:#4a90e2; color:#fff; border:none; border-radius:30px; font-size:16px; font-weight:700; cursor:pointer; margin-top:8px; }

/* UTR Modal */
.utr-modal-overlay { display:none; position:fixed; top:0;left:0;right:0;bottom:0; background:rgba(0,0,0,0.5); z-index:600; align-items:flex-end; justify-content:center; }
.utr-modal-overlay.show { display:flex; }
.utr-modal-box { background:#fff; width:100%; max-width:480px; border-radius:20px 20px 0 0; padding:0 0 20px; animation:slideUp 0.3s ease; }
.utr-modal-header { display:flex; justify-content:space-between; align-items:center; padding:16px; border-bottom:1px solid #f0f0f0; }
.utr-modal-title { font-size:16px; font-weight:700; color:#222; }
.utr-modal-submit { background:#4a90e2; color:#fff; border:none; border-radius:20px; padding:8px 18px; font-size:14px; font-weight:600; cursor:pointer; }
.utr-modal-body { padding:16px; }
.utr-modal-input { width:100%; padding:13px 14px; border:1.5px solid #e5e8ec; border-radius:10px; font-size:15px; color:#333; outline:none; background:#fafafa; margin-bottom:14px; }
.utr-detail-row { display:flex; justify-content:space-between; padding:8px 0; font-size:13px; border-bottom:1px solid #f0f0f0; }
.utr-detail-row:last-child { border-bottom:none; }
.utr-detail-lbl { color:#888; }
.utr-detail-val { color:#333; font-weight:500; }
.utr-detail-val.orange { color:#e85d04; font-weight:600; }

/* Toast */
.toast { position:fixed; top:50%; left:50%; transform:translate(-50%,-50%) scale(0.8); background:rgba(0,0,0,0.78); color:#fff; padding:20px 28px; border-radius:16px; font-size:15px; text-align:center; z-index:999; opacity:0; transition:all 0.3s; pointer-events:none; min-width:160px; }
.toast.show { opacity:1; transform:translate(-50%,-50%) scale(1); }
.toast-icon { font-size:28px; display:block; margin-bottom:6px; }
</style>
</head>
<body>

<div class="header">
    <a href="deposit.php" class="header-back">&#8249;</a>
    <span class="header-title">Deposit history</span>
    <div class="header-space"></div>
</div>

<!-- Filter Tabs -->
<div class="filter-tabs">
    <div class="filter-tab all-tab active" onclick="filterType('all')" id="ft-all">
        <span>⊞</span> All
    </div>
    <div class="filter-tab" onclick="filterType('UPI_QR')" id="ft-UPI_QR">
        <img src="https://bindassgame.bet/GoaGame/payNameIcon/payNameIcon2_20250514192004oqqi.jpg" alt="">
        ArUpi Pay
    </div>
    <div class="filter-tab" onclick="filterType('PAYTM_QR')" id="ft-PAYTM_QR">
        <img src="https://bindassgame.bet/GoaGame/payNameIcon/payNameIcon_20231123112348mygk.jpg" alt="">
        Paytm X QR
    </div>
    <div class="filter-tab" onclick="filterType('UPI')" id="ft-UPI">
        <img src="https://bindassgame.bet/GoaGame/payNameIcon/payNameIcon_20231215123948l6y1.jpg" alt="">
        UPI
    </div>
</div>

<!-- Status + Date Filter -->
<div class="filter-row">
    <div class="filter-select-box" onclick="openStatusSheet()">
        <span id="statusFilterLabel">All</span>
        <span class="arrow">▾</span>
    </div>
    <div class="filter-select-box" onclick="openCalSheet()">
        <span id="dateFilterLabel">Choose a date</span>
        <span class="arrow">▾</span>
    </div>
</div>

<!-- History List -->
<div class="history-section" id="historyList">
    <?php if (empty($deposits)): ?>
    <div class="no-history">
        <div class="no-history-icon">📂</div>
        <div>No deposit history</div>
    </div>
    <?php else: ?>
    <?php foreach ($deposits as $dep): ?>
    <div class="history-card dep-card"
         data-type="<?php echo $dep['type'] ?? ''; ?>"
         data-status="<?php echo $dep['status'] ?? 'Pending'; ?>"
         data-date="<?php echo $dep['date'] ?? ''; ?>">
        <div class="history-top">
            <span class="deposit-badge">Deposit</span>
            <?php
            $st = $dep['status'] ?? 'Pending';
            $stClass = 'status-pending'; $stTxt = $st;
            if ($st === 'Complete' || $st === 'Completed') { $stClass = 'status-complete'; $stTxt = 'Complete ›'; }
            elseif ($st === 'Failed') { $stClass = 'status-failed'; }
            elseif ($st === 'Processing') { $stClass = 'status-processing'; }
            ?>
            <span class="<?php echo $stClass; ?>"><?php echo $stTxt; ?></span>
        </div>
        <div class="history-row">
            <span class="lbl">Order amount</span>
            <span class="val orange">₹<?php echo number_format($dep['amount'] ?? 0, 2); ?></span>
        </div>
        <?php if (($dep['status'] ?? '') === 'Complete' || ($dep['status'] ?? '') === 'Completed'): ?>
        <div class="history-row">
            <span class="lbl">You get</span>
            <span class="val" style="color:#22b573;font-weight:600;">₹<?php echo number_format($dep['total_get'] ?? ($dep['amount'] ?? 0), 2); ?></span>
        </div>
        <?php endif; ?>
        <div class="history-row">
            <span class="lbl">Type</span>
            <span class="val"><?php echo htmlspecialchars($dep['type'] ?? ''); ?></span>
        </div>
        <div class="history-row">
            <span class="lbl">Time</span>
            <span class="val"><?php echo htmlspecialchars($dep['time'] ?? ''); ?></span>
        </div>
        <div class="history-row">
            <span class="lbl">Order number</span>
            <div class="order-copy" onclick="copyText('<?php echo $dep['order_id'] ?? ''; ?>')">
                <span><?php echo htmlspecialchars($dep['order_id'] ?? ''); ?></span>
                <span>⧉</span>
            </div>
        </div>
        <?php if (in_array($dep['status'] ?? '', ['Pending', 'Failed'])): ?>
        <button class="submit-utr-btn" onclick="openUtrModal('<?php echo $dep['order_id']; ?>','<?php echo $dep['amount']; ?>','<?php echo $dep['type']; ?>','<?php echo $dep['time']; ?>')">
            Submit Utr
        </button>
        <?php endif; ?>
    </div>
    <?php endforeach; ?>
    <?php endif; ?>
</div>

<!-- Status Sheet -->
<div class="sheet-overlay" id="statusSheet">
    <div class="sheet-box">
        <div class="sheet-header">
            <span class="sheet-cancel" onclick="closeStatusSheet()">Cancel</span>
            <span></span>
            <span class="sheet-confirm" onclick="applyStatus()">Confirm</span>
        </div>
        <div class="sheet-option" onclick="selectStatus('all')">All</div>
        <div class="sheet-option selected" onclick="selectStatus('Pending')">To Be Paid</div>
        <div class="sheet-option" onclick="selectStatus('Complete')">Complete</div>
        <div class="sheet-option" onclick="selectStatus('Failed')">Failed</div>
    </div>
</div>

<!-- Calendar Sheet -->
<div class="cal-sheet-overlay" id="calSheet">
    <div class="cal-box">
        <div class="cal-header">
            <span class="cal-close" onclick="closeCalSheet()">×</span>
            <span class="cal-title">Calendar</span>
            <span style="width:24px;"></span>
        </div>
        <div class="cal-grid-header">
            <span>Sun</span><span>Mon</span><span>Tue</span>
            <span>Wed</span><span>Thu</span><span>Fri</span><span>Sat</span>
        </div>
        <div id="calBody"></div>
        <button class="cal-confirm-btn" onclick="applyDate()">Confirm</button>
    </div>
</div>

<!-- UTR Modal -->
<div class="utr-modal-overlay" id="utrModal">
    <div class="utr-modal-box">
        <div class="utr-modal-header">
            <button style="background:none;border:none;font-size:15px;color:#999;cursor:pointer;" onclick="closeUtrModal()">Cancel</button>
            <span class="utr-modal-title">Submit Utr</span>
            <button class="utr-modal-submit" onclick="submitHistoryUtr()">Submit</button>
        </div>
        <div class="utr-modal-body">
            <div style="font-size:14px;font-weight:600;color:#555;margin-bottom:8px;">Utr</div>
            <input type="number" class="utr-modal-input" id="historyUtrInput" placeholder="Input 12 digits here">
            <div class="utr-detail-row"><span class="utr-detail-lbl">Balance</span><span class="utr-detail-val orange" id="utrBal">₹0.00</span></div>
            <div class="utr-detail-row"><span class="utr-detail-lbl">Type</span><span class="utr-detail-val" id="utrType">-</span></div>
            <div class="utr-detail-row"><span class="utr-detail-lbl">Time</span><span class="utr-detail-val" id="utrTime">-</span></div>
            <div class="utr-detail-row"><span class="utr-detail-lbl">Order number</span><span class="utr-detail-val" id="utrOrder" style="font-size:11px;">-</span></div>
        </div>
    </div>
</div>

<div class="toast" id="toast">
    <span class="toast-icon" id="toastIcon">✓</span>
    <span id="toastMsg">Success</span>
</div>

<script>
let currentTypeFilter = 'all';
let currentStatusFilter = 'all';
let selectedStatus = 'all';
let startDate = null, endDate = null, pickingStart = true;
let historyUtrOrderId = '';

// ============ FILTER TYPE ============
function filterType(type) {
    currentTypeFilter = type;
    document.querySelectorAll('.filter-tab').forEach(t => t.classList.remove('active'));
    document.getElementById('ft-' + type).classList.add('active');
    applyFilters();
}

function applyFilters() {
    const cards = document.querySelectorAll('.dep-card');
    cards.forEach(card => {
        const t = card.dataset.type;
        const s = card.dataset.status;
        const d = card.dataset.date;

        let show = true;
        if (currentTypeFilter !== 'all' && t !== currentTypeFilter) show = false;
        if (currentStatusFilter !== 'all') {
            if (currentStatusFilter === 'Complete' && s !== 'Complete' && s !== 'Completed') show = false;
            else if (currentStatusFilter !== 'Complete' && s !== currentStatusFilter) show = false;
        }
        if (startDate && endDate) {
            if (d < startDate || d > endDate) show = false;
        }
        card.style.display = show ? 'block' : 'none';
    });
}

// ============ STATUS SHEET ============
function openStatusSheet() { document.getElementById('statusSheet').classList.add('show'); }
function closeStatusSheet() { document.getElementById('statusSheet').classList.remove('show'); }
function selectStatus(s) {
    selectedStatus = s;
    document.querySelectorAll('.sheet-option').forEach(o => o.classList.remove('selected'));
    event.target.classList.add('selected');
}
function applyStatus() {
    currentStatusFilter = selectedStatus;
    const labels = { 'all': 'All', 'Pending': 'To Be Paid', 'Complete': 'Complete', 'Failed': 'Failed' };
    document.getElementById('statusFilterLabel').textContent = labels[currentStatusFilter] || 'All';
    closeStatusSheet();
    applyFilters();
}

// ============ CALENDAR ============
function openCalSheet() {
    buildCalendar();
    document.getElementById('calSheet').classList.add('show');
}
function closeCalSheet() { document.getElementById('calSheet').classList.remove('show'); }

function buildCalendar() {
    const body = document.getElementById('calBody');
    body.innerHTML = '';
    const now = new Date();
    for (let mo = -1; mo <= 0; mo++) {
        const d = new Date(now.getFullYear(), now.getMonth() + mo, 1);
        const year = d.getFullYear();
        const month = d.getMonth();
        const title = document.createElement('div');
        title.className = 'cal-month-title';
        title.textContent = year + '/' + (month + 1);
        body.appendChild(title);

        const grid = document.createElement('div');
        grid.className = 'cal-grid';
        const firstDay = new Date(year, month, 1).getDay();
        for (let i = 0; i < firstDay; i++) {
            const empty = document.createElement('div');
            empty.className = 'cal-day empty';
            grid.appendChild(empty);
        }
        const daysInMonth = new Date(year, month + 1, 0).getDate();
        for (let day = 1; day <= daysInMonth; day++) {
            const dateStr = year + '-' + String(month + 1).padStart(2, '0') + '-' + String(day).padStart(2, '0');
            const dayEl = document.createElement('div');
            dayEl.className = 'cal-day';
            dayEl.textContent = day;
            if (dateStr === startDate) { dayEl.classList.add('selected-start'); dayEl.textContent = day + '\nStart'; }
            if (dateStr === endDate) { dayEl.classList.add('selected-end'); dayEl.textContent = day + '\nEnd'; }
            if (startDate && endDate && dateStr > startDate && dateStr < endDate) dayEl.classList.add('in-range');
            dayEl.onclick = () => pickDate(dateStr, dayEl);
            grid.appendChild(dayEl);
        }
        body.appendChild(grid);
    }
}

function pickDate(dateStr, el) {
    if (pickingStart || !startDate) {
        startDate = dateStr; endDate = null; pickingStart = false;
    } else {
        if (dateStr < startDate) { endDate = startDate; startDate = dateStr; }
        else { endDate = dateStr; }
        pickingStart = true;
    }
    buildCalendar();
}

function applyDate() {
    if (startDate && endDate) {
        document.getElementById('dateFilterLabel').textContent = startDate + ' ~ ' + endDate;
    } else if (startDate) {
        document.getElementById('dateFilterLabel').textContent = startDate;
        endDate = startDate;
    }
    closeCalSheet();
    applyFilters();
}

// ============ UTR MODAL ============
function openUtrModal(orderId, amount, type, time) {
    historyUtrOrderId = orderId;
    document.getElementById('historyUtrInput').value = '';
    document.getElementById('utrBal').textContent = '₹' + parseFloat(amount).toFixed(2);
    document.getElementById('utrType').textContent = type;
    document.getElementById('utrTime').textContent = time;
    document.getElementById('utrOrder').textContent = orderId;
    document.getElementById('utrModal').classList.add('show');
}
function closeUtrModal() { document.getElementById('utrModal').classList.remove('show'); }

function submitHistoryUtr() {
    const utr = document.getElementById('historyUtrInput').value.trim();
    if (!utr || utr.length < 10) { showToast('⚠️', 'Enter valid UTR!'); return; }

    const fd = new FormData();
    fd.append('action', 'submit_utr');
    fd.append('order_id', historyUtrOrderId);
    fd.append('utr', utr);

    fetch('deposit.php', { method: 'POST', body: fd })
    .then(r => r.json())
    .then(data => {
        closeUtrModal();
        if (data.success) { showToast('✓', 'UTR submitted!'); setTimeout(() => location.reload(), 1500); }
        else showToast('✗', data.message || 'Failed!');
    });
}

// ============ UTILS ============
function copyText(text) {
    if (navigator.clipboard) { navigator.clipboard.writeText(text).then(() => showToast('📋', 'Copied!')); }
    else {
        const el = document.createElement('textarea'); el.value = text;
        document.body.appendChild(el); el.select(); document.execCommand('copy');
        document.body.removeChild(el); showToast('📋', 'Copied!');
    }
}
function showToast(icon, msg) {
    document.getElementById('toastIcon').textContent = icon;
    document.getElementById('toastMsg').textContent = msg;
    const t = document.getElementById('toast');
    t.classList.add('show');
    setTimeout(() => t.classList.remove('show'), 2500);
}

document.getElementById('statusSheet').addEventListener('click', e => { if(e.target===document.getElementById('statusSheet')) closeStatusSheet(); });
document.getElementById('calSheet').addEventListener('click', e => { if(e.target===document.getElementById('calSheet')) closeCalSheet(); });
document.getElementById('utrModal').addEventListener('click', e => { if(e.target===document.getElementById('utrModal')) closeUtrModal(); });
</script>
</body>
</html>