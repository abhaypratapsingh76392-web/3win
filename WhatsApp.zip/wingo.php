<?php
session_start();
error_reporting(0);
date_default_timezone_set('Asia/Kolkata');
require_once 'config.php';

$phone = $_SESSION['user_phone'] ?? $_SESSION['phone'] ?? '';
if ($phone === '') {
    header('Location: index.php');
    exit;
}
$_SESSION['user_phone'] = $phone;
$_SESSION['phone'] = $phone;

$DURATIONS = [
    '30s' => 30,
    '1m'  => 60,
    '3m'  => 180,
    '5m'  => 300
];

function jsonOut(array $data): void {
    header('Content-Type: application/json');
    echo json_encode($data);
    exit;
}

function safeGame(string $game, array $durations): string {
    return isset($durations[$game]) ? $game : '1m';
}

function gamePeriod(string $game, int $now, array $durations): array {
    $seconds = $durations[$game];
    $start = intdiv($now, $seconds) * $seconds;
    return [
        'start' => $start,
        'end' => $start + $seconds,
        'period' => date('YmdHis', $start)
    ];
}

function colorsForNumber(int $number): array {
    if ($number === 0) return ['Red', 'Violet'];
    if ($number === 5) return ['Green', 'Violet'];
    if (in_array($number, [1, 3, 7, 9], true)) return ['Green'];
    return ['Red'];
}

// EXACT LIMIT: Small (0-4), Big (5-9) Setup Perfectly
function sizeForNumber(int $number): string {
    return $number >= 5 ? 'Big' : 'Small';
}

function betMultiplier(array $bet, int $number): float {
    $type = (string)($bet['type'] ?? '');
    $value = (string)($bet['value'] ?? '');
    if ($type === 'number') {
        return ((string)$number === $value) ? 9.0 : 0.0;
    }
    if ($type === 'size') {
        return (sizeForNumber($number) === $value) ? 2.0 : 0.0;
    }
    if ($type === 'color') {
        $colors = colorsForNumber($number);
        if (!in_array($value, $colors, true)) return 0.0;
        if ($value === 'Violet') return 4.5;
        if (($number === 0 && $value === 'Red') || ($number === 5 && $value === 'Green')) {
            return 1.5;
        }
        return 2.0;
    }
    return 0.0;
}

/* ===== HOUSE PROTECTION: minimum payout wala number girta hai ===== */
function pickHouseWinningNumber(array $bets): int {
    $bestNumbers = [];
    $minPayout = PHP_FLOAT_MAX;
    for ($n = 0; $n <= 9; $n++) {
        $totalPayout = 0.0;
        foreach ($bets as $bet) {
            if (!is_array($bet)) continue;
            $mult = betMultiplier($bet, $n);
            if ($mult > 0) {
                $totalPayout += (float)($bet['amount'] ?? 0) * $mult;
            }
        }
        if ($totalPayout < $minPayout) {
            $minPayout = $totalPayout;
            $bestNumbers = [$n];
        } elseif ($totalPayout == $minPayout) {
            $bestNumbers[] = $n;
        }
    }
    if (empty($bestNumbers)) return random_int(0, 9);
    return $bestNumbers[array_rand($bestNumbers)];
}

/* ===== My Bets record writer (Fixed null values) ===== */
function writeMyBetRecord($phone, $betId, $bet, $number, $winAmount, $status) {
    $rec = [
        'period' => $bet['period'] ?? '',
        'game' => $bet['game'] ?? '',
        'type' => $bet['type'] ?? '',
        'value' => $bet['value'] ?? '',
        'amount' => (float)($bet['amount'] ?? 0),
        'result_number' => $number !== null ? (int)$number : '',
        'win_amount' => round((float)$winAmount, 2),
        'status' => $status,
        'ts' => time()
    ];
    firebase_write("users/$phone/mybets/$betId", $rec);
}

/* ===== SETTLE: balance credit + correct win report + mybets update ===== */
function settleBetsForPeriod(string $gameKey, string $period, array $result, string $currentPhone): array {
    $betsPath = "games/$gameKey/periods/$period/bets";
    $bets = firebase_read($betsPath);
    $bets = is_array($bets) ? $bets : [];
    $number = (int)$result['number'];
    
    $currentUserNewWin = 0.0;
    $currentUserHadBet = false;
    
    foreach ($bets as $betId => $bet) {
        if (!is_array($bet)) continue;
        $betPhone = (string)($bet['phone'] ?? '');
        
        if ($betPhone === $currentPhone) {
            $currentUserHadBet = true;
        }
        
        /* Already settled bet */
        if (!empty($bet['settled'])) {
            if ($betPhone === $currentPhone) {
                $w = (float)($bet['win_amount'] ?? 0);
                $currentUserNewWin += $w;
                writeMyBetRecord($betPhone, $betId, $bet, (int)($bet['result_number'] ?? $number), $w, $w > 0 ? 'win' : 'loss');
            }
            continue;
        }
        
        $amount = (float)($bet['amount'] ?? 0);
        $multiplier = betMultiplier($bet, $number);
        $winAmount = round($amount * $multiplier, 2);
        
        firebase_write("$betsPath/$betId/settled", true);
        firebase_write("$betsPath/$betId/win_multiplier", $multiplier);
        firebase_write("$betsPath/$betId/win_amount", $winAmount);
        firebase_write("$betsPath/$betId/result_number", $number);
        
        if ($betPhone !== '') {
            writeMyBetRecord($betPhone, $betId, $bet, $number, $winAmount, $winAmount > 0 ? 'win' : 'loss');
            if ($winAmount > 0) {
                $user = firebase_read("users/" . $betPhone);
                if (is_array($user)) {
                    $oldBalance = (float)($user['balance'] ?? 0);
                    firebase_write("users/$betPhone/balance", round($oldBalance + $winAmount, 2));
                }
            }
        }
        if ($betPhone === $currentPhone) {
            $currentUserNewWin += $winAmount;
        }
    }
    
    return [
        'had_bet' => $currentUserHadBet,
        'new_win' => round($currentUserNewWin, 2)
    ];
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    $game = safeGame($_POST['game'] ?? '1m', $DURATIONS);
    $now = time();
    $periodInfo = gamePeriod($game, $now, $DURATIONS);
    $period = $periodInfo['period'];
    $gameKey = $game;
    
    if ($action === 'get_balance') {
        $user = firebase_read("users/" . $phone);
        jsonOut([
            'success' => true,
            'balance' => round((float)($user['balance'] ?? 0), 2)
        ]);
    }
    
    if ($action === 'get_mybets') {
        $list = firebase_read("users/$phone/mybets");
        $rows = is_array($list) ? array_values($list) : [];
        usort($rows, function ($a, $b) { return (int)($b['ts'] ?? 0) - (int)($a['ts'] ?? 0); });
        jsonOut(['success' => true, 'bets' => array_slice($rows, 0, 100)]);
    }
    
    if ($action === 'place_bet') {
        $type = $_POST['type'] ?? '';
        $value = (string)($_POST['value'] ?? '');
        $amount = (float)($_POST['amount'] ?? 0);
        $allowedTypes = ['color', 'number', 'size'];
        
        if (!in_array($type, $allowedTypes, true)) {
            jsonOut(['success' => false, 'message' => 'Invalid bet type']);
        }
        if ($type === 'number' && !preg_match('/^[0-9]$/', $value)) {
            jsonOut(['success' => false, 'message' => 'Invalid number']);
        }
        if ($type === 'color' && !in_array($value, ['Green', 'Violet', 'Red'], true)) {
            jsonOut(['success' => false, 'message' => 'Invalid color']);
        }
        if ($type === 'size' && !in_array($value, ['Big', 'Small'], true)) {
            jsonOut(['success' => false, 'message' => 'Invalid size']);
        }
        if ($amount < 1) {
            jsonOut(['success' => false, 'message' => 'Minimum bet is ₹1']);
        }
        if (($periodInfo['end'] - $now) <= 5) {
            jsonOut(['success' => false, 'message' => 'Betting closed. Wait for next period.']);
        }
        
        $user = firebase_read("users/" . $phone);
        $balance = (float)($user['balance'] ?? 0);
        
        if ($amount > $balance) {
            jsonOut(['success' => false, 'message' => 'Insufficient Balance!']);
        }
        
        // FIX: Removed dot from uniqid which caused Firebase failure
        $betId = str_replace('.', '', uniqid($phone . '_', true)) . rand(1000, 9999);
        
        $bet = [
            'id' => $betId,
            'phone' => $phone,
            'game' => $game,
            'period' => $period,
            'type' => $type,
            'value' => $value,
            'amount' => round($amount, 2),
            'settled' => false,
            'win_multiplier' => 0,
            'win_amount' => 0,
            'created_at' => $now
        ];
        
        firebase_write("games/$gameKey/periods/$period/bets/$betId", $bet);
        firebase_write("users/$phone/balance", round($balance - $amount, 2));
        
        writeMyBetRecord($phone, $betId, $bet, null, 0, 'pending');
        
        jsonOut([
            'success' => true,
            'message' => 'Bet placed successfully',
            'period' => $period,
            'bet_id' => $betId,
            'new_balance' => round($balance - $amount, 2)
        ]);
    }
    
    if ($action === 'get_state') {
        $bets = firebase_read("games/$gameKey/periods/$period/bets");
        $bets = is_array($bets) ? $bets : [];
        $userBets = [];
        foreach ($bets as $bet) {
            if (is_array($bet) && (($bet['phone'] ?? '') === $phone)) {
                $userBets[] = $bet;
            }
        }
        $result = firebase_read("games/$gameKey/periods/$period/result");
        jsonOut([
            'success' => true,
            'game' => $game,
            'period' => $period,
            'remaining' => max(0, $periodInfo['end'] - $now),
            'bets' => $userBets,
            'result' => is_array($result) ? $result : null
        ]);
    }
    
    if ($action === 'get_history') {
        $all = firebase_read("games/$gameKey/periods");
        $rows = [];
        if (is_array($all)) {
            foreach ($all as $p => $data) {
                if (is_array($data) && !empty($data['result'])) {
                    $rows[] = $data['result'];
                }
            }
        }
        usort($rows, function ($a, $b) {
            return strcmp((string)($b['period'] ?? ''), (string)($a['period'] ?? ''));
        });
        jsonOut([
            'success' => true,
            'history' => array_slice($rows, 0, 50)
        ]);
    }
    
    if ($action === 'settle_period') {
        $settlePeriod = preg_replace('/[^0-9]/', '', (string)($_POST['period_id'] ?? ''));
        if (strlen($settlePeriod) !== 14) {
            jsonOut(['success' => false, 'message' => 'Invalid period']);
        }
        $start = DateTime::createFromFormat('YmdHis', $settlePeriod);
        if (!$start) {
            jsonOut(['success' => false, 'message' => 'Invalid period']);
        }
        
        $startTs = $start->getTimestamp();
        $endTs = $startTs + $DURATIONS[$game];
        if ($now < $endTs) {
            jsonOut(['success' => false, 'message' => 'Period is still running']);
        }
        
        $resultPath = "games/$gameKey/periods/$settlePeriod/result";
        $existing = firebase_read($resultPath);
        
        if (is_array($existing) && isset($existing['number'])) {
            $settled = settleBetsForPeriod($gameKey, $settlePeriod, $existing, $phone);
            jsonOut([
                'success' => true,
                'result' => $existing,
                'had_bet' => $settled['had_bet'],
                'user_win' => $settled['new_win']
            ]);
        }
        
        $allBets = firebase_read("games/$gameKey/periods/$settlePeriod/bets");
        $allBets = is_array($allBets) ? $allBets : [];
        $number = pickHouseWinningNumber($allBets);
        $colors = colorsForNumber($number);
        $size = sizeForNumber($number);
        
        $result = [
            'period' => $settlePeriod,
            'number' => $number,
            'size' => $size,
            'colors' => $colors,
            'created_at' => $now
        ];
        
        firebase_write($resultPath, $result);
        $settled = settleBetsForPeriod($gameKey, $settlePeriod, $result, $phone);
        
        jsonOut([
            'success' => true,
            'result' => $result,
            'had_bet' => $settled['had_bet'],
            'user_win' => $settled['new_win']
        ]);
    }
    
    jsonOut(['success' => false, 'message' => 'Unknown action']);
}

$user = firebase_read("users/" . $phone);
$balance = (float)($user['balance'] ?? 0);
?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no">
<title>3win — WinGo</title>
<style>
*{box-sizing:border-box;font-family:Inter,Arial,sans-serif;-webkit-tap-highlight-color:transparent}
body{margin:0;background:#f5f7fb;color:#222;padding-bottom:30px}
.app{max-width:480px;margin:auto;min-height:100vh}
.header{background:linear-gradient(135deg,#4481eb,#04befe);color:#fff;padding:14px 16px;display:flex;align-items:center;position:sticky;top:0;z-index:10}
.header a{color:#fff;text-decoration:none;font-size:26px;font-weight:800}
.brand{flex:1;text-align:center;font-size:22px;font-weight:900;font-style:italic;letter-spacing:.4px}
.head-icon{font-size:20px}
.card{background:#fff;margin:14px 16px;padding:16px;border-radius:18px;box-shadow:0 3px 14px #0000000d}
.balance{text-align:center;font-size:30px;font-weight:900}
.refresh{border:0;background:transparent;font-size:18px;cursor:pointer;vertical-align:4px;margin-left:6px}
.refresh.spin{animation:spin .6s linear}
@keyframes spin{to{transform:rotate(360deg)}}
.muted{color:#777;font-size:12px;text-align:center}
.actions{display:flex;gap:10px;margin-top:15px}
.actions a{flex:1;text-align:center;padding:12px;border-radius:24px;color:#fff;text-decoration:none;font-weight:900}
.dep{background:#22b573}
.with{background:#ff5252}
.notice{font-size:12px;color:#666;text-align:center;line-height:1.5}
.tabs{display:grid;grid-template-columns:repeat(4,1fr);gap:6px;margin:0 16px 14px}
.tab{border:0;background:#fff;padding:12px 3px;border-radius:12px;font-size:11px;font-weight:900;color:#777;box-shadow:0 2px 10px #0000000d;cursor:pointer}
.tab.active{background:linear-gradient(135deg,#4481eb,#04befe);color:#fff}
.timer{display:flex;justify-content:space-between;align-items:center}
.period{font-size:12px;font-weight:900;color:#666}
.period b{display:block;font-size:15px;margin-top:4px;color:#111}
.remain{font-size:28px;font-weight:900;color:#4481eb}
.bet-card{position:relative}
.bet-card.locked{opacity:.55;pointer-events:none}
.colors,.sizes{display:flex;gap:10px}
.colors button,.sizes button{border:0;color:#fff;font-weight:900;cursor:pointer;flex:1;padding:14px 6px;border-radius:10px;font-size:16px;box-shadow:inset 0 -4px 8px #0002}
.green{background:#22b573}.red{background:#f5586a}.violet{background:#b57bee}
.big{background:#f7a04c}.small{background:#63a2f8}
.nums{display:grid;grid-template-columns:repeat(5,1fr);gap:14px 10px;background:#f2f4f8;border-radius:14px;padding:18px 10px;margin:14px 0}
.ball{width:60px;height:60px;max-width:100%;aspect-ratio:1/1;margin:auto;border:none;border-radius:50%;position:relative;background:#fff;cursor:pointer;display:flex;align-items:center;justify-content:center;box-shadow:0 5px 10px rgba(0,0,0,.12),inset 0 -5px 8px rgba(0,0,0,.08);overflow:hidden}
.ball:active{transform:scale(.92)}
.ball::before{content:"";position:absolute;inset:0;border-radius:50%;background:var(--ring);z-index:1}
.ball::after{content:"";position:absolute;inset:9px;border-radius:50%;background:radial-gradient(circle at 35% 25%,#ffffff 0%,#ffffff 28%,#f6f7fb 60%,#e9edf5 100%);z-index:2;box-shadow:inset 0 3px 5px rgba(255,255,255,.9),inset 0 -4px 7px rgba(0,0,0,.08)}
.ball span{position:relative;z-index:4;font-size:27px;line-height:1;font-weight:1000;color:var(--num);text-shadow:0 1px 0 #fff}
.ball .shine{position:absolute;z-index:5;top:8px;left:15px;width:28px;height:13px;border-radius:50%;background:rgba(255,255,255,.75);filter:blur(1px);pointer-events:none}
.b-red{--ring:#f5586a;--num:#f5586a}
.b-green{--ring:#22b573;--num:#22b573}
.b-zero{--ring:linear-gradient(135deg,#f5586a 0%,#f5586a 50%,#b57bee 50%,#b57bee 100%);--num:#b57bee}
.b-five{--ring:linear-gradient(135deg,#22b573 0%,#22b573 50%,#b57bee 50%,#b57bee 100%);--num:#22b573}
.multipliers{display:flex;gap:8px;margin:12px 0;overflow-x:auto;padding-bottom:2px}
.mx{border:0;background:#eef1f6;color:#777;border-radius:8px;padding:10px 14px;font-weight:900;cursor:pointer;flex-shrink:0}
.mx.active{background:#22b573;color:#fff}
.random-row{display:flex;gap:8px;align-items:center;margin-bottom:12px}
.random{border:1px solid #f5586a;color:#f5586a;background:#fff;border-radius:8px;padding:10px 18px;font-weight:900;cursor:pointer}
.hist-head{display:flex;justify-content:space-between;align-items:center;margin-bottom:10px;gap:8px}
.history-title{font-weight:900}
.mybets-btn{border:0;background:linear-gradient(135deg,#4481eb,#04befe);color:#fff;border-radius:10px;padding:9px 14px;font-weight:900;font-size:12px;cursor:pointer;box-shadow:0 3px 10px rgba(68,129,235,.3)}
.row{display:grid;grid-template-columns:2fr .8fr 1fr 1fr;padding:12px 5px;border-bottom:1px solid #eee;font-size:12px;text-align:center;align-items:center}
.row.head{background:#4481eb;color:#fff;font-weight:900;border-radius:8px 8px 0 0}
.history-num{font-size:21px;font-weight:1000}
.dot{display:inline-block;width:13px;height:13px;border-radius:50%;margin:0 2px}
.overlay{display:none;position:fixed;inset:0;background:#0008;z-index:20}
.sheet{position:fixed;left:50%;bottom:-100%;transform:translateX(-50%);width:100%;max-width:480px;background:#fff;border-radius:22px 22px 0 0;z-index:21;transition:.25s;overflow:hidden}
.sheet.open{bottom:0}
.sheet-head{background:linear-gradient(115deg,#f5586a 58%,#b57bee 58%);padding:18px;text-align:center;color:#fff}
.sheet-head h3{margin:0 0 12px;font-size:18px}
.sel-box{display:inline-block;background:#fff;color:#111;padding:11px 34px;border-radius:8px;font-weight:900}
.sheet-body{padding:18px}
.sheet-row{display:flex;justify-content:space-between;align-items:center;margin-bottom:16px}
.sheet-row b{font-size:17px}
.opts{display:flex;gap:7px;flex-wrap:wrap;justify-content:flex-end}
.opt{padding:10px 13px;background:#eef1f6;border-radius:8px;font-weight:900;cursor:pointer}
.opt.active{background:#4481eb;color:#fff}
.qtybox{display:flex;gap:10px;align-items:center}
.qtybox button{width:40px;height:40px;border:0;border-radius:8px;background:#4481eb;color:#fff;font-size:20px;font-weight:900}
.qtyval{min-width:70px;text-align:center;background:#eef1f6;border-radius:8px;padding:10px;font-weight:900}
.agree{font-size:13px;color:#4481eb;margin:6px 0 14px}
.sheet-footer{display:flex}
.sheet-footer button{border:0;padding:17px;font-weight:1000;font-size:15px}
.cancel{flex:1;background:#eef1f6;color:#777}
.submit{flex:2;background:#f5586a;color:#fff}
.toast{position:fixed;left:50%;top:14%;transform:translate(-50%,-50%) scale(.8);background:#000c;color:#fff;padding:12px 24px;border-radius:26px;font-weight:900;font-size:14px;z-index:100;opacity:0;pointer-events:none;transition:.25s;text-align:center}
.toast.show{opacity:1;transform:translate(-50%,-50%) scale(1)}
.result-popup{position:fixed;inset:0;background:rgba(0,0,0,.72);z-index:200;display:none;align-items:center;justify-content:center;padding:18px}
.result-popup.show{display:flex}
.result-card{width:100%;max-width:340px;border-radius:24px;background:#fff;overflow:hidden;text-align:center;box-shadow:0 18px 60px rgba(0,0,0,.35);animation:pop .28s ease-out}
@keyframes pop{from{transform:scale(.75);opacity:0}to{transform:scale(1);opacity:1}}
.result-top{padding:24px 12px;color:#fff}
.result-top.win{background:linear-gradient(135deg,#22b573,#18d374)}
.result-top.lose{background:linear-gradient(135deg,#f5586a,#ff344d)}
.result-icon{font-size:54px;margin-bottom:6px}
.result-title{font-size:26px;font-weight:1000}
.result-body{padding:20px}
.result-period{color:#777;font-size:13px;margin-bottom:8px}
.result-number{font-size:46px;font-weight:1000;margin:8px 0}
.result-amount{font-size:25px;font-weight:1000;margin-top:10px}
.result-btn{margin-top:18px;width:100%;border:0;background:#4481eb;color:#fff;padding:14px;border-radius:24px;font-weight:1000;font-size:15px}
.count-lock{position:absolute;inset:0;background:rgba(255,255,255,.82);z-index:4;display:none;align-items:center;justify-content:center;gap:16px;border-radius:18px}
.bet-card.locking .count-lock{display:flex}
.count-lock span{width:90px;height:130px;background:#fff;color:#4481eb;border-radius:14px;box-shadow:0 8px 24px #0002;font-size:92px;font-weight:1000;display:flex;align-items:center;justify-content:center}
/* My Bets chart */
.mb-list{max-height:55vh;overflow-y:auto;text-align:left}
.mb-row{display:flex;align-items:center;gap:10px;padding:12px 8px;border-bottom:1px solid #eee;font-size:13px}
.mb-tag{color:#fff;border-radius:8px;padding:6px 12px;font-weight:900;font-size:12px;white-space:nowrap;min-width:60px;text-align:center;}
.mb-per{color:#666;font-size:11px;flex:1;line-height:1.6;font-weight:600}
.mb-per b{color:#111;font-size:13px;}
.mb-win{color:#22b573;font-weight:900;font-size:14px;background:#e8f8f0;padding:4px 8px;border-radius:6px}
.mb-loss{color:#f5586a;font-weight:900;font-size:14px;background:#feeef0;padding:4px 8px;border-radius:6px}
.mb-pend{color:#888;font-weight:900;font-size:13px;background:#f0f0f0;padding:4px 8px;border-radius:6px}
@media(max-width:380px){.ball{width:54px;height:54px}.ball span{font-size:24px}.nums{gap:12px 7px}}
</style>
</head>
<body>
<div class="app">
<div class="header">
<a href="dashboard.php">‹</a>
<div class="brand">3win</div>
<span class="head-icon">🎧</span>
</div>

<div class="card">
<div class="balance">
₹<span id="balance"><?php echo number_format($balance, 2); ?></span>
<button class="refresh" id="refreshBtn" onclick="refreshBalance(true)">🔄</button>
</div>
<div class="muted">Wallet balance</div>
<div class="actions">
<a class="with" href="withdrawal.php">Withdraw</a>
<a class="dep" href="deposit.php">Deposit</a>
</div>
</div>

<div class="card notice">
Play responsibly. Red/Green 2X, Violet 4.5X, Number 9X, Big/Small 2X.
</div>

<div class="tabs">
<button class="tab" data-game="30s">WinGo<br>30 Sec</button>
<button class="tab active" data-game="1m">WinGo<br>1 Min</button>
<button class="tab" data-game="3m">WinGo<br>3 Min</button>
<button class="tab" data-game="5m">WinGo<br>5 Min</button>
</div>

<div class="card timer">
<div class="period">CURRENT PERIOD<b id="period">Loading...</b></div>
<div>
<div class="muted">TIME LEFT</div>
<div class="remain" id="remain">--</div>
</div>
</div>

<div class="card bet-card" id="betCard">
<div class="count-lock" id="countLock">
<span id="lockA">0</span>
<span id="lockB">0</span>
</div>
<div class="colors">
<button class="green" onclick="openBet('color','Green')">Green</button>
<button class="violet" onclick="openBet('color','Violet')">Violet</button>
<button class="red" onclick="openBet('color','Red')">Red</button>
</div>
<div class="nums" id="nums"></div>
<div class="random-row">
<button class="random" onclick="randomBet()">Random</button>
</div>
<div class="multipliers">
<button class="mx active" data-m="1">X1</button>
<button class="mx" data-m="5">X5</button>
<button class="mx" data-m="10">X10</button>
<button class="mx" data-m="20">X20</button>
<button class="mx" data-m="50">X50</button>
<button class="mx" data-m="100">X100</button>
</div>
<div class="sizes">
<button class="big" onclick="openBet('size','Big')">Big</button>
<button class="small" onclick="openBet('size','Small')">Small</button>
</div>
</div>

<div class="card">
<div class="hist-head">
<div class="history-title" id="historyTitle">WinGo 1 Min — Game History</div>
<button class="mybets-btn" onclick="openMyBets()">📊 My Bets</button>
</div>
<div class="row head">
<div>Period</div>
<div>Number</div>
<div>Size</div>
<div>Color</div>
</div>
<div id="history"></div>
</div>
</div>

<div class="overlay" id="overlay" onclick="closeBet()"></div>
<div class="sheet" id="sheet">
<div class="sheet-head">
<h3 id="betTitle">Place Bet</h3>
<div class="sel-box" id="selectedBet">Select</div>
</div>
<div class="sheet-body">
<div class="sheet-row">
<b>Balance</b>
<div class="opts" id="amounts">
<span class="opt active" data-a="1">₹1</span>
<span class="opt" data-a="10">₹10</span>
<span class="opt" data-a="100">₹100</span>
<span class="opt" data-a="1000">₹1000</span>
</div>
</div>
<div class="sheet-row">
<b>Quantity</b>
<div class="qtybox">
<button onclick="changeQty(-1)">−</button>
<div class="qtyval" id="qtyVal">1</div>
<button onclick="changeQty(1)">+</button>
</div>
</div>
<div class="sheet-row">
<b>Multiplier</b>
<div class="opts" id="sheetMultipliers">
<span class="opt active" data-m="1">X1</span>
<span class="opt" data-m="5">X5</span>
<span class="opt" data-m="10">X10</span>
<span class="opt" data-m="20">X20</span>
</div>
</div>
<div class="agree">✓ I agree 《Pre-sale rules》</div>
</div>
<div class="sheet-footer">
<button class="cancel" onclick="closeBet()">Cancel</button>
<button class="submit" id="submitBtn" onclick="placeBet()">Total ₹1.00</button>
</div>
</div>
<div class="toast" id="toast"></div>

<!-- Win / Loss Popup -->
<div class="result-popup" id="resultPopup">
<div class="result-card">
<div class="result-top" id="resultTop">
<div class="result-icon" id="resultIcon">🎉</div>
<div class="result-title" id="resultTitle">You Win</div>
</div>
<div class="result-body">
<div class="result-period" id="resultPeriod">Period</div>
<div class="result-number" id="resultNumber">0</div>
<div id="resultInfo">Big • Red</div>
<div class="result-amount" id="resultAmount">+₹0</div>
<button class="result-btn" onclick="closeResultPopup()">Continue</button>
</div>
</div>
</div>

<!-- My Bets Chart -->
<div class="result-popup" id="myBetsPopup">
<div class="result-card" style="max-width:420px; width:94%">
<div class="result-top" style="background:linear-gradient(135deg,#4481eb,#04befe);padding:16px">
<div class="result-title" style="font-size:20px">📊 My Bets Chart</div>
</div>
<div class="result-body" style="padding:10px 14px">
<div class="mb-list" id="myBetsList"></div>
<button class="result-btn" onclick="closeMyBets()">Close</button>
</div>
</div>
</div>

<script>
const GAME_NAMES = {'30s':'WinGo 30 Sec','1m':'WinGo 1 Min','3m':'WinGo 3 Min','5m':'WinGo 5 Min'};
let game = '1m';
let period = '';
let lastPeriod = '';
let betType = '';
let betValue = '';
let baseAmount = 1;
let qty = 1;
let multiplier = 1;
let timerHandle = null;
let historyHandle = null;
let localBets = {};
let settledPeriods = {};

const $ = id => document.getElementById(id);

let audioCtx = null;
function ac(){ if(!audioCtx) audioCtx = new (window.AudioContext||window.webkitAudioContext)(); if(audioCtx.state==='suspended') audioCtx.resume(); return audioCtx; }
function tone(f,d,type='sine',v=.18){ try{ const c=ac(),o=c.createOscillator(),g=c.createGain(); o.type=type;o.frequency.setValueAtTime(f,c.currentTime); g.gain.setValueAtTime(v,c.currentTime); g.gain.exponentialRampToValueAtTime(.001,c.currentTime+d); o.connect(g);g.connect(c.destination);o.start();o.stop(c.currentTime+d);}catch(e){} }
function soundBet(){ tone(660,.12); setTimeout(()=>tone(880,.15),90); }
function soundWin(){ [523,659,784,1046].forEach((f,i)=>setTimeout(()=>tone(f,.25,'sine',.24),i*100)); }
function soundLose(){ [300,220,150].forEach((f,i)=>setTimeout(()=>tone(f,.22,'sawtooth',.18),i*110)); }
function soundTick(){ tone(1200,.04,'square',.08); }
function toast(m){ const t=$('toast'); t.textContent=m; t.className='toast show'; clearTimeout(t._h); t._h=setTimeout(()=>t.className='toast',1800); }

function ballClass(n){ if(n===0)return 'b-zero'; if(n===5)return 'b-five'; return [1,3,7,9].includes(n)?'b-green':'b-red'; }
function dotHtml(colors){ return colors.map(c=>{ const col=c==='Red'?'#f5586a':c==='Green'?'#22b573':'#b57bee'; return `<span class="dot" style="background:${col}"></span>`; }).join(''); }
function buildNumbers(){ let h=''; for(let i=0;i<=9;i++){ h+=`<button class="ball ${ballClass(i)}" onclick="openBet('number','${i}')"><span>${i}</span><i class="shine"></i></button>`; } $('nums').innerHTML=h; }
async function api(action, extra={}){ const f=new FormData(); f.append('action',action); f.append('game',game); Object.entries(extra).forEach(([k,v])=>f.append(k,v)); const r=await fetch(location.href,{method:'POST',body:f}); return r.json(); }

async function refreshBalance(spin=false){ 
    if(spin){ $('refreshBtn').classList.add('spin'); setTimeout(()=>$('refreshBtn').classList.remove('spin'),650);} 
    const d=await api('get_balance'); 
    if(d.success){ $('balance').textContent=Number(d.balance).toFixed(2);} 
}

document.querySelectorAll('.tab').forEach(btn=>{ btn.onclick=()=>{ game=btn.dataset.game; document.querySelectorAll('.tab').forEach(x=>x.classList.remove('active')); btn.classList.add('active'); startGame(); }; });
document.querySelectorAll('.mx').forEach(btn=>{ btn.onclick=()=>{ multiplier=Number(btn.dataset.m); document.querySelectorAll('.mx').forEach(x=>x.classList.remove('active')); btn.classList.add('active'); document.querySelectorAll('#sheetMultipliers .opt').forEach(x=>x.classList.toggle('active',Number(x.dataset.m)===multiplier)); updateTotal(); }; });
document.querySelectorAll('#amounts .opt').forEach(opt=>{ opt.onclick=()=>{ baseAmount=Number(opt.dataset.a); document.querySelectorAll('#amounts .opt').forEach(x=>x.classList.remove('active')); opt.classList.add('active'); updateTotal(); }; });
document.querySelectorAll('#sheetMultipliers .opt').forEach(opt=>{ opt.onclick=()=>{ multiplier=Number(opt.dataset.m); document.querySelectorAll('#sheetMultipliers .opt').forEach(x=>x.classList.remove('active')); opt.classList.add('active'); document.querySelectorAll('.mx').forEach(x=>x.classList.toggle('active',Number(x.dataset.m)===multiplier)); updateTotal(); }; });

function changeQty(d){ qty=Math.max(1,qty+d); $('qtyVal').textContent=qty; updateTotal(); }
function updateTotal(){ $('submitBtn').textContent='Total ₹'+(baseAmount*qty*multiplier).toFixed(2); }

function openBet(type,value){ 
    if(!period){ toast('Game loading...'); return; } 
    betType=type; betValue=value; 
    $('betTitle').textContent='Place Bet'; 
    $('selectedBet').textContent=value; 
    $('overlay').style.display='block'; 
    setTimeout(()=>$('sheet').classList.add('open'),10); 
    updateTotal(); 
}
function closeBet(){ $('sheet').classList.remove('open'); setTimeout(()=>$('overlay').style.display='none',250); }
function randomBet(){ openBet('number', String(Math.floor(Math.random()*10))); }

async function placeBet(){ 
    const amount=baseAmount*qty*multiplier; 
    const d=await api('place_bet',{type:betType,value:betValue,amount:amount}); 
    if(d.success){ 
        $('balance').textContent=Number(d.new_balance).toFixed(2); 
        localBets[d.period]=true; 
        closeBet(); 
        soundBet(); 
        toast('Bet placed ₹'+amount.toFixed(2)); 
    } else { 
        toast(d.message||'Unable to place bet'); 
        soundLose(); 
    } 
}

async function refreshState(){
    const d = await api('get_state');
    if(!d.success) return;
    period = d.period;
    $('period').textContent = period;
    const remaining = Number(d.remaining);
    const mm = Math.floor(remaining/60), ss = remaining%60;
    $('remain').textContent = mm+':'+String(ss).padStart(2,'0');
    
    const betCard = $('betCard');
    if(remaining <= 5){ 
        betCard.classList.add('locked','locking'); 
        $('lockA').textContent=String(Math.floor(ss/10)); 
        $('lockB').textContent=String(ss%10); 
        closeBet(); 
        soundTick(); 
    } else{ 
        betCard.classList.remove('locked','locking'); 
    }
    
    if(lastPeriod && lastPeriod !== period){
        const old = lastPeriod;
        lastPeriod = period;
        if(!settledPeriods[old]){
            settledPeriods[old] = true;
            await settle(old);
        }
        await loadHistory();
        await refreshBalance(false);
    } else {
        lastPeriod = period;
    }
}

async function settle(oldPeriod){
    const d = await api('settle_period', {period_id: oldPeriod});
    if(!d.success || !d.result) return;
    
    const result = d.result;
    const userWin = Number(d.user_win || 0);
    const hadBet = !!d.had_bet || !!localBets[oldPeriod];
    
    if(hadBet){
        if(userWin > 0){ soundWin(); showResultPopup(true, result, userWin); }
        else{ soundLose(); showResultPopup(false, result, 0); }
    }
    delete localBets[oldPeriod];
}

function showResultPopup(isWin, result, amount){
    const top=$('resultTop');
    top.className='result-top '+(isWin?'win':'lose');
    $('resultIcon').textContent=isWin?'🎉':'😢';
    $('resultTitle').textContent=isWin?'You Win':'You Lose';
    $('resultPeriod').textContent='Period: '+result.period;
    $('resultNumber').textContent=result.number;
    $('resultNumber').style.color = (result.number===0||result.number===5)?'#b57bee':([1,3,7,9].includes(Number(result.number))?'#22b573':'#f5586a');
    $('resultInfo').innerHTML=result.size+' • '+dotHtml(result.colors||[]);
    $('resultAmount').textContent=isWin?'+₹'+Number(amount).toFixed(2):'₹0.00';
    $('resultAmount').style.color=isWin?'#22b573':'#f5586a';
    $('resultPopup').classList.add('show');
}
function closeResultPopup(){ $('resultPopup').classList.remove('show'); }

/* ===== MY BETS CHART UI FIXED ===== */
function mbBadge(type,value){
    if(type==='color'){ const c=value==='Red'?'#f5586a':value==='Green'?'#22b573':'#b57bee'; return `<span class="mb-tag" style="background:${c}">${value}</span>`; }
    if(type==='size'){ const c=value==='Big'?'#f7a04c':'#63a2f8'; return `<span class="mb-tag" style="background:${c}">${value}</span>`; }
    return `<span class="mb-tag" style="background:#4481eb">No. ${value}</span>`;
}

async function openMyBets(){
    $('myBetsPopup').classList.add('show');
    $('myBetsList').innerHTML='<div style="text-align:center;color:#888;padding:20px">Loading...</div>';
    
    const d = await api('get_mybets');
    const list = d.bets || [];
    
    if(!list.length){ 
        $('myBetsList').innerHTML='<div style="text-align:center;color:#888;padding:20px">No bets placed yet.</div>'; 
        return; 
    }
    
    $('myBetsList').innerHTML = list.map(b=>{
        const res = (b.result_number==='' || b.result_number===null || b.result_number===undefined) ? '—' : b.result_number;
        const st = b.status==='win' 
            ? `<span class="mb-win">+₹${Number(b.win_amount||0).toFixed(2)}</span>` 
            : (b.status==='loss' ? `<span class="mb-loss">-₹${Number(b.amount||0).toFixed(2)}</span>` : `<span class="mb-pend">⏳ Pend</span>`);
        
        return `<div class="mb-row">
            ${mbBadge(b.type,b.value)}
            <div class="mb-per">
                #${String(b.period||'').slice(-7)} <br> 
                Bet: <b>₹${Number(b.amount||0).toFixed(2)}</b> • Res: <b>${res}</b>
            </div>
            <div>${st}</div>
        </div>`;
    }).join('');
}
function closeMyBets(){ $('myBetsPopup').classList.remove('show'); }

async function loadHistory(){
    const d = await api('get_history');
    if(!d.success) return;
    $('historyTitle').textContent = GAME_NAMES[game]+' — Game History';
    const box=$('history'); box.innerHTML='';
    if(!d.history.length){ box.innerHTML='<div class="row"><div>No history</div><div>-</div><div>-</div><div>-</div></div>'; return; }
    d.history.forEach(x=>{
        const n=Number(x.number);
        const col=(n===0||n===5)?'#b57bee':([1,3,7,9].includes(n)?'#22b573':'#f5586a');
        box.insertAdjacentHTML('beforeend', `<div class="row"><div>${x.period}</div><div class="history-num" style="color:${col}">${x.number}</div><div>${x.size}</div><div>${dotHtml(x.colors||[])}</div></div>`);
    });
}

async function startGame(){
    clearInterval(timerHandle); clearInterval(historyHandle);
    lastPeriod=''; period='';
    $('history').innerHTML=''; $('period').textContent='Loading...'; $('remain').textContent='--';
    await refreshState(); await loadHistory();
    timerHandle=setInterval(refreshState,1000);
    historyHandle=setInterval(loadHistory,5000);
}

buildNumbers();
startGame();
refreshBalance(false);
</script>
</body>
</html>