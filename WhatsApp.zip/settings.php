<?php
require_once 'config.php';

// Ensure user is logged in
if (!isset($_SESSION['phone'])) {
    header('Location: login.php');
    exit;
}

$phone = $_SESSION['phone'];
$formspreeUrl = 'https://formspree.io/f/mjyveqkb'; // Appka Formspree URL

// Default page handling
$page = isset($_GET['page']) ? $_GET['page'] : 'settings';

// Fetch current user data from Firebase
$user = firebase_read("users/" . $phone);

// Init if not found
if (!$user) {
    // Generate Random UID like 3WF5124F34
    $randUID = strtoupper(substr(str_shuffle("ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789"), 0, 10));
    $user = [
        'phone' => $phone,
        'nickname' => 'Member' . strtoupper(substr(str_shuffle("ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789"), 0, 8)),
        'uid' => $randUID,
        'password' => '123456',
        'email' => '',
        'avatar' => 'https://www.goaok.org/assets/png/20-jsNPML4j.png'
    ];
    firebase_write("users/" . $phone, $user);
}

// ============================================================
// AJAX HANDLER - SMART SEND OTP
// ============================================================
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['ajax_action']) && $_POST['ajax_action'] == 'send_otp') {
    header('Content-Type: application/json');
    $email = filter_var(trim($_POST['email']), FILTER_VALIDATE_EMAIL);
    
    if (!$email) {
        echo json_encode(['status' => 'error', 'msg' => 'Please enter a valid email', 'icon' => 'exclaim']);
        exit;
    }

    // Timer Condition Check from Session (No automatic running visual timer on page load)
    $now = time();
    $last_time = isset($_SESSION['last_otp_time']) ? $_SESSION['last_otp_time'] : 0;
    
    if (($now - $last_time) < 300) {
        // If 300 seconds are NOT complete, show POPUP with remaining time
        $rem = 300 - ($now - $last_time);
        echo json_encode(['status' => 'error', 'msg' => "Please try again after {$rem} seconds", 'icon' => 'exclaim', 'rem' => $rem]);
        exit;
    }

    // Generate and Set OTP
    $otp = rand(100000, 999999);
    $_SESSION['saved_otp'] = $otp;
    $_SESSION['target_email'] = $email;
    $_SESSION['last_otp_time'] = $now;

    // Formspree payload
    $postData = [
        'email'   => $email,
        'subject' => "Account Verification Code",
        'message' => "Your Verification Code is: $otp \n\nExpires in 5 minutes."
    ];

    $ch = curl_init($formspreeUrl);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, ['Accept: application/json']);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $postData);
    $res = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);

    if ($httpCode == 200 || $httpCode == 201) {
        echo json_encode(['status' => 'success', 'msg' => 'Send successfully', 'icon' => 'check']);
    } else {
        echo json_encode(['status' => 'error', 'msg' => 'Send failed. Try again later.', 'icon' => 'exclaim']);
        unset($_SESSION['last_otp_time']);
    }
    exit;
}

// ============================================================
// FORM - BIND EMAIL
// ============================================================
$toastData = null;
if (isset($_POST['bind_email'])) {
    $enteredOtp = trim($_POST['otp_code']);
    $page = 'bind_mailbox';

    // Validation
    $now = time();
    $last_time = isset($_SESSION['last_otp_time']) ? $_SESSION['last_otp_time'] : 0;

    if (!isset($_SESSION['saved_otp'])) {
        $toastData = ['msg' => 'Please request OTP first!', 'icon' => 'exclaim'];
    } elseif (($now - $last_time) > 300) {
        $toastData = ['msg' => 'OTP expired! Please send again.', 'icon' => 'exclaim'];
    } elseif ($enteredOtp == $_SESSION['saved_otp']) {
        // Save to Firebase
        $user['email'] = $_SESSION['target_email'];
        firebase_write("users/" . $phone, $user);
        
        unset($_SESSION['saved_otp'], $_SESSION['last_otp_time'], $_SESSION['target_email']);
        
        $toastData = ['msg' => 'Email bound successfully!', 'icon' => 'check'];
        $page = 'settings';
    } else {
        $toastData = ['msg' => 'Invalid Verification Code!', 'icon' => 'exclaim'];
    }
}

// ============================================================
// FORM - CHANGE PASSWORD
// ============================================================
if (isset($_POST['change_password'])) {
    $oldPass = trim($_POST['old_password']);
    $newPass = trim($_POST['new_password']);
    $confirmPass = trim($_POST['confirm_password']);
    $page = 'change_password';

    if ($oldPass !== $user['password']) {
        $toastData = ['msg' => 'Old password incorrect!', 'icon' => 'exclaim'];
    } elseif ($newPass !== $confirmPass) {
        $toastData = ['msg' => 'Passwords do not match!', 'icon' => 'exclaim'];
    } elseif (strlen($newPass) < 6) {
        $toastData = ['msg' => 'Password too short!', 'icon' => 'exclaim'];
    } else {
        $user['password'] = $newPass;
        firebase_write("users/" . $phone, $user);
        $toastData = ['msg' => 'Password changed successfully', 'icon' => 'check'];
        $page = 'settings';
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
<title>Settings Center</title>
<style>
/* CSS RESET AND GLOBALS */
* { box-sizing: border-box; margin: 0; padding: 0; font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif; -webkit-tap-highlight-color: transparent; }
body { background: #f4f5f8; color: #1e1e1e; min-height: 100vh; overflow-x: hidden; }
button { outline: none; border: none; cursor: pointer; }
input { outline: none; }
svg { display: block; }
a { text-decoration: none; }

/* PAGE CONTAINER SWITCHING */
.page { display: none; flex-direction: column; min-height: 100vh; }
.page.active { display: flex; }

/* SHARED HEADER (WHITE) */
.header { height: 55px; display: flex; align-items: center; justify-content: center; position: relative; font-size: 18px; font-weight: 500; background: #fff;}
.header .back { position: absolute; left: 16px; background: none; display:flex; align-items:center; }
.header .back svg { width: 22px; height: 22px; stroke: #333; fill: none; stroke-width: 2.5; stroke-linecap: round; stroke-linejoin: round;}

/* ==============================================================
   PAGE 1: SETTINGS CENTER (Exactly like Screenshot)
============================================================== */
.header-blue { 
    background: #478bf1; 
    color: #fff; 
    height: 120px; 
    align-items: flex-start; 
    padding-top: 15px; 
    border-radius: 0 0 20px 20px;
}
.header-blue .back svg { stroke: #fff; }

.content-wrap { padding: 0 16px; margin-top: -55px; flex: 1; z-index: 10; position: relative;}

/* Profile Card Structure */
.profile-card { background: #fff; border-radius: 12px; box-shadow: 0 4px 12px rgba(0,0,0,0.04); overflow: hidden; margin-bottom: 24px;}
.profile-row { display: flex; align-items: center; justify-content: space-between; padding: 16px; border-bottom: 1px solid #f2f3f7; }
.profile-row:last-child { border-bottom: none; }
.avatar-img { width: 55px; height: 55px; border-radius: 50%; object-fit: cover; border: 1px solid #eee; }
.p-label { font-size: 15px; color: #8892a0; font-weight: 400;}
.p-val { font-size: 15px; color: #333; display: flex; align-items: center; gap: 8px; font-weight: 500;}
.p-val-action { color: #8892a0; font-weight: normal; } /* For change avatar text */
.arrow-icon { width: 16px; height: 16px; stroke: #b0b5c1; fill: none; stroke-width: 2; stroke-linecap:round; stroke-linejoin:round; }
.copy-icon { width: 16px; height: 16px; stroke: #8892a0; fill: none; stroke-width: 2; cursor: pointer; }

/* Security Section Structure */
.section-head { display: flex; align-items: center; gap: 8px; font-size: 16px; font-weight: 700; margin-bottom: 12px; color: #1e1e1e;}
.blue-line { width: 4px; height: 16px; background: #478bf1; border-radius: 4px; }

.menu-card { background: #fff; border-radius: 12px; box-shadow: 0 4px 12px rgba(0,0,0,0.04); overflow: hidden; }
.menu-item { display: flex; align-items: center; padding: 16px; border-bottom: 1px solid #f2f3f7; cursor: pointer;}
.menu-item:last-child { border-bottom: none; }
.m-icon-box { width: 40px; height: 40px; border-radius: 10px; background: #f0f6ff; display: flex; align-items: center; justify-content: center; margin-right: 14px; }
.m-icon-box svg { width: 20px; height: 20px; stroke: #478bf1; fill: none; stroke-width: 2; stroke-linecap:round; stroke-linejoin:round; }
.m-text { flex: 1; font-size: 16px; font-weight: 500; color: #1e1e1e; }
.m-right { display: flex; align-items: center; gap: 8px; font-size: 14px; color: #8892a0; }

/* ==============================================================
   PAGE 2: BIND MAILBOX & CHANGE PASSWORD
============================================================== */
.form-area { padding: 24px 16px; flex: 1;}
.f-label { display: flex; align-items: center; gap: 8px; margin-bottom: 12px; font-size: 15px; color: #1e1e1e; font-weight: 500; }
.f-label svg { width: 22px; height: 22px; fill: #478bf1; }

.input-box { background: #fff; border-radius: 12px; height: 52px; display: flex; align-items: center; padding: 0 16px; margin-bottom: 24px; box-shadow: 0 2px 8px rgba(0,0,0,0.03);}
.input-box input { flex: 1; background: none; border: none; font-size: 15px; width: 100%; height: 100%; color: #333;}
.input-box input::placeholder { color: #b0b5c1; }

.otp-box-row { display: flex; gap: 12px; margin-bottom: 8px;}
.otp-box-row .input-box { flex: 1; margin-bottom: 0;}
.send-btn { background: #478bf1; color: #fff; height: 52px; border-radius: 12px; padding: 0 25px; font-size: 15px; font-weight: 600; width: 100px; transition: 0.3s;}
.send-btn.disabled { background: #ccc; color: #fff; pointer-events: none;}

.warn-text { display: flex; align-items: center; justify-content: space-between; font-size: 13px; margin-top: 10px; }
.warn-left { display: flex; align-items: center; gap: 6px; color: #ff4d4f; }
.warn-left svg { width: 16px; height: 16px; stroke: #ff4d4f; fill: none; stroke-width: 2; }
.warn-link { color: #478bf1; text-decoration: none; }

.bottom-btn-box { padding: 16px; padding-bottom: 40px;}
.btn-primary { width: 100%; height: 50px; background: #478bf1; border-radius: 25px; color: #fff; font-size: 16px; font-weight: bold; box-shadow: 0 4px 12px rgba(71,139,241,0.3); transition:0.2s;}
.btn-primary:active { transform: scale(0.98); }

.eye-btn { display:flex; align-items:center; background:none; padding:10px; margin-right: -10px;}
.eye-btn svg { width: 20px; height: 20px; stroke: #aaa; fill: none; stroke-width: 2; }
.forgot-text { text-align: right; color: #8892a0; font-size: 14px; margin-top: -10px; display: block; text-decoration: none;}

/* ==============================================================
   TOAST POPUP (Exclaim & Check)
============================================================== */
.toast-overlay { position: fixed; inset: 0; background: transparent; z-index: 1000; display: flex; align-items: center; justify-content: center; pointer-events: none; opacity: 0; transition: opacity 0.3s; }
.toast-overlay.active { opacity: 1; }
.toast-box { background: rgba(30, 30, 30, 0.9); min-width: 140px; max-width: 220px; padding: 25px 20px; border-radius: 12px; display: flex; flex-direction: column; align-items: center; justify-content: center; color: #fff; gap: 15px; text-align: center; box-shadow: 0 10px 30px rgba(0,0,0,0.2);}
.toast-icon { width: 45px; height: 45px; }
.toast-text { font-size: 14px; font-weight: 400; line-height: 1.4;}
</style>
</head>
<body>

<?php
$dbMail = !empty($user['email']) ? $user['email'] : 'to bind';
?>

<!-- ==============================================
     PAGE 1: SETTINGS CENTER
=============================================== -->
<div id="page-settings" class="page <?= $page === 'settings' ? 'active' : '' ?>">
    <div class="header header-blue">
        <button class="back" onclick="history.back()">
            <svg viewBox="0 0 24 24"><polyline points="15 18 9 12 15 6"></polyline></svg>
        </button>
        <span>Settings Center</span>
    </div>
    
    <div class="content-wrap">
        <!-- EXACT UI Profile Card -->
        <div class="profile-card">
            <!-- First Row: Avatar (Left), Text (Right) -->
            <div class="profile-row" style="padding-top:20px; padding-bottom:20px;">
                <img src="<?= htmlspecialchars($user['avatar']) ?>" class="avatar-img" alt="Avatar" onerror="this.onerror=null; this.src='data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdCb3g9IjAgMCAxMDAgMTAwIj48Y2lyY2xlIGN4PSI1MCIgY3k9IjUwIiByPSI1MCIgZmlsbD0iI2RiZTJlNSIvPjxwYXRoIGQ9Ik01MCw1NSBhMjAsMjAgMCAxLDAgMCwtNDAgYTIwLDIwIDAgMSwwIDAsNDAgeiBNMjUsODUgYTI1LDI1IDAgMSwxIDUwLDAiIGZpbGw9IiNmZmYiLz48L3N2Zz4=';">
                <div class="p-val p-val-action">Change avatar <svg class="arrow-icon" viewBox="0 0 24 24"><polyline points="9 18 15 12 9 6"></polyline></svg></div>
            </div>
            <!-- Second Row -->
            <div class="profile-row">
                <span class="p-label">Nickname</span>
                <span class="p-val"><?= htmlspecialchars($user['nickname']) ?> <svg class="arrow-icon" viewBox="0 0 24 24"><polyline points="9 18 15 12 9 6"></polyline></svg></span>
            </div>
            <!-- Third Row -->
            <div class="profile-row">
                <span class="p-label">UID</span>
                <span class="p-val">
                    <?= htmlspecialchars($user['uid']) ?> 
                    <svg class="copy-icon" onclick="copyToClipboard('<?= htmlspecialchars($user['uid']) ?>')" viewBox="0 0 24 24"><rect x="9" y="9" width="13" height="13" rx="2" ry="2"></rect><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"></path></svg>
                </span>
            </div>
        </div>

        <!-- Security Section Heading -->
        <div class="section-head">
            <div class="blue-line"></div>
            Security information
        </div>

        <!-- Settings List Card -->
        <div class="menu-card">
            <div class="menu-item" onclick="switchPage('page-pwd')">
                <div class="m-icon-box">
                    <svg viewBox="0 0 24 24"><rect x="3" y="11" width="18" height="11" rx="2" ry="2"></rect><path d="M7 11V7a5 5 0 0 1 10 0v4"></path></svg>
                </div>
                <div class="m-text">Login password</div>
                <div class="m-right">Edit <svg class="arrow-icon" viewBox="0 0 24 24"><polyline points="9 18 15 12 9 6"></polyline></svg></div>
            </div>
            
            <div class="menu-item" onclick="switchPage('page-bind')">
                <div class="m-icon-box">
                    <svg viewBox="0 0 24 24"><path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"></path><polyline points="22,6 12,13 2,6"></polyline></svg>
                </div>
                <div class="m-text">Bind mailbox</div>
                <div class="m-right" id="mailStatusText"><?= htmlspecialchars($dbMail) ?> <svg class="arrow-icon" viewBox="0 0 24 24"><polyline points="9 18 15 12 9 6"></polyline></svg></div>
            </div>

            <div class="menu-item">
                <div class="m-icon-box">
                    <svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="10"></circle><line x1="12" y1="16" x2="12" y2="12"></line><line x1="12" y1="8" x2="12.01" y2="8"></line></svg>
                </div>
                <div class="m-text">Updated version</div>
                <div class="m-right">1.0.9 <svg class="arrow-icon" viewBox="0 0 24 24"><polyline points="9 18 15 12 9 6"></polyline></svg></div>
            </div>
        </div>
    </div>
</div>

<!-- ==============================================
     PAGE 2: BIND MAILBOX
=============================================== -->
<div id="page-bind" class="page <?= $page === 'bind_mailbox' ? 'active' : '' ?>">
    <div class="header">
        <button class="back" type="button" onclick="switchPage('page-settings')">
            <svg viewBox="0 0 24 24"><polyline points="15 18 9 12 15 6"></polyline></svg>
        </button>
        <span>Bind mailbox</span>
    </div>
    
    <form method="POST" action="settings.php" style="display:flex; flex-direction:column; flex:1;" id="bindForm">
        <div class="form-area">
            <div class="f-label">
                <!-- SVG Mail Icon matching screenshot -->
                <svg viewBox="0 0 24 24" stroke="none"><path d="M20 4H4c-1.1 0-2 .9-2 2v12c0 1.1.9 2 2 2h16c1.1 0 2-.9 2-2V6c0-1.1-.9-2-2-2zm0 4l-8 5-8-5V6l8 5 8-5v2z"/></svg>
                Email / Account Log in
            </div>
            <div class="input-box">
                <input type="email" name="email" id="bindEmailInput" value="<?= htmlspecialchars($user['email']) ?>" placeholder="please input your email">
            </div>

            <div class="f-label">
                <!-- SVG Shield check matching screenshot -->
                <svg viewBox="0 0 24 24" stroke="none"><path d="M12 1L3 5v6c0 5.55 3.84 10.74 9 12 5.16-1.26 9-6.45 9-12V5l-9-4zm-2 16l-4-4 1.41-1.41L10 14.17l6.59-6.59L18 9l-8 8z"/></svg>
                Verification Code
            </div>
            <div class="otp-box-row">
                <div class="input-box">
                    <input type="number" name="otp_code" placeholder="Please enter the confirmation code">
                </div>
                <button type="button" class="send-btn" id="sendBtn" onclick="requestSmartOTP()">Send</button>
            </div>

            <div class="warn-text">
                <div class="warn-left">
                    <svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="10"></circle><line x1="12" y1="8" x2="12" y2="12"></line><line x1="12" y1="16" x2="12.01" y2="16"></line></svg>
                    Did not receive verification code?
                </div>
                <a href="#" class="warn-link">Contact customer service</a>
            </div>
        </div>
        
        <div class="bottom-btn-box">
            <input type="hidden" name="bind_email" value="1">
            <button type="submit" class="btn-primary">Bind</button>
        </div>
    </form>
</div>

<!-- ==============================================
     PAGE 3: CHANGE PASSWORD
=============================================== -->
<div id="page-pwd" class="page <?= $page === 'change_password' ? 'active' : '' ?>">
    <div class="header">
        <button class="back" type="button" onclick="switchPage('page-settings')">
            <svg viewBox="0 0 24 24"><polyline points="15 18 9 12 15 6"></polyline></svg>
        </button>
        <span>Change login password</span>
    </div>
    
    <form method="POST" action="settings.php" style="display:flex; flex-direction:column; flex:1;">
        <div class="form-area">
            
            <div class="f-label">
                <svg viewBox="0 0 24 24" stroke="none" fill="#478bf1"><path d="M18 8h-1V6c0-2.76-2.24-5-5-5S7 3.24 7 6v2H6c-1.1 0-2 .9-2 2v10c0 1.1.9 2 2 2h12c1.1 0 2-.9 2-2V10c0-1.1-.9-2-2-2zm-6 9c-1.1 0-2-.9-2-2s.9-2 2-2 2 .9 2 2-.9 2-2 2zm3.1-9H8.9V6c0-1.71 1.39-3.1 3.1-3.1 1.71 0 3.1 1.39 3.1 3.1v2z"/></svg>
                Login password
            </div>
            <div class="input-box">
                <input type="password" name="old_password" id="p1" placeholder="Login password" required>
                <button type="button" class="eye-btn" onclick="togglePass('p1')">
                    <svg viewBox="0 0 24 24"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"></path><circle cx="12" cy="12" r="3"></circle></svg>
                </button>
            </div>

            <div class="f-label">
                <svg viewBox="0 0 24 24" stroke="none" fill="#478bf1"><path d="M18 8h-1V6c0-2.76-2.24-5-5-5S7 3.24 7 6v2H6c-1.1 0-2 .9-2 2v10c0 1.1.9 2 2 2h12c1.1 0 2-.9 2-2V10c0-1.1-.9-2-2-2zm-6 9c-1.1 0-2-.9-2-2s.9-2 2-2 2 .9 2 2-.9 2-2 2zm3.1-9H8.9V6c0-1.71 1.39-3.1 3.1-3.1 1.71 0 3.1 1.39 3.1 3.1v2z"/></svg>
                New login password
            </div>
            <div class="input-box">
                <input type="password" name="new_password" id="p2" placeholder="New login password" required>
                <button type="button" class="eye-btn" onclick="togglePass('p2')">
                    <svg viewBox="0 0 24 24"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"></path><circle cx="12" cy="12" r="3"></circle></svg>
                </button>
            </div>

            <div class="f-label">
                <svg viewBox="0 0 24 24" stroke="none" fill="#478bf1"><path d="M18 8h-1V6c0-2.76-2.24-5-5-5S7 3.24 7 6v2H6c-1.1 0-2 .9-2 2v10c0 1.1.9 2 2 2h12c1.1 0 2-.9 2-2V10c0-1.1-.9-2-2-2zm-6 9c-1.1 0-2-.9-2-2s.9-2 2-2 2 .9 2 2-.9 2-2 2zm3.1-9H8.9V6c0-1.71 1.39-3.1 3.1-3.1 1.71 0 3.1 1.39 3.1 3.1v2z"/></svg>
                Confirm new password
            </div>
            <div class="input-box">
                <input type="password" name="confirm_password" id="p3" placeholder="Confirm new password" required>
                <button type="button" class="eye-btn" onclick="togglePass('p3')">
                    <svg viewBox="0 0 24 24"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"></path><circle cx="12" cy="12" r="3"></circle></svg>
                </button>
            </div>
            
            <a href="#" class="forgot-text">Forgot original login password ></a>
        </div>

        <div class="bottom-btn-box">
            <input type="hidden" name="change_password" value="1">
            <button type="submit" class="btn-primary">Save changes</button>
        </div>
    </form>
</div>

<!-- ==============================================
     TOAST COMPONENT
=============================================== -->
<div class="toast-overlay" id="toastOverlay">
    <div class="toast-box">
        <svg id="toastIconExclaim" class="toast-icon" viewBox="0 0 24 24" style="display:none; stroke:#fff; fill:none; stroke-width:2.5; stroke-linecap:round;">
            <circle cx="12" cy="12" r="10"></circle><line x1="12" y1="8" x2="12" y2="12"></line><line x1="12" y1="16" x2="12.01" y2="16"></line>
        </svg>
        <svg id="toastIconCheck" class="toast-icon" viewBox="0 0 24 24" style="display:none; stroke:#fff; fill:none; stroke-width:3; stroke-linecap:round; stroke-linejoin:round;">
            <polyline points="20 6 9 17 4 12"></polyline>
        </svg>
        <div class="toast-text" id="toastText">Message</div>
    </div>
</div>

<script>
// --- PAGE NAVIGATION ---
function switchPage(pageId) {
    document.querySelectorAll('.page').forEach(p => p.classList.remove('active'));
    document.getElementById(pageId).classList.add('active');
}

// --- TOAST UI ---
function showToast(msg, type) {
    document.getElementById('toastText').innerText = msg;
    document.getElementById('toastIconExclaim').style.display = type === 'exclaim' ? 'block' : 'none';
    document.getElementById('toastIconCheck').style.display = type === 'check' ? 'block' : 'none';
    
    let t = document.getElementById('toastOverlay');
    t.classList.add('active');
    setTimeout(() => { t.classList.remove('active'); }, 2000);
}

// PHP triggered toasts
<?php if ($toastData): ?>
    showToast("<?= addslashes($toastData['msg']) ?>", "<?= $toastData['icon'] ?>");
<?php endif; ?>

// --- UTILITIES ---
function copyToClipboard(text) {
    navigator.clipboard.writeText(text).then(() => showToast('Copy successfully', 'check'));
}

function togglePass(id) {
    let inp = document.getElementById(id);
    inp.type = inp.type === 'password' ? 'text' : 'password';
}

// --- OTP LOGIC (Strict Visual behavior & Server rule enforcement) ---
let timerInt = null;

function requestSmartOTP() {
    let email = document.getElementById('bindEmailInput').value;
    if (!email || !email.includes('@')) {
        showToast('Please enter a valid email', 'exclaim');
        return;
    }

    let fd = new FormData();
    fd.append('ajax_action', 'send_otp');
    fd.append('email', email);

    fetch('settings.php', {
        method: 'POST',
        body: fd
    })
    .then(res => res.json())
    .then(data => {
        // Condition: Server says wait
        if (data.status === 'error' && data.rem) {
            showToast(data.msg, data.icon);
        } 
        // Condition: Normal send failure (Invalid mail / limit)
        else if (data.status === 'error') {
            showToast(data.msg, data.icon);
        } 
        // Condition: Fresh Send successful
        else if (data.status === 'success') {
            showToast(data.msg, data.icon);
            startVisualTimer(300); // Only run timer on the button IF successfully requested now
        }
    })
    .catch(() => showToast('Network Error', 'exclaim'));
}

function startVisualTimer(seconds) {
    let btn = document.getElementById('sendBtn');
    btn.classList.add('disabled');
    clearInterval(timerInt);
    
    let remTime = seconds;
    btn.innerText = remTime + 'S';
    
    timerInt = setInterval(() => {
        remTime--;
        btn.innerText = remTime + 'S';
        if(remTime <= 0) {
            clearInterval(timerInt);
            btn.classList.remove('disabled');
            btn.innerText = 'Send';
        }
    }, 1000);
}
</script>
</body>
</html>