<?php
session_start();
require_once 'config.php';

if (!isset($_SESSION['user_phone'])) {
    header('Location: index.php');
    exit;
}

$phone = $_SESSION['user_phone'];
$userData = firebase_read("users/" . $phone);
$balance = $userData['balance'] ?? 0;

// ========== AJAX HANDLERS ==========
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    header('Content-Type: application/json');
    $action = $_POST['action'];

    // 1. START GAME (Deduct Bet)
    if ($action === 'start_game') {
        $bet = (float)($_POST['bet'] ?? 0);
        $mines = (int)($_POST['mines'] ?? 1);

        if ($bet < 10) {
            echo json_encode(['success' => false, 'msg' => 'Minimum bet is ₹10']); exit;
        }
        if ($balance < $bet) {
            echo json_encode(['success' => false, 'msg' => 'Insufficient balance!']); exit;
        }

        // Deduct balance
        $new_balance = $balance - $bet;
        firebase_write("users/" . $phone . "/balance", $new_balance);

        // Generate a unique Game ID
        $game_id = "3.760" . rand(100000, 999999);

        echo json_encode([
            'success' => true, 
            'balance' => $new_balance,
            'game_id' => $game_id
        ]);
        exit;
    }

    // 2. CASH OUT (Add Winnings)
    if ($action === 'cash_out') {
        $win_amount = (float)($_POST['win_amount'] ?? 0);

        if ($win_amount > 0) {
            $new_balance = $balance + $win_amount;
            firebase_write("users/" . $phone . "/balance", $new_balance);
            
            echo json_encode(['success' => true, 'balance' => $new_balance]);
        } else {
            echo json_encode(['success' => false, 'msg' => 'Invalid win amount']);
        }
        exit;
    }
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
<title>Mines Game</title>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800;900&display=swap" rel="stylesheet">
<link href="https://fonts.googleapis.com/icon?family=Material+Icons+Round" rel="stylesheet">
<style>
    * { margin: 0; padding: 0; box-sizing: border-box; font-family: 'Inter', sans-serif; -webkit-tap-highlight-color: transparent; user-select: none; }
    body { background-color: #0052cc; color: white; overflow: hidden; height: 100vh; display: flex; flex-direction: column; }
    
    /* Top Header */
    .top-header { display: flex; justify-content: space-between; align-items: center; padding: 10px 16px; background: #0a0f1c; z-index: 10; flex: 0 0 auto; }
    .back-btn { color: white; text-decoration: none; display: flex; align-items: center; font-size: 24px; }
    .balance-pill { background: #1a243d; border: 1px solid #2a3b5c; border-radius: 20px; padding: 4px 16px 4px 4px; display: flex; align-items: center; gap: 8px; }
    .coin-icon { width: 24px; height: 24px; background: radial-gradient(circle, #ffca28, #f57c00); border-radius: 50%; border: 2px solid #fff; display: flex; align-items: center; justify-content: center; font-size: 12px; font-weight: bold; color: white; }
    .bal-amt { font-size: 15px; font-weight: 800; letter-spacing: 0.5px; }
    .header-actions { display: flex; gap: 10px; }
    .icon-btn { width: 32px; height: 32px; background: #1a243d; border-radius: 50%; display: flex; align-items: center; justify-content: center; color: #8ba4c7; font-size: 20px; border: 1px solid #2a3b5c; }
    .icon-btn.globe { background: #ff9800; color: white; border: none; }

    /* Main Game Area */
    .game-container { flex: 1 1 auto; background: #0052cc; display: flex; flex-direction: column; padding: 12px 16px; position: relative; min-height: 0; }
    
    .title { text-align: center; font-size: 20px; font-weight: 900; letter-spacing: 1px; margin-bottom: 10px; text-shadow: 0 2px 4px rgba(0,0,0,0.2); flex: 0 0 auto; }

    /* Info Bar */
    .info-bar { display: flex; justify-content: space-between; align-items: center; margin-bottom: 10px; border-bottom: 1px solid #0047b3; padding-bottom: 8px; flex: 0 0 auto; }
    .game-id { color: #80b3ff; font-size: 13px; font-weight: 600; display: flex; align-items: center; gap: 5px; }
    .game-id span { color: #fff; }
    .next-win { background: #ffb300; color: #000; padding: 4px 14px; border-radius: 20px; font-size: 13px; font-weight: 800; box-shadow: 0 2px 5px rgba(0,0,0,0.2); }

    /* Mines Grid */
    .grid-wrapper { flex: 1 1 auto; display: flex; align-items: center; justify-content: center; margin-bottom: 10px; min-height: 0; }
    .mines-grid { display: grid; grid-template-columns: repeat(5, 1fr); gap: 6px; width: 100%; max-width: 340px; aspect-ratio: 1; margin: 0 auto; }
    
    .box { background: #003d99; border-radius: 8px; box-shadow: 0 4px 0 #002966; display: flex; align-items: center; justify-content: center; cursor: pointer; transition: transform 0.1s, box-shadow 0.1s; position: relative; }
    .box::after { content: ''; width: 8px; height: 8px; background: #005ce6; border-radius: 50%; }
    .box:active { transform: translateY(4px); box-shadow: 0 0 0 #002966; }
    
    /* Box States */
    .box.opened { transform: translateY(4px); box-shadow: 0 0 0 transparent; cursor: default; }
    .box.opened::after { display: none; }
    
    .box.star { background: linear-gradient(180deg, #ffb300, #ff8f00); box-shadow: 0 4px 0 #c66900; animation: pop 0.3s cubic-bezier(0.175, 0.885, 0.32, 1.275); }
    .box.star.opened { box-shadow: 0 0 0 transparent; }
    .box.star::before { content: '⭐'; font-size: 24px; filter: drop-shadow(0 2px 2px rgba(0,0,0,0.2)); }
    
    .box.mine { background: #1e293b; box-shadow: 0 4px 0 #0f172a; animation: shake 0.4s; }
    .box.mine.opened { box-shadow: 0 0 0 transparent; }
    .box.mine::before { content: '💣'; font-size: 24px; }
    .box.mine.blast { background: #ef4444; box-shadow: 0 4px 0 #991b1b; }

    @keyframes pop { 0% { transform: scale(0.5); opacity: 0; } 100% { transform: scale(1); opacity: 1; } }
    @keyframes shake { 0%, 100% { transform: translateX(0); } 25% { transform: translateX(-4px); } 75% { transform: translateX(4px); } }

    /* Controls Area (Fixed for small screens) */
    .controls { background: #0047b3; border-radius: 16px; padding: 12px; box-shadow: 0 -4px 15px rgba(0,0,0,0.1); flex: 0 0 auto; z-index: 5; }
    
    .top-controls { display: flex; justify-content: space-between; align-items: center; margin-bottom: 10px; gap: 6px; }
    .btn-random { background: #005ce6; border: 1px solid #0073ff; color: white; padding: 8px 14px; border-radius: 20px; font-size: 12px; font-weight: 700; cursor: pointer; white-space: nowrap; }
    
    /* Auto Game Toggle - Improved Design */
    .auto-toggle { display: flex; align-items: center; gap: 6px; font-size: 12px; font-weight: 600; color: #fff; white-space: nowrap; }
    .switch { position: relative; display: inline-block; width: 38px; height: 22px; }
    .switch input { opacity: 0; width: 0; height: 0; }
    .slider { position: absolute; cursor: pointer; top: 0; left: 0; right: 0; bottom: 0; background-color: #002966; transition: .3s; border-radius: 22px; border: 1px solid #003d99; }
    .slider:before { position: absolute; content: ""; height: 16px; width: 16px; left: 2px; bottom: 2px; background-color: #80b3ff; transition: .3s; border-radius: 50%; }
    input:checked + .slider { background-color: #00e676; border-color: #00e676; }
    input:checked + .slider:before { transform: translateX(16px); background-color: white; }

    .mines-select { background: #002966; border: 1px solid #003d99; color: white; padding: 8px 12px; border-radius: 20px; font-size: 12px; font-weight: 700; appearance: none; outline: none; cursor: pointer; }

    /* Bet Input Area */
    .bet-area { background: #003d99; border-radius: 12px; padding: 8px 12px; margin-bottom: 10px; }
    .bet-input-row { display: flex; align-items: center; justify-content: space-between; }
    .bet-label-col { display: flex; flex-direction: column; }
    .bet-label { font-size: 11px; color: #80b3ff; margin-bottom: 2px; }
    .bet-input { background: transparent; border: none; color: white; font-size: 16px; font-weight: 800; outline: none; width: 100px; }
    
    .bet-actions { display: flex; gap: 6px; }
    .b-act { width: 32px; height: 32px; background: #005ce6; border-radius: 50%; display: flex; align-items: center; justify-content: center; font-weight: bold; font-size: 16px; box-shadow: 0 2px 0 #002966; cursor: pointer; border: 1px solid #0073ff; }
    .b-act:active { transform: translateY(2px); box-shadow: 0 0 0 transparent; }

    /* Action Buttons */
    .action-row { display: flex; gap: 10px; }
    .refresh-btn { width: 44px; height: 44px; background: #005ce6; border-radius: 50%; display: flex; align-items: center; justify-content: center; border: 1px solid #0073ff; box-shadow: 0 4px 0 #002966; cursor: pointer; flex-shrink: 0; }
    .refresh-btn:active { transform: translateY(4px); box-shadow: 0 0 0 transparent; }
    
    .main-btn { flex: 1; border: none; border-radius: 25px; font-size: 16px; font-weight: 900; color: white; text-shadow: 0 1px 2px rgba(0,0,0,0.3); cursor: pointer; transition: 0.1s; display: flex; align-items: center; justify-content: center; gap: 8px; height: 44px; }
    .main-btn:active { transform: translateY(4px); }
    
    .btn-bet { background: linear-gradient(180deg, #66bb6a, #2e7d32); box-shadow: 0 6px 0 #1b5e20; }
    .btn-bet:active { box-shadow: 0 0 0 transparent; }
    
    .btn-cashout { background: linear-gradient(180deg, #ffca28, #f57c00); box-shadow: 0 6px 0 #e65100; display: none; }
    .btn-cashout:active { box-shadow: 0 0 0 transparent; }

    /* Footer */
    .footer { background: #0047b3; padding: 10px 16px; display: flex; justify-content: space-between; align-items: center; border-top: 1px solid #003d99; flex: 0 0 auto; }
    .f-icon { width: 28px; height: 28px; background: #ff9800; border-radius: 50%; display: flex; align-items: center; justify-content: center; font-weight: bold; color: #fff; font-size: 16px; }
    .f-amt { font-size: 15px; font-weight: 800; }
    .f-menu { color: #fff; background: #003d99; width: 28px; height: 28px; border-radius: 50%; display: flex; align-items: center; justify-content: center; }

    /* Toast */
    .toast { position: fixed; top: 20%; left: 50%; transform: translate(-50%, -50%) scale(0.8); background: rgba(0,0,0,0.8); padding: 10px 20px; border-radius: 20px; font-weight: bold; opacity: 0; pointer-events: none; transition: 0.2s; z-index: 100; }
    .toast.show { opacity: 1; transform: translate(-50%, -50%) scale(1); }
</style>
</head>
<body>

<!-- Header -->
<div class="top-header">
    <a href="dashboard.php" class="back-btn"><span class="material-icons-round">chevron_left</span></a>
    <div class="balance-pill">
        <div class="coin-icon">₹</div>
        <span class="bal-amt" id="topBal"><?= number_format($balance, 2) ?></span>
    </div>
    <div class="header-actions">
        <div class="icon-btn"><span class="material-icons-round">add</span></div>
        <div class="icon-btn globe"><span class="material-icons-round">language</span></div>
    </div>
</div>

<!-- Game Area -->
<div class="game-container">
    <div class="title">MINES</div>
    
    <div class="info-bar">
        <div class="game-id">Game ID: <span id="gameIdTxt">Wait...</span> <span class="material-icons-round" style="font-size:16px;">arrow_drop_down</span></div>
        <div class="next-win" id="nextWinPill">Next: 10.10 INR</div>
    </div>

    <div class="grid-wrapper">
        <div class="mines-grid" id="grid">
            <!-- 25 Boxes generated by JS -->
        </div>
    </div>

    <!-- Controls -->
    <div class="controls">
        <div class="top-controls">
            <div class="btn-random">RANDOM</div>
            
            <div class="auto-toggle" id="autoToggleDiv">
                <label class="switch">
                    <input type="checkbox" id="autoGame">
                    <span class="slider"></span>
                </label>
                Auto Game
            </div>

            <select class="mines-select" id="mineCount" onchange="updateMultiplier()">
                <!-- Options 1 to 20 generated by JS -->
            </select>
        </div>

        <div class="bet-area">
            <div class="bet-input-row">
                <div class="bet-label-col">
                    <span class="bet-label">Bet</span>
                    <input type="number" class="bet-input" id="betAmount" value="10.00">
                </div>
                <div class="bet-actions">
                    <div class="b-act" onclick="adjBet(0.5)">-</div>
                    <div class="b-act" id="midBtn" onclick="adjBet('stack')"><span class="material-icons-round" style="font-size:18px;">layers</span></div>
                    <div class="b-act" onclick="adjBet(2)">+</div>
                </div>
            </div>
        </div>

        <div class="action-row">
            <div class="refresh-btn"><span class="material-icons-round">autorenew</span></div>
            <button class="main-btn btn-bet" id="btnBet" onclick="startGame()">
                <span class="material-icons-round">play_arrow</span> BET
            </button>
            <button class="main-btn btn-cashout" id="btnCashout" onclick="cashOut()">
                💰 CASH OUT <span id="cashoutAmt">₹0.00</span>
            </button>
        </div>
    </div>
</div>

<!-- Footer -->
<div class="footer">
    <div class="f-icon">?</div>
    <div class="f-amt" id="bottomAmt">0 INR</div>
    <div class="f-menu"><span class="material-icons-round">menu</span></div>
</div>

<div class="toast" id="toast"></div>

<script>
// --- GAME STATE ---
let balance = <?= (float)$balance ?>;
let isPlaying = false;
let currentBet = 10;
let mines = 1;
let openedBoxes = 0;
let currentMultiplier = 1.00;
let boardData = []; 

const grid = document.getElementById('grid');
const btnBet = document.getElementById('btnBet');
const btnCashout = document.getElementById('btnCashout');
const nextWinPill = document.getElementById('nextWinPill');
const cashoutAmtTxt = document.getElementById('cashoutAmt');
const betInput = document.getElementById('betAmount');
const mineSelect = document.getElementById('mineCount');
const midBtn = document.getElementById('midBtn');
const autoToggleDiv = document.getElementById('autoToggleDiv');

// Populate Mines Dropdown (1 to 20)
for(let i=1; i<=20; i++) {
    let opt = document.createElement('option');
    opt.value = i;
    opt.textContent = `Mines: ${i}`;
    mineSelect.appendChild(opt);
}

// Initialize Grid UI
function initGrid() {
    grid.innerHTML = '';
    for (let i = 0; i < 25; i++) {
        let box = document.createElement('div');
        box.className = 'box';
        box.id = 'box-' + i;
        box.onclick = () => openBox(i);
        grid.appendChild(box);
    }
}
initGrid();

function showToast(msg) {
    const t = document.getElementById('toast');
    t.textContent = msg;
    t.classList.add('show');
    setTimeout(() => t.classList.remove('show'), 2000);
}

function updateBalUI() {
    document.getElementById('topBal').textContent = balance.toFixed(2);
}

function adjBet(action) {
    if(isPlaying) return;
    let val = parseFloat(betInput.value);
    if(action === 2) val += 10; // + button
    else if(action === 0.5) val -= 10; // - button
    else if(action === 'stack') val *= 2; // Stack/2x button
    
    if(val < 10) val = 10;
    betInput.value = val.toFixed(2);
    updateMultiplier();
}

// Multiplier Logic
function getNextMultiplier() {
    let remainingSafe = 25 - mines - openedBoxes;
    let totalRemaining = 25 - openedBoxes;
    if (remainingSafe <= 0) return currentMultiplier;
    let stepMult = totalRemaining / remainingSafe;
    return currentMultiplier * (stepMult * 0.97); 
}

function updateMultiplier() {
    if(!isPlaying) {
        mines = parseInt(mineSelect.value);
        currentBet = parseFloat(betInput.value);
        currentMultiplier = 1.00;
        let nextM = getNextMultiplier();
        nextWinPill.textContent = `Next: ${(currentBet * nextM).toFixed(2)} INR`;
    }
}
updateMultiplier();

// --- CORE GAMEPLAY (LAG-FREE) ---

function startGame() {
    if (isPlaying) return;
    currentBet = parseFloat(betInput.value);
    mines = parseInt(mineSelect.value);

    if (currentBet < 10) return showToast("Min bet ₹10");
    if (balance < currentBet) return showToast("Low Balance!");

    btnBet.innerHTML = "Loading...";
    
    const fd = new URLSearchParams();
    fd.append('action', 'start_game');
    fd.append('bet', currentBet);
    fd.append('mines', mines);

    fetch(window.location.href, { method: 'POST', body: fd })
    .then(res => res.json())
    .then(data => {
        if (data.success) {
            balance = data.balance;
            updateBalUI();
            document.getElementById('gameIdTxt').textContent = data.game_id;
            
            generateLocalBoard();
            
            isPlaying = true;
            openedBoxes = 0;
            currentMultiplier = 1.00;
            
            for(let i=0; i<25; i++) {
                let b = document.getElementById('box-'+i);
                b.className = 'box';
                b.style.opacity = '1';
            }

            mineSelect.disabled = true;
            betInput.disabled = true;
            
            // UI Changes for Playing State
            btnBet.style.display = 'none';
            btnCashout.style.display = 'flex';
            cashoutAmtTxt.textContent = `₹${currentBet.toFixed(2)}`;
            
            // Change Stack icon to 2x
            midBtn.innerHTML = '<span style="font-size:14px; font-weight:900;">2x</span>';
            midBtn.onclick = () => adjBet('stack');
            
            // Hide Auto Game toggle to match screenshot 2
            autoToggleDiv.style.display = 'none';
            
            updateMultiplier();
        } else {
            showToast(data.msg);
            btnBet.innerHTML = `<span class="material-icons-round">play_arrow</span> BET`;
        }
    }).catch(err => {
        showToast("Network Error");
        btnBet.innerHTML = `<span class="material-icons-round">play_arrow</span> BET`;
    });
}

function generateLocalBoard() {
    boardData = Array(25).fill('star');
    let minesPlaced = 0;
    while(minesPlaced < mines) {
        let randIdx = Math.floor(Math.random() * 25);
        if(boardData[randIdx] !== 'mine') {
            boardData[randIdx] = 'mine';
            minesPlaced++;
        }
    }
}

function openBox(index) {
    if (!isPlaying) return;
    let box = document.getElementById('box-' + index);
    if (box.classList.contains('opened')) return; 

    box.classList.add('opened');

    if (boardData[index] === 'star') {
        box.classList.add('star');
        openedBoxes++;
        
        currentMultiplier = getNextMultiplier();
        let currentWin = currentBet * currentMultiplier;
        
        cashoutAmtTxt.textContent = `₹${currentWin.toFixed(2)}`;
        document.getElementById('bottomAmt').textContent = `${currentWin.toFixed(2)} INR`;
        
        let nextM = getNextMultiplier();
        nextWinPill.textContent = `Next: ${(currentBet * nextM).toFixed(2)} INR`;

        if (openedBoxes === (25 - mines)) {
            cashOut();
        }

    } else {
        box.classList.add('mine', 'blast');
        revealAll();
        endGame(false);
    }
}

function revealAll() {
    for(let i=0; i<25; i++) {
        let b = document.getElementById('box-'+i);
        if(!b.classList.contains('opened')) {
            b.classList.add('opened');
            if(boardData[i] === 'mine') {
                b.classList.add('mine');
                b.style.opacity = '0.5'; 
            } else {
                b.classList.add('star');
                b.style.opacity = '0.5'; 
            }
        }
    }
}

function cashOut() {
    if (!isPlaying || openedBoxes === 0) return;
    
    let winAmount = currentBet * currentMultiplier;
    btnCashout.innerHTML = "Processing...";

    const fd = new URLSearchParams();
    fd.append('action', 'cash_out');
    fd.append('win_amount', winAmount);

    fetch(window.location.href, { method: 'POST', body: fd })
    .then(res => res.json())
    .then(data => {
        if(data.success) {
            balance = data.balance;
            updateBalUI();
            showToast(`Cashed out ₹${winAmount.toFixed(2)}!`);
            revealAll();
            endGame(true);
        }
    });
}

function endGame(won) {
    isPlaying = false;
    mineSelect.disabled = false;
    betInput.disabled = false;
    
    setTimeout(() => {
        btnCashout.style.display = 'none';
        btnBet.style.display = 'flex';
        btnBet.innerHTML = `<span class="material-icons-round">play_arrow</span> BET`;
        
        // Restore UI to Idle State
        midBtn.innerHTML = '<span class="material-icons-round" style="font-size:18px;">layers</span>';
        autoToggleDiv.style.display = 'flex';
        
        updateMultiplier();
    }, 1500); 
}

</script>
</body>
</html>