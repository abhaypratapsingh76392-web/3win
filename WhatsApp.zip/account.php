<?php
declare(strict_types=1);

session_start();

require_once __DIR__ . '/config.php';

if (!isset($_SESSION['user_phone']) || empty($_SESSION['user_phone'])) {
    header('Location: index.php');
    exit;
}

$phone = (string) $_SESSION['user_phone'];

/*
|--------------------------------------------------------------------------
| Firebase config adapter
|--------------------------------------------------------------------------
| config.php ko change nahi kiya gaya.
|--------------------------------------------------------------------------
*/

function acc_config_value(
    array $constantNames,
    array $variableNames
): string {
    foreach ($constantNames as $name) {
        if (defined($name) && constant($name) !== '') {
            return (string) constant($name);
        }
    }

    foreach ($variableNames as $name) {
        if (
            isset($GLOBALS[$name]) &&
            $GLOBALS[$name] !== ''
        ) {
            return (string) $GLOBALS[$name];
        }
    }

    return '';
}

$firebaseUrl = rtrim(
    acc_config_value(
        [
            'FIREBASE_DATABASE_URL',
            'FIREBASE_URL',
            'DATABASE_URL'
        ],
        [
            'firebase_database_url',
            'firebase_url',
            'database_url',
            'databaseURL',
            'firebaseDatabaseUrl',
            'databaseUrl'
        ]
    ),
    '/'
);

$firebaseToken = acc_config_value(
    [
        'FIREBASE_DATABASE_SECRET',
        'FIREBASE_AUTH_TOKEN',
        'FIREBASE_ID_TOKEN',
        'DATABASE_SECRET'
    ],
    [
        'firebase_database_secret',
        'firebase_secret',
        'firebase_token',
        'firebase_auth_token',
        'database_secret',
        'database_token'
    ]
);

/*
|--------------------------------------------------------------------------
| Firebase functions
|--------------------------------------------------------------------------
*/

function acc_db_key(string $value): string
{
    return str_replace(
        ['.', '#', '$', '[', ']', '/'],
        '_',
        trim($value)
    );
}

function acc_db_path(string $value): string
{
    return rawurlencode(acc_db_key($value));
}

function acc_firebase_request(
    string $path,
    string $method = 'GET',
    $data = null
) {
    global $firebaseUrl, $firebaseToken;

    if ($firebaseUrl === '') {
        return null;
    }

    $path = trim($path, '/');

    $url = $firebaseUrl . '/';

    if ($path !== '') {
        $url .= $path . '/';
    }

    $url .= '.json';

    if ($firebaseToken !== '') {
        $url .= '?auth=' . rawurlencode($firebaseToken);
    }

    if (!function_exists('curl_init')) {
        return null;
    }

    $curl = curl_init($url);

    curl_setopt_array($curl, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_CUSTOMREQUEST => strtoupper($method),
        CURLOPT_CONNECTTIMEOUT => 10,
        CURLOPT_TIMEOUT => 20,
        CURLOPT_HTTPHEADER => [
            'Content-Type: application/json'
        ]
    ]);

    if ($data !== null) {
        curl_setopt(
            $curl,
            CURLOPT_POSTFIELDS,
            json_encode(
                $data,
                JSON_UNESCAPED_UNICODE |
                JSON_UNESCAPED_SLASHES
            )
        );
    }

    $response = curl_exec($curl);
    $httpCode = (int) curl_getinfo(
        $curl,
        CURLINFO_HTTP_CODE
    );

    curl_close($curl);

    if (
        $response === false ||
        $httpCode < 200 ||
        $httpCode >= 300
    ) {
        return null;
    }

    if (
        $response === '' ||
        $response === 'null'
    ) {
        return null;
    }

    return json_decode($response, true);
}

function acc_firebase_get(string $path)
{
    return acc_firebase_request($path, 'GET');
}

function acc_firebase_put(string $path, $data)
{
    return acc_firebase_request($path, 'PUT', $data);
}

/*
|--------------------------------------------------------------------------
| Helper functions
|--------------------------------------------------------------------------
*/

function acc_escape($value): string
{
    return htmlspecialchars(
        (string) $value,
        ENT_QUOTES,
        'UTF-8'
    );
}

function acc_field(
    array $data,
    array $keys,
    $default = null
) {
    foreach ($keys as $key) {
        if (array_key_exists($key, $data)) {
            return $data[$key];
        }
    }

    return $default;
}

function acc_number($value): float
{
    if ($value === null || $value === '') {
        return 0;
    }

    $value = str_replace(
        ['₹', ',', ' '],
        '',
        (string) $value
    );

    return (float) $value;
}

function acc_money($value): string
{
    return '₹' . number_format(
        acc_number($value),
        2
    );
}

function acc_time($value): int
{
    if ($value === null || $value === '') {
        return 0;
    }

    if (is_numeric($value)) {
        $value = (int) $value;

        if ($value > 20000000000) {
            return (int) floor($value / 1000);
        }

        return $value;
    }

    $time = strtotime((string) $value);

    return $time ?: 0;
}

function acc_date($value): string
{
    $time = acc_time($value);

    if (!$time) {
        return '—';
    }

    return date('d M Y, h:i A', $time);
}

function acc_collection_rows($data): array
{
    if (!is_array($data) || empty($data)) {
        return [];
    }

    $singleRecordFields = [
        'amount',
        'value',
        'change',
        'type',
        'detail',
        'description',
        'direction',
        'createdAt',
        'created_at',
        'date',
        'time',
        'status'
    ];

    foreach ($singleRecordFields as $field) {
        if (array_key_exists($field, $data)) {
            return [$data];
        }
    }

    $rows = [];

    foreach ($data as $key => $row) {
        if (is_array($row)) {
            $row['_id'] = $key;
            $rows[] = $row;
        } else {
            $rows[] = [
                '_id' => $key,
                'amount' => $row
            ];
        }
    }

    return $rows;
}

/*
|--------------------------------------------------------------------------
| Logout
|--------------------------------------------------------------------------
*/

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';

    if ($action === 'logout') {
        $_SESSION = [];

        if (ini_get('session.use_cookies')) {
            $params = session_get_cookie_params();

            setcookie(
                session_name(),
                '',
                time() - 42000,
                $params['path'],
                $params['domain'],
                $params['secure'],
                $params['httponly']
            );
        }

        session_destroy();

        header('Location: index.php');
        exit;
    }
}

/*
|--------------------------------------------------------------------------
| User profile
|--------------------------------------------------------------------------
*/

$userKey = acc_db_path($phone);

$profile = acc_firebase_get(
    'users/' . $userKey
);

if (!is_array($profile)) {
    $profile = [];
}

$userName = (string) acc_field(
    $profile,
    [
        'name',
        'username',
        'userName',
        'nickname',
        'displayName'
    ],
    ''
);

if ($userName === '') {
    $phoneOnly = preg_replace('/\D+/', '', $phone);
    $userName = 'MEMBER' . substr(
        (string) $phoneOnly,
        -4
    );
}

/*
|--------------------------------------------------------------------------
| Unique user ID
|--------------------------------------------------------------------------
*/

$userId = (string) acc_field(
    $profile,
    [
        'uid',
        'userId',
        'user_id',
        'memberId',
        'member_id',
        'id'
    ],
    ''
);

if ($userId === '') {
    $numberId = abs(
        crc32('3win-user-' . $phone)
    ) % 10000000;

    $userId = '3' . str_pad(
        (string) $numberId,
        6,
        '0',
        STR_PAD_LEFT
    );

    acc_firebase_put(
        'users/' . $userKey . '/uid',
        $userId
    );
}

/*
|--------------------------------------------------------------------------
| VIP and login
|--------------------------------------------------------------------------
*/

$vipValue = acc_field(
    $profile,
    [
        'vip',
        'vipLevel',
        'vip_level',
        'level',
        'userLevel'
    ],
    0
);

if (is_numeric($vipValue)) {
    $vipText = 'VIP' . (int) $vipValue;
} else {
    $vipText = (string) $vipValue;

    if ($vipText === '') {
        $vipText = 'VIP0';
    }
}

$lastLogin = acc_field(
    $profile,
    [
        'lastLogin',
        'last_login',
        'lastLoginAt',
        'last_login_at',
        'loginTime'
    ],
    ''
);

$avatarUrl =
    'https://www.goaok.org/assets/png/20-jsNPML4j.png';

/*
|--------------------------------------------------------------------------
| Balance
|--------------------------------------------------------------------------
*/

$wallet = acc_firebase_get(
    'wallets/' . $userKey
);

if (!is_array($wallet)) {
    $wallet = [];
}

$balance = 0;
$balanceFound = false;

$balanceFields = [
    'balance',
    'walletBalance',
    'wallet_balance',
    'money',
    'amount'
];

foreach ($balanceFields as $field) {
    if (array_key_exists($field, $profile)) {
        $balance = acc_number($profile[$field]);
        $balanceFound = true;
        break;
    }
}

if (
    !$balanceFound &&
    isset($profile['wallet']) &&
    is_array($profile['wallet'])
) {
    foreach ($balanceFields as $field) {
        if (
            array_key_exists(
                $field,
                $profile['wallet']
            )
        ) {
            $balance = acc_number(
                $profile['wallet'][$field]
            );

            $balanceFound = true;
            break;
        }
    }
}

if (!$balanceFound) {
    foreach ($balanceFields as $field) {
        if (array_key_exists($field, $wallet)) {
            $balance = acc_number($wallet[$field]);
            break;
        }
    }
}

/*
|--------------------------------------------------------------------------
| Transactions
|--------------------------------------------------------------------------
*/

$transactionData = acc_firebase_get(
    'transactions/' . $userKey
);

if (
    !is_array($transactionData) ||
    empty($transactionData)
) {
    $transactionData = acc_firebase_get(
        'walletTransactions/' . $userKey
    );
}

$transactions = [];

foreach (
    acc_collection_rows($transactionData)
    as $row
) {
    $rawAmount = acc_field(
        $row,
        [
            'amount',
            'value',
            'change',
            'money',
            'balanceChange'
        ],
        0
    );

    $rawAmountNumber = acc_number($rawAmount);
    $amount = abs($rawAmountNumber);

    $detail = (string) acc_field(
        $row,
        [
            'detail',
            'description',
            'title',
            'remark',
            'remarks',
            'name'
        ],
        'Wallet transaction'
    );

    $type = strtolower((string) acc_field(
        $row,
        [
            'type',
            'transactionType',
            'transaction_type',
            'kind',
            'category',
            'source'
        ],
        ''
    ));

    $direction = strtolower((string) acc_field(
        $row,
        [
            'direction',
            'entryType',
            'entry_type',
            'mode'
        ],
        ''
    ));

    $text = $type . ' ' . $direction . ' ' .
        strtolower($detail);

    $creditWords = [
        'deposit',
        'recharge',
        'bonus',
        'gift',
        'commission',
        'refund',
        'reward',
        'credit',
        'income',
        'received'
    ];

    $debitWords = [
        'withdraw',
        'withdrawal',
        'deduct',
        'debit',
        'fee',
        'charge',
        'spent',
        'payment'
    ];

    $isCredit = false;
    $isDebit = false;

    foreach ($creditWords as $word) {
        if (strpos($text, $word) !== false) {
            $isCredit = true;
            break;
        }
    }

    foreach ($debitWords as $word) {
        if (strpos($text, $word) !== false) {
            $isDebit = true;
            break;
        }
    }

    if ($rawAmountNumber < 0) {
        $isCredit = false;
        $isDebit = true;
    }

    if (!$isCredit && !$isDebit) {
        $isCredit = true;
    }

    $createdAt = acc_field(
        $row,
        [
            'createdAt',
            'created_at',
            'date',
            'time',
            'timestamp'
        ],
        ''
    );

    $afterBalance = acc_field(
        $row,
        [
            'balanceAfter',
            'balance_after',
            'afterBalance',
            'currentBalance',
            'balance'
        ],
        null
    );

    $transactions[] = [
        'id' => (string) ($row['_id'] ?? ''),
        'detail' => $detail,
        'amount' => $amount,
        'credit' => $isCredit && !$isDebit,
        'status' => (string) acc_field(
            $row,
            ['status', 'state'],
            'Completed'
        ),
        'createdAt' => $createdAt,
        'time' => acc_time($createdAt),
        'balance' => $afterBalance
    ];
}

/*
|--------------------------------------------------------------------------
| Deposit and withdraw fallback
|--------------------------------------------------------------------------
*/

if (empty($transactions)) {
    $depositData = acc_firebase_get(
        'deposits/' . $userKey
    );

    foreach (
        acc_collection_rows($depositData)
        as $row
    ) {
        $createdAt = acc_field(
            $row,
            [
                'createdAt',
                'created_at',
                'date',
                'time'
            ],
            ''
        );

        $transactions[] = [
            'id' => (string) ($row['_id'] ?? ''),
            'detail' => 'Deposit',
            'amount' => abs(acc_number(acc_field(
                $row,
                ['amount', 'value', 'money'],
                0
            ))),
            'credit' => true,
            'status' => (string) acc_field(
                $row,
                ['status', 'state'],
                'Pending'
            ),
            'createdAt' => $createdAt,
            'time' => acc_time($createdAt),
            'balance' => acc_field(
                $row,
                [
                    'balanceAfter',
                    'balance_after',
                    'balance'
                ],
                null
            )
        ];
    }

    $withdrawData = acc_firebase_get(
        'withdrawals/' . $userKey
    );

    foreach (
        acc_collection_rows($withdrawData)
        as $row
    ) {
        $createdAt = acc_field(
            $row,
            [
                'createdAt',
                'created_at',
                'date',
                'time'
            ],
            ''
        );

        $transactions[] = [
            'id' => (string) ($row['_id'] ?? ''),
            'detail' => 'Withdraw',
            'amount' => abs(acc_number(acc_field(
                $row,
                ['amount', 'value', 'money'],
                0
            ))),
            'credit' => false,
            'status' => (string) acc_field(
                $row,
                ['status', 'state'],
                'Pending'
            ),
            'createdAt' => $createdAt,
            'time' => acc_time($createdAt),
            'balance' => acc_field(
                $row,
                [
                    'balanceAfter',
                    'balance_after',
                    'balance'
                ],
                null
            )
        ];
    }
}

usort(
    $transactions,
    function ($first, $second) {
        return $second['time'] <=> $first['time'];
    }
);

$totalReceived = 0;
$totalDeducted = 0;

foreach ($transactions as $transaction) {
    if ($transaction['credit']) {
        $totalReceived += $transaction['amount'];
    } else {
        $totalDeducted += $transaction['amount'];
    }
}

$view = $_GET['view'] ?? 'account';

if (
    $view !== 'transactions' &&
    $view !== 'account'
) {
    $view = 'account';
}
?>

<!DOCTYPE html>
<html lang="en">
<head>

<meta charset="UTF-8">

<meta
    name="viewport"
    content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no"
>

<title>
    <?= $view === 'transactions'
        ? 'Transaction history'
        : 'Account' ?>
</title>

<link
    href="https://fonts.googleapis.com/icon?family=Material+Icons+Round"
    rel="stylesheet"
>

<style>

:root {
    --blue: #4781ff;
    --blue2: #5daaff;
    --page: #f5f6ff;
    --text: #252b3d;
    --muted: #7d879e;
    --green: #20b36d;
    --red: #ef5b65;
    --orange: #ff982f;
    --white: #ffffff;
}

* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
    font-family: Arial, Helvetica, sans-serif;
    -webkit-tap-highlight-color: transparent;
}

html {
    scroll-behavior: smooth;
}

body {
    background: var(--page);
    color: var(--text);
    overflow-x: hidden;
    padding-bottom: 76px;
}

.app {
    width: 100%;
    max-width: 480px;
    min-height: 100vh;
    margin: 0 auto;
    overflow: hidden;
    background: var(--page);
}

/* Compact profile header */

.account-hero {
    background: linear-gradient(
        135deg,
        #4380ff,
        #61aeff
    );
    padding: 27px 14px 0;
    color: white;
    border-radius: 0 0 39px 39px;
}

.profile-row {
    display: flex;
    align-items: center;
    gap: 11px;
}

.profile-image {
    width: 68px;
    height: 68px;
    border-radius: 50%;
    object-fit: cover;
    flex-shrink: 0;
    background: white;
    border: 2px solid rgba(255,255,255,.9);
}

.profile-info {
    min-width: 0;
    flex: 1;
}

.profile-name {
    font-size: 18px;
    font-weight: 400;
    line-height: 1.1;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
    margin-bottom: 6px;
}

.vip-badge {
    display: inline-flex;
    align-items: center;
    background: white;
    color: #8490a5;
    border-radius: 13px;
    padding: 3px 6px;
    font-size: 9px;
    font-weight: bold;
    margin-left: 3px;
    vertical-align: middle;
}

.uid-row {
    display: inline-flex;
    align-items: center;
    gap: 5px;
    background: #ffae4d;
    border-radius: 18px;
    padding: 5px 9px;
    font-size: 13px;
    margin-bottom: 5px;
}

.uid-row button {
    border: 0;
    background: transparent;
    color: white;
    display: flex;
    align-items: center;
    cursor: pointer;
}

.uid-row .material-icons-round {
    font-size: 16px;
}

.last-login {
    font-size: 10px;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
}

/* Balance section */

.balance-card {
    background: white;
    color: var(--text);
    border-radius: 22px;
    padding: 17px 15px 13px;
    margin-top: 18px;
    transform: translateY(26px);
    box-shadow: 0 5px 18px rgba(50,80,150,.08);
}

.balance-top {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 8px;
    padding-bottom: 14px;
    border-bottom: 1px solid #edf0f6;
}

.balance-title {
    color: var(--muted);
    font-size: 18px;
    margin-bottom: 5px;
}

.balance-amount {
    font-size: 28px;
    line-height: 1;
    font-weight: bold;
}

.wallet-button {
    background: linear-gradient(
        90deg,
        #4381ff,
        #60adff
    );
    color: white;
    text-decoration: none;
    border-radius: 27px;
    padding: 11px 15px;
    font-size: 16px;
    white-space: nowrap;
}

.wallet-actions {
    display: grid;
    grid-template-columns: repeat(3, 1fr);
    gap: 3px;
    padding-top: 13px;
}

.wallet-action {
    color: var(--text);
    text-decoration: none;
    text-align: center;
    font-size: 14px;
}

.action-icon {
    width: 43px;
    height: 43px;
    border-radius: 12px;
    margin: 0 auto 5px;
    display: flex;
    align-items: center;
    justify-content: center;
}

.action-icon .material-icons-round {
    font-size: 26px;
}

.deposit-action {
    background: #ffc5c8;
    color: #f05e69;
}

.withdraw-action {
    background: #ffd09d;
    color: #ef8b21;
}

.vip-action {
    background: #a9ead8;
    color: #15a98c;
}

/* Main content */

.page-content {
    padding: 48px 14px 18px;
}

/* Transaction, deposit and withdraw */

.feature-grid {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 11px;
}

.feature-card {
    min-height: 106px;
    background: white;
    border-radius: 12px;
    padding: 12px 11px;
    text-decoration: none;
    color: var(--text);
    box-shadow: 0 4px 13px rgba(50,80,150,.04);
}

.feature-icon {
    width: 42px;
    height: 42px;
    border-radius: 11px;
    margin-bottom: 7px;
    display: flex;
    align-items: center;
    justify-content: center;
}

.feature-icon .material-icons-round {
    font-size: 27px;
}

.transaction-feature {
    background: #b9f0df;
    color: #20b88f;
}

.deposit-feature {
    background: #ffc5c8;
    color: #f05e68;
}

.withdraw-feature {
    background: #ffd09b;
    color: #ed891e;
}

.feature-card h3 {
    font-size: 17px;
    line-height: 1.1;
    font-weight: 500;
    margin-bottom: 3px;
}

.feature-card p {
    color: var(--muted);
    font-size: 13px;
    line-height: 1.15;
}

/* Account menu */

.menu-card {
    background: white;
    border-radius: 17px;
    margin-top: 13px;
    overflow: hidden;
    box-shadow: 0 4px 13px rgba(50,80,150,.04);
}

.menu-item {
    min-height: 64px;
    padding: 9px 15px;
    display: flex;
    align-items: center;
    gap: 11px;
    text-decoration: none;
    color: var(--text);
    border-bottom: 1px solid #edf0f6;
}

.menu-item:last-child {
    border-bottom: 0;
}

.menu-icon {
    width: 41px;
    height: 41px;
    border-radius: 11px;
    background: #bdd4ff;
    color: var(--blue);
    display: flex;
    align-items: center;
    justify-content: center;
    flex-shrink: 0;
}

.menu-icon .material-icons-round {
    font-size: 25px;
}

.menu-title {
    flex: 1;
    font-size: 17px;
}

.menu-value {
    color: var(--muted);
    font-size: 14px;
}

.menu-arrow {
    color: #676d76;
    font-size: 25px;
}

/* Service center */

.service-card {
    background: white;
    border-radius: 17px;
    margin-top: 13px;
    padding: 18px 10px 15px;
}

.service-card h2 {
    font-size: 20px;
    font-weight: 400;
    margin: 0 3px 19px;
}

.service-grid {
    display: grid;
    grid-template-columns: repeat(3, 1fr);
    gap: 19px 3px;
}

.service-item {
    color: var(--muted);
    text-decoration: none;
    text-align: center;
    font-size: 12px;
    line-height: 1.2;
}

.service-item .material-icons-round {
    width: 44px;
    height: 44px;
    display: flex;
    align-items: center;
    justify-content: center;
    margin: 0 auto 6px;
    border-radius: 12px;
    background: #c5d8ff;
    color: var(--blue);
    font-size: 27px;
}

/* Logout */

.logout-button {
    width: 100%;
    height: 50px;
    margin-top: 28px;
    border-radius: 28px;
    border: 1px solid var(--blue);
    background: transparent;
    color: var(--blue);
    font-size: 18px;
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 8px;
    cursor: pointer;
}

.logout-button .material-icons-round {
    font-size: 31px;
}

/* Transaction page */

.inner-header {
    height: 62px;
    background: white;
    display: flex;
    align-items: center;
    justify-content: center;
    position: relative;
    border-bottom: 1px solid #edf0f6;
}

.inner-header h1 {
    font-size: 21px;
    font-weight: 500;
}

.back-button {
    position: absolute;
    left: 11px;
    color: var(--text);
    text-decoration: none;
    display: flex;
    align-items: center;
}

.back-button .material-icons-round {
    font-size: 32px;
}

.transaction-content {
    padding: 14px;
}

.summary-grid {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 10px;
    margin-bottom: 13px;
}

.summary-card {
    background: white;
    padding: 13px 8px;
    border-radius: 13px;
    text-align: center;
}

.summary-card strong {
    display: block;
    font-size: 18px;
    margin-bottom: 5px;
}

.summary-card span {
    color: var(--muted);
    font-size: 12px;
}

.received {
    color: var(--green);
}

.deducted {
    color: var(--red);
}

.transaction-list {
    display: flex;
    flex-direction: column;
    gap: 11px;
}

.transaction-card {
    background: white;
    border-radius: 15px;
    padding: 13px;
}

.transaction-heading {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 8px;
    margin-bottom: 10px;
}

.transaction-title {
    font-size: 16px;
    font-weight: bold;
}

.transaction-amount {
    font-size: 17px;
    font-weight: bold;
    white-space: nowrap;
}

.credit {
    color: var(--green);
}

.debit {
    color: var(--red);
}

.transaction-line {
    display: flex;
    justify-content: space-between;
    gap: 8px;
    padding: 9px 10px;
    margin-top: 6px;
    border-radius: 6px;
    background: #f7f8fd;
    font-size: 12px;
}

.transaction-line span:first-child {
    color: var(--muted);
}

.transaction-line span:last-child {
    text-align: right;
    word-break: break-word;
}

.empty-box {
    padding: 45px 15px;
    border-radius: 16px;
    text-align: center;
    background: white;
    color: var(--muted);
}

/* Logout popup */

.modal {
    position: fixed;
    inset: 0;
    z-index: 200;
    display: none;
    align-items: center;
    justify-content: center;
    padding: 18px;
    background: rgba(0,0,0,.58);
}

.modal.show {
    display: flex;
}

.modal-box {
    width: 100%;
    max-width: 370px;
    padding: 29px 21px 22px;
    border-radius: 25px;
    background: white;
    text-align: center;
}

.warning {
    width: 70px;
    height: 70px;
    margin: 0 auto 19px;
    border-radius: 50%;
    background: #6884ff;
    color: white;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 49px;
    font-weight: bold;
}

.modal-box h2 {
    font-size: 22px;
    margin-bottom: 21px;
}

.confirm-button,
.cancel-button {
    width: 100%;
    height: 50px;
    border-radius: 27px;
    font-size: 17px;
    cursor: pointer;
}

.confirm-button {
    border: 0;
    background: linear-gradient(
        90deg,
        #4381ff,
        #60adff
    );
    color: white;
    margin-bottom: 11px;
}

.cancel-button {
    color: var(--blue);
    border: 1px solid var(--blue);
    background: white;
}

/* Bottom navigation */

.bottom-nav {
    position: fixed;
    left: 50%;
    bottom: 0;
    z-index: 100;
    width: 100%;
    max-width: 480px;
    height: 70px;
    transform: translateX(-50%);
    display: grid;
    grid-template-columns: repeat(5, 1fr);
    align-items: end;
    background: white;
    border-radius: 18px 18px 0 0;
    box-shadow: 0 -4px 18px rgba(0,0,0,.07);
}

.bottom-nav a {
    height: 64px;
    display: flex;
    align-items: center;
    justify-content: center;
    flex-direction: column;
    gap: 2px;
    color: #8991a1;
    text-decoration: none;
    font-size: 10px;
    font-weight: bold;
}

.bottom-nav a.active {
    color: var(--blue);
}

.bottom-nav .material-icons-round {
    font-size: 24px;
}

.spin-link {
    margin-top: -24px;
}

.spin-circle {
    width: 59px;
    height: 59px;
    margin-bottom: 3px;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    background: white;
    box-shadow:
        0 0 0 6px white,
        0 4px 13px rgba(0,0,0,.18);
}

.spin-image {
    width: 52px;
    height: 52px;
    object-fit: cover;
    border-radius: 50%;
}

@media (max-width: 360px) {
    .profile-name {
        font-size: 16px;
    }

    .balance-title {
        font-size: 16px;
    }

    .balance-amount {
        font-size: 25px;
    }

    .wallet-button {
        padding: 10px 12px;
        font-size: 14px;
    }

    .feature-card h3 {
        font-size: 15px;
    }

    .feature-card p {
        font-size: 12px;
    }
}

</style>
</head>

<body>

<div class="app">

<?php if ($view === 'account'): ?>

    <!-- Compact user header -->

    <section class="account-hero">

        <div class="profile-row">

            <img
                class="profile-image"
                src="<?= acc_escape($avatarUrl) ?>"
                alt="User"
            >

            <div class="profile-info">

                <div class="profile-name">
                    <?= acc_escape($userName) ?>

                    <span class="vip-badge">
                        <?= acc_escape($vipText) ?>
                    </span>
                </div>

                <div class="uid-row">

                    <span>UID</span>
                    <span>|</span>
                    <b><?= acc_escape($userId) ?></b>

                    <button
                        type="button"
                        onclick="copyText(<?= acc_escape(
                            json_encode($userId)
                        ) ?>)"
                    >
                        <span class="material-icons-round">
                            content_copy
                        </span>
                    </button>

                </div>

                <div class="last-login">
                    Last login:
                    <?= acc_escape(
                        $lastLogin !== ''
                            ? acc_date($lastLogin)
                            : '—'
                    ) ?>
                </div>

            </div>

        </div>

        <!-- Balance card -->

        <div class="balance-card">

            <div class="balance-top">

                <div>
                    <div class="balance-title">
                        Total balance
                    </div>

                    <div class="balance-amount">
                        <?= acc_money($balance) ?>
                    </div>
                </div>

                <!-- Enter wallet opens withdrawal.php -->

                <a
                    class="wallet-button"
                    href="withdrawal.php"
                >
                    Enter wallet
                </a>

            </div>

            <!-- AR Wallet intentionally removed -->

            <div class="wallet-actions">

                <a
                    class="wallet-action"
                    href="deposit.php"
                >
                    <span class="action-icon" style="background: transparent;">
                        <img src="https://i.ibb.co/v4Gd61nh/8865720.png" style="width: 43px; height: 43px; object-fit: contain; border-radius: 12px;" alt="Deposit">
                    </span>
                    Deposit
                </a>

                <a
                    class="wallet-action"
                    href="withdrawal.php"
                >
                    <span class="action-icon" style="background: transparent;">
                        <img src="https://i.ibb.co/qM6BgZMN/2066-withdrawal.gif" style="width: 43px; height: 43px; object-fit: contain; border-radius: 12px;" alt="Withdraw">
                    </span>
                    Withdraw
                </a>

                <a
                    class="wallet-action"
                    href="vip.php"
                >
                    <span class="action-icon" style="background: transparent;">
                        <img src="https://i.ibb.co/PZZwnhBc/badge-vip-icon-royal-premium-vip-symbol-vector.jpg" style="width: 43px; height: 43px; object-fit: cover; border-radius: 12px;" alt="VIP">
                    </span>
                    VIP
                </a>

            </div>

        </div>

    </section>

    <main class="page-content">

        <!-- Game History intentionally removed -->

        <div class="feature-grid">

            <a
                class="feature-card"
                href="account.php?view=transactions"
            >
                <span class="feature-icon transaction-feature">
                    <span class="material-icons-round">
                        receipt_long
                    </span>
                </span>

                <h3>Transaction</h3>
                <p>My transaction history</p>
            </a>

            <a
                class="feature-card"
                href="deposit.php"
            >
                <span class="feature-icon" style="background: transparent;">
                    <img src="https://i.ibb.co/v4Gd61nh/8865720.png" style="width: 42px; height: 42px; object-fit: contain;" alt="Deposit">
                </span>

                <h3>Deposit</h3>
                <p>My deposit history</p>
            </a>

            <a
                class="feature-card"
                href="withdrawal.php"
            >
                <span class="feature-icon" style="background: transparent;">
                    <img src="https://i.ibb.co/qM6BgZMN/2066-withdrawal.gif" style="width: 42px; height: 42px; object-fit: contain;" alt="Withdraw">
                </span>

                <h3>Withdraw</h3>
                <p>My withdraw history</p>
            </a>

        </div>

        <!-- Account menu -->

        <div class="menu-card">

            <a
                class="menu-item"
                href="notification.php"
            >
                <span class="menu-icon">
                    <span class="material-icons-round">
                        mail
                    </span>
                </span>

                <span class="menu-title">
                    Notification
                </span>

                <span class="material-icons-round menu-arrow">
                    chevron_right
                </span>
            </a>

            <a
                class="menu-item"
                href="gift.php"
            >
                <span class="menu-icon">
                    <span class="material-icons-round">
                        redeem
                    </span>
                </span>

                <span class="menu-title">
                    Gifts
                </span>

                <span class="material-icons-round menu-arrow">
                    chevron_right
                </span>
            </a>

            <a
                class="menu-item"
                href="activity.php"
            >
                <span class="menu-icon">
                    <span class="material-icons-round">
                        bar_chart
                    </span>
                </span>

                <span class="menu-title">
                    Game statistics
                </span>

                <span class="material-icons-round menu-arrow">
                    chevron_right
                </span>
            </a>

            <a
                class="menu-item"
                href="language.php"
            >
                <span class="menu-icon">
                    <span class="material-icons-round">
                        language
                    </span>
                </span>

                <span class="menu-title">
                    Language
                </span>

                <span class="menu-value">
                    English
                </span>

                <span class="material-icons-round menu-arrow">
                    chevron_right
                </span>
            </a>

        </div>

        <!-- Service center -->

        <section class="service-card">

            <h2>Service center</h2>

            <div class="service-grid">

                <a
                    class="service-item"
                    href="settings.php"
                >
                    <span class="material-icons-round">
                        settings
                    </span>
                    Settings
                </a>

                <a
                    class="service-item"
                    href="feedback.php"
                >
                    <span class="material-icons-round">
                        description
                    </span>
                    Feedback
                </a>

                <a
                    class="service-item"
                    href="announcement.php"
                >
                    <span class="material-icons-round">
                        campaign
                    </span>
                    Announcement
                </a>

                <a
                    class="service-item"
                    href="customer-service.php"
                >
                    <span class="material-icons-round">
                        support_agent
                    </span>
                    Customer Service
                </a>

                <a
                    class="service-item"
                    href="guide.php"
                >
                    <span class="material-icons-round">
                        menu_book
                    </span>
                    Beginner's Guide
                </a>

                <a
                    class="service-item"
                    href="about.php"
                >
                    <span class="material-icons-round">
                        view_in_ar
                    </span>
                    About us
                </a>

            </div>

        </section>

        <button
            class="logout-button"
            type="button"
            onclick="openLogout()"
        >
            <span class="material-icons-round">
                power_settings_new
            </span>
            Log out
        </button>

    </main>

<?php else: ?>

    <!-- Transaction history page -->

    <header class="inner-header">

        <a
            class="back-button"
            href="account.php"
        >
            <span class="material-icons-round">
                arrow_back
            </span>
        </a>

        <h1>Transaction history</h1>

    </header>

    <main class="transaction-content">

        <div class="summary-grid">

            <div class="summary-card">
                <strong class="received">
                    <?= acc_money($totalReceived) ?>
                </strong>
                <span>Total received</span>
            </div>

            <div class="summary-card">
                <strong class="deducted">
                    <?= acc_money($totalDeducted) ?>
                </strong>
                <span>Total deducted</span>
            </div>

        </div>

        <div class="transaction-list">

            <?php if (empty($transactions)): ?>

                <div class="empty-box">
                    No transaction record found.
                </div>

            <?php else: ?>

                <?php foreach ($transactions as $transaction): ?>

                    <?php
                    $amountClass = $transaction['credit']
                        ? 'credit'
                        : 'debit';

                    $sign = $transaction['credit']
                        ? '+'
                        : '-';
                    ?>

                    <div class="transaction-card">

                        <div class="transaction-heading">

                            <div class="transaction-title">
                                <?= acc_escape(
                                    $transaction['detail']
                                ) ?>
                            </div>

                            <div
                                class="transaction-amount
                                <?= $amountClass ?>"
                            >
                                <?= $sign . acc_money(
                                    $transaction['amount']
                                ) ?>
                            </div>

                        </div>

                        <div class="transaction-line">
                            <span>Detail</span>
                            <span>
                                <?= acc_escape(
                                    $transaction['detail']
                                ) ?>
                            </span>
                        </div>

                        <div class="transaction-line">
                            <span>Time</span>
                            <span>
                                <?= acc_escape(
                                    acc_date(
                                        $transaction['createdAt']
                                    )
                                ) ?>
                            </span>
                        </div>

                        <div class="transaction-line">
                            <span>Status</span>
                            <span>
                                <?= acc_escape(
                                    $transaction['status']
                                ) ?>
                            </span>
                        </div>

                        <?php if (
                            $transaction['balance'] !== null &&
                            $transaction['balance'] !== ''
                        ): ?>

                            <div class="transaction-line">
                                <span>Balance</span>
                                <span>
                                    <?= acc_money(
                                        $transaction['balance']
                                    ) ?>
                                </span>
                            </div>

                        <?php endif; ?>

                    </div>

                <?php endforeach; ?>

            <?php endif; ?>

        </div>

    </main>

<?php endif; ?>

<!-- Logout popup -->

<div
    class="modal"
    id="logoutModal"
    onclick="closeLogout(event)"
>

    <div
        class="modal-box"
        onclick="event.stopPropagation()"
    >

        <div class="warning">!</div>

        <h2>Do you want to log out?</h2>

        <form method="post" action="account.php">

            <input
                type="hidden"
                name="action"
                value="logout"
            >

            <button
                class="confirm-button"
                type="submit"
            >
                Confirm
            </button>

        </form>

        <button
            class="cancel-button"
            type="button"
            onclick="closeLogout()"
        >
            Cancel
        </button>

    </div>

</div>

<!-- Same bottom navigation -->

<nav class="bottom-nav">

    <a href="dashboard.php">
        <span class="material-icons-round">
            home
        </span>
        Home
    </a>

    <a href="activity.php">
        <span class="material-icons-round">
            local_activity
        </span>
        Activity
    </a>

    <a
        href="spin.php"
        class="spin-link"
    >
        <span class="spin-circle">
            <img
                class="spin-image"
                src="https://i.ibb.co/q3FfkmGc/images.png"
                alt="Spin"
            >
        </span>
        Get ₹500
    </a>

    <a href="promotion.php">
        <span class="material-icons-round">
            card_giftcard
        </span>
        Promotion
    </a>

    <a
        href="account.php"
        class="<?= $view === 'account'
            ? 'active'
            : '' ?>"
    >
        <span class="material-icons-round">
            person
        </span>
        Account
    </a>

</nav>

</div>

<script>

function copyText(value) {
    if (navigator.clipboard) {
        navigator.clipboard
            .writeText(value)
            .then(function () {
                showMessage('Copied successfully');
            });

        return;
    }

    const input = document.createElement('textarea');

    input.value = value;
    document.body.appendChild(input);
    input.select();

    document.execCommand('copy');

    input.remove();

    showMessage('Copied successfully');
}

function showMessage(message) {
    let toast = document.getElementById('accountToast');

    if (!toast) {
        toast = document.createElement('div');

        toast.id = 'accountToast';

        toast.style.position = 'fixed';
        toast.style.left = '50%';
        toast.style.top = '15%';
        toast.style.transform = 'translateX(-50%)';
        toast.style.zIndex = '500';
        toast.style.padding = '11px 18px';
        toast.style.borderRadius = '22px';
        toast.style.background = '#111827';
        toast.style.color = '#ffffff';
        toast.style.fontSize = '13px';

        document.body.appendChild(toast);
    }

    toast.textContent = message;

    clearTimeout(window.accountToastTimer);

    window.accountToastTimer = setTimeout(function () {
        toast.remove();
    }, 1700);
}

function openLogout() {
    document
        .getElementById('logoutModal')
        .classList.add('show');
}

function closeLogout(event) {
    if (
        event &&
        event.target &&
        event.target.id !== 'logoutModal'
    ) {
        return;
    }

    document
        .getElementById('logoutModal')
        .classList.remove('show');
}

</script>

</body>
</html>