<?php
session_start();
error_reporting(0);
date_default_timezone_set('Asia/Kolkata');
require_once 'config.php';

// =========================================================================
// DOWNLOAD APK URL CONFIGURATION 
// =========================================================================
$downloadUrl = "https://github.com/abhaypratapsingh76392-web/verbose-winner/releases/download/3win/3win.apk"; 

$phone = $_SESSION['user_phone'] ?? $_SESSION['phone'] ?? '';
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
<title>Download page</title>
<style>
* { margin: 0; padding: 0; box-sizing: border-box; font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif; -webkit-tap-highlight-color: transparent; }
body { background: #f7f9fc; color: #222; min-height: 100vh; display: flex; justify-content: center; }
.app { width: 100%; max-width: 480px; min-height: 100vh; background: #f7f9fc; display: flex; flex-direction: column; position: relative; padding-bottom: 30px; }

/* HEADER */
.header { height: 50px; background: #fff; display: flex; align-items: center; justify-content: center; position: sticky; top: 0; z-index: 50; border-bottom: 1px solid #f0f1f5; }
.back-btn { position: absolute; left: 16px; font-size: 26px; color: #333; text-decoration: none; cursor: pointer; line-height: 1; display: flex; align-items: center; justify-content: center; }
.header-title { font-size: 18px; font-weight: 500; color: #222; }

/* MAIN CONTENT */
.content { padding: 16px; flex: 1; display: flex; flex-direction: column; }

/* BANNER CARD */
.banner-card {
    width: 100%;
    height: 180px;
    border-radius: 18px;
    position: relative;
    overflow: hidden;
    background: linear-gradient(135deg, #1b73f8 0%, #2982ff 50%, #4da0ff 100%);
    box-shadow: 0 8px 24px rgba(27, 115, 248, 0.25);
    display: flex;
    align-items: center;
    padding: 20px;
}

/* Background Rays & Flares */
.banner-bg-glow {
    position: absolute;
    right: -20px;
    top: -20px;
    width: 260px;
    height: 260px;
    background: radial-gradient(circle, rgba(255, 138, 0, 0.8) 0%, rgba(255, 75, 0, 0.4) 45%, transparent 70%);
    border-radius: 50%;
    pointer-events: none;
}

/* Text on Banner */
.banner-text {
    position: relative;
    z-index: 5;
    max-width: 55%;
}
.banner-text h2 {
    color: #fff;
    font-size: 22px;
    font-weight: 900;
    line-height: 1.18;
    letter-spacing: -0.2px;
    text-shadow: 0 2px 4px rgba(0,0,0,0.15);
}

/* Trophy & Graphics on Right */
.banner-graphic {
    position: absolute;
    right: 15px;
    top: 50%;
    transform: translateY(-50%);
    width: 160px;
    height: 150px;
    display: flex;
    align-items: center;
    justify-content: center;
    z-index: 4;
}
.trophy-svg {
    width: 100%;
    height: 100%;
    filter: drop-shadow(0 4px 10px rgba(0,0,0,0.25));
}

/* FLOATING BALLS */
.float-ball {
    position: absolute;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    color: #fff;
    font-weight: 900;
    box-shadow: 0 4px 10px rgba(0,0,0,0.3);
    z-index: 10;
}
/* Ball 0 (Pink top-left) */
.ball-0 {
    width: 38px;
    height: 38px;
    left: 8px;
    top: 10px;
    background: radial-gradient(circle at 35% 30%, #ff8ea3, #f53158);
    font-size: 15px;
    border: 2px solid rgba(255,255,255,0.6);
}
/* Ball 7 (Green top-right) */
.ball-7 {
    width: 30px;
    height: 30px;
    right: 18px;
    top: 8px;
    background: radial-gradient(circle at 35% 30%, #68e895, #1dbf54);
    font-size: 13px;
    border: 1.5px solid rgba(255,255,255,0.6);
}
/* Ball 8 (Pink Saturn bottom-right) */
.ball-8 {
    width: 44px;
    height: 44px;
    right: 12px;
    bottom: 8px;
    background: radial-gradient(circle at 35% 30%, #ff7b96, #ea264e);
    font-size: 17px;
    border: 2px solid rgba(255,255,255,0.6);
}
.ball-8::after {
    content: '';
    position: absolute;
    width: 58px;
    height: 20px;
    border: 2px solid rgba(255, 255, 255, 0.6);
    border-radius: 50%;
    transform: rotate(-25deg);
}

/* BUTTONS CONTAINER */
.btn-group {
    margin-top: 36px;
    display: flex;
    flex-direction: column;
    gap: 16px;
}

/* BUTTON 2: COMPLETE INSTALLATION (Coral Red) */
.btn-complete {
    width: 100%;
    height: 52px;
    border-radius: 28px;
    background: linear-gradient(180deg, #f75858 0%, #ef4646 100%);
    color: #fff;
    border: none;
    font-size: 16px;
    font-weight: 700;
    cursor: pointer;
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 8px;
    box-shadow: 0 4px 14px rgba(247, 88, 88, 0.35);
    text-decoration: none;
    transition: transform 0.15s ease, filter 0.15s ease;
}
.btn-complete:active { transform: scale(0.98); filter: brightness(0.95); }

/* FLOATING CUSTOMER SERVICE CHAT BUBBLE */
.service-float {
    position: fixed;
    right: 18px;
    bottom: 35px;
    width: 52px;
    height: 52px;
    border-radius: 50%;
    background: #fff;
    display: flex;
    align-items: center;
    justify-content: center;
    box-shadow: 0 4px 16px rgba(0, 0, 0, 0.12);
    z-index: 100;
    cursor: pointer;
    text-decoration: none;
}
.service-icon-inner {
    width: 44px;
    height: 44px;
    border-radius: 50%;
    background: #3e82f7;
    display: flex;
    align-items: center;
    justify-content: center;
}
.service-icon-inner svg {
    width: 26px;
    height: 26px;
    fill: #fff;
}
</style>
</head>
<body>

<div class="app">
    <!-- HEADER -->
    <div class="header">
        <a href="account.php" class="back-btn">‹</a>
        <div class="header-title">Download page</div>
    </div>

    <!-- MAIN CONTENT -->
    <div class="content">
        <!-- EXACT BANNER CARD -->
        <div class="banner-card">
            <!-- Orange explosion light -->
            <div class="banner-bg-glow"></div>

            <!-- Floating Lottery Balls (0, 7, 8) -->
            <div class="float-ball ball-0">0</div>
            <div class="float-ball ball-7">7</div>
            <div class="float-ball ball-8">8</div>

            <!-- Left Text -->
            <div class="banner-text">
                <h2>Download<br>popular app<br>games</h2>
            </div>

            <!-- Right Trophy & Coins Graphic -->
            <div class="banner-graphic">
                <svg class="trophy-svg" viewBox="0 0 160 150">
                    <defs>
                        <radialGradient id="tGlow" cx="50%" cy="50%" r="50%">
                            <stop offset="0%" stop-color="#fffb91"/>
                            <stop offset="60%" stop-color="#ff9900"/>
                            <stop offset="100%" stop-color="transparent"/>
                        </radialGradient>
                        <linearGradient id="tGold" x1="0" y1="0" x2="0" y2="1">
                            <stop offset="0%" stop-color="#fff099"/>
                            <stop offset="50%" stop-color="#ffb700"/>
                            <stop offset="100%" stop-color="#cc8800"/>
                        </linearGradient>
                        <linearGradient id="tSilver" x1="0" y1="0" x2="0" y2="1">
                            <stop offset="0%" stop-color="#ffffff"/>
                            <stop offset="50%" stop-color="#d9e6f7"/>
                            <stop offset="100%" stop-color="#8faed6"/>
                        </linearGradient>
                    </defs>

                    <!-- Background Flare -->
                    <circle cx="85" cy="75" r="65" fill="url(#tGlow)" opacity="0.8"/>

                    <!-- Flying Coins -->
                    <circle cx="45" cy="30" r="10" fill="url(#tGold)" stroke="#fff" stroke-width="1.5"/>
                    <text x="45" y="34" font-size="10" font-weight="bold" fill="#805300" text-anchor="middle">$</text>

                    <circle cx="125" cy="40" r="8" fill="url(#tGold)" stroke="#fff" stroke-width="1"/>

                    <!-- Trophy Handles -->
                    <path d="M42 55 C30 55 30 85 55 88" fill="none" stroke="url(#tSilver)" stroke-width="6" stroke-linecap="round"/>
                    <path d="M118 55 C130 55 130 85 105 88" fill="none" stroke="url(#tSilver)" stroke-width="6" stroke-linecap="round"/>

                    <!-- Trophy Cup Body -->
                    <path d="M50 48 L110 48 C108 85 92 98 80 100 C68 98 52 85 50 48 Z" fill="url(#tSilver)"/>
                    
                    <!-- Trophy Rim Filled with Coins -->
                    <ellipse cx="80" cy="48" rx="30" ry="12" fill="#ffb700" stroke="#fff" stroke-width="2"/>
                    <circle cx="75" cy="46" r="6" fill="#ffd866"/>
                    <circle cx="85" cy="44" r="5" fill="#fff"/>

                    <!-- Trophy Stand -->
                    <path d="M72 100 L88 100 L94 122 L66 122 Z" fill="url(#tSilver)"/>
                    <ellipse cx="80" cy="122" rx="22" ry="6" fill="url(#tSilver)"/>
                </svg>
            </div>
        </div>

        <!-- BUTTONS GROUP -->
        <div class="btn-group">
            <!-- 2. Complete Installation (Red) -->
            <a href="<?= htmlspecialchars($downloadUrl) ?>" class="btn-complete" id="btnComplete" download>
                <svg width="18" height="18" viewBox="0 0 24 24" fill="#fff">
                    <path d="M19 9h-4V3H9v6H5l7 7 7-7zM5 18v2h14v-2H5z"/>
                </svg>
                Complete Installation
            </a>
        </div>
    </div>

    <!-- FLOATING CUSTOMER SERVICE ICON -->
    <a href="customer-service.php" class="service-float">
        <div class="service-icon-inner">
            <svg viewBox="0 0 24 24">
                <path d="M20 2H4c-1.1 0-2 .9-2 2v18l4-4h14c1.1 0 2-.9 2-2V4c0-1.1-.9-2-2-2zm-6 9h-4v-2h4v2zm2-4H8V5h8v2z"/>
            </svg>
        </div>
    </a>
</div>

</body>
</html>
