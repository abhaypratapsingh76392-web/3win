<?php
session_start();
require_once 'config.php';

if (!isset($_SESSION['user_phone'])) {
    header('Location: index.php');
    exit;
}

$phone = $_SESSION['user_phone'];
$today = date('Y-m-d');
$yesterday = date('Y-m-d', strtotime('-1 day'));

// Fetch User Data
$userData = firebase_read("users/" . $phone);
$balance = $userData['balance'] ?? 0;
$last_deposit_date = $userData['last_deposit_date'] ?? ''; // To check if deposited today

// Fetch Attendance Data
$attData = firebase_read("users/" . $phone . "/attendance") ?? [
    'consecutive_days' => 0,
    'last_claim_date' => '',
    'accumulated' => 0
];

// Reset logic if missed a day
if ($attData['last_claim_date'] != $today && $attData['last_claim_date'] != $yesterday && $attData['last_claim_date'] != '') {
    $attData['consecutive_days'] = 0;
    firebase_write("users/" . $phone . "/attendance/consecutive_days", 0);
}

$rewards = [1 => 4.00, 2 => 20.00, 3 => 100.00, 4 => 200.00, 5 => 450.00, 6 => 2000.00, 7 => 7000.00];

// ========== AJAX HANDLERS ==========
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    header('Content-Type: application/json');
    $action = $_POST['action'];

    if ($action === 'claim') {
        // 1. Check if already claimed today
        if ($attData['last_claim_date'] == $today) {
            echo json_encode(['success' => false, 'msg' => 'You have already claimed today!']);
            exit;
        }

        // 2. Check if deposited today (Uncomment below line to strictly enforce deposit rule)
        /*
        if ($last_deposit_date != $today) {
            echo json_encode(['success' => false, 'msg' => 'Players with no deposit history today cannot claim the bonus.']);
            exit;
        }
        */

        // 3. Calculate new day and reward
        $next_day = $attData['consecutive_days'] + 1;
        if ($next_day > 7) $next_day = 1; // Reset after 7 days

        $reward_amount = $rewards[$next_day];

        // 4. Update Database
        $attData['consecutive_days'] = $next_day;
        $attData['last_claim_date'] = $today;
        $attData['accumulated'] += $reward_amount;

        firebase_write("users/" . $phone . "/attendance", $attData);
        
        // Update Balance
        $new_balance = $balance + $reward_amount;
        firebase_write("users/" . $phone . "/balance", $new_balance);

        // Save History
        $history = firebase_read("users/" . $phone . "/attendance_history") ?? [];
        array_unshift($history, [
            'date' => date('Y-m-d H:i:s'),
            'amount' => $reward_amount,
            'day' => $next_day
        ]);
        firebase_write("users/" . $phone . "/attendance_history", $history);

        echo json_encode(['success' => true, 'msg' => 'Claimed ₹' . $reward_amount . ' successfully!', 'new_day' => $next_day, 'accumulated' => $attData['accumulated']]);
        exit;
    }

    if ($action === 'get_history') {
        $history = firebase_read("users/" . $phone . "/attendance_history") ?? [];
        echo json_encode(['success' => true, 'data' => $history]);
        exit;
    }
    exit;
}

$current_day = $attData['consecutive_days'];
$is_claimed_today = ($attData['last_claim_date'] == $today);
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
<title>Attendance Bonus</title>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
<link href="https://fonts.googleapis.com/icon?family=Material+Icons+Round" rel="stylesheet">
<style>
* { margin: 0; padding: 0; box-sizing: border-box; font-family: 'Inter', sans-serif; -webkit-tap-highlight-color: transparent; }
body { background-color: #f7f8ff; color: #333; overflow-x: hidden; }
.app-container { max-width: 480px; margin: 0 auto; background: #f7f8ff; min-height: 100vh; position: relative; box-shadow: 0 0 20px rgba(0,0,0,0.05); overflow: hidden; }

/* Top Header */
.top-header { display: flex; align-items: center; padding: 12px 16px; background: #fff; color: #333; position: sticky; top: 0; z-index: 100; box-shadow: 0 2px 5px rgba(0,0,0,0.02); }
.tb-back { background: none; border: none; font-size: 24px; color: #666; cursor: pointer; display: flex; align-items: center; }
.tb-title { flex: 1; text-align: center; font-size: 18px; font-weight: 600; margin-right: 24px; }

/* Pages Setup */
.page { display: none; animation: slideIn 0.3s ease forwards; padding-bottom: 90px; }
.page.active { display: block; }
@keyframes slideIn { from { transform: translateX(100%); opacity: 0; } to { transform: translateX(0); opacity: 1; } }

/* Banner Section */
.banner { background: linear-gradient(135deg, #ff5e5e 0%, #ff3b3b 100%); padding: 20px 16px 30px; color: white; position: relative; overflow: hidden; }
.banner h2 { font-size: 22px; font-weight: 700; margin-bottom: 4px; position: relative; z-index: 2; }
.banner p { font-size: 12px; opacity: 0.9; margin-bottom: 15px; position: relative; z-index: 2; }

/* Ribbon */
.ribbon-wrap { display: flex; align-items: center; margin-bottom: 15px; position: relative; z-index: 2; }
.ribbon { background: white; color: #ff3b3b; padding: 6px 12px; font-size: 13px; font-weight: 600; border-radius: 4px 0 0 4px; display: flex; align-items: center; gap: 5px; }
.ribbon span { color: #ff3b3b; font-size: 16px; font-weight: 800; }
.ribbon-tail { width: 0; height: 0; border-top: 15px solid transparent; border-bottom: 15px solid transparent; border-left: 12px solid white; }

.accumulated { position: relative; z-index: 2; }
.accumulated span { display: block; font-size: 12px; opacity: 0.9; }
.accumulated h3 { font-size: 28px; font-weight: 800; margin-top: 2px; }

/* Banner Buttons */
.banner-btns { display: flex; justify-content: space-between; margin-top: 20px; position: relative; z-index: 2; }
.b-btn { background: linear-gradient(90deg, #ffca28, #ff9800); border: none; color: white; padding: 8px 20px; border-radius: 20px; font-size: 13px; font-weight: 600; box-shadow: 0 4px 10px rgba(255, 152, 0, 0.3); cursor: pointer; }

/* Banner Illustration (CSS representation of calendar) */
.banner-ill { position: absolute; right: -10px; bottom: -10px; width: 160px; height: 160px; z-index: 1; opacity: 0.9; }

/* Grid Section */
.grid-container { padding: 16px; display: grid; grid-template-columns: repeat(3, 1fr); gap: 12px; margin-top: -15px; position: relative; z-index: 10; }
.day-card { background: white; border-radius: 12px; padding: 15px 5px; display: flex; flex-direction: column; align-items: center; box-shadow: 0 4px 10px rgba(0,0,0,0.03); position: relative; }
.day-card.active { background: #f0f4ff; border: 1px solid #4781ff; }
.day-card.claimed { opacity: 0.6; }
.day-amt { font-size: 15px; font-weight: 700; color: #333; margin-bottom: 10px; }
.day-coin { width: 45px; height: 45px; margin-bottom: 10px; }
.day-lbl { font-size: 12px; color: #888; font-weight: 500; }

/* Day 7 Card */
.day7-card { grid-column: span 3; background: white; border-radius: 12px; padding: 15px 20px; display: flex; align-items: center; justify-content: space-between; box-shadow: 0 4px 10px rgba(0,0,0,0.03); }
.day7-card.active { background: #f0f4ff; border: 1px solid #4781ff; }
.day7-card.claimed { opacity: 0.6; }
.day7-img { width: 100px; height: auto; }
.day7-info { text-align: right; }
.day7-info h4 { font-size: 18px; font-weight: 800; color: #333; margin-bottom: 4px; }
.day7-info p { font-size: 13px; color: #888; font-weight: 500; }

/* Bottom Button */
.bottom-fixed { position: fixed; bottom: 0; width: 100%; max-width: 480px; background: white; padding: 15px 20px; box-shadow: 0 -4px 15px rgba(0,0,0,0.05); z-index: 50; }
.claim-btn { width: 100%; background: #4781ff; color: white; border: none; padding: 14px; border-radius: 30px; font-size: 16px; font-weight: 700; box-shadow: 0 4px 15px rgba(71,129,255,0.3); cursor: pointer; transition: 0.2s; }
.claim-btn:active { transform: scale(0.98); }
.claim-btn.disabled { background: #ccc; box-shadow: none; cursor: not-allowed; }

/* Floating CS Icon */
.float-cs { position: fixed; right: 15px; bottom: 100px; width: 50px; height: 50px; border-radius: 50%; background: white; display: flex; align-items: center; justify-content: center; box-shadow: 0 4px 15px rgba(0,0,0,0.15); z-index: 60; }
.float-cs img { width: 100%; height: 100%; object-fit: cover; border-radius: 50%; }

/* Rules Page Styles */
.rules-wrap { padding: 16px; }
.rules-table { width: 100%; border-collapse: collapse; background: white; border-radius: 12px; overflow: hidden; box-shadow: 0 4px 10px rgba(0,0,0,0.03); margin-bottom: 20px; text-align: center; }
.rules-table th { background: #4781ff; color: white; padding: 12px 5px; font-size: 12px; font-weight: 600; }
.rules-table td { padding: 12px 5px; font-size: 13px; color: #555; border-bottom: 1px solid #f0f0f0; }
.rules-list-box { background: white; border-radius: 12px; padding: 20px 16px; box-shadow: 0 4px 10px rgba(0,0,0,0.03); }
.rl-title { background: #4781ff; color: white; display: inline-block; padding: 6px 30px; border-radius: 20px; font-size: 14px; font-weight: 700; margin-top: -35px; margin-bottom: 15px; position: relative; left: 50%; transform: translateX(-50%); }
.rules-list { list-style: none; }
.rules-list li { font-size: 13px; color: #666; margin-bottom: 12px; padding-left: 15px; position: relative; line-height: 1.5; }
.rules-list li::before { content: '◆'; color: #4781ff; position: absolute; left: 0; top: 0; font-size: 14px; }

/* History Page Styles */
.history-wrap { padding: 16px; }
.empty-state { display: flex; flex-direction: column; align-items: center; justify-content: center; padding-top: 80px; opacity: 0.6; }
.empty-state img { width: 150px; margin-bottom: 15px; filter: grayscale(100%); opacity: 0.5; }
.empty-state p { font-size: 14px; color: #888; font-weight: 500; }
.hist-item { background: white; padding: 15px; border-radius: 12px; margin-bottom: 10px; display: flex; justify-content: space-between; align-items: center; box-shadow: 0 2px 8px rgba(0,0,0,0.03); }
.hist-l h4 { font-size: 15px; color: #333; margin-bottom: 4px; }
.hist-l p { font-size: 12px; color: #888; }
.hist-r { font-size: 16px; font-weight: 700; color: #4781ff; }

/* Toast */
.toast { position: fixed; left: 50%; top: 40%; transform: translate(-50%, -50%) scale(.8); background: rgba(0,0,0,0.8); color: #fff; padding: 12px 24px; border-radius: 8px; font-weight: 600; font-size: 14px; z-index: 1000; opacity: 0; pointer-events: none; transition: .2s; text-align: center; width: 80%; }
.toast.show { opacity: 1; transform: translate(-50%, -50%) scale(1); }
</style>
</head>
<body>
<div class="app-container">

    <!-- Top Header -->
    <div class="top-header">
        <button class="tb-back" onclick="goBack()"><span class="material-icons-round">chevron_left</span></button>
        <div class="tb-title" id="headerTitle">Attendance</div>
    </div>

    <!-- PAGE 1: MAIN ATTENDANCE -->
    <div id="page-main" class="page active">
        <div class="banner">
            <h2>Attendance bonus</h2>
            <p>Get rewards based on consecutive login days</p>
            
            <div class="ribbon-wrap">
                <div class="ribbon">Attended consecutively <span id="consecDays"><?= $current_day ?></span> Day</div>
                <div class="ribbon-tail"></div>
            </div>

            <div class="accumulated">
                <span>Accumulated</span>
                <h3 id="accAmt">₹<?= number_format($attData['accumulated'], 2) ?></h3>
            </div>

            <div class="banner-btns">
                <button class="b-btn" onclick="showPage('page-rules', 'Game Rules')">Game Rules</button>
                <button class="b-btn" onclick="showPage('page-history', 'Attendance history'); loadHistory();">Attendance history</button>
            </div>

            <!-- Decorative Image -->
            <img src="https://cdn-icons-png.flaticon.com/512/10691/10691802.png" class="banner-ill" alt="Calendar">
        </div>

        <div class="grid-container">
            <?php for($i=1; $i<=6; $i++): 
                $statusClass = '';
                if ($i < $current_day || ($i == $current_day && $is_claimed_today)) $statusClass = 'claimed';
                else if ($i == $current_day + 1 && !$is_claimed_today) $statusClass = 'active';
                else if ($i == $current_day && !$is_claimed_today) $statusClass = 'active';
            ?>
            <div class="day-card <?= $statusClass ?>" id="card-<?= $i ?>">
                <div class="day-amt">₹<?= number_format($rewards[$i], 2) ?></div>
                <img src="https://www.goaok.org/assets/png/coin-DS--QtUV.png" class="day-coin">
                <div class="day-lbl"><?= $i ?> Day</div>
            </div>
            <?php endfor; ?>

            <?php 
                $statusClass7 = '';
                if ($current_day == 7 && $is_claimed_today) $statusClass7 = 'claimed';
                else if ($current_day == 6 && !$is_claimed_today) $statusClass7 = 'active';
            ?>
            <div class="day7-card <?= $statusClass7 ?>" id="card-7">
                <img src="https://www.goaok.org/assets/png/day7Bg-qRdDEgwv.png" class="day7-img">
                <div class="day7-info">
                    <h4>₹7,000.00</h4>
                    <p>7 Day</p>
                </div>
            </div>
        </div>

        <div class="bottom-fixed">
            <?php if($is_claimed_today): ?>
                <button class="claim-btn disabled">Claimed</button>
            <?php else: ?>
                <button class="claim-btn" id="claimBtn" onclick="claimBonus()">Attendance</button>
            <?php endif; ?>
        </div>
    </div>

    <!-- PAGE 2: GAME RULES -->
    <div id="page-rules" class="page">
        <div class="rules-wrap">
            <table class="rules-table">
                <thead>
                    <tr>
                        <th>Continuous<br>attendance</th>
                        <th>Accumulated<br>amount</th>
                        <th>Attendance<br>bonus</th>
                    </tr>
                </thead>
                <tbody>
                    <tr><td>1</td><td>₹200.00</td><td>₹4.00</td></tr>
                    <tr><td>2</td><td>₹1,000.00</td><td>₹20.00</td></tr>
                    <tr><td>3</td><td>₹3,000.00</td><td>₹100.00</td></tr>
                    <tr><td>4</td><td>₹9,000.00</td><td>₹200.00</td></tr>
                    <tr><td>5</td><td>₹20,000.00</td><td>₹450.00</td></tr>
                    <tr><td>6</td><td>₹60,000.00</td><td>₹2,000.00</td></tr>
                    <tr><td>7</td><td>₹200,000.00</td><td>₹7,000.00</td></tr>
                </tbody>
            </table>

            <div class="rules-list-box">
                <div class="rl-title">Rules</div>
                <ul class="rules-list">
                    <li>The higher the number of consecutive login days, the more rewards you get, up to 7 consecutive days.</li>
                    <li>During the activity, please check in once a day.</li>
                    <li>Players with no deposit history cannot claim the bonus.</li>
                    <li>Deposit requirements must be met from day one.</li>
                    <li>The platform reserves the right to final interpretation of this activity.</li>
                    <li>When you encounter problems, please contact customer service.</li>
                </ul>
            </div>
        </div>
    </div>

    <!-- PAGE 3: HISTORY -->
    <div id="page-history" class="page">
        <div class="history-wrap" id="historyContent">
            <!-- Loaded via AJAX -->
            <div class="empty-state">
                <img src="https://cdn-icons-png.flaticon.com/512/7486/7486754.png" alt="No Data">
                <p>No data</p>
            </div>
        </div>
    </div>

    <!-- Floating CS Icon -->
    <a href="#" class="float-cs">
        <img src="https://i.ibb.co/chSVTqKv/icon-sevice-BIWTN-c-L-1.png" alt="CS">
    </a>

    <div class="toast" id="toast"></div>

</div>

<script>
let currentPage = 'page-main';

function showPage(pageId, title) {
    document.querySelectorAll('.page').forEach(p => p.classList.remove('active'));
    document.getElementById(pageId).classList.add('active');
    document.getElementById('headerTitle').textContent = title;
    currentPage = pageId;
    window.scrollTo(0,0);
}

function goBack() {
    if (currentPage !== 'page-main') {
        showPage('page-main', 'Attendance');
    } else {
        window.location.href = 'dashboard.php';
    }
}

function showToast(msg) {
    const t = document.getElementById('toast');
    t.textContent = msg;
    t.classList.add('show');
    clearTimeout(t._h);
    t._h = setTimeout(() => t.classList.remove('show'), 2500);
}

function claimBonus() {
    const btn = document.getElementById('claimBtn');
    btn.innerHTML = 'Processing...';
    btn.classList.add('disabled');
    btn.disabled = true;

    const fd = new URLSearchParams();
    fd.append('action', 'claim');

    fetch(window.location.href, { method: 'POST', body: fd })
    .then(res => res.json())
    .then(data => {
        if (data.success) {
            showToast(data.msg);
            document.getElementById('consecDays').textContent = data.new_day;
            document.getElementById('accAmt').textContent = '₹' + parseFloat(data.accumulated).toFixed(2);
            
            // Update UI Cards
            document.querySelectorAll('.day-card, .day7-card').forEach(c => {
                c.classList.remove('active');
            });
            for(let i=1; i<=data.new_day; i++) {
                let c = document.getElementById('card-'+i);
                if(c) c.classList.add('claimed');
            }

            btn.innerHTML = 'Claimed';
        } else {
            showToast(data.msg);
            btn.innerHTML = 'Attendance';
            btn.classList.remove('disabled');
            btn.disabled = false;
        }
    }).catch(err => {
        showToast('Network error. Try again.');
        btn.innerHTML = 'Attendance';
        btn.classList.remove('disabled');
        btn.disabled = false;
    });
}

function loadHistory() {
    const hc = document.getElementById('historyContent');
    hc.innerHTML = '<div style="text-align:center; padding: 40px; color:#888;">Loading...</div>';

    const fd = new URLSearchParams();
    fd.append('action', 'get_history');

    fetch(window.location.href, { method: 'POST', body: fd })
    .then(res => res.json())
    .then(data => {
        if (data.success && data.data.length > 0) {
            let html = '';
            data.data.forEach(item => {
                html += `
                <div class="hist-item">
                    <div class="hist-l">
                        <h4>Attendance Bonus</h4>
                        <p>${item.date}</p>
                    </div>
                    <div class="hist-r">+₹${parseFloat(item.amount).toFixed(2)}</div>
                </div>`;
            });
            hc.innerHTML = html;
        } else {
            hc.innerHTML = `
            <div class="empty-state">
                <img src="https://cdn-icons-png.flaticon.com/512/7486/7486754.png" alt="No Data">
                <p>No data</p>
            </div>`;
        }
    });
}
</script>
</body>
</html>